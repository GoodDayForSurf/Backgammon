/**
* DevExtreme (renovation/ui/pager/common/keyboard_action_context.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.KeyboardActionContext = void 0;
var _inferno = require("@devextreme/runtime/inferno");
const KeyboardActionContext = exports.KeyboardActionContext = (0, _inferno.createContext)(undefined);
