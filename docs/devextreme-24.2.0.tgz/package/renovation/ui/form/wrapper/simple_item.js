/**
* DevExtreme (renovation/ui/form/wrapper/simple_item.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.SimpleItem = void 0;
const SimpleItem = exports.SimpleItem = {};
