/**
* DevExtreme (renovation/ui/form/form_props.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.FormProps = void 0;
var _screen_utils = require("../responsive_box/screen_utils");
const FormProps = exports.FormProps = {
  scrollingEnabled: false,
  screenByWidth: _screen_utils.convertToScreenSizeQualifier
};
