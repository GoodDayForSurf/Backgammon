/**
* DevExtreme (renovation/ui/scroll_view/common/scrollbar_props.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.ScrollbarProps = void 0;
const ScrollbarProps = exports.ScrollbarProps = {
  direction: 'vertical',
  containerSize: 0,
  contentSize: 0,
  visible: false,
  containerHasSizes: false,
  scrollLocation: 0,
  minOffset: 0,
  maxOffset: 0
};
