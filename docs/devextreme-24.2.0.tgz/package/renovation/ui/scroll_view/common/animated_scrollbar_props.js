/**
* DevExtreme (renovation/ui/scroll_view/common/animated_scrollbar_props.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.AnimatedScrollbarProps = void 0;
var _scrollbar_props = require("./scrollbar_props");
const AnimatedScrollbarProps = exports.AnimatedScrollbarProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(_scrollbar_props.ScrollbarProps), Object.getOwnPropertyDescriptors({
  pulledDown: false,
  bottomPocketSize: 0,
  contentPaddingBottom: 0
})));
