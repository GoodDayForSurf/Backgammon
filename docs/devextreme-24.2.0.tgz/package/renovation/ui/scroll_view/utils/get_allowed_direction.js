/**
* DevExtreme (renovation/ui/scroll_view/utils/get_allowed_direction.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.allowedDirection = allowedDirection;
var _consts = require("../common/consts");
var _scroll_direction = require("./scroll_direction");
function allowedDirection(direction, scrollTopMax, scrollLeftMax, bounceEnabled) {
  const {
    isBoth,
    isHorizontal,
    isVertical
  } = new _scroll_direction.ScrollDirection(direction);
  const vDirectionAllowed = isVertical && (scrollTopMax > 0 || bounceEnabled);
  const hDirectionAllowed = isHorizontal && (scrollLeftMax > 0 || bounceEnabled);
  if (isBoth && vDirectionAllowed && hDirectionAllowed) {
    return _consts.DIRECTION_BOTH;
  }
  if (isHorizontal && hDirectionAllowed) {
    return _consts.DIRECTION_HORIZONTAL;
  }
  if (isVertical && vDirectionAllowed) {
    return _consts.DIRECTION_VERTICAL;
  }
  return undefined;
}
