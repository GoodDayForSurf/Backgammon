/**
* DevExtreme (renovation/ui/common/event_callback.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

exports.WorkaroundForVue = void 0;
class WorkaroundForVue {
  constructor() {
    this.dummy = '';
  }
}
exports.WorkaroundForVue = WorkaroundForVue;
