/**
* DevExtreme (ui/form/ui.form.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * @docid
 * @hidden
 */
export interface ColCountResponsible {
    /**
     * @docid
     * @default undefined
     * @public
     */
    lg?: number;
    /**
     * @docid
     * @default undefined
     * @public
     */
    md?: number;
    /**
     * @docid
     * @default undefined
     * @public
     */
    sm?: number;
    /**
     * @docid
     * @default undefined
     * @public
     */
    xs?: number;
}
