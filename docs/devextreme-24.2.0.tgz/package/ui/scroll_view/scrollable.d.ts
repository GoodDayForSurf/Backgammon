/**
* DevExtreme (ui/scroll_view/scrollable.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export { dxScrollableOptions as Options } from './ui.scrollable';
