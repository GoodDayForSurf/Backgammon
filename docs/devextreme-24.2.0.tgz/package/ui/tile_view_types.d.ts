/**
* DevExtreme (ui/tile_view_types.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  Orientation,
  ScrollbarMode,
  ContentReadyEvent,
  DisposingEvent,
  InitializedEvent,
  ItemClickEvent,
  ItemContextMenuEvent,
  ItemHoldEvent,
  ItemRenderedEvent,
  OptionChangedEvent,
  dxTileViewOptions,
  Item,
  Properties,
} from './tile_view';
