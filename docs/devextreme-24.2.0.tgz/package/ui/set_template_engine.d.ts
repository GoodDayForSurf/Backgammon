/**
* DevExtreme (ui/set_template_engine.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
//eslint-disable-next-line no-restricted-exports
export { default } from '../core/set_template_engine';
