/**
* DevExtreme (ui/widget/template.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
    template,
} from '../../core/templates/template';

/**
 * @docid ui.template
 * @namespace DevExpress.ui
 * @deprecated
 * @public
 */
export type Template = template;
