/**
* DevExtreme (data/endpoint_selector.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * @docid
 * @namespace DevExpress
 * @public
 */
export default class EndpointSelector {
    constructor(options: any);
    /**
     * @docid
     * @publicName urlFor(key)
     * @public
     */
    urlFor(key: string): string;
}
