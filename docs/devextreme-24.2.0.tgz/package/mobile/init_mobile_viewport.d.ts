/**
* DevExtreme (mobile/init_mobile_viewport.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * @docid utils.initMobileViewport
 * @publicName initMobileViewport(options)
 * @namespace DevExpress.utils
 * @public
 */
export default function initMobileViewport(options: { allowZoom?: boolean; allowPan?: boolean; allowSelection?: boolean }): void;
