/**
* DevExtreme (data_helper.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import DataSource from './data/data_source';

/**
 * @docid
 * @hidden
 */
export default class DataHelperMixin {
    /**
     * @docid
     * @publicName getDataSource()
     * @public
     */
    getDataSource(): DataSource;
}
