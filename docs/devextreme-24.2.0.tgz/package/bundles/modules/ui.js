/**
* DevExtreme (bundles/modules/ui.js)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

require("./core");
/* global DevExpress */
/* eslint-disable import/no-commonjs */

module.exports = DevExpress.ui = {};
