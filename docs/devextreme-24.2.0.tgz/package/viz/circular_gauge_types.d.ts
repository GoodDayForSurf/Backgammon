/**
* DevExtreme (viz/circular_gauge_types.d.ts)
* Version: 24.2.0
* Build date: Thu Aug 01 2024
*
* Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  CircularGaugeElementOrientation,
  CircularGaugeLabelOverlap,
  DisposingEvent,
  DrawnEvent,
  ExportedEvent,
  ExportingEvent,
  FileSavingEvent,
  IncidentOccurredEvent,
  InitializedEvent,
  OptionChangedEvent,
  TooltipHiddenEvent,
  TooltipShownEvent,
  RangeContainer,
  Scale,
  ScaleLabel,
  Properties,
} from './circular_gauge';
