import * as i0 from '@angular/core';
import { forwardRef, PLATFORM_ID, Component, Inject, Input, Output, HostListener, NgModule } from '@angular/core';
import DxSwitch from 'devextreme/ui/switch';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
const CUSTOM_VALUE_ACCESSOR_PROVIDER = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DxSwitchComponent),
    multi: true
};
/**
 * [descr:dxSwitch]

 */
class DxSwitchComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxSwitchOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxSwitchOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxSwitchOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    /**
     * [descr:dxSwitchOptions.name]
    
     */
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxSwitchOptions.switchedOffText]
    
     */
    get switchedOffText() {
        return this._getOption('switchedOffText');
    }
    set switchedOffText(value) {
        this._setOption('switchedOffText', value);
    }
    /**
     * [descr:dxSwitchOptions.switchedOnText]
    
     */
    get switchedOnText() {
        return this._getOption('switchedOnText');
    }
    set switchedOnText(value) {
        this._setOption('switchedOnText', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode() {
        return this._getOption('validationMessageMode');
    }
    set validationMessageMode(value) {
        this._setOption('validationMessageMode', value);
    }
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition() {
        return this._getOption('validationMessagePosition');
    }
    set validationMessagePosition(value) {
        this._setOption('validationMessagePosition', value);
    }
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    /**
     * [descr:dxSwitchOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxSwitchOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxSwitchOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxSwitchOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxSwitchOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxSwitchOptions.onValueChanged]
    
    
     */
    onValueChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    switchedOffTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    switchedOnTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur;
    change(_) { }
    touched = (_) => { };
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'valueChanged', emit: 'onValueChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'isDirtyChange' },
            { emit: 'isValidChange' },
            { emit: 'nameChange' },
            { emit: 'readOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'switchedOffTextChange' },
            { emit: 'switchedOnTextChange' },
            { emit: 'tabIndexChange' },
            { emit: 'validationErrorChange' },
            { emit: 'validationErrorsChange' },
            { emit: 'validationMessageModeChange' },
            { emit: 'validationMessagePositionChange' },
            { emit: 'validationStatusChange' },
            { emit: 'valueChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'onBlur' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxSwitch(element, options);
    }
    writeValue(value) {
        this.eventHelper.lockedValueChangeEvent = true;
        this.value = value;
        this.eventHelper.lockedValueChangeEvent = false;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    registerOnChange(fn) { this.change = fn; }
    registerOnTouched(fn) { this.touched = fn; }
    _createWidget(element) {
        super._createWidget(element);
        this.instance.on('focusOut', (e) => {
            this.eventHelper.fireNgEvent('onBlur', [e]);
        });
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('validationErrors', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('validationErrors');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSwitchComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxSwitchComponent, selector: "dx-switch", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", isDirty: "isDirty", isValid: "isValid", name: "name", readOnly: "readOnly", rtlEnabled: "rtlEnabled", switchedOffText: "switchedOffText", switchedOnText: "switchedOnText", tabIndex: "tabIndex", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", isDirtyChange: "isDirtyChange", isValidChange: "isValidChange", nameChange: "nameChange", readOnlyChange: "readOnlyChange", rtlEnabledChange: "rtlEnabledChange", switchedOffTextChange: "switchedOffTextChange", switchedOnTextChange: "switchedOnTextChange", tabIndexChange: "tabIndexChange", validationErrorChange: "validationErrorChange", validationErrorsChange: "validationErrorsChange", validationMessageModeChange: "validationMessageModeChange", validationMessagePositionChange: "validationMessagePositionChange", validationStatusChange: "validationStatusChange", valueChange: "valueChange", visibleChange: "visibleChange", widthChange: "widthChange", onBlur: "onBlur" }, host: { listeners: { "valueChange": "change($event)", "onBlur": "touched($event)" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            CUSTOM_VALUE_ACCESSOR_PROVIDER,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSwitchComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-switch',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        CUSTOM_VALUE_ACCESSOR_PROVIDER,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], name: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], switchedOffText: [{
                type: Input
            }], switchedOnText: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationMessageMode: [{
                type: Input
            }], validationMessagePosition: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onValueChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], isDirtyChange: [{
                type: Output
            }], isValidChange: [{
                type: Output
            }], nameChange: [{
                type: Output
            }], readOnlyChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], switchedOffTextChange: [{
                type: Output
            }], switchedOnTextChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], validationErrorChange: [{
                type: Output
            }], validationErrorsChange: [{
                type: Output
            }], validationMessageModeChange: [{
                type: Output
            }], validationMessagePositionChange: [{
                type: Output
            }], validationStatusChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], change: [{
                type: HostListener,
                args: ['valueChange', ['$event']]
            }], touched: [{
                type: HostListener,
                args: ['onBlur', ['$event']]
            }] } });
class DxSwitchModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSwitchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxSwitchModule, declarations: [DxSwitchComponent], imports: [DxIntegrationModule,
            DxTemplateModule], exports: [DxSwitchComponent, DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSwitchModule, imports: [DxIntegrationModule,
            DxTemplateModule, DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSwitchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxSwitchComponent
                    ],
                    exports: [
                        DxSwitchComponent,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxSwitchComponent, DxSwitchModule };
//# sourceMappingURL=devextreme-angular-ui-switch.mjs.map
