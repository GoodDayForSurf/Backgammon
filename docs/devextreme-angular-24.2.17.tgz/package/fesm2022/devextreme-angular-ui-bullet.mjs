import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, NgModule } from '@angular/core';
import DxBullet from 'devextreme/viz/bullet';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxoMarginModule, DxoSizeModule, DxoTooltipModule, DxoBorderModule, DxoFontModule, DxoFormatModule, DxoShadowModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxBullet]

 */
class DxBulletComponent extends DxComponent {
    instance = null;
    /**
     * [descr:dxBulletOptions.color]
    
     */
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxBulletOptions.endScaleValue]
    
     */
    get endScaleValue() {
        return this._getOption('endScaleValue');
    }
    set endScaleValue(value) {
        this._setOption('endScaleValue', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxBulletOptions.showTarget]
    
     */
    get showTarget() {
        return this._getOption('showTarget');
    }
    set showTarget(value) {
        this._setOption('showTarget', value);
    }
    /**
     * [descr:dxBulletOptions.showZeroLevel]
    
     */
    get showZeroLevel() {
        return this._getOption('showZeroLevel');
    }
    set showZeroLevel(value) {
        this._setOption('showZeroLevel', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxBulletOptions.startScaleValue]
    
     */
    get startScaleValue() {
        return this._getOption('startScaleValue');
    }
    set startScaleValue(value) {
        this._setOption('startScaleValue', value);
    }
    /**
     * [descr:dxBulletOptions.target]
    
     */
    get target() {
        return this._getOption('target');
    }
    set target(value) {
        this._setOption('target', value);
    }
    /**
     * [descr:dxBulletOptions.targetColor]
    
     */
    get targetColor() {
        return this._getOption('targetColor');
    }
    set targetColor(value) {
        this._setOption('targetColor', value);
    }
    /**
     * [descr:dxBulletOptions.targetWidth]
    
     */
    get targetWidth() {
        return this._getOption('targetWidth');
    }
    set targetWidth(value) {
        this._setOption('targetWidth', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseSparklineOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxBulletOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
    
     * [descr:dxBulletOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxBulletOptions.onDrawn]
    
    
     */
    onDrawn;
    /**
    
     * [descr:dxBulletOptions.onExported]
    
    
     */
    onExported;
    /**
    
     * [descr:dxBulletOptions.onExporting]
    
    
     */
    onExporting;
    /**
    
     * [descr:dxBulletOptions.onFileSaving]
    
    
     */
    onFileSaving;
    /**
    
     * [descr:dxBulletOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred;
    /**
    
     * [descr:dxBulletOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxBulletOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxBulletOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden;
    /**
    
     * [descr:dxBulletOptions.onTooltipShown]
    
    
     */
    onTooltipShown;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endScaleValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTargetChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showZeroLevelChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startScaleValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetColorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { emit: 'colorChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'endScaleValueChange' },
            { emit: 'marginChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showTargetChange' },
            { emit: 'showZeroLevelChange' },
            { emit: 'sizeChange' },
            { emit: 'startScaleValueChange' },
            { emit: 'targetChange' },
            { emit: 'targetColorChange' },
            { emit: 'targetWidthChange' },
            { emit: 'themeChange' },
            { emit: 'tooltipChange' },
            { emit: 'valueChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxBullet(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBulletComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxBulletComponent, selector: "dx-bullet", inputs: { color: "color", disabled: "disabled", elementAttr: "elementAttr", endScaleValue: "endScaleValue", margin: "margin", pathModified: "pathModified", rtlEnabled: "rtlEnabled", showTarget: "showTarget", showZeroLevel: "showZeroLevel", size: "size", startScaleValue: "startScaleValue", target: "target", targetColor: "targetColor", targetWidth: "targetWidth", theme: "theme", tooltip: "tooltip", value: "value" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", colorChange: "colorChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", endScaleValueChange: "endScaleValueChange", marginChange: "marginChange", pathModifiedChange: "pathModifiedChange", rtlEnabledChange: "rtlEnabledChange", showTargetChange: "showTargetChange", showZeroLevelChange: "showZeroLevelChange", sizeChange: "sizeChange", startScaleValueChange: "startScaleValueChange", targetChange: "targetChange", targetColorChange: "targetColorChange", targetWidthChange: "targetWidthChange", themeChange: "themeChange", tooltipChange: "tooltipChange", valueChange: "valueChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBulletComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-bullet', template: '', providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { color: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], endScaleValue: [{
                type: Input
            }], margin: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showTarget: [{
                type: Input
            }], showZeroLevel: [{
                type: Input
            }], size: [{
                type: Input
            }], startScaleValue: [{
                type: Input
            }], target: [{
                type: Input
            }], targetColor: [{
                type: Input
            }], targetWidth: [{
                type: Input
            }], theme: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], value: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], colorChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], endScaleValueChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], showTargetChange: [{
                type: Output
            }], showZeroLevelChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], startScaleValueChange: [{
                type: Output
            }], targetChange: [{
                type: Output
            }], targetColorChange: [{
                type: Output
            }], targetWidthChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }] } });
class DxBulletModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBulletModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxBulletModule, declarations: [DxBulletComponent], imports: [DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxBulletComponent, DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBulletModule, imports: [DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxIntegrationModule,
            DxTemplateModule, DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBulletModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoMarginModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoShadowModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxBulletComponent
                    ],
                    exports: [
                        DxBulletComponent,
                        DxoMarginModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoShadowModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxBulletComponent, DxBulletModule };
//# sourceMappingURL=devextreme-angular-ui-bullet.mjs.map
