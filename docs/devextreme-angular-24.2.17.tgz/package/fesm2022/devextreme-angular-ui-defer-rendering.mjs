import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, NgModule } from '@angular/core';
import DxDeferRendering from 'devextreme/ui/defer_rendering';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAnimationModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxDeferRendering]

 */
class DxDeferRenderingComponent extends DxComponent {
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxDeferRenderingOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxDeferRenderingOptions.renderWhen]
    
     */
    get renderWhen() {
        return this._getOption('renderWhen');
    }
    set renderWhen(value) {
        this._setOption('renderWhen', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDeferRenderingOptions.showLoadIndicator]
    
     */
    get showLoadIndicator() {
        return this._getOption('showLoadIndicator');
    }
    set showLoadIndicator(value) {
        this._setOption('showLoadIndicator', value);
    }
    /**
     * [descr:dxDeferRenderingOptions.staggerItemSelector]
    
     */
    get staggerItemSelector() {
        return this._getOption('staggerItemSelector');
    }
    set staggerItemSelector(value) {
        this._setOption('staggerItemSelector', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxDeferRenderingOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxDeferRenderingOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxDeferRenderingOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxDeferRenderingOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxDeferRenderingOptions.onRendered]
    
    
     */
    onRendered;
    /**
    
     * [descr:dxDeferRenderingOptions.onShown]
    
    
     */
    onShown;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    renderWhenChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showLoadIndicatorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    staggerItemSelectorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'rendered', emit: 'onRendered' },
            { subscribe: 'shown', emit: 'onShown' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'animationChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'renderWhenChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showLoadIndicatorChange' },
            { emit: 'staggerItemSelectorChange' },
            { emit: 'tabIndexChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxDeferRendering(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDeferRenderingComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxDeferRenderingComponent, selector: "dx-defer-rendering", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animation: "animation", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", renderWhen: "renderWhen", rtlEnabled: "rtlEnabled", showLoadIndicator: "showLoadIndicator", staggerItemSelector: "staggerItemSelector", tabIndex: "tabIndex", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onRendered: "onRendered", onShown: "onShown", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", animationChange: "animationChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", renderWhenChange: "renderWhenChange", rtlEnabledChange: "rtlEnabledChange", showLoadIndicatorChange: "showLoadIndicatorChange", staggerItemSelectorChange: "staggerItemSelectorChange", tabIndexChange: "tabIndexChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDeferRenderingComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-defer-rendering',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animation: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], renderWhen: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showLoadIndicator: [{
                type: Input
            }], staggerItemSelector: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onRendered: [{
                type: Output
            }], onShown: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], renderWhenChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], showLoadIndicatorChange: [{
                type: Output
            }], staggerItemSelectorChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxDeferRenderingModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDeferRenderingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxDeferRenderingModule, declarations: [DxDeferRenderingComponent], imports: [DxoAnimationModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxDeferRenderingComponent, DxoAnimationModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDeferRenderingModule, imports: [DxoAnimationModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDeferRenderingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoAnimationModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxDeferRenderingComponent
                    ],
                    exports: [
                        DxDeferRenderingComponent,
                        DxoAnimationModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxDeferRenderingComponent, DxDeferRenderingModule };
//# sourceMappingURL=devextreme-angular-ui-defer-rendering.mjs.map
