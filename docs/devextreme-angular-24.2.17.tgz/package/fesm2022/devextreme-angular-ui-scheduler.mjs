import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, ContentChildren, NgModule } from '@angular/core';
import DxScheduler from 'devextreme/ui/scheduler';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxiResourceComponent, DxiViewComponent, DxoAppointmentDraggingModule, DxoEditingModule, DxiResourceModule, DxoScrollingModule, DxiViewModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxScheduler]

 */
class DxSchedulerComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxSchedulerOptions.adaptivityEnabled]
    
     */
    get adaptivityEnabled() {
        return this._getOption('adaptivityEnabled');
    }
    set adaptivityEnabled(value) {
        this._setOption('adaptivityEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.allDayExpr]
    
     */
    get allDayExpr() {
        return this._getOption('allDayExpr');
    }
    set allDayExpr(value) {
        this._setOption('allDayExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.allDayPanelMode]
    
     */
    get allDayPanelMode() {
        return this._getOption('allDayPanelMode');
    }
    set allDayPanelMode(value) {
        this._setOption('allDayPanelMode', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentCollectorTemplate]
    
     */
    get appointmentCollectorTemplate() {
        return this._getOption('appointmentCollectorTemplate');
    }
    set appointmentCollectorTemplate(value) {
        this._setOption('appointmentCollectorTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentDragging]
    
     */
    get appointmentDragging() {
        return this._getOption('appointmentDragging');
    }
    set appointmentDragging(value) {
        this._setOption('appointmentDragging', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentTemplate]
    
     */
    get appointmentTemplate() {
        return this._getOption('appointmentTemplate');
    }
    set appointmentTemplate(value) {
        this._setOption('appointmentTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentTooltipTemplate]
    
     */
    get appointmentTooltipTemplate() {
        return this._getOption('appointmentTooltipTemplate');
    }
    set appointmentTooltipTemplate(value) {
        this._setOption('appointmentTooltipTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.cellDuration]
    
     */
    get cellDuration() {
        return this._getOption('cellDuration');
    }
    set cellDuration(value) {
        this._setOption('cellDuration', value);
    }
    /**
     * [descr:dxSchedulerOptions.crossScrollingEnabled]
    
     */
    get crossScrollingEnabled() {
        return this._getOption('crossScrollingEnabled');
    }
    set crossScrollingEnabled(value) {
        this._setOption('crossScrollingEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.currentDate]
    
     */
    get currentDate() {
        return this._getOption('currentDate');
    }
    set currentDate(value) {
        this._setOption('currentDate', value);
    }
    /**
     * [descr:dxSchedulerOptions.currentView]
    
     */
    get currentView() {
        return this._getOption('currentView');
    }
    set currentView(value) {
        this._setOption('currentView', value);
    }
    /**
     * [descr:dxSchedulerOptions.customizeDateNavigatorText]
    
     */
    get customizeDateNavigatorText() {
        return this._getOption('customizeDateNavigatorText');
    }
    set customizeDateNavigatorText(value) {
        this._setOption('customizeDateNavigatorText', value);
    }
    /**
     * [descr:dxSchedulerOptions.dataCellTemplate]
    
     */
    get dataCellTemplate() {
        return this._getOption('dataCellTemplate');
    }
    set dataCellTemplate(value) {
        this._setOption('dataCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxSchedulerOptions.dateCellTemplate]
    
     */
    get dateCellTemplate() {
        return this._getOption('dateCellTemplate');
    }
    set dateCellTemplate(value) {
        this._setOption('dateCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat() {
        return this._getOption('dateSerializationFormat');
    }
    set dateSerializationFormat(value) {
        this._setOption('dateSerializationFormat', value);
    }
    /**
     * [descr:dxSchedulerOptions.descriptionExpr]
    
     */
    get descriptionExpr() {
        return this._getOption('descriptionExpr');
    }
    set descriptionExpr(value) {
        this._setOption('descriptionExpr', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.dropDownAppointmentTemplate]
    
     * @deprecated [depNote:dxSchedulerOptions.dropDownAppointmentTemplate]
    
     */
    get dropDownAppointmentTemplate() {
        return this._getOption('dropDownAppointmentTemplate');
    }
    set dropDownAppointmentTemplate(value) {
        this._setOption('dropDownAppointmentTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxSchedulerOptions.endDateExpr]
    
     */
    get endDateExpr() {
        return this._getOption('endDateExpr');
    }
    set endDateExpr(value) {
        this._setOption('endDateExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.endDateTimeZoneExpr]
    
     */
    get endDateTimeZoneExpr() {
        return this._getOption('endDateTimeZoneExpr');
    }
    set endDateTimeZoneExpr(value) {
        this._setOption('endDateTimeZoneExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.endDayHour]
    
     */
    get endDayHour() {
        return this._getOption('endDayHour');
    }
    set endDayHour(value) {
        this._setOption('endDayHour', value);
    }
    /**
     * [descr:dxSchedulerOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    /**
     * [descr:dxSchedulerOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.groupByDate]
    
     */
    get groupByDate() {
        return this._getOption('groupByDate');
    }
    set groupByDate(value) {
        this._setOption('groupByDate', value);
    }
    /**
     * [descr:dxSchedulerOptions.groups]
    
     */
    get groups() {
        return this._getOption('groups');
    }
    set groups(value) {
        this._setOption('groups', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxSchedulerOptions.indicatorUpdateInterval]
    
     */
    get indicatorUpdateInterval() {
        return this._getOption('indicatorUpdateInterval');
    }
    set indicatorUpdateInterval(value) {
        this._setOption('indicatorUpdateInterval', value);
    }
    /**
     * [descr:dxSchedulerOptions.max]
    
     */
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    /**
     * [descr:dxSchedulerOptions.maxAppointmentsPerCell]
    
     */
    get maxAppointmentsPerCell() {
        return this._getOption('maxAppointmentsPerCell');
    }
    set maxAppointmentsPerCell(value) {
        this._setOption('maxAppointmentsPerCell', value);
    }
    /**
     * [descr:dxSchedulerOptions.min]
    
     */
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    /**
     * [descr:dxSchedulerOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxSchedulerOptions.offset]
    
     */
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    /**
     * [descr:dxSchedulerOptions.recurrenceEditMode]
    
     */
    get recurrenceEditMode() {
        return this._getOption('recurrenceEditMode');
    }
    set recurrenceEditMode(value) {
        this._setOption('recurrenceEditMode', value);
    }
    /**
     * [descr:dxSchedulerOptions.recurrenceExceptionExpr]
    
     */
    get recurrenceExceptionExpr() {
        return this._getOption('recurrenceExceptionExpr');
    }
    set recurrenceExceptionExpr(value) {
        this._setOption('recurrenceExceptionExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.recurrenceRuleExpr]
    
     */
    get recurrenceRuleExpr() {
        return this._getOption('recurrenceRuleExpr');
    }
    set recurrenceRuleExpr(value) {
        this._setOption('recurrenceRuleExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.remoteFiltering]
    
     */
    get remoteFiltering() {
        return this._getOption('remoteFiltering');
    }
    set remoteFiltering(value) {
        this._setOption('remoteFiltering', value);
    }
    /**
     * [descr:dxSchedulerOptions.resourceCellTemplate]
    
     */
    get resourceCellTemplate() {
        return this._getOption('resourceCellTemplate');
    }
    set resourceCellTemplate(value) {
        this._setOption('resourceCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.resources]
    
     */
    get resources() {
        return this._getOption('resources');
    }
    set resources(value) {
        this._setOption('resources', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.scrolling]
    
     */
    get scrolling() {
        return this._getOption('scrolling');
    }
    set scrolling(value) {
        this._setOption('scrolling', value);
    }
    /**
     * [descr:dxSchedulerOptions.selectedCellData]
    
     */
    get selectedCellData() {
        return this._getOption('selectedCellData');
    }
    set selectedCellData(value) {
        this._setOption('selectedCellData', value);
    }
    /**
     * [descr:dxSchedulerOptions.shadeUntilCurrentTime]
    
     */
    get shadeUntilCurrentTime() {
        return this._getOption('shadeUntilCurrentTime');
    }
    set shadeUntilCurrentTime(value) {
        this._setOption('shadeUntilCurrentTime', value);
    }
    /**
     * [descr:dxSchedulerOptions.showAllDayPanel]
    
     */
    get showAllDayPanel() {
        return this._getOption('showAllDayPanel');
    }
    set showAllDayPanel(value) {
        this._setOption('showAllDayPanel', value);
    }
    /**
     * [descr:dxSchedulerOptions.showCurrentTimeIndicator]
    
     */
    get showCurrentTimeIndicator() {
        return this._getOption('showCurrentTimeIndicator');
    }
    set showCurrentTimeIndicator(value) {
        this._setOption('showCurrentTimeIndicator', value);
    }
    /**
     * [descr:dxSchedulerOptions.startDateExpr]
    
     */
    get startDateExpr() {
        return this._getOption('startDateExpr');
    }
    set startDateExpr(value) {
        this._setOption('startDateExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.startDateTimeZoneExpr]
    
     */
    get startDateTimeZoneExpr() {
        return this._getOption('startDateTimeZoneExpr');
    }
    set startDateTimeZoneExpr(value) {
        this._setOption('startDateTimeZoneExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.startDayHour]
    
     */
    get startDayHour() {
        return this._getOption('startDayHour');
    }
    set startDayHour(value) {
        this._setOption('startDayHour', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxSchedulerOptions.textExpr]
    
     */
    get textExpr() {
        return this._getOption('textExpr');
    }
    set textExpr(value) {
        this._setOption('textExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.timeCellTemplate]
    
     */
    get timeCellTemplate() {
        return this._getOption('timeCellTemplate');
    }
    set timeCellTemplate(value) {
        this._setOption('timeCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.timeZone]
    
     */
    get timeZone() {
        return this._getOption('timeZone');
    }
    set timeZone(value) {
        this._setOption('timeZone', value);
    }
    /**
     * [descr:dxSchedulerOptions.useDropDownViewSwitcher]
    
     */
    get useDropDownViewSwitcher() {
        return this._getOption('useDropDownViewSwitcher');
    }
    set useDropDownViewSwitcher(value) {
        this._setOption('useDropDownViewSwitcher', value);
    }
    /**
     * [descr:dxSchedulerOptions.views]
    
     */
    get views() {
        return this._getOption('views');
    }
    set views(value) {
        this._setOption('views', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentAdded]
    
    
     */
    onAppointmentAdded;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentAdding]
    
    
     */
    onAppointmentAdding;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentClick]
    
    
     */
    onAppointmentClick;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentContextMenu]
    
    
     */
    onAppointmentContextMenu;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentDblClick]
    
    
     */
    onAppointmentDblClick;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentDeleted]
    
    
     */
    onAppointmentDeleted;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentDeleting]
    
    
     */
    onAppointmentDeleting;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentFormOpening]
    
    
     */
    onAppointmentFormOpening;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentRendered]
    
    
     */
    onAppointmentRendered;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentTooltipShowing]
    
    
     */
    onAppointmentTooltipShowing;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentUpdated]
    
    
     */
    onAppointmentUpdated;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentUpdating]
    
    
     */
    onAppointmentUpdating;
    /**
    
     * [descr:dxSchedulerOptions.onCellClick]
    
    
     */
    onCellClick;
    /**
    
     * [descr:dxSchedulerOptions.onCellContextMenu]
    
    
     */
    onCellContextMenu;
    /**
    
     * [descr:dxSchedulerOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxSchedulerOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxSchedulerOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxSchedulerOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptivityEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allDayExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allDayPanelModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentCollectorTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentDraggingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentTooltipTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cellDurationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    crossScrollingEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    currentDateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    currentViewChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeDateNavigatorTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataCellTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateCellTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateSerializationFormatChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    descriptionExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownAppointmentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateTimeZoneExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDayHourChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstDayOfWeekChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupByDateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorUpdateIntervalChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxAppointmentsPerCellChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    offsetChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    recurrenceEditModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    recurrenceExceptionExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    recurrenceRuleExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    remoteFilteringChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourceCellTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourcesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedCellDataChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadeUntilCurrentTimeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showAllDayPanelChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCurrentTimeIndicatorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateTimeZoneExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDayHourChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    timeCellTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    timeZoneChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useDropDownViewSwitcherChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    viewsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    get resourcesChildren() {
        return this._getOption('resources');
    }
    set resourcesChildren(value) {
        this.setChildren('resources', value);
    }
    get viewsChildren() {
        return this._getOption('views');
    }
    set viewsChildren(value) {
        this.setChildren('views', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'appointmentAdded', emit: 'onAppointmentAdded' },
            { subscribe: 'appointmentAdding', emit: 'onAppointmentAdding' },
            { subscribe: 'appointmentClick', emit: 'onAppointmentClick' },
            { subscribe: 'appointmentContextMenu', emit: 'onAppointmentContextMenu' },
            { subscribe: 'appointmentDblClick', emit: 'onAppointmentDblClick' },
            { subscribe: 'appointmentDeleted', emit: 'onAppointmentDeleted' },
            { subscribe: 'appointmentDeleting', emit: 'onAppointmentDeleting' },
            { subscribe: 'appointmentFormOpening', emit: 'onAppointmentFormOpening' },
            { subscribe: 'appointmentRendered', emit: 'onAppointmentRendered' },
            { subscribe: 'appointmentTooltipShowing', emit: 'onAppointmentTooltipShowing' },
            { subscribe: 'appointmentUpdated', emit: 'onAppointmentUpdated' },
            { subscribe: 'appointmentUpdating', emit: 'onAppointmentUpdating' },
            { subscribe: 'cellClick', emit: 'onCellClick' },
            { subscribe: 'cellContextMenu', emit: 'onCellContextMenu' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'adaptivityEnabledChange' },
            { emit: 'allDayExprChange' },
            { emit: 'allDayPanelModeChange' },
            { emit: 'appointmentCollectorTemplateChange' },
            { emit: 'appointmentDraggingChange' },
            { emit: 'appointmentTemplateChange' },
            { emit: 'appointmentTooltipTemplateChange' },
            { emit: 'cellDurationChange' },
            { emit: 'crossScrollingEnabledChange' },
            { emit: 'currentDateChange' },
            { emit: 'currentViewChange' },
            { emit: 'customizeDateNavigatorTextChange' },
            { emit: 'dataCellTemplateChange' },
            { emit: 'dataSourceChange' },
            { emit: 'dateCellTemplateChange' },
            { emit: 'dateSerializationFormatChange' },
            { emit: 'descriptionExprChange' },
            { emit: 'disabledChange' },
            { emit: 'dropDownAppointmentTemplateChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'endDateExprChange' },
            { emit: 'endDateTimeZoneExprChange' },
            { emit: 'endDayHourChange' },
            { emit: 'firstDayOfWeekChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'groupByDateChange' },
            { emit: 'groupsChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'indicatorUpdateIntervalChange' },
            { emit: 'maxChange' },
            { emit: 'maxAppointmentsPerCellChange' },
            { emit: 'minChange' },
            { emit: 'noDataTextChange' },
            { emit: 'offsetChange' },
            { emit: 'recurrenceEditModeChange' },
            { emit: 'recurrenceExceptionExprChange' },
            { emit: 'recurrenceRuleExprChange' },
            { emit: 'remoteFilteringChange' },
            { emit: 'resourceCellTemplateChange' },
            { emit: 'resourcesChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollingChange' },
            { emit: 'selectedCellDataChange' },
            { emit: 'shadeUntilCurrentTimeChange' },
            { emit: 'showAllDayPanelChange' },
            { emit: 'showCurrentTimeIndicatorChange' },
            { emit: 'startDateExprChange' },
            { emit: 'startDateTimeZoneExprChange' },
            { emit: 'startDayHourChange' },
            { emit: 'tabIndexChange' },
            { emit: 'textExprChange' },
            { emit: 'timeCellTemplateChange' },
            { emit: 'timeZoneChange' },
            { emit: 'useDropDownViewSwitcherChange' },
            { emit: 'viewsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxScheduler(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('groups', changes);
        this.setupChanges('resources', changes);
        this.setupChanges('selectedCellData', changes);
        this.setupChanges('views', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('groups');
        this._idh.doCheck('resources');
        this._idh.doCheck('selectedCellData');
        this._idh.doCheck('views');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSchedulerComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxSchedulerComponent, selector: "dx-scheduler", inputs: { accessKey: "accessKey", adaptivityEnabled: "adaptivityEnabled", allDayExpr: "allDayExpr", allDayPanelMode: "allDayPanelMode", appointmentCollectorTemplate: "appointmentCollectorTemplate", appointmentDragging: "appointmentDragging", appointmentTemplate: "appointmentTemplate", appointmentTooltipTemplate: "appointmentTooltipTemplate", cellDuration: "cellDuration", crossScrollingEnabled: "crossScrollingEnabled", currentDate: "currentDate", currentView: "currentView", customizeDateNavigatorText: "customizeDateNavigatorText", dataCellTemplate: "dataCellTemplate", dataSource: "dataSource", dateCellTemplate: "dateCellTemplate", dateSerializationFormat: "dateSerializationFormat", descriptionExpr: "descriptionExpr", disabled: "disabled", dropDownAppointmentTemplate: "dropDownAppointmentTemplate", editing: "editing", elementAttr: "elementAttr", endDateExpr: "endDateExpr", endDateTimeZoneExpr: "endDateTimeZoneExpr", endDayHour: "endDayHour", firstDayOfWeek: "firstDayOfWeek", focusStateEnabled: "focusStateEnabled", groupByDate: "groupByDate", groups: "groups", height: "height", hint: "hint", indicatorUpdateInterval: "indicatorUpdateInterval", max: "max", maxAppointmentsPerCell: "maxAppointmentsPerCell", min: "min", noDataText: "noDataText", offset: "offset", recurrenceEditMode: "recurrenceEditMode", recurrenceExceptionExpr: "recurrenceExceptionExpr", recurrenceRuleExpr: "recurrenceRuleExpr", remoteFiltering: "remoteFiltering", resourceCellTemplate: "resourceCellTemplate", resources: "resources", rtlEnabled: "rtlEnabled", scrolling: "scrolling", selectedCellData: "selectedCellData", shadeUntilCurrentTime: "shadeUntilCurrentTime", showAllDayPanel: "showAllDayPanel", showCurrentTimeIndicator: "showCurrentTimeIndicator", startDateExpr: "startDateExpr", startDateTimeZoneExpr: "startDateTimeZoneExpr", startDayHour: "startDayHour", tabIndex: "tabIndex", textExpr: "textExpr", timeCellTemplate: "timeCellTemplate", timeZone: "timeZone", useDropDownViewSwitcher: "useDropDownViewSwitcher", views: "views", visible: "visible", width: "width" }, outputs: { onAppointmentAdded: "onAppointmentAdded", onAppointmentAdding: "onAppointmentAdding", onAppointmentClick: "onAppointmentClick", onAppointmentContextMenu: "onAppointmentContextMenu", onAppointmentDblClick: "onAppointmentDblClick", onAppointmentDeleted: "onAppointmentDeleted", onAppointmentDeleting: "onAppointmentDeleting", onAppointmentFormOpening: "onAppointmentFormOpening", onAppointmentRendered: "onAppointmentRendered", onAppointmentTooltipShowing: "onAppointmentTooltipShowing", onAppointmentUpdated: "onAppointmentUpdated", onAppointmentUpdating: "onAppointmentUpdating", onCellClick: "onCellClick", onCellContextMenu: "onCellContextMenu", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", accessKeyChange: "accessKeyChange", adaptivityEnabledChange: "adaptivityEnabledChange", allDayExprChange: "allDayExprChange", allDayPanelModeChange: "allDayPanelModeChange", appointmentCollectorTemplateChange: "appointmentCollectorTemplateChange", appointmentDraggingChange: "appointmentDraggingChange", appointmentTemplateChange: "appointmentTemplateChange", appointmentTooltipTemplateChange: "appointmentTooltipTemplateChange", cellDurationChange: "cellDurationChange", crossScrollingEnabledChange: "crossScrollingEnabledChange", currentDateChange: "currentDateChange", currentViewChange: "currentViewChange", customizeDateNavigatorTextChange: "customizeDateNavigatorTextChange", dataCellTemplateChange: "dataCellTemplateChange", dataSourceChange: "dataSourceChange", dateCellTemplateChange: "dateCellTemplateChange", dateSerializationFormatChange: "dateSerializationFormatChange", descriptionExprChange: "descriptionExprChange", disabledChange: "disabledChange", dropDownAppointmentTemplateChange: "dropDownAppointmentTemplateChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", endDateExprChange: "endDateExprChange", endDateTimeZoneExprChange: "endDateTimeZoneExprChange", endDayHourChange: "endDayHourChange", firstDayOfWeekChange: "firstDayOfWeekChange", focusStateEnabledChange: "focusStateEnabledChange", groupByDateChange: "groupByDateChange", groupsChange: "groupsChange", heightChange: "heightChange", hintChange: "hintChange", indicatorUpdateIntervalChange: "indicatorUpdateIntervalChange", maxChange: "maxChange", maxAppointmentsPerCellChange: "maxAppointmentsPerCellChange", minChange: "minChange", noDataTextChange: "noDataTextChange", offsetChange: "offsetChange", recurrenceEditModeChange: "recurrenceEditModeChange", recurrenceExceptionExprChange: "recurrenceExceptionExprChange", recurrenceRuleExprChange: "recurrenceRuleExprChange", remoteFilteringChange: "remoteFilteringChange", resourceCellTemplateChange: "resourceCellTemplateChange", resourcesChange: "resourcesChange", rtlEnabledChange: "rtlEnabledChange", scrollingChange: "scrollingChange", selectedCellDataChange: "selectedCellDataChange", shadeUntilCurrentTimeChange: "shadeUntilCurrentTimeChange", showAllDayPanelChange: "showAllDayPanelChange", showCurrentTimeIndicatorChange: "showCurrentTimeIndicatorChange", startDateExprChange: "startDateExprChange", startDateTimeZoneExprChange: "startDateTimeZoneExprChange", startDayHourChange: "startDayHourChange", tabIndexChange: "tabIndexChange", textExprChange: "textExprChange", timeCellTemplateChange: "timeCellTemplateChange", timeZoneChange: "timeZoneChange", useDropDownViewSwitcherChange: "useDropDownViewSwitcherChange", viewsChange: "viewsChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "resourcesChildren", predicate: DxiResourceComponent }, { propertyName: "viewsChildren", predicate: DxiViewComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSchedulerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-scheduler',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], adaptivityEnabled: [{
                type: Input
            }], allDayExpr: [{
                type: Input
            }], allDayPanelMode: [{
                type: Input
            }], appointmentCollectorTemplate: [{
                type: Input
            }], appointmentDragging: [{
                type: Input
            }], appointmentTemplate: [{
                type: Input
            }], appointmentTooltipTemplate: [{
                type: Input
            }], cellDuration: [{
                type: Input
            }], crossScrollingEnabled: [{
                type: Input
            }], currentDate: [{
                type: Input
            }], currentView: [{
                type: Input
            }], customizeDateNavigatorText: [{
                type: Input
            }], dataCellTemplate: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], dateCellTemplate: [{
                type: Input
            }], dateSerializationFormat: [{
                type: Input
            }], descriptionExpr: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dropDownAppointmentTemplate: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], endDateExpr: [{
                type: Input
            }], endDateTimeZoneExpr: [{
                type: Input
            }], endDayHour: [{
                type: Input
            }], firstDayOfWeek: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], groupByDate: [{
                type: Input
            }], groups: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], indicatorUpdateInterval: [{
                type: Input
            }], max: [{
                type: Input
            }], maxAppointmentsPerCell: [{
                type: Input
            }], min: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], offset: [{
                type: Input
            }], recurrenceEditMode: [{
                type: Input
            }], recurrenceExceptionExpr: [{
                type: Input
            }], recurrenceRuleExpr: [{
                type: Input
            }], remoteFiltering: [{
                type: Input
            }], resourceCellTemplate: [{
                type: Input
            }], resources: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrolling: [{
                type: Input
            }], selectedCellData: [{
                type: Input
            }], shadeUntilCurrentTime: [{
                type: Input
            }], showAllDayPanel: [{
                type: Input
            }], showCurrentTimeIndicator: [{
                type: Input
            }], startDateExpr: [{
                type: Input
            }], startDateTimeZoneExpr: [{
                type: Input
            }], startDayHour: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], textExpr: [{
                type: Input
            }], timeCellTemplate: [{
                type: Input
            }], timeZone: [{
                type: Input
            }], useDropDownViewSwitcher: [{
                type: Input
            }], views: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onAppointmentAdded: [{
                type: Output
            }], onAppointmentAdding: [{
                type: Output
            }], onAppointmentClick: [{
                type: Output
            }], onAppointmentContextMenu: [{
                type: Output
            }], onAppointmentDblClick: [{
                type: Output
            }], onAppointmentDeleted: [{
                type: Output
            }], onAppointmentDeleting: [{
                type: Output
            }], onAppointmentFormOpening: [{
                type: Output
            }], onAppointmentRendered: [{
                type: Output
            }], onAppointmentTooltipShowing: [{
                type: Output
            }], onAppointmentUpdated: [{
                type: Output
            }], onAppointmentUpdating: [{
                type: Output
            }], onCellClick: [{
                type: Output
            }], onCellContextMenu: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], adaptivityEnabledChange: [{
                type: Output
            }], allDayExprChange: [{
                type: Output
            }], allDayPanelModeChange: [{
                type: Output
            }], appointmentCollectorTemplateChange: [{
                type: Output
            }], appointmentDraggingChange: [{
                type: Output
            }], appointmentTemplateChange: [{
                type: Output
            }], appointmentTooltipTemplateChange: [{
                type: Output
            }], cellDurationChange: [{
                type: Output
            }], crossScrollingEnabledChange: [{
                type: Output
            }], currentDateChange: [{
                type: Output
            }], currentViewChange: [{
                type: Output
            }], customizeDateNavigatorTextChange: [{
                type: Output
            }], dataCellTemplateChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], dateCellTemplateChange: [{
                type: Output
            }], dateSerializationFormatChange: [{
                type: Output
            }], descriptionExprChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], dropDownAppointmentTemplateChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], endDateExprChange: [{
                type: Output
            }], endDateTimeZoneExprChange: [{
                type: Output
            }], endDayHourChange: [{
                type: Output
            }], firstDayOfWeekChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], groupByDateChange: [{
                type: Output
            }], groupsChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], indicatorUpdateIntervalChange: [{
                type: Output
            }], maxChange: [{
                type: Output
            }], maxAppointmentsPerCellChange: [{
                type: Output
            }], minChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], offsetChange: [{
                type: Output
            }], recurrenceEditModeChange: [{
                type: Output
            }], recurrenceExceptionExprChange: [{
                type: Output
            }], recurrenceRuleExprChange: [{
                type: Output
            }], remoteFilteringChange: [{
                type: Output
            }], resourceCellTemplateChange: [{
                type: Output
            }], resourcesChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollingChange: [{
                type: Output
            }], selectedCellDataChange: [{
                type: Output
            }], shadeUntilCurrentTimeChange: [{
                type: Output
            }], showAllDayPanelChange: [{
                type: Output
            }], showCurrentTimeIndicatorChange: [{
                type: Output
            }], startDateExprChange: [{
                type: Output
            }], startDateTimeZoneExprChange: [{
                type: Output
            }], startDayHourChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], textExprChange: [{
                type: Output
            }], timeCellTemplateChange: [{
                type: Output
            }], timeZoneChange: [{
                type: Output
            }], useDropDownViewSwitcherChange: [{
                type: Output
            }], viewsChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], resourcesChildren: [{
                type: ContentChildren,
                args: [DxiResourceComponent]
            }], viewsChildren: [{
                type: ContentChildren,
                args: [DxiViewComponent]
            }] } });
class DxSchedulerModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSchedulerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxSchedulerModule, declarations: [DxSchedulerComponent], imports: [DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxSchedulerComponent, DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSchedulerModule, imports: [DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSchedulerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoAppointmentDraggingModule,
                        DxoEditingModule,
                        DxiResourceModule,
                        DxoScrollingModule,
                        DxiViewModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxSchedulerComponent
                    ],
                    exports: [
                        DxSchedulerComponent,
                        DxoAppointmentDraggingModule,
                        DxoEditingModule,
                        DxiResourceModule,
                        DxoScrollingModule,
                        DxiViewModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxSchedulerComponent, DxSchedulerModule };
//# sourceMappingURL=devextreme-angular-ui-scheduler.mjs.map
