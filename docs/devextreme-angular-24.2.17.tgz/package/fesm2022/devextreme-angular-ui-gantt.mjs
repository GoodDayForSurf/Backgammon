import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, ContentChildren, NgModule } from '@angular/core';
import DxGantt from 'devextreme/ui/gantt';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxiColumnComponent, DxiStripLineComponent, DxiColumnModule, DxoFormatModule, DxoHeaderFilterModule, DxoSearchModule, DxoContextMenuModule, DxiItemModule, DxoDependenciesModule, DxoEditingModule, DxoFilterRowModule, DxoOperationDescriptionsModule, DxoTextsModule, DxoResourceAssignmentsModule, DxoResourcesModule, DxoScaleTypeRangeModule, DxoSortingModule, DxiStripLineModule, DxoTasksModule, DxoToolbarModule, DxoValidationModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxGantt]

 */
class DxGanttComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxGanttOptions.allowSelection]
    
     */
    get allowSelection() {
        return this._getOption('allowSelection');
    }
    set allowSelection(value) {
        this._setOption('allowSelection', value);
    }
    /**
     * [descr:dxGanttOptions.columns]
    
     */
    get columns() {
        return this._getOption('columns');
    }
    set columns(value) {
        this._setOption('columns', value);
    }
    /**
     * [descr:dxGanttOptions.contextMenu]
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * [descr:dxGanttOptions.dependencies]
    
     */
    get dependencies() {
        return this._getOption('dependencies');
    }
    set dependencies(value) {
        this._setOption('dependencies', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxGanttOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxGanttOptions.endDateRange]
    
     */
    get endDateRange() {
        return this._getOption('endDateRange');
    }
    set endDateRange(value) {
        this._setOption('endDateRange', value);
    }
    /**
     * [descr:dxGanttOptions.filterRow]
    
     */
    get filterRow() {
        return this._getOption('filterRow');
    }
    set filterRow(value) {
        this._setOption('filterRow', value);
    }
    /**
     * [descr:dxGanttOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxGanttOptions.headerFilter]
    
     */
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxGanttOptions.resourceAssignments]
    
     */
    get resourceAssignments() {
        return this._getOption('resourceAssignments');
    }
    set resourceAssignments(value) {
        this._setOption('resourceAssignments', value);
    }
    /**
     * [descr:dxGanttOptions.resources]
    
     */
    get resources() {
        return this._getOption('resources');
    }
    set resources(value) {
        this._setOption('resources', value);
    }
    /**
     * [descr:dxGanttOptions.rootValue]
    
     */
    get rootValue() {
        return this._getOption('rootValue');
    }
    set rootValue(value) {
        this._setOption('rootValue', value);
    }
    /**
     * [descr:dxGanttOptions.scaleType]
    
     */
    get scaleType() {
        return this._getOption('scaleType');
    }
    set scaleType(value) {
        this._setOption('scaleType', value);
    }
    /**
     * [descr:dxGanttOptions.scaleTypeRange]
    
     */
    get scaleTypeRange() {
        return this._getOption('scaleTypeRange');
    }
    set scaleTypeRange(value) {
        this._setOption('scaleTypeRange', value);
    }
    /**
     * [descr:dxGanttOptions.selectedRowKey]
    
     */
    get selectedRowKey() {
        return this._getOption('selectedRowKey');
    }
    set selectedRowKey(value) {
        this._setOption('selectedRowKey', value);
    }
    /**
     * [descr:dxGanttOptions.showDependencies]
    
     */
    get showDependencies() {
        return this._getOption('showDependencies');
    }
    set showDependencies(value) {
        this._setOption('showDependencies', value);
    }
    /**
     * [descr:dxGanttOptions.showResources]
    
     */
    get showResources() {
        return this._getOption('showResources');
    }
    set showResources(value) {
        this._setOption('showResources', value);
    }
    /**
     * [descr:dxGanttOptions.showRowLines]
    
     */
    get showRowLines() {
        return this._getOption('showRowLines');
    }
    set showRowLines(value) {
        this._setOption('showRowLines', value);
    }
    /**
     * [descr:dxGanttOptions.sorting]
    
     */
    get sorting() {
        return this._getOption('sorting');
    }
    set sorting(value) {
        this._setOption('sorting', value);
    }
    /**
     * [descr:dxGanttOptions.startDateRange]
    
     */
    get startDateRange() {
        return this._getOption('startDateRange');
    }
    set startDateRange(value) {
        this._setOption('startDateRange', value);
    }
    /**
     * [descr:dxGanttOptions.stripLines]
    
     */
    get stripLines() {
        return this._getOption('stripLines');
    }
    set stripLines(value) {
        this._setOption('stripLines', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxGanttOptions.taskContentTemplate]
    
     */
    get taskContentTemplate() {
        return this._getOption('taskContentTemplate');
    }
    set taskContentTemplate(value) {
        this._setOption('taskContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.taskListWidth]
    
     */
    get taskListWidth() {
        return this._getOption('taskListWidth');
    }
    set taskListWidth(value) {
        this._setOption('taskListWidth', value);
    }
    /**
     * [descr:dxGanttOptions.taskProgressTooltipContentTemplate]
    
     */
    get taskProgressTooltipContentTemplate() {
        return this._getOption('taskProgressTooltipContentTemplate');
    }
    set taskProgressTooltipContentTemplate(value) {
        this._setOption('taskProgressTooltipContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.tasks]
    
     */
    get tasks() {
        return this._getOption('tasks');
    }
    set tasks(value) {
        this._setOption('tasks', value);
    }
    /**
     * [descr:dxGanttOptions.taskTimeTooltipContentTemplate]
    
     */
    get taskTimeTooltipContentTemplate() {
        return this._getOption('taskTimeTooltipContentTemplate');
    }
    set taskTimeTooltipContentTemplate(value) {
        this._setOption('taskTimeTooltipContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.taskTitlePosition]
    
     */
    get taskTitlePosition() {
        return this._getOption('taskTitlePosition');
    }
    set taskTitlePosition(value) {
        this._setOption('taskTitlePosition', value);
    }
    /**
     * [descr:dxGanttOptions.taskTooltipContentTemplate]
    
     */
    get taskTooltipContentTemplate() {
        return this._getOption('taskTooltipContentTemplate');
    }
    set taskTooltipContentTemplate(value) {
        this._setOption('taskTooltipContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.toolbar]
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * [descr:dxGanttOptions.validation]
    
     */
    get validation() {
        return this._getOption('validation');
    }
    set validation(value) {
        this._setOption('validation', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxGanttOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxGanttOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing;
    /**
    
     * [descr:dxGanttOptions.onCustomCommand]
    
    
     */
    onCustomCommand;
    /**
    
     * [descr:dxGanttOptions.onDependencyDeleted]
    
    
     */
    onDependencyDeleted;
    /**
    
     * [descr:dxGanttOptions.onDependencyDeleting]
    
    
     */
    onDependencyDeleting;
    /**
    
     * [descr:dxGanttOptions.onDependencyInserted]
    
    
     */
    onDependencyInserted;
    /**
    
     * [descr:dxGanttOptions.onDependencyInserting]
    
    
     */
    onDependencyInserting;
    /**
    
     * [descr:dxGanttOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxGanttOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxGanttOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxGanttOptions.onResourceAssigned]
    
    
     */
    onResourceAssigned;
    /**
    
     * [descr:dxGanttOptions.onResourceAssigning]
    
    
     */
    onResourceAssigning;
    /**
    
     * [descr:dxGanttOptions.onResourceDeleted]
    
    
     */
    onResourceDeleted;
    /**
    
     * [descr:dxGanttOptions.onResourceDeleting]
    
    
     */
    onResourceDeleting;
    /**
    
     * [descr:dxGanttOptions.onResourceInserted]
    
    
     */
    onResourceInserted;
    /**
    
     * [descr:dxGanttOptions.onResourceInserting]
    
    
     */
    onResourceInserting;
    /**
    
     * [descr:dxGanttOptions.onResourceManagerDialogShowing]
    
    
     */
    onResourceManagerDialogShowing;
    /**
    
     * [descr:dxGanttOptions.onResourceUnassigned]
    
    
     */
    onResourceUnassigned;
    /**
    
     * [descr:dxGanttOptions.onResourceUnassigning]
    
    
     */
    onResourceUnassigning;
    /**
    
     * [descr:dxGanttOptions.onScaleCellPrepared]
    
    
     */
    onScaleCellPrepared;
    /**
    
     * [descr:dxGanttOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * [descr:dxGanttOptions.onTaskClick]
    
    
     */
    onTaskClick;
    /**
    
     * [descr:dxGanttOptions.onTaskDblClick]
    
    
     */
    onTaskDblClick;
    /**
    
     * [descr:dxGanttOptions.onTaskDeleted]
    
    
     */
    onTaskDeleted;
    /**
    
     * [descr:dxGanttOptions.onTaskDeleting]
    
    
     */
    onTaskDeleting;
    /**
    
     * [descr:dxGanttOptions.onTaskEditDialogShowing]
    
    
     */
    onTaskEditDialogShowing;
    /**
    
     * [descr:dxGanttOptions.onTaskInserted]
    
    
     */
    onTaskInserted;
    /**
    
     * [descr:dxGanttOptions.onTaskInserting]
    
    
     */
    onTaskInserting;
    /**
    
     * [descr:dxGanttOptions.onTaskMoving]
    
    
     */
    onTaskMoving;
    /**
    
     * [descr:dxGanttOptions.onTaskUpdated]
    
    
     */
    onTaskUpdated;
    /**
    
     * [descr:dxGanttOptions.onTaskUpdating]
    
    
     */
    onTaskUpdating;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSelectionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextMenuChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dependenciesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateRangeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterRowChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstDayOfWeekChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourceAssignmentsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourcesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rootValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleTypeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleTypeRangeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRowKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDependenciesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showResourcesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowLinesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateRangeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stripLinesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskListWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskProgressTooltipContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tasksChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTimeTooltipContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTitlePositionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTooltipContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    get columnsChildren() {
        return this._getOption('columns');
    }
    set columnsChildren(value) {
        this.setChildren('columns', value);
    }
    get stripLinesChildren() {
        return this._getOption('stripLines');
    }
    set stripLinesChildren(value) {
        this.setChildren('stripLines', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'customCommand', emit: 'onCustomCommand' },
            { subscribe: 'dependencyDeleted', emit: 'onDependencyDeleted' },
            { subscribe: 'dependencyDeleting', emit: 'onDependencyDeleting' },
            { subscribe: 'dependencyInserted', emit: 'onDependencyInserted' },
            { subscribe: 'dependencyInserting', emit: 'onDependencyInserting' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'resourceAssigned', emit: 'onResourceAssigned' },
            { subscribe: 'resourceAssigning', emit: 'onResourceAssigning' },
            { subscribe: 'resourceDeleted', emit: 'onResourceDeleted' },
            { subscribe: 'resourceDeleting', emit: 'onResourceDeleting' },
            { subscribe: 'resourceInserted', emit: 'onResourceInserted' },
            { subscribe: 'resourceInserting', emit: 'onResourceInserting' },
            { subscribe: 'resourceManagerDialogShowing', emit: 'onResourceManagerDialogShowing' },
            { subscribe: 'resourceUnassigned', emit: 'onResourceUnassigned' },
            { subscribe: 'resourceUnassigning', emit: 'onResourceUnassigning' },
            { subscribe: 'scaleCellPrepared', emit: 'onScaleCellPrepared' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'taskClick', emit: 'onTaskClick' },
            { subscribe: 'taskDblClick', emit: 'onTaskDblClick' },
            { subscribe: 'taskDeleted', emit: 'onTaskDeleted' },
            { subscribe: 'taskDeleting', emit: 'onTaskDeleting' },
            { subscribe: 'taskEditDialogShowing', emit: 'onTaskEditDialogShowing' },
            { subscribe: 'taskInserted', emit: 'onTaskInserted' },
            { subscribe: 'taskInserting', emit: 'onTaskInserting' },
            { subscribe: 'taskMoving', emit: 'onTaskMoving' },
            { subscribe: 'taskUpdated', emit: 'onTaskUpdated' },
            { subscribe: 'taskUpdating', emit: 'onTaskUpdating' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowSelectionChange' },
            { emit: 'columnsChange' },
            { emit: 'contextMenuChange' },
            { emit: 'dependenciesChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'endDateRangeChange' },
            { emit: 'filterRowChange' },
            { emit: 'firstDayOfWeekChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'headerFilterChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'resourceAssignmentsChange' },
            { emit: 'resourcesChange' },
            { emit: 'rootValueChange' },
            { emit: 'scaleTypeChange' },
            { emit: 'scaleTypeRangeChange' },
            { emit: 'selectedRowKeyChange' },
            { emit: 'showDependenciesChange' },
            { emit: 'showResourcesChange' },
            { emit: 'showRowLinesChange' },
            { emit: 'sortingChange' },
            { emit: 'startDateRangeChange' },
            { emit: 'stripLinesChange' },
            { emit: 'tabIndexChange' },
            { emit: 'taskContentTemplateChange' },
            { emit: 'taskListWidthChange' },
            { emit: 'taskProgressTooltipContentTemplateChange' },
            { emit: 'tasksChange' },
            { emit: 'taskTimeTooltipContentTemplateChange' },
            { emit: 'taskTitlePositionChange' },
            { emit: 'taskTooltipContentTemplateChange' },
            { emit: 'toolbarChange' },
            { emit: 'validationChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxGantt(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('columns', changes);
        this.setupChanges('stripLines', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('columns');
        this._idh.doCheck('stripLines');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxGanttComponent, selector: "dx-gantt", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowSelection: "allowSelection", columns: "columns", contextMenu: "contextMenu", dependencies: "dependencies", disabled: "disabled", editing: "editing", elementAttr: "elementAttr", endDateRange: "endDateRange", filterRow: "filterRow", firstDayOfWeek: "firstDayOfWeek", focusStateEnabled: "focusStateEnabled", headerFilter: "headerFilter", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", resourceAssignments: "resourceAssignments", resources: "resources", rootValue: "rootValue", scaleType: "scaleType", scaleTypeRange: "scaleTypeRange", selectedRowKey: "selectedRowKey", showDependencies: "showDependencies", showResources: "showResources", showRowLines: "showRowLines", sorting: "sorting", startDateRange: "startDateRange", stripLines: "stripLines", tabIndex: "tabIndex", taskContentTemplate: "taskContentTemplate", taskListWidth: "taskListWidth", taskProgressTooltipContentTemplate: "taskProgressTooltipContentTemplate", tasks: "tasks", taskTimeTooltipContentTemplate: "taskTimeTooltipContentTemplate", taskTitlePosition: "taskTitlePosition", taskTooltipContentTemplate: "taskTooltipContentTemplate", toolbar: "toolbar", validation: "validation", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onContextMenuPreparing: "onContextMenuPreparing", onCustomCommand: "onCustomCommand", onDependencyDeleted: "onDependencyDeleted", onDependencyDeleting: "onDependencyDeleting", onDependencyInserted: "onDependencyInserted", onDependencyInserting: "onDependencyInserting", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResourceAssigned: "onResourceAssigned", onResourceAssigning: "onResourceAssigning", onResourceDeleted: "onResourceDeleted", onResourceDeleting: "onResourceDeleting", onResourceInserted: "onResourceInserted", onResourceInserting: "onResourceInserting", onResourceManagerDialogShowing: "onResourceManagerDialogShowing", onResourceUnassigned: "onResourceUnassigned", onResourceUnassigning: "onResourceUnassigning", onScaleCellPrepared: "onScaleCellPrepared", onSelectionChanged: "onSelectionChanged", onTaskClick: "onTaskClick", onTaskDblClick: "onTaskDblClick", onTaskDeleted: "onTaskDeleted", onTaskDeleting: "onTaskDeleting", onTaskEditDialogShowing: "onTaskEditDialogShowing", onTaskInserted: "onTaskInserted", onTaskInserting: "onTaskInserting", onTaskMoving: "onTaskMoving", onTaskUpdated: "onTaskUpdated", onTaskUpdating: "onTaskUpdating", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowSelectionChange: "allowSelectionChange", columnsChange: "columnsChange", contextMenuChange: "contextMenuChange", dependenciesChange: "dependenciesChange", disabledChange: "disabledChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", endDateRangeChange: "endDateRangeChange", filterRowChange: "filterRowChange", firstDayOfWeekChange: "firstDayOfWeekChange", focusStateEnabledChange: "focusStateEnabledChange", headerFilterChange: "headerFilterChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", resourceAssignmentsChange: "resourceAssignmentsChange", resourcesChange: "resourcesChange", rootValueChange: "rootValueChange", scaleTypeChange: "scaleTypeChange", scaleTypeRangeChange: "scaleTypeRangeChange", selectedRowKeyChange: "selectedRowKeyChange", showDependenciesChange: "showDependenciesChange", showResourcesChange: "showResourcesChange", showRowLinesChange: "showRowLinesChange", sortingChange: "sortingChange", startDateRangeChange: "startDateRangeChange", stripLinesChange: "stripLinesChange", tabIndexChange: "tabIndexChange", taskContentTemplateChange: "taskContentTemplateChange", taskListWidthChange: "taskListWidthChange", taskProgressTooltipContentTemplateChange: "taskProgressTooltipContentTemplateChange", tasksChange: "tasksChange", taskTimeTooltipContentTemplateChange: "taskTimeTooltipContentTemplateChange", taskTitlePositionChange: "taskTitlePositionChange", taskTooltipContentTemplateChange: "taskTooltipContentTemplateChange", toolbarChange: "toolbarChange", validationChange: "validationChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "columnsChildren", predicate: DxiColumnComponent }, { propertyName: "stripLinesChildren", predicate: DxiStripLineComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-gantt',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowSelection: [{
                type: Input
            }], columns: [{
                type: Input
            }], contextMenu: [{
                type: Input
            }], dependencies: [{
                type: Input
            }], disabled: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], endDateRange: [{
                type: Input
            }], filterRow: [{
                type: Input
            }], firstDayOfWeek: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], resourceAssignments: [{
                type: Input
            }], resources: [{
                type: Input
            }], rootValue: [{
                type: Input
            }], scaleType: [{
                type: Input
            }], scaleTypeRange: [{
                type: Input
            }], selectedRowKey: [{
                type: Input
            }], showDependencies: [{
                type: Input
            }], showResources: [{
                type: Input
            }], showRowLines: [{
                type: Input
            }], sorting: [{
                type: Input
            }], startDateRange: [{
                type: Input
            }], stripLines: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], taskContentTemplate: [{
                type: Input
            }], taskListWidth: [{
                type: Input
            }], taskProgressTooltipContentTemplate: [{
                type: Input
            }], tasks: [{
                type: Input
            }], taskTimeTooltipContentTemplate: [{
                type: Input
            }], taskTitlePosition: [{
                type: Input
            }], taskTooltipContentTemplate: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], validation: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onContextMenuPreparing: [{
                type: Output
            }], onCustomCommand: [{
                type: Output
            }], onDependencyDeleted: [{
                type: Output
            }], onDependencyDeleting: [{
                type: Output
            }], onDependencyInserted: [{
                type: Output
            }], onDependencyInserting: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onResourceAssigned: [{
                type: Output
            }], onResourceAssigning: [{
                type: Output
            }], onResourceDeleted: [{
                type: Output
            }], onResourceDeleting: [{
                type: Output
            }], onResourceInserted: [{
                type: Output
            }], onResourceInserting: [{
                type: Output
            }], onResourceManagerDialogShowing: [{
                type: Output
            }], onResourceUnassigned: [{
                type: Output
            }], onResourceUnassigning: [{
                type: Output
            }], onScaleCellPrepared: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onTaskClick: [{
                type: Output
            }], onTaskDblClick: [{
                type: Output
            }], onTaskDeleted: [{
                type: Output
            }], onTaskDeleting: [{
                type: Output
            }], onTaskEditDialogShowing: [{
                type: Output
            }], onTaskInserted: [{
                type: Output
            }], onTaskInserting: [{
                type: Output
            }], onTaskMoving: [{
                type: Output
            }], onTaskUpdated: [{
                type: Output
            }], onTaskUpdating: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowSelectionChange: [{
                type: Output
            }], columnsChange: [{
                type: Output
            }], contextMenuChange: [{
                type: Output
            }], dependenciesChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], endDateRangeChange: [{
                type: Output
            }], filterRowChange: [{
                type: Output
            }], firstDayOfWeekChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], headerFilterChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], resourceAssignmentsChange: [{
                type: Output
            }], resourcesChange: [{
                type: Output
            }], rootValueChange: [{
                type: Output
            }], scaleTypeChange: [{
                type: Output
            }], scaleTypeRangeChange: [{
                type: Output
            }], selectedRowKeyChange: [{
                type: Output
            }], showDependenciesChange: [{
                type: Output
            }], showResourcesChange: [{
                type: Output
            }], showRowLinesChange: [{
                type: Output
            }], sortingChange: [{
                type: Output
            }], startDateRangeChange: [{
                type: Output
            }], stripLinesChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], taskContentTemplateChange: [{
                type: Output
            }], taskListWidthChange: [{
                type: Output
            }], taskProgressTooltipContentTemplateChange: [{
                type: Output
            }], tasksChange: [{
                type: Output
            }], taskTimeTooltipContentTemplateChange: [{
                type: Output
            }], taskTitlePositionChange: [{
                type: Output
            }], taskTooltipContentTemplateChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], validationChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], columnsChildren: [{
                type: ContentChildren,
                args: [DxiColumnComponent]
            }], stripLinesChildren: [{
                type: ContentChildren,
                args: [DxiStripLineComponent]
            }] } });
class DxGanttModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, declarations: [DxGanttComponent], imports: [DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxGanttComponent, DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, imports: [DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxIntegrationModule,
            DxTemplateModule, DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiColumnModule,
                        DxoFormatModule,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoContextMenuModule,
                        DxiItemModule,
                        DxoDependenciesModule,
                        DxoEditingModule,
                        DxoFilterRowModule,
                        DxoOperationDescriptionsModule,
                        DxoTextsModule,
                        DxoResourceAssignmentsModule,
                        DxoResourcesModule,
                        DxoScaleTypeRangeModule,
                        DxoSortingModule,
                        DxiStripLineModule,
                        DxoTasksModule,
                        DxoToolbarModule,
                        DxoValidationModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxGanttComponent
                    ],
                    exports: [
                        DxGanttComponent,
                        DxiColumnModule,
                        DxoFormatModule,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoContextMenuModule,
                        DxiItemModule,
                        DxoDependenciesModule,
                        DxoEditingModule,
                        DxoFilterRowModule,
                        DxoOperationDescriptionsModule,
                        DxoTextsModule,
                        DxoResourceAssignmentsModule,
                        DxoResourcesModule,
                        DxoScaleTypeRangeModule,
                        DxoSortingModule,
                        DxiStripLineModule,
                        DxoTasksModule,
                        DxoToolbarModule,
                        DxoValidationModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxGanttComponent, DxGanttModule };
//# sourceMappingURL=devextreme-angular-ui-gantt.mjs.map
