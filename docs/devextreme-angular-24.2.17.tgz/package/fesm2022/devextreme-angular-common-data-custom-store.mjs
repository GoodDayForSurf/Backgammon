export { isGroupItemsArray, isItemsArray, isLoadResultObject } from 'devextreme/common/data/custom-store';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=devextreme-angular-common-data-custom-store.mjs.map
