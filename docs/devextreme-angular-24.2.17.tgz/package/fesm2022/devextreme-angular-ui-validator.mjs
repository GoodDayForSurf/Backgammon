import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, SkipSelf, Optional, Host, Inject, Input, Output, ContentChildren, NgModule } from '@angular/core';
import DxValidator from 'devextreme/ui/validator';
import * as i1 from 'devextreme-angular/core';
import { DxComponentExtension, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxiValidationRuleComponent, DxoAdapterModule, DxiValidationRuleModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxValidator]

 */
class DxValidatorComponent extends DxComponentExtension {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:dxValidatorOptions.adapter]
    
     */
    get adapter() {
        return this._getOption('adapter');
    }
    set adapter(value) {
        this._setOption('adapter', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxValidatorOptions.name]
    
     */
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    /**
     * [descr:dxValidatorOptions.validationGroup]
    
     */
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    /**
     * [descr:dxValidatorOptions.validationRules]
    
     */
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:DOMComponentOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:ComponentOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:DOMComponentOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxValidatorOptions.onValidated]
    
    
     */
    onValidated;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adapterChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationGroupChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationRulesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    get validationRulesChildren() {
        return this._getOption('validationRules');
    }
    set validationRulesChildren(value) {
        this.setChildren('validationRules', value);
    }
    parentElement;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, parentOptionHost, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'validated', emit: 'onValidated' },
            { emit: 'adapterChange' },
            { emit: 'elementAttrChange' },
            { emit: 'heightChange' },
            { emit: 'nameChange' },
            { emit: 'validationGroupChange' },
            { emit: 'validationRulesChange' },
            { emit: 'widthChange' }
        ]);
        this.parentElement = this.getParentElement(parentOptionHost);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        if (this.parentElement) {
            return new DxValidator(this.parentElement, options);
        }
        return new DxValidator(element, options);
    }
    getParentElement(host) {
        if (host) {
            const parentHost = host.getHost();
            return parentHost.element.nativeElement;
        }
        return;
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('validationRules', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('validationRules');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxValidatorComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost, host: true, optional: true, skipSelf: true }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxValidatorComponent, selector: "dx-validator", inputs: { adapter: "adapter", elementAttr: "elementAttr", height: "height", name: "name", validationGroup: "validationGroup", validationRules: "validationRules", width: "width" }, outputs: { onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValidated: "onValidated", adapterChange: "adapterChange", elementAttrChange: "elementAttrChange", heightChange: "heightChange", nameChange: "nameChange", validationGroupChange: "validationGroupChange", validationRulesChange: "validationRulesChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "validationRulesChildren", predicate: DxiValidationRuleComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxValidatorComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-validator',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Optional
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { adapter: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], height: [{
                type: Input
            }], name: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], width: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onValidated: [{
                type: Output
            }], adapterChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], nameChange: [{
                type: Output
            }], validationGroupChange: [{
                type: Output
            }], validationRulesChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], validationRulesChildren: [{
                type: ContentChildren,
                args: [DxiValidationRuleComponent]
            }] } });
class DxValidatorModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxValidatorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxValidatorModule, declarations: [DxValidatorComponent], imports: [DxoAdapterModule,
            DxiValidationRuleModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxValidatorComponent, DxoAdapterModule,
            DxiValidationRuleModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxValidatorModule, imports: [DxoAdapterModule,
            DxiValidationRuleModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAdapterModule,
            DxiValidationRuleModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxValidatorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoAdapterModule,
                        DxiValidationRuleModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxValidatorComponent
                    ],
                    exports: [
                        DxValidatorComponent,
                        DxoAdapterModule,
                        DxiValidationRuleModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxValidatorComponent, DxValidatorModule };
//# sourceMappingURL=devextreme-angular-ui-validator.mjs.map
