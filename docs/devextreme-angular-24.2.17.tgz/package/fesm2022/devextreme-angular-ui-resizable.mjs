import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, NgModule } from '@angular/core';
import DxResizable from 'devextreme/ui/resizable';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxResizable]

 */
class DxResizableComponent extends DxComponent {
    instance = null;
    /**
     * [descr:dxResizableOptions.area]
    
     */
    get area() {
        return this._getOption('area');
    }
    set area(value) {
        this._setOption('area', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxResizableOptions.handles]
    
     */
    get handles() {
        return this._getOption('handles');
    }
    set handles(value) {
        this._setOption('handles', value);
    }
    /**
     * [descr:dxResizableOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxResizableOptions.keepAspectRatio]
    
     */
    get keepAspectRatio() {
        return this._getOption('keepAspectRatio');
    }
    set keepAspectRatio(value) {
        this._setOption('keepAspectRatio', value);
    }
    /**
     * [descr:dxResizableOptions.maxHeight]
    
     */
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    /**
     * [descr:dxResizableOptions.maxWidth]
    
     */
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    /**
     * [descr:dxResizableOptions.minHeight]
    
     */
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    /**
     * [descr:dxResizableOptions.minWidth]
    
     */
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxResizableOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxResizableOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxResizableOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxResizableOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxResizableOptions.onResize]
    
    
     */
    onResize;
    /**
    
     * [descr:dxResizableOptions.onResizeEnd]
    
    
     */
    onResizeEnd;
    /**
    
     * [descr:dxResizableOptions.onResizeStart]
    
    
     */
    onResizeStart;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    areaChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    handlesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keepAspectRatioChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'resize', emit: 'onResize' },
            { subscribe: 'resizeEnd', emit: 'onResizeEnd' },
            { subscribe: 'resizeStart', emit: 'onResizeStart' },
            { emit: 'areaChange' },
            { emit: 'elementAttrChange' },
            { emit: 'handlesChange' },
            { emit: 'heightChange' },
            { emit: 'keepAspectRatioChange' },
            { emit: 'maxHeightChange' },
            { emit: 'maxWidthChange' },
            { emit: 'minHeightChange' },
            { emit: 'minWidthChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'widthChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxResizable(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxResizableComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxResizableComponent, selector: "dx-resizable", inputs: { area: "area", elementAttr: "elementAttr", handles: "handles", height: "height", keepAspectRatio: "keepAspectRatio", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", rtlEnabled: "rtlEnabled", width: "width" }, outputs: { onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResize: "onResize", onResizeEnd: "onResizeEnd", onResizeStart: "onResizeStart", areaChange: "areaChange", elementAttrChange: "elementAttrChange", handlesChange: "handlesChange", heightChange: "heightChange", keepAspectRatioChange: "keepAspectRatioChange", maxHeightChange: "maxHeightChange", maxWidthChange: "maxWidthChange", minHeightChange: "minHeightChange", minWidthChange: "minWidthChange", rtlEnabledChange: "rtlEnabledChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxResizableComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-resizable',
                    template: '<ng-content></ng-content>',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { area: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], handles: [{
                type: Input
            }], height: [{
                type: Input
            }], keepAspectRatio: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], width: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onResize: [{
                type: Output
            }], onResizeEnd: [{
                type: Output
            }], onResizeStart: [{
                type: Output
            }], areaChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], handlesChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], keepAspectRatioChange: [{
                type: Output
            }], maxHeightChange: [{
                type: Output
            }], maxWidthChange: [{
                type: Output
            }], minHeightChange: [{
                type: Output
            }], minWidthChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxResizableModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxResizableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxResizableModule, declarations: [DxResizableComponent], imports: [DxIntegrationModule,
            DxTemplateModule], exports: [DxResizableComponent, DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxResizableModule, imports: [DxIntegrationModule,
            DxTemplateModule, DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxResizableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxResizableComponent
                    ],
                    exports: [
                        DxResizableComponent,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxResizableComponent, DxResizableModule };
//# sourceMappingURL=devextreme-angular-ui-resizable.mjs.map
