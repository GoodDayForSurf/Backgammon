import * as i0 from '@angular/core';
import { PLATFORM_ID, NgModule, Inject } from '@angular/core';
import { isPlatformServer } from '@angular/common';
import infernoRenderer from 'devextreme/core/inferno_renderer';
import { renderToString } from 'inferno-server';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
class DxServerModule {
    constructor(platformId) {
        if (isPlatformServer(platformId)) {
            infernoRenderer.inject({
                render: (component, props, container) => {
                    const el = infernoRenderer.createElement(component, props);
                    const document = container.ownerDocument;
                    const temp = document.createElement(container.tagName);
                    temp.innerHTML = renderToString(el);
                    const mainElement = temp.childNodes[0];
                    const childString = mainElement.innerHTML;
                    for (let i = 0; i < mainElement.attributes.length; i++) {
                        temp.setAttribute(mainElement.attributes[i].name, mainElement.attributes[i].value);
                    }
                    temp.innerHTML = childString;
                    container.outerHTML = temp.outerHTML;
                },
            });
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule, deps: [{ token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [],
                    imports: [],
                    providers: [],
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; } });

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxServerModule };
//# sourceMappingURL=devextreme-angular-server.mjs.map
