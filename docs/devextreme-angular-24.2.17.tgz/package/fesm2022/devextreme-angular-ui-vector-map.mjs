import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, ContentChildren, NgModule } from '@angular/core';
import DxVectorMap from 'devextreme/viz/vector_map';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxiAnnotationComponent, DxiLayerComponent, DxiLegendComponent, DxiAnnotationModule, DxoBorderModule, DxoFontModule, DxoImageModule, DxoShadowModule, DxoBackgroundModule, DxoCommonAnnotationSettingsModule, DxoControlBarModule, DxoExportModule, DxiLayerModule, DxoLabelModule, DxiLegendModule, DxoMarginModule, DxoSourceModule, DxoTitleModule, DxoSubtitleModule, DxoLoadingIndicatorModule, DxoProjectionModule, DxoSizeModule, DxoTooltipModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxVectorMap]

 */
class DxVectorMapComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:dxVectorMapOptions.annotations]
    
     */
    get annotations() {
        return this._getOption('annotations');
    }
    set annotations(value) {
        this._setOption('annotations', value);
    }
    /**
     * [descr:dxVectorMapOptions.background]
    
     */
    get background() {
        return this._getOption('background');
    }
    set background(value) {
        this._setOption('background', value);
    }
    /**
     * [descr:dxVectorMapOptions.bounds]
    
     */
    get bounds() {
        return this._getOption('bounds');
    }
    set bounds(value) {
        this._setOption('bounds', value);
    }
    /**
     * [descr:dxVectorMapOptions.center]
    
     */
    get center() {
        return this._getOption('center');
    }
    set center(value) {
        this._setOption('center', value);
    }
    /**
     * [descr:dxVectorMapOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings() {
        return this._getOption('commonAnnotationSettings');
    }
    set commonAnnotationSettings(value) {
        this._setOption('commonAnnotationSettings', value);
    }
    /**
     * [descr:dxVectorMapOptions.controlBar]
    
     */
    get controlBar() {
        return this._getOption('controlBar');
    }
    set controlBar(value) {
        this._setOption('controlBar', value);
    }
    /**
     * [descr:dxVectorMapOptions.customizeAnnotation]
    
     */
    get customizeAnnotation() {
        return this._getOption('customizeAnnotation');
    }
    set customizeAnnotation(value) {
        this._setOption('customizeAnnotation', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxVectorMapOptions.layers]
    
     */
    get layers() {
        return this._getOption('layers');
    }
    set layers(value) {
        this._setOption('layers', value);
    }
    /**
     * [descr:dxVectorMapOptions.legends]
    
     */
    get legends() {
        return this._getOption('legends');
    }
    set legends(value) {
        this._setOption('legends', value);
    }
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:dxVectorMapOptions.maxZoomFactor]
    
     */
    get maxZoomFactor() {
        return this._getOption('maxZoomFactor');
    }
    set maxZoomFactor(value) {
        this._setOption('maxZoomFactor', value);
    }
    /**
     * [descr:dxVectorMapOptions.panningEnabled]
    
     */
    get panningEnabled() {
        return this._getOption('panningEnabled');
    }
    set panningEnabled(value) {
        this._setOption('panningEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:dxVectorMapOptions.projection]
    
     */
    get projection() {
        return this._getOption('projection');
    }
    set projection(value) {
        this._setOption('projection', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxVectorMapOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxVectorMapOptions.touchEnabled]
    
     */
    get touchEnabled() {
        return this._getOption('touchEnabled');
    }
    set touchEnabled(value) {
        this._setOption('touchEnabled', value);
    }
    /**
     * [descr:dxVectorMapOptions.wheelEnabled]
    
     */
    get wheelEnabled() {
        return this._getOption('wheelEnabled');
    }
    set wheelEnabled(value) {
        this._setOption('wheelEnabled', value);
    }
    /**
     * [descr:dxVectorMapOptions.zoomFactor]
    
     */
    get zoomFactor() {
        return this._getOption('zoomFactor');
    }
    set zoomFactor(value) {
        this._setOption('zoomFactor', value);
    }
    /**
     * [descr:dxVectorMapOptions.zoomingEnabled]
    
     */
    get zoomingEnabled() {
        return this._getOption('zoomingEnabled');
    }
    set zoomingEnabled(value) {
        this._setOption('zoomingEnabled', value);
    }
    /**
    
     * [descr:dxVectorMapOptions.onCenterChanged]
    
    
     */
    onCenterChanged;
    /**
    
     * [descr:dxVectorMapOptions.onClick]
    
    
     */
    onClick;
    /**
    
     * [descr:dxVectorMapOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxVectorMapOptions.onDrawn]
    
    
     */
    onDrawn;
    /**
    
     * [descr:dxVectorMapOptions.onExported]
    
    
     */
    onExported;
    /**
    
     * [descr:dxVectorMapOptions.onExporting]
    
    
     */
    onExporting;
    /**
    
     * [descr:dxVectorMapOptions.onFileSaving]
    
    
     */
    onFileSaving;
    /**
    
     * [descr:dxVectorMapOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred;
    /**
    
     * [descr:dxVectorMapOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxVectorMapOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxVectorMapOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * [descr:dxVectorMapOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden;
    /**
    
     * [descr:dxVectorMapOptions.onTooltipShown]
    
    
     */
    onTooltipShown;
    /**
    
     * [descr:dxVectorMapOptions.onZoomFactorChanged]
    
    
     */
    onZoomFactorChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    annotationsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    backgroundChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    boundsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAnnotationSettingsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    controlBarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeAnnotationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layersChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxZoomFactorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    panningEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    projectionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    touchEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wheelEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomFactorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomingEnabledChange;
    get annotationsChildren() {
        return this._getOption('annotations');
    }
    set annotationsChildren(value) {
        this.setChildren('annotations', value);
    }
    get layersChildren() {
        return this._getOption('layers');
    }
    set layersChildren(value) {
        this.setChildren('layers', value);
    }
    get legendsChildren() {
        return this._getOption('legends');
    }
    set legendsChildren(value) {
        this.setChildren('legends', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'centerChanged', emit: 'onCenterChanged' },
            { subscribe: 'click', emit: 'onClick' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { subscribe: 'zoomFactorChanged', emit: 'onZoomFactorChanged' },
            { emit: 'annotationsChange' },
            { emit: 'backgroundChange' },
            { emit: 'boundsChange' },
            { emit: 'centerChange' },
            { emit: 'commonAnnotationSettingsChange' },
            { emit: 'controlBarChange' },
            { emit: 'customizeAnnotationChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'exportChange' },
            { emit: 'layersChange' },
            { emit: 'legendsChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'maxZoomFactorChange' },
            { emit: 'panningEnabledChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'projectionChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'sizeChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'touchEnabledChange' },
            { emit: 'wheelEnabledChange' },
            { emit: 'zoomFactorChange' },
            { emit: 'zoomingEnabledChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxVectorMap(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('annotations', changes);
        this.setupChanges('bounds', changes);
        this.setupChanges('center', changes);
        this.setupChanges('layers', changes);
        this.setupChanges('legends', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('annotations');
        this._idh.doCheck('bounds');
        this._idh.doCheck('center');
        this._idh.doCheck('layers');
        this._idh.doCheck('legends');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxVectorMapComponent, selector: "dx-vector-map", inputs: { annotations: "annotations", background: "background", bounds: "bounds", center: "center", commonAnnotationSettings: "commonAnnotationSettings", controlBar: "controlBar", customizeAnnotation: "customizeAnnotation", disabled: "disabled", elementAttr: "elementAttr", export: "export", layers: "layers", legends: "legends", loadingIndicator: "loadingIndicator", maxZoomFactor: "maxZoomFactor", panningEnabled: "panningEnabled", pathModified: "pathModified", projection: "projection", redrawOnResize: "redrawOnResize", rtlEnabled: "rtlEnabled", size: "size", theme: "theme", title: "title", tooltip: "tooltip", touchEnabled: "touchEnabled", wheelEnabled: "wheelEnabled", zoomFactor: "zoomFactor", zoomingEnabled: "zoomingEnabled" }, outputs: { onCenterChanged: "onCenterChanged", onClick: "onClick", onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", onZoomFactorChanged: "onZoomFactorChanged", annotationsChange: "annotationsChange", backgroundChange: "backgroundChange", boundsChange: "boundsChange", centerChange: "centerChange", commonAnnotationSettingsChange: "commonAnnotationSettingsChange", controlBarChange: "controlBarChange", customizeAnnotationChange: "customizeAnnotationChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", exportChange: "exportChange", layersChange: "layersChange", legendsChange: "legendsChange", loadingIndicatorChange: "loadingIndicatorChange", maxZoomFactorChange: "maxZoomFactorChange", panningEnabledChange: "panningEnabledChange", pathModifiedChange: "pathModifiedChange", projectionChange: "projectionChange", redrawOnResizeChange: "redrawOnResizeChange", rtlEnabledChange: "rtlEnabledChange", sizeChange: "sizeChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", touchEnabledChange: "touchEnabledChange", wheelEnabledChange: "wheelEnabledChange", zoomFactorChange: "zoomFactorChange", zoomingEnabledChange: "zoomingEnabledChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "annotationsChildren", predicate: DxiAnnotationComponent }, { propertyName: "layersChildren", predicate: DxiLayerComponent }, { propertyName: "legendsChildren", predicate: DxiLegendComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-vector-map', template: '', providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { annotations: [{
                type: Input
            }], background: [{
                type: Input
            }], bounds: [{
                type: Input
            }], center: [{
                type: Input
            }], commonAnnotationSettings: [{
                type: Input
            }], controlBar: [{
                type: Input
            }], customizeAnnotation: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], export: [{
                type: Input
            }], layers: [{
                type: Input
            }], legends: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], maxZoomFactor: [{
                type: Input
            }], panningEnabled: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], projection: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], size: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], touchEnabled: [{
                type: Input
            }], wheelEnabled: [{
                type: Input
            }], zoomFactor: [{
                type: Input
            }], zoomingEnabled: [{
                type: Input
            }], onCenterChanged: [{
                type: Output
            }], onClick: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], onZoomFactorChanged: [{
                type: Output
            }], annotationsChange: [{
                type: Output
            }], backgroundChange: [{
                type: Output
            }], boundsChange: [{
                type: Output
            }], centerChange: [{
                type: Output
            }], commonAnnotationSettingsChange: [{
                type: Output
            }], controlBarChange: [{
                type: Output
            }], customizeAnnotationChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], layersChange: [{
                type: Output
            }], legendsChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], maxZoomFactorChange: [{
                type: Output
            }], panningEnabledChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], projectionChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], touchEnabledChange: [{
                type: Output
            }], wheelEnabledChange: [{
                type: Output
            }], zoomFactorChange: [{
                type: Output
            }], zoomingEnabledChange: [{
                type: Output
            }], annotationsChildren: [{
                type: ContentChildren,
                args: [DxiAnnotationComponent]
            }], layersChildren: [{
                type: ContentChildren,
                args: [DxiLayerComponent]
            }], legendsChildren: [{
                type: ContentChildren,
                args: [DxiLegendComponent]
            }] } });
class DxVectorMapModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, declarations: [DxVectorMapComponent], imports: [DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxVectorMapComponent, DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, imports: [DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxIntegrationModule,
            DxTemplateModule, DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiAnnotationModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoImageModule,
                        DxoShadowModule,
                        DxoBackgroundModule,
                        DxoCommonAnnotationSettingsModule,
                        DxoControlBarModule,
                        DxoExportModule,
                        DxiLayerModule,
                        DxoLabelModule,
                        DxiLegendModule,
                        DxoMarginModule,
                        DxoSourceModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoProjectionModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxVectorMapComponent
                    ],
                    exports: [
                        DxVectorMapComponent,
                        DxiAnnotationModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoImageModule,
                        DxoShadowModule,
                        DxoBackgroundModule,
                        DxoCommonAnnotationSettingsModule,
                        DxoControlBarModule,
                        DxoExportModule,
                        DxiLayerModule,
                        DxoLabelModule,
                        DxiLegendModule,
                        DxoMarginModule,
                        DxoSourceModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoProjectionModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxVectorMapComponent, DxVectorMapModule };
//# sourceMappingURL=devextreme-angular-ui-vector-map.mjs.map
