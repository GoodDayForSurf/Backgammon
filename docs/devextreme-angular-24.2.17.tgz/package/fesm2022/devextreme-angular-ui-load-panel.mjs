import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, NgModule } from '@angular/core';
import DxLoadPanel from 'devextreme/ui/load_panel';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule } from 'devextreme-angular/ui/nested';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxLoadPanel]

 */
class DxLoadPanelComponent extends DxComponent {
    instance = null;
    /**
     * [descr:dxLoadPanelOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxOverlayOptions.closeOnOutsideClick]
    
     * @deprecated [depNote:dxOverlayOptions.closeOnOutsideClick]
    
     */
    get closeOnOutsideClick() {
        return this._getOption('closeOnOutsideClick');
    }
    set closeOnOutsideClick(value) {
        this._setOption('closeOnOutsideClick', value);
    }
    /**
     * [descr:dxLoadPanelOptions.container]
    
     */
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    /**
     * [descr:dxOverlayOptions.deferRendering]
    
     */
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    /**
     * [descr:dxLoadPanelOptions.delay]
    
     */
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    /**
     * [descr:dxLoadPanelOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxLoadPanelOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxOverlayOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    /**
     * [descr:dxOverlayOptions.hideOnParentScroll]
    
     */
    get hideOnParentScroll() {
        return this._getOption('hideOnParentScroll');
    }
    set hideOnParentScroll(value) {
        this._setOption('hideOnParentScroll', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxLoadPanelOptions.indicatorSrc]
    
     */
    get indicatorSrc() {
        return this._getOption('indicatorSrc');
    }
    set indicatorSrc(value) {
        this._setOption('indicatorSrc', value);
    }
    /**
     * [descr:dxLoadPanelOptions.maxHeight]
    
     */
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    /**
     * [descr:dxLoadPanelOptions.maxWidth]
    
     */
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    /**
     * [descr:dxLoadPanelOptions.message]
    
     */
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    /**
     * [descr:dxOverlayOptions.minHeight]
    
     */
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    /**
     * [descr:dxOverlayOptions.minWidth]
    
     */
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    /**
     * [descr:dxLoadPanelOptions.position]
    
     */
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxOverlayOptions.shading]
    
     */
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    /**
     * [descr:dxLoadPanelOptions.shadingColor]
    
     */
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    /**
     * [descr:dxLoadPanelOptions.showIndicator]
    
     */
    get showIndicator() {
        return this._getOption('showIndicator');
    }
    set showIndicator(value) {
        this._setOption('showIndicator', value);
    }
    /**
     * [descr:dxLoadPanelOptions.showPane]
    
     */
    get showPane() {
        return this._getOption('showPane');
    }
    set showPane(value) {
        this._setOption('showPane', value);
    }
    /**
     * [descr:dxOverlayOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:dxLoadPanelOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxOverlayOptions.wrapperAttr]
    
     */
    get wrapperAttr() {
        return this._getOption('wrapperAttr');
    }
    set wrapperAttr(value) {
        this._setOption('wrapperAttr', value);
    }
    /**
    
     * [descr:dxLoadPanelOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxLoadPanelOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxLoadPanelOptions.onHidden]
    
    
     */
    onHidden;
    /**
    
     * [descr:dxLoadPanelOptions.onHiding]
    
    
     */
    onHiding;
    /**
    
     * [descr:dxLoadPanelOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxLoadPanelOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxLoadPanelOptions.onShowing]
    
    
     */
    onShowing;
    /**
    
     * [descr:dxLoadPanelOptions.onShown]
    
    
     */
    onShown;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    closeOnOutsideClickChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    delayChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnOutsideClickChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnParentScrollChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorSrcChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    messageChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingColorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showIndicatorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showPaneChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapperAttrChange;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'hidden', emit: 'onHidden' },
            { subscribe: 'hiding', emit: 'onHiding' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'showing', emit: 'onShowing' },
            { subscribe: 'shown', emit: 'onShown' },
            { emit: 'animationChange' },
            { emit: 'closeOnOutsideClickChange' },
            { emit: 'containerChange' },
            { emit: 'deferRenderingChange' },
            { emit: 'delayChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hideOnOutsideClickChange' },
            { emit: 'hideOnParentScrollChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'indicatorSrcChange' },
            { emit: 'maxHeightChange' },
            { emit: 'maxWidthChange' },
            { emit: 'messageChange' },
            { emit: 'minHeightChange' },
            { emit: 'minWidthChange' },
            { emit: 'positionChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'shadingChange' },
            { emit: 'shadingColorChange' },
            { emit: 'showIndicatorChange' },
            { emit: 'showPaneChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wrapperAttrChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxLoadPanel(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxLoadPanelComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxLoadPanelComponent, selector: "dx-load-panel", inputs: { animation: "animation", closeOnOutsideClick: "closeOnOutsideClick", container: "container", deferRendering: "deferRendering", delay: "delay", focusStateEnabled: "focusStateEnabled", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", indicatorSrc: "indicatorSrc", maxHeight: "maxHeight", maxWidth: "maxWidth", message: "message", minHeight: "minHeight", minWidth: "minWidth", position: "position", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showIndicator: "showIndicator", showPane: "showPane", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onShowing: "onShowing", onShown: "onShown", animationChange: "animationChange", closeOnOutsideClickChange: "closeOnOutsideClickChange", containerChange: "containerChange", deferRenderingChange: "deferRenderingChange", delayChange: "delayChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hideOnOutsideClickChange: "hideOnOutsideClickChange", hideOnParentScrollChange: "hideOnParentScrollChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", indicatorSrcChange: "indicatorSrcChange", maxHeightChange: "maxHeightChange", maxWidthChange: "maxWidthChange", messageChange: "messageChange", minHeightChange: "minHeightChange", minWidthChange: "minWidthChange", positionChange: "positionChange", rtlEnabledChange: "rtlEnabledChange", shadingChange: "shadingChange", shadingColorChange: "shadingColorChange", showIndicatorChange: "showIndicatorChange", showPaneChange: "showPaneChange", visibleChange: "visibleChange", widthChange: "widthChange", wrapperAttrChange: "wrapperAttrChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxLoadPanelComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-load-panel',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { animation: [{
                type: Input
            }], closeOnOutsideClick: [{
                type: Input
            }], container: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], delay: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hideOnParentScroll: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], indicatorSrc: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], message: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], position: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showIndicator: [{
                type: Input
            }], showPane: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapperAttr: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onHidden: [{
                type: Output
            }], onHiding: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onShowing: [{
                type: Output
            }], onShown: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], closeOnOutsideClickChange: [{
                type: Output
            }], containerChange: [{
                type: Output
            }], deferRenderingChange: [{
                type: Output
            }], delayChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hideOnOutsideClickChange: [{
                type: Output
            }], hideOnParentScrollChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], indicatorSrcChange: [{
                type: Output
            }], maxHeightChange: [{
                type: Output
            }], maxWidthChange: [{
                type: Output
            }], messageChange: [{
                type: Output
            }], minHeightChange: [{
                type: Output
            }], minWidthChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], shadingChange: [{
                type: Output
            }], shadingColorChange: [{
                type: Output
            }], showIndicatorChange: [{
                type: Output
            }], showPaneChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wrapperAttrChange: [{
                type: Output
            }] } });
class DxLoadPanelModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxLoadPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxLoadPanelModule, declarations: [DxLoadPanelComponent], imports: [DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxLoadPanelComponent, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxLoadPanelModule, imports: [DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxLoadPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxLoadPanelComponent
                    ],
                    exports: [
                        DxLoadPanelComponent,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxLoadPanelComponent, DxLoadPanelModule };
//# sourceMappingURL=devextreme-angular-ui-load-panel.mjs.map
