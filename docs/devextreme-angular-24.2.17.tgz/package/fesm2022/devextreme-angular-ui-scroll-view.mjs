import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, Input, Output, NgModule } from '@angular/core';
import DxScrollView from 'devextreme/ui/scroll_view';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost, DxIntegrationModule, DxTemplateModule } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxScrollView]

 */
class DxScrollViewComponent extends DxComponent {
    instance = null;
    /**
     * [descr:dxScrollableOptions.bounceEnabled]
    
     */
    get bounceEnabled() {
        return this._getOption('bounceEnabled');
    }
    set bounceEnabled(value) {
        this._setOption('bounceEnabled', value);
    }
    /**
     * [descr:dxScrollableOptions.direction]
    
     */
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    /**
     * [descr:dxScrollableOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxScrollViewOptions.pulledDownText]
    
     */
    get pulledDownText() {
        return this._getOption('pulledDownText');
    }
    set pulledDownText(value) {
        this._setOption('pulledDownText', value);
    }
    /**
     * [descr:dxScrollViewOptions.pullingDownText]
    
     */
    get pullingDownText() {
        return this._getOption('pullingDownText');
    }
    set pullingDownText(value) {
        this._setOption('pullingDownText', value);
    }
    /**
     * [descr:dxScrollViewOptions.reachBottomText]
    
     */
    get reachBottomText() {
        return this._getOption('reachBottomText');
    }
    set reachBottomText(value) {
        this._setOption('reachBottomText', value);
    }
    /**
     * [descr:dxScrollViewOptions.refreshingText]
    
     */
    get refreshingText() {
        return this._getOption('refreshingText');
    }
    set refreshingText(value) {
        this._setOption('refreshingText', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxScrollableOptions.scrollByContent]
    
     */
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    /**
     * [descr:dxScrollableOptions.scrollByThumb]
    
     */
    get scrollByThumb() {
        return this._getOption('scrollByThumb');
    }
    set scrollByThumb(value) {
        this._setOption('scrollByThumb', value);
    }
    /**
     * [descr:dxScrollableOptions.showScrollbar]
    
     */
    get showScrollbar() {
        return this._getOption('showScrollbar');
    }
    set showScrollbar(value) {
        this._setOption('showScrollbar', value);
    }
    /**
     * [descr:dxScrollableOptions.useNative]
    
     */
    get useNative() {
        return this._getOption('useNative');
    }
    set useNative(value) {
        this._setOption('useNative', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxScrollViewOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxScrollViewOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxScrollViewOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxScrollViewOptions.onPullDown]
    
    
     */
    onPullDown;
    /**
    
     * [descr:dxScrollViewOptions.onReachBottom]
    
    
     */
    onReachBottom;
    /**
    
     * [descr:dxScrollViewOptions.onScroll]
    
    
     */
    onScroll;
    /**
    
     * [descr:dxScrollViewOptions.onUpdated]
    
    
     */
    onUpdated;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    bounceEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    directionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pulledDownTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pullingDownTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    reachBottomTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    refreshingTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByContentChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByThumbChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showScrollbarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'pullDown', emit: 'onPullDown' },
            { subscribe: 'reachBottom', emit: 'onReachBottom' },
            { subscribe: 'scroll', emit: 'onScroll' },
            { subscribe: 'updated', emit: 'onUpdated' },
            { emit: 'bounceEnabledChange' },
            { emit: 'directionChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'heightChange' },
            { emit: 'pulledDownTextChange' },
            { emit: 'pullingDownTextChange' },
            { emit: 'reachBottomTextChange' },
            { emit: 'refreshingTextChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollByContentChange' },
            { emit: 'scrollByThumbChange' },
            { emit: 'showScrollbarChange' },
            { emit: 'useNativeChange' },
            { emit: 'widthChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxScrollView(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxScrollViewComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxScrollViewComponent, selector: "dx-scroll-view", inputs: { bounceEnabled: "bounceEnabled", direction: "direction", disabled: "disabled", elementAttr: "elementAttr", height: "height", pulledDownText: "pulledDownText", pullingDownText: "pullingDownText", reachBottomText: "reachBottomText", refreshingText: "refreshingText", rtlEnabled: "rtlEnabled", scrollByContent: "scrollByContent", scrollByThumb: "scrollByThumb", showScrollbar: "showScrollbar", useNative: "useNative", width: "width" }, outputs: { onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onPullDown: "onPullDown", onReachBottom: "onReachBottom", onScroll: "onScroll", onUpdated: "onUpdated", bounceEnabledChange: "bounceEnabledChange", directionChange: "directionChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", heightChange: "heightChange", pulledDownTextChange: "pulledDownTextChange", pullingDownTextChange: "pullingDownTextChange", reachBottomTextChange: "reachBottomTextChange", refreshingTextChange: "refreshingTextChange", rtlEnabledChange: "rtlEnabledChange", scrollByContentChange: "scrollByContentChange", scrollByThumbChange: "scrollByThumbChange", showScrollbarChange: "showScrollbarChange", useNativeChange: "useNativeChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxScrollViewComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-scroll-view',
                    template: '<ng-content></ng-content>',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { bounceEnabled: [{
                type: Input
            }], direction: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], height: [{
                type: Input
            }], pulledDownText: [{
                type: Input
            }], pullingDownText: [{
                type: Input
            }], reachBottomText: [{
                type: Input
            }], refreshingText: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrollByContent: [{
                type: Input
            }], scrollByThumb: [{
                type: Input
            }], showScrollbar: [{
                type: Input
            }], useNative: [{
                type: Input
            }], width: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onPullDown: [{
                type: Output
            }], onReachBottom: [{
                type: Output
            }], onScroll: [{
                type: Output
            }], onUpdated: [{
                type: Output
            }], bounceEnabledChange: [{
                type: Output
            }], directionChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], pulledDownTextChange: [{
                type: Output
            }], pullingDownTextChange: [{
                type: Output
            }], reachBottomTextChange: [{
                type: Output
            }], refreshingTextChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollByContentChange: [{
                type: Output
            }], scrollByThumbChange: [{
                type: Output
            }], showScrollbarChange: [{
                type: Output
            }], useNativeChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxScrollViewModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxScrollViewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxScrollViewModule, declarations: [DxScrollViewComponent], imports: [DxIntegrationModule,
            DxTemplateModule], exports: [DxScrollViewComponent, DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxScrollViewModule, imports: [DxIntegrationModule,
            DxTemplateModule, DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxScrollViewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxScrollViewComponent
                    ],
                    exports: [
                        DxScrollViewComponent,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxScrollViewComponent, DxScrollViewModule };
//# sourceMappingURL=devextreme-angular-ui-scroll-view.mjs.map
