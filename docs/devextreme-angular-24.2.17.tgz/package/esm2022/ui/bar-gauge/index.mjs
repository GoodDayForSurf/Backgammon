/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter } from '@angular/core';
import DxBarGauge from 'devextreme/viz/bar_gauge';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxoAnimationModule } from 'devextreme-angular/ui/nested';
import { DxoExportModule } from 'devextreme-angular/ui/nested';
import { DxoGeometryModule } from 'devextreme-angular/ui/nested';
import { DxoLabelModule } from 'devextreme-angular/ui/nested';
import { DxoFontModule } from 'devextreme-angular/ui/nested';
import { DxoFormatModule } from 'devextreme-angular/ui/nested';
import { DxoLegendModule } from 'devextreme-angular/ui/nested';
import { DxoBorderModule } from 'devextreme-angular/ui/nested';
import { DxoItemTextFormatModule } from 'devextreme-angular/ui/nested';
import { DxoMarginModule } from 'devextreme-angular/ui/nested';
import { DxoTitleModule } from 'devextreme-angular/ui/nested';
import { DxoSubtitleModule } from 'devextreme-angular/ui/nested';
import { DxoLoadingIndicatorModule } from 'devextreme-angular/ui/nested';
import { DxoSizeModule } from 'devextreme-angular/ui/nested';
import { DxoTooltipModule } from 'devextreme-angular/ui/nested';
import { DxoShadowModule } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxBarGauge]

 */
export class DxBarGaugeComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:dxBarGaugeOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxBarGaugeOptions.backgroundColor]
    
     */
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    /**
     * [descr:dxBarGaugeOptions.barSpacing]
    
     */
    get barSpacing() {
        return this._getOption('barSpacing');
    }
    set barSpacing(value) {
        this._setOption('barSpacing', value);
    }
    /**
     * [descr:dxBarGaugeOptions.baseValue]
    
     */
    get baseValue() {
        return this._getOption('baseValue');
    }
    set baseValue(value) {
        this._setOption('baseValue', value);
    }
    /**
     * [descr:dxBarGaugeOptions.centerTemplate]
    
     */
    get centerTemplate() {
        return this._getOption('centerTemplate');
    }
    set centerTemplate(value) {
        this._setOption('centerTemplate', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxBarGaugeOptions.endValue]
    
     */
    get endValue() {
        return this._getOption('endValue');
    }
    set endValue(value) {
        this._setOption('endValue', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxBarGaugeOptions.geometry]
    
     */
    get geometry() {
        return this._getOption('geometry');
    }
    set geometry(value) {
        this._setOption('geometry', value);
    }
    /**
     * [descr:dxBarGaugeOptions.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxBarGaugeOptions.legend]
    
     */
    get legend() {
        return this._getOption('legend');
    }
    set legend(value) {
        this._setOption('legend', value);
    }
    /**
     * [descr:dxBarGaugeOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:dxBarGaugeOptions.palette]
    
     */
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    /**
     * [descr:dxBarGaugeOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode() {
        return this._getOption('paletteExtensionMode');
    }
    set paletteExtensionMode(value) {
        this._setOption('paletteExtensionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:dxBarGaugeOptions.relativeInnerRadius]
    
     */
    get relativeInnerRadius() {
        return this._getOption('relativeInnerRadius');
    }
    set relativeInnerRadius(value) {
        this._setOption('relativeInnerRadius', value);
    }
    /**
     * [descr:dxBarGaugeOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping() {
        return this._getOption('resolveLabelOverlapping');
    }
    set resolveLabelOverlapping(value) {
        this._setOption('resolveLabelOverlapping', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxBarGaugeOptions.startValue]
    
     */
    get startValue() {
        return this._getOption('startValue');
    }
    set startValue(value) {
        this._setOption('startValue', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxBarGaugeOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxBarGaugeOptions.values]
    
     */
    get values() {
        return this._getOption('values');
    }
    set values(value) {
        this._setOption('values', value);
    }
    /**
    
     * [descr:dxBarGaugeOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxBarGaugeOptions.onDrawn]
    
    
     */
    onDrawn;
    /**
    
     * [descr:dxBarGaugeOptions.onExported]
    
    
     */
    onExported;
    /**
    
     * [descr:dxBarGaugeOptions.onExporting]
    
    
     */
    onExporting;
    /**
    
     * [descr:dxBarGaugeOptions.onFileSaving]
    
    
     */
    onFileSaving;
    /**
    
     * [descr:dxBarGaugeOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred;
    /**
    
     * [descr:dxBarGaugeOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxBarGaugeOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxBarGaugeOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden;
    /**
    
     * [descr:dxBarGaugeOptions.onTooltipShown]
    
    
     */
    onTooltipShown;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    backgroundColorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barSpacingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    baseValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    geometryChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    relativeInnerRadiusChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resolveLabelOverlappingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valuesChange;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { emit: 'animationChange' },
            { emit: 'backgroundColorChange' },
            { emit: 'barSpacingChange' },
            { emit: 'baseValueChange' },
            { emit: 'centerTemplateChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'endValueChange' },
            { emit: 'exportChange' },
            { emit: 'geometryChange' },
            { emit: 'labelChange' },
            { emit: 'legendChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'paletteChange' },
            { emit: 'paletteExtensionModeChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'relativeInnerRadiusChange' },
            { emit: 'resolveLabelOverlappingChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'sizeChange' },
            { emit: 'startValueChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'valuesChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxBarGauge(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('palette', changes);
        this.setupChanges('values', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('palette');
        this._idh.doCheck('values');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBarGaugeComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxBarGaugeComponent, selector: "dx-bar-gauge", inputs: { animation: "animation", backgroundColor: "backgroundColor", barSpacing: "barSpacing", baseValue: "baseValue", centerTemplate: "centerTemplate", disabled: "disabled", elementAttr: "elementAttr", endValue: "endValue", export: "export", geometry: "geometry", label: "label", legend: "legend", loadingIndicator: "loadingIndicator", margin: "margin", palette: "palette", paletteExtensionMode: "paletteExtensionMode", pathModified: "pathModified", redrawOnResize: "redrawOnResize", relativeInnerRadius: "relativeInnerRadius", resolveLabelOverlapping: "resolveLabelOverlapping", rtlEnabled: "rtlEnabled", size: "size", startValue: "startValue", theme: "theme", title: "title", tooltip: "tooltip", values: "values" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", animationChange: "animationChange", backgroundColorChange: "backgroundColorChange", barSpacingChange: "barSpacingChange", baseValueChange: "baseValueChange", centerTemplateChange: "centerTemplateChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", endValueChange: "endValueChange", exportChange: "exportChange", geometryChange: "geometryChange", labelChange: "labelChange", legendChange: "legendChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", paletteChange: "paletteChange", paletteExtensionModeChange: "paletteExtensionModeChange", pathModifiedChange: "pathModifiedChange", redrawOnResizeChange: "redrawOnResizeChange", relativeInnerRadiusChange: "relativeInnerRadiusChange", resolveLabelOverlappingChange: "resolveLabelOverlappingChange", rtlEnabledChange: "rtlEnabledChange", sizeChange: "sizeChange", startValueChange: "startValueChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", valuesChange: "valuesChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBarGaugeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-bar-gauge', template: '', providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { animation: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], barSpacing: [{
                type: Input
            }], baseValue: [{
                type: Input
            }], centerTemplate: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], endValue: [{
                type: Input
            }], export: [{
                type: Input
            }], geometry: [{
                type: Input
            }], label: [{
                type: Input
            }], legend: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteExtensionMode: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], relativeInnerRadius: [{
                type: Input
            }], resolveLabelOverlapping: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], size: [{
                type: Input
            }], startValue: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], values: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], backgroundColorChange: [{
                type: Output
            }], barSpacingChange: [{
                type: Output
            }], baseValueChange: [{
                type: Output
            }], centerTemplateChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], endValueChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], geometryChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], legendChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], paletteChange: [{
                type: Output
            }], paletteExtensionModeChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], relativeInnerRadiusChange: [{
                type: Output
            }], resolveLabelOverlappingChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], startValueChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], valuesChange: [{
                type: Output
            }] } });
export class DxBarGaugeModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBarGaugeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxBarGaugeModule, declarations: [DxBarGaugeComponent], imports: [DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxBarGaugeComponent, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBarGaugeModule, imports: [DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxBarGaugeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoAnimationModule,
                        DxoExportModule,
                        DxoGeometryModule,
                        DxoLabelModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLegendModule,
                        DxoBorderModule,
                        DxoItemTextFormatModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoShadowModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxBarGaugeComponent
                    ],
                    exports: [
                        DxBarGaugeComponent,
                        DxoAnimationModule,
                        DxoExportModule,
                        DxoGeometryModule,
                        DxoLabelModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLegendModule,
                        DxoBorderModule,
                        DxoItemTextFormatModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoShadowModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL2Jhci1nYXVnZS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUdwQyxPQUFPLEVBQ0gsYUFBYSxFQUNiLFNBQVMsRUFDVCxRQUFRLEVBQ1IsVUFBVSxFQUNWLE1BQU0sRUFDTixXQUFXLEVBQ1gsTUFBTSxFQUVOLEtBQUssRUFDTCxNQUFNLEVBRU4sWUFBWSxFQUlmLE1BQU0sZUFBZSxDQUFDO0FBU3ZCLE9BQU8sVUFBVSxNQUFNLDBCQUEwQixDQUFDO0FBR2xELE9BQU8sRUFDSCxXQUFXLEVBQ1gsY0FBYyxFQUNkLG1CQUFtQixFQUNuQixnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2hCLE1BQU0seUJBQXlCLENBQUM7QUFFakMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDdkUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNqRSxPQUFPLEVBQUUseUJBQXlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUN6RSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDOzs7QUFLL0Q7OztHQUdHO0FBWUgsTUFBTSxPQUFPLG1CQUFvQixTQUFRLFdBQVc7SUFxbkJoQztJQUNBO0lBcm5CaEIsUUFBUSxHQUFlLElBQUksQ0FBQztJQUU1Qjs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQTJFO1FBQ3JGLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBYTtRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWE7UUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBYTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQXNCO1FBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYztRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFVO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWE7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBOEw7UUFDck0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBaUQ7UUFDMUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBd0w7UUFDOUwsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBc29DO1FBQzdvQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBK0U7UUFDaEcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUF1RTtRQUM5RSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUF1QztRQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxvQkFBb0I7UUFDcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQUksb0JBQW9CLENBQUMsS0FBMkI7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUFjO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBYztRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBSSxtQkFBbUIsQ0FBQyxLQUFhO1FBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksdUJBQXVCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFDRCxJQUFJLHVCQUF1QixDQUFDLEtBQXdCO1FBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxJQUFJO1FBQ0osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxLQUFrRTtRQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFhO1FBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQVk7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBOFo7UUFDcGEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBNG1CO1FBQ3BuQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUFvQjtRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDTyxXQUFXLENBQStCO0lBRXBEOzs7OztPQUtHO0lBQ08sT0FBTyxDQUEyQjtJQUU1Qzs7Ozs7T0FLRztJQUNPLFVBQVUsQ0FBOEI7SUFFbEQ7Ozs7O09BS0c7SUFDTyxXQUFXLENBQStCO0lBRXBEOzs7OztPQUtHO0lBQ08sWUFBWSxDQUFnQztJQUV0RDs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7Ozs7T0FLRztJQUNPLGFBQWEsQ0FBaUM7SUFFeEQ7Ozs7O09BS0c7SUFDTyxlQUFlLENBQW1DO0lBRTVEOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLGNBQWMsQ0FBa0M7SUFFMUQ7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBcUY7SUFFOUc7Ozs7T0FJRztJQUNPLHFCQUFxQixDQUF1QjtJQUV0RDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQXVCO0lBRWpEOzs7O09BSUc7SUFDTyxlQUFlLENBQXVCO0lBRWhEOzs7O09BSUc7SUFDTyxvQkFBb0IsQ0FBZ0M7SUFFOUQ7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBd0I7SUFFaEQ7Ozs7T0FJRztJQUNPLGlCQUFpQixDQUFvQjtJQUUvQzs7OztPQUlHO0lBQ08sY0FBYyxDQUF1QjtJQUUvQzs7OztPQUlHO0lBQ08sWUFBWSxDQUF3TTtJQUU5Tjs7OztPQUlHO0lBQ08sY0FBYyxDQUEyRDtJQUVuRjs7OztPQUlHO0lBQ08sV0FBVyxDQUFrTTtJQUV2Tjs7OztPQUlHO0lBQ08sWUFBWSxDQUFncEM7SUFFdHFDOzs7O09BSUc7SUFDTyxzQkFBc0IsQ0FBeUY7SUFFekg7Ozs7T0FJRztJQUNPLFlBQVksQ0FBaUY7SUFFdkc7Ozs7T0FJRztJQUNPLGFBQWEsQ0FBaUQ7SUFFeEU7Ozs7T0FJRztJQUNPLDBCQUEwQixDQUFxQztJQUV6RTs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXdCO0lBRXBEOzs7O09BSUc7SUFDTyxvQkFBb0IsQ0FBd0I7SUFFdEQ7Ozs7T0FJRztJQUNPLHlCQUF5QixDQUF1QjtJQUUxRDs7OztPQUlHO0lBQ08sNkJBQTZCLENBQWtDO0lBRXpFOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBd0I7SUFFbEQ7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBNEU7SUFFaEc7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF1QjtJQUVqRDs7OztPQUlHO0lBQ08sV0FBVyxDQUFzQjtJQUUzQzs7OztPQUlHO0lBQ08sV0FBVyxDQUF3YTtJQUU3Yjs7OztPQUlHO0lBQ08sYUFBYSxDQUFzbkI7SUFFN29COzs7O09BSUc7SUFDTyxZQUFZLENBQThCO0lBUXBELFlBQVksVUFBc0IsRUFBRSxNQUFjLEVBQUUsWUFBNEIsRUFDaEUsY0FBNkIsRUFDN0IsSUFBMEIsRUFDbEMsVUFBNEIsRUFDNUIsYUFBNEIsRUFDUCxVQUFlO1FBRXhDLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBTnZFLG1CQUFjLEdBQWQsY0FBYyxDQUFlO1FBQzdCLFNBQUksR0FBSixJQUFJLENBQXNCO1FBT3RDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUN0QixFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRTtZQUN2QyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUM3QyxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUNqRCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDbkQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDakMsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDbEMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSw0QkFBNEIsRUFBRTtZQUN0QyxFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRTtZQUNoQyxFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRTtZQUNyQyxFQUFFLElBQUksRUFBRSwrQkFBK0IsRUFBRTtZQUN6QyxFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7WUFDdEIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1NBQzNCLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hCLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVTLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUV0QyxPQUFPLElBQUksVUFBVSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBR0QsV0FBVztRQUNQLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQzlCLEtBQUssQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUVELFlBQVksQ0FBQyxJQUFZLEVBQUUsT0FBc0I7UUFDN0MsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsQztJQUNMLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNwQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbEIsS0FBSyxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxJQUFZLEVBQUUsS0FBVTtRQUMvQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDakQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztRQUUzRCxJQUFJLE9BQU8sSUFBSSxTQUFTLEVBQUU7WUFDdEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDOzJIQTlzQlEsbUJBQW1CLDhOQXluQlosV0FBVzsrR0F6bkJsQixtQkFBbUIsb2tFQVBqQjtZQUNQLGNBQWM7WUFDZCxhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtTQUN2QixzRUFQUyxFQUFFOzs0RkFTSCxtQkFBbUI7a0JBWC9CLFNBQVM7K0JBQ0ksY0FBYyxZQUNkLEVBQUUsYUFFRDt3QkFDUCxjQUFjO3dCQUNkLGFBQWE7d0JBQ2IsZ0JBQWdCO3dCQUNoQixvQkFBb0I7cUJBQ3ZCOzswQkEybkJRLE1BQU07MkJBQUMsV0FBVzs0Q0FqbkJ2QixTQUFTO3NCQURaLEtBQUs7Z0JBY0YsZUFBZTtzQkFEbEIsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsU0FBUztzQkFEWixLQUFLO2dCQWNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLFdBQVc7c0JBRGQsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsTUFBTTtzQkFEVCxLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixLQUFLO3NCQURSLEtBQUs7Z0JBY0YsTUFBTTtzQkFEVCxLQUFLO2dCQWNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFjRixNQUFNO3NCQURULEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLG9CQUFvQjtzQkFEdkIsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0YsY0FBYztzQkFEakIsS0FBSztnQkFjRixtQkFBbUI7c0JBRHRCLEtBQUs7Z0JBY0YsdUJBQXVCO3NCQUQxQixLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixLQUFLO3NCQURSLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjSSxXQUFXO3NCQUFwQixNQUFNO2dCQVFHLE9BQU87c0JBQWhCLE1BQU07Z0JBUUcsVUFBVTtzQkFBbkIsTUFBTTtnQkFRRyxXQUFXO3NCQUFwQixNQUFNO2dCQVFHLFlBQVk7c0JBQXJCLE1BQU07Z0JBUUcsa0JBQWtCO3NCQUEzQixNQUFNO2dCQVFHLGFBQWE7c0JBQXRCLE1BQU07Z0JBUUcsZUFBZTtzQkFBeEIsTUFBTTtnQkFRRyxlQUFlO3NCQUF4QixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxzQkFBc0I7c0JBQS9CLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxhQUFhO3NCQUF0QixNQUFNO2dCQU9HLDBCQUEwQjtzQkFBbkMsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQU9HLHlCQUF5QjtzQkFBbEMsTUFBTTtnQkFPRyw2QkFBNkI7c0JBQXRDLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLFVBQVU7c0JBQW5CLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPRyxhQUFhO3NCQUF0QixNQUFNO2dCQU9HLFlBQVk7c0JBQXJCLE1BQU07O0FBa0pYLE1BQU0sT0FBTyxnQkFBZ0I7MkhBQWhCLGdCQUFnQjs0SEFBaEIsZ0JBQWdCLGlCQTl2QmhCLG1CQUFtQixhQW10QjVCLGtCQUFrQjtZQUNsQixlQUFlO1lBQ2YsaUJBQWlCO1lBQ2pCLGNBQWM7WUFDZCxhQUFhO1lBQ2IsZUFBZTtZQUNmLGVBQWU7WUFDZixlQUFlO1lBQ2YsdUJBQXVCO1lBQ3ZCLGVBQWU7WUFDZixjQUFjO1lBQ2QsaUJBQWlCO1lBQ2pCLHlCQUF5QjtZQUN6QixhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLGVBQWU7WUFDZixtQkFBbUI7WUFDbkIsZ0JBQWdCLGFBcHVCUCxtQkFBbUIsRUEydUI1QixrQkFBa0I7WUFDbEIsZUFBZTtZQUNmLGlCQUFpQjtZQUNqQixjQUFjO1lBQ2QsYUFBYTtZQUNiLGVBQWU7WUFDZixlQUFlO1lBQ2YsZUFBZTtZQUNmLHVCQUF1QjtZQUN2QixlQUFlO1lBQ2YsY0FBYztZQUNkLGlCQUFpQjtZQUNqQix5QkFBeUI7WUFDekIsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQixlQUFlO1lBQ2YsZ0JBQWdCOzRIQUdQLGdCQUFnQixZQTNDekIsa0JBQWtCO1lBQ2xCLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsY0FBYztZQUNkLGFBQWE7WUFDYixlQUFlO1lBQ2YsZUFBZTtZQUNmLGVBQWU7WUFDZix1QkFBdUI7WUFDdkIsZUFBZTtZQUNmLGNBQWM7WUFDZCxpQkFBaUI7WUFDakIseUJBQXlCO1lBQ3pCLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsZUFBZTtZQUNmLG1CQUFtQjtZQUNuQixnQkFBZ0IsRUFPaEIsa0JBQWtCO1lBQ2xCLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsY0FBYztZQUNkLGFBQWE7WUFDYixlQUFlO1lBQ2YsZUFBZTtZQUNmLGVBQWU7WUFDZix1QkFBdUI7WUFDdkIsZUFBZTtZQUNmLGNBQWM7WUFDZCxpQkFBaUI7WUFDakIseUJBQXlCO1lBQ3pCLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsZUFBZTtZQUNmLGdCQUFnQjs7NEZBR1AsZ0JBQWdCO2tCQTdDNUIsUUFBUTttQkFBQztvQkFDUixPQUFPLEVBQUU7d0JBQ1Asa0JBQWtCO3dCQUNsQixlQUFlO3dCQUNmLGlCQUFpQjt3QkFDakIsY0FBYzt3QkFDZCxhQUFhO3dCQUNiLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixlQUFlO3dCQUNmLHVCQUF1Qjt3QkFDdkIsZUFBZTt3QkFDZixjQUFjO3dCQUNkLGlCQUFpQjt3QkFDakIseUJBQXlCO3dCQUN6QixhQUFhO3dCQUNiLGdCQUFnQjt3QkFDaEIsZUFBZTt3QkFDZixtQkFBbUI7d0JBQ25CLGdCQUFnQjtxQkFDakI7b0JBQ0QsWUFBWSxFQUFFO3dCQUNaLG1CQUFtQjtxQkFDcEI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLG1CQUFtQjt3QkFDbkIsa0JBQWtCO3dCQUNsQixlQUFlO3dCQUNmLGlCQUFpQjt3QkFDakIsY0FBYzt3QkFDZCxhQUFhO3dCQUNiLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixlQUFlO3dCQUNmLHVCQUF1Qjt3QkFDdkIsZUFBZTt3QkFDZixjQUFjO3dCQUNkLGlCQUFpQjt3QkFDakIseUJBQXlCO3dCQUN6QixhQUFhO3dCQUNiLGdCQUFnQjt3QkFDaEIsZUFBZTt3QkFDZixnQkFBZ0I7cUJBQ2pCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG5cbmltcG9ydCB7XG4gICAgVHJhbnNmZXJTdGF0ZSxcbiAgICBDb21wb25lbnQsXG4gICAgTmdNb2R1bGUsXG4gICAgRWxlbWVudFJlZixcbiAgICBOZ1pvbmUsXG4gICAgUExBVEZPUk1fSUQsXG4gICAgSW5qZWN0LFxuXG4gICAgSW5wdXQsXG4gICAgT3V0cHV0LFxuICAgIE9uRGVzdHJveSxcbiAgICBFdmVudEVtaXR0ZXIsXG4gICAgT25DaGFuZ2VzLFxuICAgIERvQ2hlY2ssXG4gICAgU2ltcGxlQ2hhbmdlc1xufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG5pbXBvcnQgeyBFeHBvcnRGb3JtYXQsIEhvcml6b250YWxBbGlnbm1lbnQsIE9yaWVudGF0aW9uLCBQb3NpdGlvbiwgVmVydGljYWxFZGdlIH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24nO1xuaW1wb3J0IHsgQW5pbWF0aW9uRWFzZU1vZGUsIERhc2hTdHlsZSwgRm9udCwgUGFsZXR0ZSwgUGFsZXR0ZUV4dGVuc2lvbk1vZGUsIFNoaWZ0TGFiZWxPdmVybGFwLCBUZXh0T3ZlcmZsb3csIFRoZW1lLCBXb3JkV3JhcCB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uL2NoYXJ0cyc7XG5pbXBvcnQgeyBVc2VyRGVmaW5lZEVsZW1lbnQgfSBmcm9tICdkZXZleHRyZW1lL2NvcmUvZWxlbWVudCc7XG5pbXBvcnQgeyBGb3JtYXQgfSBmcm9tICdkZXZleHRyZW1lL2xvY2FsaXphdGlvbic7XG5pbXBvcnQgeyBEaXNwb3NpbmdFdmVudCwgRHJhd25FdmVudCwgRXhwb3J0ZWRFdmVudCwgRXhwb3J0aW5nRXZlbnQsIEZpbGVTYXZpbmdFdmVudCwgSW5jaWRlbnRPY2N1cnJlZEV2ZW50LCBJbml0aWFsaXplZEV2ZW50LCBPcHRpb25DaGFuZ2VkRXZlbnQsIFRvb2x0aXBIaWRkZW5FdmVudCwgVG9vbHRpcFNob3duRXZlbnQgfSBmcm9tICdkZXZleHRyZW1lL3Zpei9iYXJfZ2F1Z2UnO1xuXG5pbXBvcnQgRHhCYXJHYXVnZSBmcm9tICdkZXZleHRyZW1lL3Zpei9iYXJfZ2F1Z2UnO1xuXG5cbmltcG9ydCB7XG4gICAgRHhDb21wb25lbnQsXG4gICAgRHhUZW1wbGF0ZUhvc3QsXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlLFxuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgSXRlcmFibGVEaWZmZXJIZWxwZXIsXG4gICAgV2F0Y2hlckhlbHBlclxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IER4b0FuaW1hdGlvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvRXhwb3J0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9HZW9tZXRyeU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvTGFiZWxNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0ZvbnRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0Zvcm1hdE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvTGVnZW5kTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Cb3JkZXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0l0ZW1UZXh0Rm9ybWF0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9NYXJnaW5Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1RpdGxlTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9TdWJ0aXRsZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvTG9hZGluZ0luZGljYXRvck1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2l6ZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVG9vbHRpcE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2hhZG93TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5cblxuXG5cbi8qKlxuICogW2Rlc2NyOmR4QmFyR2F1Z2VdXG5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeC1iYXItZ2F1Z2UnLFxuICAgIHRlbXBsYXRlOiAnJyxcbiAgICBzdHlsZXM6IFsgJyA6aG9zdCB7ICBkaXNwbGF5OiBibG9jazsgfSddLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgV2F0Y2hlckhlbHBlcixcbiAgICAgICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4QmFyR2F1Z2VDb21wb25lbnQgZXh0ZW5kcyBEeENvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25DaGFuZ2VzLCBEb0NoZWNrIHtcbiAgICBpbnN0YW5jZTogRHhCYXJHYXVnZSA9IG51bGw7XG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMuYW5pbWF0aW9uXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFuaW1hdGlvbigpOiB7IGR1cmF0aW9uPzogbnVtYmVyLCBlYXNpbmc/OiBBbmltYXRpb25FYXNlTW9kZSwgZW5hYmxlZD86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FuaW1hdGlvbicpO1xuICAgIH1cbiAgICBzZXQgYW5pbWF0aW9uKHZhbHVlOiB7IGR1cmF0aW9uPzogbnVtYmVyLCBlYXNpbmc/OiBBbmltYXRpb25FYXNlTW9kZSwgZW5hYmxlZD86IGJvb2xlYW4gfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FuaW1hdGlvbicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5iYWNrZ3JvdW5kQ29sb3JdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYmFja2dyb3VuZENvbG9yKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2JhY2tncm91bmRDb2xvcicpO1xuICAgIH1cbiAgICBzZXQgYmFja2dyb3VuZENvbG9yKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdiYWNrZ3JvdW5kQ29sb3InLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMuYmFyU3BhY2luZ11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBiYXJTcGFjaW5nKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2JhclNwYWNpbmcnKTtcbiAgICB9XG4gICAgc2V0IGJhclNwYWNpbmcodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JhclNwYWNpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMuYmFzZVZhbHVlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGJhc2VWYWx1ZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdiYXNlVmFsdWUnKTtcbiAgICB9XG4gICAgc2V0IGJhc2VWYWx1ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmFzZVZhbHVlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLmNlbnRlclRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGNlbnRlclRlbXBsYXRlKCk6IGFueSB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NlbnRlclRlbXBsYXRlJyk7XG4gICAgfVxuICAgIHNldCBjZW50ZXJUZW1wbGF0ZSh2YWx1ZTogYW55IHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY2VudGVyVGVtcGxhdGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMuZGlzYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Rpc2FibGVkJyk7XG4gICAgfVxuICAgIHNldCBkaXNhYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Rpc2FibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMuZWxlbWVudEF0dHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZWxlbWVudEF0dHIoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcbiAgICB9XG4gICAgc2V0IGVsZW1lbnRBdHRyKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5lbmRWYWx1ZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBlbmRWYWx1ZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdlbmRWYWx1ZScpO1xuICAgIH1cbiAgICBzZXQgZW5kVmFsdWUodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2VuZFZhbHVlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkJhc2VXaWRnZXRPcHRpb25zLmV4cG9ydF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBleHBvcnQoKTogeyBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcsIGVuYWJsZWQ/OiBib29sZWFuLCBmaWxlTmFtZT86IHN0cmluZywgZm9ybWF0cz86IGFueSB8IEFycmF5PEV4cG9ydEZvcm1hdD4sIG1hcmdpbj86IG51bWJlciwgcHJpbnRpbmdFbmFibGVkPzogYm9vbGVhbiwgc3ZnVG9DYW52YXM/OiBGdW5jdGlvbiB8IHVuZGVmaW5lZCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZXhwb3J0Jyk7XG4gICAgfVxuICAgIHNldCBleHBvcnQodmFsdWU6IHsgYmFja2dyb3VuZENvbG9yPzogc3RyaW5nLCBlbmFibGVkPzogYm9vbGVhbiwgZmlsZU5hbWU/OiBzdHJpbmcsIGZvcm1hdHM/OiBhbnkgfCBBcnJheTxFeHBvcnRGb3JtYXQ+LCBtYXJnaW4/OiBudW1iZXIsIHByaW50aW5nRW5hYmxlZD86IGJvb2xlYW4sIHN2Z1RvQ2FudmFzPzogRnVuY3Rpb24gfCB1bmRlZmluZWQgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2V4cG9ydCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5nZW9tZXRyeV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBnZW9tZXRyeSgpOiB7IGVuZEFuZ2xlPzogbnVtYmVyLCBzdGFydEFuZ2xlPzogbnVtYmVyIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdnZW9tZXRyeScpO1xuICAgIH1cbiAgICBzZXQgZ2VvbWV0cnkodmFsdWU6IHsgZW5kQW5nbGU/OiBudW1iZXIsIHN0YXJ0QW5nbGU/OiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2dlb21ldHJ5JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLmxhYmVsXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGxhYmVsKCk6IHsgY29ubmVjdG9yQ29sb3I/OiBzdHJpbmcgfCB1bmRlZmluZWQsIGNvbm5lY3RvcldpZHRoPzogbnVtYmVyLCBjdXN0b21pemVUZXh0PzogRnVuY3Rpb24sIGZvbnQ/OiBGb250LCBmb3JtYXQ/OiBGb3JtYXQgfCBzdHJpbmcgfCB1bmRlZmluZWQsIGluZGVudD86IG51bWJlciwgdmlzaWJsZT86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2xhYmVsJyk7XG4gICAgfVxuICAgIHNldCBsYWJlbCh2YWx1ZTogeyBjb25uZWN0b3JDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgY29ubmVjdG9yV2lkdGg/OiBudW1iZXIsIGN1c3RvbWl6ZVRleHQ/OiBGdW5jdGlvbiwgZm9udD86IEZvbnQsIGZvcm1hdD86IEZvcm1hdCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaW5kZW50PzogbnVtYmVyLCB2aXNpYmxlPzogYm9vbGVhbiB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbGFiZWwnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMubGVnZW5kXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGxlZ2VuZCgpOiB7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgYm9yZGVyPzogeyBjb2xvcj86IHN0cmluZywgY29ybmVyUmFkaXVzPzogbnVtYmVyLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2x1bW5Db3VudD86IG51bWJlciwgY29sdW1uSXRlbVNwYWNpbmc/OiBudW1iZXIsIGN1c3RvbWl6ZUhpbnQ/OiBGdW5jdGlvbiwgY3VzdG9taXplSXRlbXM/OiBGdW5jdGlvbiwgY3VzdG9taXplVGV4dD86IEZ1bmN0aW9uLCBmb250PzogRm9udCwgaG9yaXpvbnRhbEFsaWdubWVudD86IEhvcml6b250YWxBbGlnbm1lbnQsIGl0ZW1zQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgaXRlbVRleHRGb3JtYXQ/OiBGb3JtYXQgfCBzdHJpbmcgfCB1bmRlZmluZWQsIGl0ZW1UZXh0UG9zaXRpb24/OiBQb3NpdGlvbiB8IHVuZGVmaW5lZCwgbWFyZ2luPzogbnVtYmVyIHwgeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgbWFya2VyU2l6ZT86IG51bWJlciwgbWFya2VyVGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIG9yaWVudGF0aW9uPzogT3JpZW50YXRpb24gfCB1bmRlZmluZWQsIHBhZGRpbmdMZWZ0UmlnaHQ/OiBudW1iZXIsIHBhZGRpbmdUb3BCb3R0b20/OiBudW1iZXIsIHJvd0NvdW50PzogbnVtYmVyLCByb3dJdGVtU3BhY2luZz86IG51bWJlciwgdGl0bGU/OiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgbWFyZ2luPzogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZyB9LCB0ZXh0Pzogc3RyaW5nLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSB9LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgdmlzaWJsZT86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2xlZ2VuZCcpO1xuICAgIH1cbiAgICBzZXQgbGVnZW5kKHZhbHVlOiB7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgYm9yZGVyPzogeyBjb2xvcj86IHN0cmluZywgY29ybmVyUmFkaXVzPzogbnVtYmVyLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2x1bW5Db3VudD86IG51bWJlciwgY29sdW1uSXRlbVNwYWNpbmc/OiBudW1iZXIsIGN1c3RvbWl6ZUhpbnQ/OiBGdW5jdGlvbiwgY3VzdG9taXplSXRlbXM/OiBGdW5jdGlvbiwgY3VzdG9taXplVGV4dD86IEZ1bmN0aW9uLCBmb250PzogRm9udCwgaG9yaXpvbnRhbEFsaWdubWVudD86IEhvcml6b250YWxBbGlnbm1lbnQsIGl0ZW1zQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgaXRlbVRleHRGb3JtYXQ/OiBGb3JtYXQgfCBzdHJpbmcgfCB1bmRlZmluZWQsIGl0ZW1UZXh0UG9zaXRpb24/OiBQb3NpdGlvbiB8IHVuZGVmaW5lZCwgbWFyZ2luPzogbnVtYmVyIHwgeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgbWFya2VyU2l6ZT86IG51bWJlciwgbWFya2VyVGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIG9yaWVudGF0aW9uPzogT3JpZW50YXRpb24gfCB1bmRlZmluZWQsIHBhZGRpbmdMZWZ0UmlnaHQ/OiBudW1iZXIsIHBhZGRpbmdUb3BCb3R0b20/OiBudW1iZXIsIHJvd0NvdW50PzogbnVtYmVyLCByb3dJdGVtU3BhY2luZz86IG51bWJlciwgdGl0bGU/OiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgbWFyZ2luPzogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZyB9LCB0ZXh0Pzogc3RyaW5nLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSB9LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgdmlzaWJsZT86IGJvb2xlYW4gfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2xlZ2VuZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5sb2FkaW5nSW5kaWNhdG9yXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGxvYWRpbmdJbmRpY2F0b3IoKTogeyBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcsIGZvbnQ/OiBGb250LCBzaG93PzogYm9vbGVhbiwgdGV4dD86IHN0cmluZyB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbG9hZGluZ0luZGljYXRvcicpO1xuICAgIH1cbiAgICBzZXQgbG9hZGluZ0luZGljYXRvcih2YWx1ZTogeyBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcsIGZvbnQ/OiBGb250LCBzaG93PzogYm9vbGVhbiwgdGV4dD86IHN0cmluZyB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbG9hZGluZ0luZGljYXRvcicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpCYXNlV2lkZ2V0T3B0aW9ucy5tYXJnaW5dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbWFyZ2luKCk6IHsgYm90dG9tPzogbnVtYmVyLCBsZWZ0PzogbnVtYmVyLCByaWdodD86IG51bWJlciwgdG9wPzogbnVtYmVyIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtYXJnaW4nKTtcbiAgICB9XG4gICAgc2V0IG1hcmdpbih2YWx1ZTogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21hcmdpbicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5wYWxldHRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBhbGV0dGUoKTogUGFsZXR0ZSB8IHN0cmluZyB8IEFycmF5PHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdwYWxldHRlJyk7XG4gICAgfVxuICAgIHNldCBwYWxldHRlKHZhbHVlOiBQYWxldHRlIHwgc3RyaW5nIHwgQXJyYXk8c3RyaW5nPikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BhbGV0dGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMucGFsZXR0ZUV4dGVuc2lvbk1vZGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcGFsZXR0ZUV4dGVuc2lvbk1vZGUoKTogUGFsZXR0ZUV4dGVuc2lvbk1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdwYWxldHRlRXh0ZW5zaW9uTW9kZScpO1xuICAgIH1cbiAgICBzZXQgcGFsZXR0ZUV4dGVuc2lvbk1vZGUodmFsdWU6IFBhbGV0dGVFeHRlbnNpb25Nb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncGFsZXR0ZUV4dGVuc2lvbk1vZGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMucGF0aE1vZGlmaWVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBhdGhNb2RpZmllZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncGF0aE1vZGlmaWVkJyk7XG4gICAgfVxuICAgIHNldCBwYXRoTW9kaWZpZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdwYXRoTW9kaWZpZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMucmVkcmF3T25SZXNpemVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcmVkcmF3T25SZXNpemUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3JlZHJhd09uUmVzaXplJyk7XG4gICAgfVxuICAgIHNldCByZWRyYXdPblJlc2l6ZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3JlZHJhd09uUmVzaXplJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLnJlbGF0aXZlSW5uZXJSYWRpdXNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcmVsYXRpdmVJbm5lclJhZGl1cygpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyZWxhdGl2ZUlubmVyUmFkaXVzJyk7XG4gICAgfVxuICAgIHNldCByZWxhdGl2ZUlubmVyUmFkaXVzKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdyZWxhdGl2ZUlubmVyUmFkaXVzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLnJlc29sdmVMYWJlbE92ZXJsYXBwaW5nXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJlc29sdmVMYWJlbE92ZXJsYXBwaW5nKCk6IFNoaWZ0TGFiZWxPdmVybGFwIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVzb2x2ZUxhYmVsT3ZlcmxhcHBpbmcnKTtcbiAgICB9XG4gICAgc2V0IHJlc29sdmVMYWJlbE92ZXJsYXBwaW5nKHZhbHVlOiBTaGlmdExhYmVsT3ZlcmxhcCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Jlc29sdmVMYWJlbE92ZXJsYXBwaW5nJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkJhc2VXaWRnZXRPcHRpb25zLnJ0bEVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcnRsRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncnRsRW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgcnRsRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3J0bEVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMuc2l6ZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaXplKCk6IHsgaGVpZ2h0PzogbnVtYmVyIHwgdW5kZWZpbmVkLCB3aWR0aD86IG51bWJlciB8IHVuZGVmaW5lZCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2l6ZScpO1xuICAgIH1cbiAgICBzZXQgc2l6ZSh2YWx1ZTogeyBoZWlnaHQ/OiBudW1iZXIgfCB1bmRlZmluZWQsIHdpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzaXplJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLnN0YXJ0VmFsdWVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc3RhcnRWYWx1ZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzdGFydFZhbHVlJyk7XG4gICAgfVxuICAgIHNldCBzdGFydFZhbHVlKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzdGFydFZhbHVlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkJhc2VXaWRnZXRPcHRpb25zLnRoZW1lXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRoZW1lKCk6IFRoZW1lIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGhlbWUnKTtcbiAgICB9XG4gICAgc2V0IHRoZW1lKHZhbHVlOiBUaGVtZSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RoZW1lJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkJhc2VXaWRnZXRPcHRpb25zLnRpdGxlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRpdGxlKCk6IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50LCBtYXJnaW4/OiBudW1iZXIgfCB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBwbGFjZWhvbGRlclNpemU/OiBudW1iZXIgfCB1bmRlZmluZWQsIHN1YnRpdGxlPzogc3RyaW5nIHwgeyBmb250PzogRm9udCwgb2Zmc2V0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nLCB0ZXh0T3ZlcmZsb3c/OiBUZXh0T3ZlcmZsb3csIHdvcmRXcmFwPzogV29yZFdyYXAgfSwgdGV4dD86IHN0cmluZywgdGV4dE92ZXJmbG93PzogVGV4dE92ZXJmbG93LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgd29yZFdyYXA/OiBXb3JkV3JhcCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGl0bGUnKTtcbiAgICB9XG4gICAgc2V0IHRpdGxlKHZhbHVlOiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCwgbWFyZ2luPzogbnVtYmVyIHwgeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZywgdGV4dE92ZXJmbG93PzogVGV4dE92ZXJmbG93LCB3b3JkV3JhcD86IFdvcmRXcmFwIH0sIHRleHQ/OiBzdHJpbmcsIHRleHRPdmVyZmxvdz86IFRleHRPdmVyZmxvdywgdmVydGljYWxBbGlnbm1lbnQ/OiBWZXJ0aWNhbEVkZ2UsIHdvcmRXcmFwPzogV29yZFdyYXAgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RpdGxlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLnRvb2x0aXBdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdG9vbHRpcCgpOiB7IGFycm93TGVuZ3RoPzogbnVtYmVyLCBib3JkZXI/OiB7IGNvbG9yPzogc3RyaW5nLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2xvcj86IHN0cmluZywgY29udGFpbmVyPzogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBjb250ZW50VGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIGNvcm5lclJhZGl1cz86IG51bWJlciwgY3VzdG9taXplVG9vbHRpcD86IEZ1bmN0aW9uIHwgdW5kZWZpbmVkLCBlbmFibGVkPzogYm9vbGVhbiwgZm9udD86IEZvbnQsIGZvcm1hdD86IEZvcm1hdCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaW50ZXJhY3RpdmU/OiBib29sZWFuLCBvcGFjaXR5PzogbnVtYmVyIHwgdW5kZWZpbmVkLCBwYWRkaW5nTGVmdFJpZ2h0PzogbnVtYmVyLCBwYWRkaW5nVG9wQm90dG9tPzogbnVtYmVyLCBzaGFkb3c/OiB7IGJsdXI/OiBudW1iZXIsIGNvbG9yPzogc3RyaW5nLCBvZmZzZXRYPzogbnVtYmVyLCBvZmZzZXRZPzogbnVtYmVyLCBvcGFjaXR5PzogbnVtYmVyIH0sIHpJbmRleD86IG51bWJlciB8IHVuZGVmaW5lZCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndG9vbHRpcCcpO1xuICAgIH1cbiAgICBzZXQgdG9vbHRpcCh2YWx1ZTogeyBhcnJvd0xlbmd0aD86IG51bWJlciwgYm9yZGVyPzogeyBjb2xvcj86IHN0cmluZywgZGFzaFN0eWxlPzogRGFzaFN0eWxlLCBvcGFjaXR5PzogbnVtYmVyIHwgdW5kZWZpbmVkLCB2aXNpYmxlPzogYm9vbGVhbiwgd2lkdGg/OiBudW1iZXIgfSwgY29sb3I/OiBzdHJpbmcsIGNvbnRhaW5lcj86IFVzZXJEZWZpbmVkRWxlbWVudCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgY29udGVudFRlbXBsYXRlPzogYW55IHwgdW5kZWZpbmVkLCBjb3JuZXJSYWRpdXM/OiBudW1iZXIsIGN1c3RvbWl6ZVRvb2x0aXA/OiBGdW5jdGlvbiB8IHVuZGVmaW5lZCwgZW5hYmxlZD86IGJvb2xlYW4sIGZvbnQ/OiBGb250LCBmb3JtYXQ/OiBGb3JtYXQgfCBzdHJpbmcgfCB1bmRlZmluZWQsIGludGVyYWN0aXZlPzogYm9vbGVhbiwgb3BhY2l0eT86IG51bWJlciB8IHVuZGVmaW5lZCwgcGFkZGluZ0xlZnRSaWdodD86IG51bWJlciwgcGFkZGluZ1RvcEJvdHRvbT86IG51bWJlciwgc2hhZG93PzogeyBibHVyPzogbnVtYmVyLCBjb2xvcj86IHN0cmluZywgb2Zmc2V0WD86IG51bWJlciwgb2Zmc2V0WT86IG51bWJlciwgb3BhY2l0eT86IG51bWJlciB9LCB6SW5kZXg/OiBudW1iZXIgfCB1bmRlZmluZWQgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rvb2x0aXAnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMudmFsdWVzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHZhbHVlcygpOiBBcnJheTxudW1iZXI+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmFsdWVzJyk7XG4gICAgfVxuICAgIHNldCB2YWx1ZXModmFsdWU6IEFycmF5PG51bWJlcj4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2YWx1ZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLm9uRGlzcG9zaW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkRpc3Bvc2luZzogRXZlbnRFbWl0dGVyPERpc3Bvc2luZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5vbkRyYXduXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkRyYXduOiBFdmVudEVtaXR0ZXI8RHJhd25FdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMub25FeHBvcnRlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25FeHBvcnRlZDogRXZlbnRFbWl0dGVyPEV4cG9ydGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLm9uRXhwb3J0aW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkV4cG9ydGluZzogRXZlbnRFbWl0dGVyPEV4cG9ydGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5vbkZpbGVTYXZpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRmlsZVNhdmluZzogRXZlbnRFbWl0dGVyPEZpbGVTYXZpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMub25JbmNpZGVudE9jY3VycmVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkluY2lkZW50T2NjdXJyZWQ6IEV2ZW50RW1pdHRlcjxJbmNpZGVudE9jY3VycmVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLm9uSW5pdGlhbGl6ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uSW5pdGlhbGl6ZWQ6IEV2ZW50RW1pdHRlcjxJbml0aWFsaXplZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEJhckdhdWdlT3B0aW9ucy5vbk9wdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uT3B0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPE9wdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhCYXJHYXVnZU9wdGlvbnMub25Ub29sdGlwSGlkZGVuXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblRvb2x0aXBIaWRkZW46IEV2ZW50RW1pdHRlcjxUb29sdGlwSGlkZGVuRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4QmFyR2F1Z2VPcHRpb25zLm9uVG9vbHRpcFNob3duXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblRvb2x0aXBTaG93bjogRXZlbnRFbWl0dGVyPFRvb2x0aXBTaG93bkV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGFuaW1hdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPHsgZHVyYXRpb24/OiBudW1iZXIsIGVhc2luZz86IEFuaW1hdGlvbkVhc2VNb2RlLCBlbmFibGVkPzogYm9vbGVhbiB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGJhY2tncm91bmRDb2xvckNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBiYXJTcGFjaW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGJhc2VWYWx1ZUNoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlcj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBjZW50ZXJUZW1wbGF0ZUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueSB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkaXNhYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZWxlbWVudEF0dHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZW5kVmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZXhwb3J0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcsIGVuYWJsZWQ/OiBib29sZWFuLCBmaWxlTmFtZT86IHN0cmluZywgZm9ybWF0cz86IGFueSB8IEFycmF5PEV4cG9ydEZvcm1hdD4sIG1hcmdpbj86IG51bWJlciwgcHJpbnRpbmdFbmFibGVkPzogYm9vbGVhbiwgc3ZnVG9DYW52YXM/OiBGdW5jdGlvbiB8IHVuZGVmaW5lZCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGdlb21ldHJ5Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBlbmRBbmdsZT86IG51bWJlciwgc3RhcnRBbmdsZT86IG51bWJlciB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGxhYmVsQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjb25uZWN0b3JDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgY29ubmVjdG9yV2lkdGg/OiBudW1iZXIsIGN1c3RvbWl6ZVRleHQ/OiBGdW5jdGlvbiwgZm9udD86IEZvbnQsIGZvcm1hdD86IEZvcm1hdCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaW5kZW50PzogbnVtYmVyLCB2aXNpYmxlPzogYm9vbGVhbiB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGxlZ2VuZENoYW5nZTogRXZlbnRFbWl0dGVyPHsgYmFja2dyb3VuZENvbG9yPzogc3RyaW5nIHwgdW5kZWZpbmVkLCBib3JkZXI/OiB7IGNvbG9yPzogc3RyaW5nLCBjb3JuZXJSYWRpdXM/OiBudW1iZXIsIGRhc2hTdHlsZT86IERhc2hTdHlsZSwgb3BhY2l0eT86IG51bWJlciB8IHVuZGVmaW5lZCwgdmlzaWJsZT86IGJvb2xlYW4sIHdpZHRoPzogbnVtYmVyIH0sIGNvbHVtbkNvdW50PzogbnVtYmVyLCBjb2x1bW5JdGVtU3BhY2luZz86IG51bWJlciwgY3VzdG9taXplSGludD86IEZ1bmN0aW9uLCBjdXN0b21pemVJdGVtcz86IEZ1bmN0aW9uLCBjdXN0b21pemVUZXh0PzogRnVuY3Rpb24sIGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCwgaXRlbXNBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50IHwgdW5kZWZpbmVkLCBpdGVtVGV4dEZvcm1hdD86IEZvcm1hdCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaXRlbVRleHRQb3NpdGlvbj86IFBvc2l0aW9uIHwgdW5kZWZpbmVkLCBtYXJnaW4/OiBudW1iZXIgfCB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBtYXJrZXJTaXplPzogbnVtYmVyLCBtYXJrZXJUZW1wbGF0ZT86IGFueSB8IHVuZGVmaW5lZCwgb3JpZW50YXRpb24/OiBPcmllbnRhdGlvbiB8IHVuZGVmaW5lZCwgcGFkZGluZ0xlZnRSaWdodD86IG51bWJlciwgcGFkZGluZ1RvcEJvdHRvbT86IG51bWJlciwgcm93Q291bnQ/OiBudW1iZXIsIHJvd0l0ZW1TcGFjaW5nPzogbnVtYmVyLCB0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50IHwgdW5kZWZpbmVkLCBtYXJnaW4/OiB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBwbGFjZWhvbGRlclNpemU/OiBudW1iZXIgfCB1bmRlZmluZWQsIHN1YnRpdGxlPzogc3RyaW5nIHwgeyBmb250PzogRm9udCwgb2Zmc2V0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nIH0sIHRleHQ/OiBzdHJpbmcsIHZlcnRpY2FsQWxpZ25tZW50PzogVmVydGljYWxFZGdlIH0sIHZlcnRpY2FsQWxpZ25tZW50PzogVmVydGljYWxFZGdlLCB2aXNpYmxlPzogYm9vbGVhbiB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGxvYWRpbmdJbmRpY2F0b3JDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZywgZm9udD86IEZvbnQsIHNob3c/OiBib29sZWFuLCB0ZXh0Pzogc3RyaW5nIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbWFyZ2luQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBwYWxldHRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8UGFsZXR0ZSB8IHN0cmluZyB8IEFycmF5PHN0cmluZz4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcGFsZXR0ZUV4dGVuc2lvbk1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxQYWxldHRlRXh0ZW5zaW9uTW9kZT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBwYXRoTW9kaWZpZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJlZHJhd09uUmVzaXplQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSByZWxhdGl2ZUlubmVyUmFkaXVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJlc29sdmVMYWJlbE92ZXJsYXBwaW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8U2hpZnRMYWJlbE92ZXJsYXA+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcnRsRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2l6ZUNoYW5nZTogRXZlbnRFbWl0dGVyPHsgaGVpZ2h0PzogbnVtYmVyIHwgdW5kZWZpbmVkLCB3aWR0aD86IG51bWJlciB8IHVuZGVmaW5lZCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHN0YXJ0VmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGhlbWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxUaGVtZT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0aXRsZUNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHsgZm9udD86IEZvbnQsIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50LCBtYXJnaW4/OiBudW1iZXIgfCB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBwbGFjZWhvbGRlclNpemU/OiBudW1iZXIgfCB1bmRlZmluZWQsIHN1YnRpdGxlPzogc3RyaW5nIHwgeyBmb250PzogRm9udCwgb2Zmc2V0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nLCB0ZXh0T3ZlcmZsb3c/OiBUZXh0T3ZlcmZsb3csIHdvcmRXcmFwPzogV29yZFdyYXAgfSwgdGV4dD86IHN0cmluZywgdGV4dE92ZXJmbG93PzogVGV4dE92ZXJmbG93LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgd29yZFdyYXA/OiBXb3JkV3JhcCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRvb2x0aXBDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGFycm93TGVuZ3RoPzogbnVtYmVyLCBib3JkZXI/OiB7IGNvbG9yPzogc3RyaW5nLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2xvcj86IHN0cmluZywgY29udGFpbmVyPzogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBjb250ZW50VGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIGNvcm5lclJhZGl1cz86IG51bWJlciwgY3VzdG9taXplVG9vbHRpcD86IEZ1bmN0aW9uIHwgdW5kZWZpbmVkLCBlbmFibGVkPzogYm9vbGVhbiwgZm9udD86IEZvbnQsIGZvcm1hdD86IEZvcm1hdCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaW50ZXJhY3RpdmU/OiBib29sZWFuLCBvcGFjaXR5PzogbnVtYmVyIHwgdW5kZWZpbmVkLCBwYWRkaW5nTGVmdFJpZ2h0PzogbnVtYmVyLCBwYWRkaW5nVG9wQm90dG9tPzogbnVtYmVyLCBzaGFkb3c/OiB7IGJsdXI/OiBudW1iZXIsIGNvbG9yPzogc3RyaW5nLCBvZmZzZXRYPzogbnVtYmVyLCBvZmZzZXRZPzogbnVtYmVyLCBvcGFjaXR5PzogbnVtYmVyIH0sIHpJbmRleD86IG51bWJlciB8IHVuZGVmaW5lZCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZhbHVlc0NoYW5nZTogRXZlbnRFbWl0dGVyPEFycmF5PG51bWJlcj4+O1xuXG5cblxuXG5cblxuXG4gICAgY29uc3RydWN0b3IoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgbmdab25lOiBOZ1pvbmUsIHRlbXBsYXRlSG9zdDogRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIF93YXRjaGVySGVscGVyOiBXYXRjaGVySGVscGVyLFxuICAgICAgICAgICAgcHJpdmF0ZSBfaWRoOiBJdGVyYWJsZURpZmZlckhlbHBlcixcbiAgICAgICAgICAgIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICB0cmFuc2ZlclN0YXRlOiBUcmFuc2ZlclN0YXRlLFxuICAgICAgICAgICAgQEluamVjdChQTEFURk9STV9JRCkgcGxhdGZvcm1JZDogYW55KSB7XG5cbiAgICAgICAgc3VwZXIoZWxlbWVudFJlZiwgbmdab25lLCB0ZW1wbGF0ZUhvc3QsIF93YXRjaGVySGVscGVyLCB0cmFuc2ZlclN0YXRlLCBwbGF0Zm9ybUlkKTtcblxuICAgICAgICB0aGlzLl9jcmVhdGVFdmVudEVtaXR0ZXJzKFtcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZGlzcG9zaW5nJywgZW1pdDogJ29uRGlzcG9zaW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkcmF3bicsIGVtaXQ6ICdvbkRyYXduJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdleHBvcnRlZCcsIGVtaXQ6ICdvbkV4cG9ydGVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdleHBvcnRpbmcnLCBlbWl0OiAnb25FeHBvcnRpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2ZpbGVTYXZpbmcnLCBlbWl0OiAnb25GaWxlU2F2aW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdpbmNpZGVudE9jY3VycmVkJywgZW1pdDogJ29uSW5jaWRlbnRPY2N1cnJlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5pdGlhbGl6ZWQnLCBlbWl0OiAnb25Jbml0aWFsaXplZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnb3B0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvbk9wdGlvbkNoYW5nZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rvb2x0aXBIaWRkZW4nLCBlbWl0OiAnb25Ub29sdGlwSGlkZGVuJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0b29sdGlwU2hvd24nLCBlbWl0OiAnb25Ub29sdGlwU2hvd24nIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdhbmltYXRpb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdiYWNrZ3JvdW5kQ29sb3JDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdiYXJTcGFjaW5nQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYmFzZVZhbHVlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnY2VudGVyVGVtcGxhdGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdkaXNhYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2VsZW1lbnRBdHRyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZW5kVmFsdWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdleHBvcnRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdnZW9tZXRyeUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2xhYmVsQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnbGVnZW5kQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnbG9hZGluZ0luZGljYXRvckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ21hcmdpbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3BhbGV0dGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdwYWxldHRlRXh0ZW5zaW9uTW9kZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3BhdGhNb2RpZmllZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3JlZHJhd09uUmVzaXplQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncmVsYXRpdmVJbm5lclJhZGl1c0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Jlc29sdmVMYWJlbE92ZXJsYXBwaW5nQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncnRsRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NpemVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzdGFydFZhbHVlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGhlbWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0aXRsZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rvb2x0aXBDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2YWx1ZXNDaGFuZ2UnIH1cbiAgICAgICAgXSk7XG5cbiAgICAgICAgdGhpcy5faWRoLnNldEhvc3QodGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgX2NyZWF0ZUluc3RhbmNlKGVsZW1lbnQsIG9wdGlvbnMpIHtcblxuICAgICAgICByZXR1cm4gbmV3IER4QmFyR2F1Z2UoZWxlbWVudCwgb3B0aW9ucyk7XG4gICAgfVxuXG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fZGVzdHJveVdpZGdldCgpO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgc3VwZXIubmdPbkNoYW5nZXMoY2hhbmdlcyk7XG4gICAgICAgIHRoaXMuc2V0dXBDaGFuZ2VzKCdwYWxldHRlJywgY2hhbmdlcyk7XG4gICAgICAgIHRoaXMuc2V0dXBDaGFuZ2VzKCd2YWx1ZXMnLCBjaGFuZ2VzKTtcbiAgICB9XG5cbiAgICBzZXR1cENoYW5nZXMocHJvcDogc3RyaW5nLCBjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgICAgIGlmICghKHByb3AgaW4gdGhpcy5fb3B0aW9uc1RvVXBkYXRlKSkge1xuICAgICAgICAgICAgdGhpcy5faWRoLnNldHVwKHByb3AsIGNoYW5nZXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdEb0NoZWNrKCkge1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygncGFsZXR0ZScpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygndmFsdWVzJyk7XG4gICAgICAgIHRoaXMuX3dhdGNoZXJIZWxwZXIuY2hlY2tXYXRjaGVycygpO1xuICAgICAgICBzdXBlci5uZ0RvQ2hlY2soKTtcbiAgICAgICAgc3VwZXIuY2xlYXJDaGFuZ2VkT3B0aW9ucygpO1xuICAgIH1cblxuICAgIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XG4gICAgICAgIGxldCBpc1NldHVwID0gdGhpcy5faWRoLnNldHVwU2luZ2xlKG5hbWUsIHZhbHVlKTtcbiAgICAgICAgbGV0IGlzQ2hhbmdlZCA9IHRoaXMuX2lkaC5nZXRDaGFuZ2VzKG5hbWUsIHZhbHVlKSAhPT0gbnVsbDtcblxuICAgICAgICBpZiAoaXNTZXR1cCB8fCBpc0NoYW5nZWQpIHtcbiAgICAgICAgICAgIHN1cGVyLl9zZXRPcHRpb24obmFtZSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgRHhvQW5pbWF0aW9uTW9kdWxlLFxuICAgIER4b0V4cG9ydE1vZHVsZSxcbiAgICBEeG9HZW9tZXRyeU1vZHVsZSxcbiAgICBEeG9MYWJlbE1vZHVsZSxcbiAgICBEeG9Gb250TW9kdWxlLFxuICAgIER4b0Zvcm1hdE1vZHVsZSxcbiAgICBEeG9MZWdlbmRNb2R1bGUsXG4gICAgRHhvQm9yZGVyTW9kdWxlLFxuICAgIER4b0l0ZW1UZXh0Rm9ybWF0TW9kdWxlLFxuICAgIER4b01hcmdpbk1vZHVsZSxcbiAgICBEeG9UaXRsZU1vZHVsZSxcbiAgICBEeG9TdWJ0aXRsZU1vZHVsZSxcbiAgICBEeG9Mb2FkaW5nSW5kaWNhdG9yTW9kdWxlLFxuICAgIER4b1NpemVNb2R1bGUsXG4gICAgRHhvVG9vbHRpcE1vZHVsZSxcbiAgICBEeG9TaGFkb3dNb2R1bGUsXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlXG4gIF0sXG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4QmFyR2F1Z2VDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4QmFyR2F1Z2VDb21wb25lbnQsXG4gICAgRHhvQW5pbWF0aW9uTW9kdWxlLFxuICAgIER4b0V4cG9ydE1vZHVsZSxcbiAgICBEeG9HZW9tZXRyeU1vZHVsZSxcbiAgICBEeG9MYWJlbE1vZHVsZSxcbiAgICBEeG9Gb250TW9kdWxlLFxuICAgIER4b0Zvcm1hdE1vZHVsZSxcbiAgICBEeG9MZWdlbmRNb2R1bGUsXG4gICAgRHhvQm9yZGVyTW9kdWxlLFxuICAgIER4b0l0ZW1UZXh0Rm9ybWF0TW9kdWxlLFxuICAgIER4b01hcmdpbk1vZHVsZSxcbiAgICBEeG9UaXRsZU1vZHVsZSxcbiAgICBEeG9TdWJ0aXRsZU1vZHVsZSxcbiAgICBEeG9Mb2FkaW5nSW5kaWNhdG9yTW9kdWxlLFxuICAgIER4b1NpemVNb2R1bGUsXG4gICAgRHhvVG9vbHRpcE1vZHVsZSxcbiAgICBEeG9TaGFkb3dNb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZVxuICBdXG59KVxuZXhwb3J0IGNsYXNzIER4QmFyR2F1Z2VNb2R1bGUgeyB9XG5cbmltcG9ydCB0eXBlICogYXMgRHhCYXJHYXVnZVR5cGVzIGZyb20gXCJkZXZleHRyZW1lL3Zpei9iYXJfZ2F1Z2VfdHlwZXNcIjtcbmV4cG9ydCB7IER4QmFyR2F1Z2VUeXBlcyB9O1xuXG5cbiJdfQ==