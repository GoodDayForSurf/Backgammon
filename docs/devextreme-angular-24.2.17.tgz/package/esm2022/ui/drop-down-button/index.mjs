/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import DxDropDownButton from 'devextreme/ui/drop_down_button';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxoDropDownOptionsModule } from 'devextreme-angular/ui/nested';
import { DxoAnimationModule } from 'devextreme-angular/ui/nested';
import { DxoHideModule } from 'devextreme-angular/ui/nested';
import { DxoFromModule } from 'devextreme-angular/ui/nested';
import { DxoPositionModule } from 'devextreme-angular/ui/nested';
import { DxoAtModule } from 'devextreme-angular/ui/nested';
import { DxoBoundaryOffsetModule } from 'devextreme-angular/ui/nested';
import { DxoCollisionModule } from 'devextreme-angular/ui/nested';
import { DxoMyModule } from 'devextreme-angular/ui/nested';
import { DxoOffsetModule } from 'devextreme-angular/ui/nested';
import { DxoToModule } from 'devextreme-angular/ui/nested';
import { DxoShowModule } from 'devextreme-angular/ui/nested';
import { DxiToolbarItemModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxiItemComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxDropDownButton]

 */
export class DxDropDownButtonComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.deferRendering]
    
     */
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.dropDownContentTemplate]
    
     */
    get dropDownContentTemplate() {
        return this._getOption('dropDownContentTemplate');
    }
    set dropDownContentTemplate(value) {
        this._setOption('dropDownContentTemplate', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.dropDownOptions]
    
     */
    get dropDownOptions() {
        return this._getOption('dropDownOptions');
    }
    set dropDownOptions(value) {
        this._setOption('dropDownOptions', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.icon]
    
     */
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.keyExpr]
    
     */
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.opened]
    
     */
    get opened() {
        return this._getOption('opened');
    }
    set opened(value) {
        this._setOption('opened', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.selectedItemKey]
    
     */
    get selectedItemKey() {
        return this._getOption('selectedItemKey');
    }
    set selectedItemKey(value) {
        this._setOption('selectedItemKey', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.showArrowIcon]
    
     */
    get showArrowIcon() {
        return this._getOption('showArrowIcon');
    }
    set showArrowIcon(value) {
        this._setOption('showArrowIcon', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.splitButton]
    
     */
    get splitButton() {
        return this._getOption('splitButton');
    }
    set splitButton(value) {
        this._setOption('splitButton', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.stylingMode]
    
     */
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.template]
    
     */
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.text]
    
     */
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.type]
    
     */
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle() {
        return this._getOption('useItemTextAsTitle');
    }
    set useItemTextAsTitle(value) {
        this._setOption('useItemTextAsTitle', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.useSelectMode]
    
     */
    get useSelectMode() {
        return this._getOption('useSelectMode');
    }
    set useSelectMode(value) {
        this._setOption('useSelectMode', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.wrapItemText]
    
     */
    get wrapItemText() {
        return this._getOption('wrapItemText');
    }
    set wrapItemText(value) {
        this._setOption('wrapItemText', value);
    }
    /**
    
     * [descr:dxDropDownButtonOptions.onButtonClick]
    
    
     */
    onButtonClick;
    /**
    
     * [descr:dxDropDownButtonOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxDropDownButtonOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxDropDownButtonOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxDropDownButtonOptions.onItemClick]
    
    
     */
    onItemClick;
    /**
    
     * [descr:dxDropDownButtonOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxDropDownButtonOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownOptionsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    iconChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showArrowIconChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    splitButtonChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    templateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useItemTextAsTitleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useSelectModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapItemTextChange;
    get itemsChildren() {
        return this._getOption('items');
    }
    set itemsChildren(value) {
        this.setChildren('items', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'buttonClick', emit: 'onButtonClick' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'dataSourceChange' },
            { emit: 'deferRenderingChange' },
            { emit: 'disabledChange' },
            { emit: 'displayExprChange' },
            { emit: 'dropDownContentTemplateChange' },
            { emit: 'dropDownOptionsChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'iconChange' },
            { emit: 'itemsChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'keyExprChange' },
            { emit: 'noDataTextChange' },
            { emit: 'openedChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'selectedItemChange' },
            { emit: 'selectedItemKeyChange' },
            { emit: 'showArrowIconChange' },
            { emit: 'splitButtonChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'templateChange' },
            { emit: 'textChange' },
            { emit: 'typeChange' },
            { emit: 'useItemTextAsTitleChange' },
            { emit: 'useSelectModeChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wrapItemTextChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxDropDownButton(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDropDownButtonComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxDropDownButtonComponent, selector: "dx-drop-down-button", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", displayExpr: "displayExpr", dropDownContentTemplate: "dropDownContentTemplate", dropDownOptions: "dropDownOptions", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", items: "items", itemTemplate: "itemTemplate", keyExpr: "keyExpr", noDataText: "noDataText", opened: "opened", rtlEnabled: "rtlEnabled", selectedItem: "selectedItem", selectedItemKey: "selectedItemKey", showArrowIcon: "showArrowIcon", splitButton: "splitButton", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useItemTextAsTitle: "useItemTextAsTitle", useSelectMode: "useSelectMode", visible: "visible", width: "width", wrapItemText: "wrapItemText" }, outputs: { onButtonClick: "onButtonClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", dataSourceChange: "dataSourceChange", deferRenderingChange: "deferRenderingChange", disabledChange: "disabledChange", displayExprChange: "displayExprChange", dropDownContentTemplateChange: "dropDownContentTemplateChange", dropDownOptionsChange: "dropDownOptionsChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", iconChange: "iconChange", itemsChange: "itemsChange", itemTemplateChange: "itemTemplateChange", keyExprChange: "keyExprChange", noDataTextChange: "noDataTextChange", openedChange: "openedChange", rtlEnabledChange: "rtlEnabledChange", selectedItemChange: "selectedItemChange", selectedItemKeyChange: "selectedItemKeyChange", showArrowIconChange: "showArrowIconChange", splitButtonChange: "splitButtonChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", templateChange: "templateChange", textChange: "textChange", typeChange: "typeChange", useItemTextAsTitleChange: "useItemTextAsTitleChange", useSelectModeChange: "useSelectModeChange", visibleChange: "visibleChange", widthChange: "widthChange", wrapItemTextChange: "wrapItemTextChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "itemsChildren", predicate: DxiItemComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDropDownButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-drop-down-button',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], dropDownContentTemplate: [{
                type: Input
            }], dropDownOptions: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], opened: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], selectedItemKey: [{
                type: Input
            }], showArrowIcon: [{
                type: Input
            }], splitButton: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useItemTextAsTitle: [{
                type: Input
            }], useSelectMode: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapItemText: [{
                type: Input
            }], onButtonClick: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], deferRenderingChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], dropDownContentTemplateChange: [{
                type: Output
            }], dropDownOptionsChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], iconChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], keyExprChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], openedChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], selectedItemKeyChange: [{
                type: Output
            }], showArrowIconChange: [{
                type: Output
            }], splitButtonChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], templateChange: [{
                type: Output
            }], textChange: [{
                type: Output
            }], typeChange: [{
                type: Output
            }], useItemTextAsTitleChange: [{
                type: Output
            }], useSelectModeChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wrapItemTextChange: [{
                type: Output
            }], itemsChildren: [{
                type: ContentChildren,
                args: [DxiItemComponent]
            }] } });
export class DxDropDownButtonModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDropDownButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxDropDownButtonModule, declarations: [DxDropDownButtonComponent], imports: [DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxDropDownButtonComponent, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDropDownButtonModule, imports: [DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxIntegrationModule,
            DxTemplateModule, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDropDownButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiToolbarItemModule,
                        DxiItemModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxDropDownButtonComponent
                    ],
                    exports: [
                        DxDropDownButtonComponent,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiToolbarItemModule,
                        DxiItemModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL2Ryb3AtZG93bi1idXR0b24vaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUNILGFBQWEsRUFDYixTQUFTLEVBQ1QsUUFBUSxFQUNSLFVBQVUsRUFDVixNQUFNLEVBQ04sV0FBVyxFQUNYLE1BQU0sRUFFTixLQUFLLEVBQ0wsTUFBTSxFQUVOLFlBQVksRUFJWixlQUFlLEVBQ2YsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBU3ZCLE9BQU8sZ0JBQWdCLE1BQU0sZ0NBQWdDLENBQUM7QUFHOUQsT0FBTyxFQUNILFdBQVcsRUFDWCxjQUFjLEVBQ2QsbUJBQW1CLEVBQ25CLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsb0JBQW9CLEVBQ3BCLGFBQWEsRUFDaEIsTUFBTSx5QkFBeUIsQ0FBQztBQUVqQyxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUN4RSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUN2RSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDM0QsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBRTdELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDOzs7QUFJaEU7OztHQUdHO0FBV0gsTUFBTSxPQUFPLHlCQUEwQixTQUFRLFdBQVc7SUFpdkJ0QztJQUNBO0lBanZCaEIsUUFBUSxHQUFxQixJQUFJLENBQUM7SUFFbEM7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUF5QjtRQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxrQkFBa0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDakQsQ0FBQztJQUNELElBQUksa0JBQWtCLENBQUMsS0FBYztRQUNqQyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWlHO1FBQzVHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBYztRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBb0M7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksdUJBQXVCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFDRCxJQUFJLHVCQUF1QixDQUFDLEtBQVU7UUFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQXFCO1FBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBVTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxpQkFBaUI7UUFDakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQUksaUJBQWlCLENBQUMsS0FBYztRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQTZDO1FBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQXlCO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBeUI7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBOEo7UUFDcEssSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBVTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFhO1FBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWE7UUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBYztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFjO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQTRCO1FBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBc0I7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFjO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFdBQVc7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNELElBQUksV0FBVyxDQUFDLEtBQWM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBa0I7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFVO1FBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQWE7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBaUI7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQWM7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFjO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBNkM7UUFDbkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBYztRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFrQztJQUUxRDs7Ozs7T0FLRztJQUNPLFdBQVcsQ0FBK0I7SUFFcEQ7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sV0FBVyxDQUErQjtJQUVwRDs7Ozs7T0FLRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7O09BS0c7SUFDTyxrQkFBa0IsQ0FBc0M7SUFFbEU7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7T0FJRztJQUNPLHdCQUF3QixDQUF3QjtJQUUxRDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQTJHO0lBRXJJOzs7O09BSUc7SUFDTyxvQkFBb0IsQ0FBd0I7SUFFdEQ7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBd0I7SUFFaEQ7Ozs7T0FJRztJQUNPLGlCQUFpQixDQUE4QztJQUV6RTs7OztPQUlHO0lBQ08sNkJBQTZCLENBQW9CO0lBRTNEOzs7O09BSUc7SUFDTyxxQkFBcUIsQ0FBK0I7SUFFOUQ7Ozs7T0FJRztJQUNPLGlCQUFpQixDQUFvQjtJQUUvQzs7OztPQUlHO0lBQ08sdUJBQXVCLENBQXdCO0lBRXpEOzs7O09BSUc7SUFDTyxZQUFZLENBQXVEO0lBRTdFOzs7O09BSUc7SUFDTyxVQUFVLENBQW1DO0lBRXZEOzs7O09BSUc7SUFDTyx1QkFBdUIsQ0FBd0I7SUFFekQ7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBbUM7SUFFdkQ7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBd0s7SUFFN0w7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFvQjtJQUVoRDs7OztPQUlHO0lBQ08sYUFBYSxDQUF1QjtJQUU5Qzs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQXVCO0lBRWpEOzs7O09BSUc7SUFDTyxZQUFZLENBQXdCO0lBRTlDOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBd0I7SUFFbEQ7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7OztPQUlHO0lBQ08scUJBQXFCLENBQWdDO0lBRS9EOzs7O09BSUc7SUFDTyxtQkFBbUIsQ0FBd0I7SUFFckQ7Ozs7T0FJRztJQUNPLGlCQUFpQixDQUF3QjtJQUVuRDs7OztPQUlHO0lBQ08saUJBQWlCLENBQTRCO0lBRXZEOzs7O09BSUc7SUFDTyxjQUFjLENBQXVCO0lBRS9DOzs7O09BSUc7SUFDTyxjQUFjLENBQW9CO0lBRTVDOzs7O09BSUc7SUFDTyxVQUFVLENBQXVCO0lBRTNDOzs7O09BSUc7SUFDTyxVQUFVLENBQTJCO0lBRS9DOzs7O09BSUc7SUFDTyx3QkFBd0IsQ0FBd0I7SUFFMUQ7Ozs7T0FJRztJQUNPLG1CQUFtQixDQUF3QjtJQUVyRDs7OztPQUlHO0lBQ08sYUFBYSxDQUF3QjtJQUUvQzs7OztPQUlHO0lBQ08sV0FBVyxDQUF1RDtJQUU1RTs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXdCO0lBS3BELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBSztRQUNuQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBS0QsWUFBWSxVQUFzQixFQUFFLE1BQWMsRUFBRSxZQUE0QixFQUNoRSxjQUE2QixFQUM3QixJQUEwQixFQUNsQyxVQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFFeEMsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFOdkUsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFDN0IsU0FBSSxHQUFKLElBQUksQ0FBc0I7UUFPdEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ25ELEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDL0MsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDbkQsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDL0MsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUU7WUFDcEMsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsK0JBQStCLEVBQUU7WUFDekMsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDakMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUNuQyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7WUFDdEIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDakMsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0IsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQ3RCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSwwQkFBMEIsRUFBRTtZQUNwQyxFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvQixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1NBQ2pDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hCLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVTLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUV0QyxPQUFPLElBQUksZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFHRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDOUIsS0FBSyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsWUFBWSxDQUFDLElBQVksRUFBRSxPQUFzQjtRQUM3QyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ2xDO0lBQ0wsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3BDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNsQixLQUFLLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRUQsVUFBVSxDQUFDLElBQVksRUFBRSxLQUFVO1FBQy9CLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNqRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDO1FBRTNELElBQUksT0FBTyxJQUFJLFNBQVMsRUFBRTtZQUN0QixLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7MkhBOTBCUSx5QkFBeUIsOE5BcXZCbEIsV0FBVzsrR0FydkJsQix5QkFBeUIsdS9FQVB2QjtZQUNQLGNBQWM7WUFDZCxhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtTQUN2Qix3REF1dUJnQixnQkFBZ0IseUVBN3VCdkIsRUFBRTs7NEZBUUgseUJBQXlCO2tCQVZyQyxTQUFTO21CQUFDO29CQUNQLFFBQVEsRUFBRSxxQkFBcUI7b0JBQy9CLFFBQVEsRUFBRSxFQUFFO29CQUNaLFNBQVMsRUFBRTt3QkFDUCxjQUFjO3dCQUNkLGFBQWE7d0JBQ2IsZ0JBQWdCO3dCQUNoQixvQkFBb0I7cUJBQ3ZCO2lCQUNKOzswQkFzdkJZLE1BQU07MkJBQUMsV0FBVzs0Q0E3dUJ2QixTQUFTO3NCQURaLEtBQUs7Z0JBY0Ysa0JBQWtCO3NCQURyQixLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixjQUFjO3NCQURqQixLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsdUJBQXVCO3NCQUQxQixLQUFLO2dCQWNGLGVBQWU7c0JBRGxCLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFjRixNQUFNO3NCQURULEtBQUs7Z0JBY0YsSUFBSTtzQkFEUCxLQUFLO2dCQWNGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLFlBQVk7c0JBRGYsS0FBSztnQkFjRixPQUFPO3NCQURWLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLGVBQWU7c0JBRGxCLEtBQUs7Z0JBY0YsYUFBYTtzQkFEaEIsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsSUFBSTtzQkFEUCxLQUFLO2dCQWNGLElBQUk7c0JBRFAsS0FBSztnQkFjRixrQkFBa0I7c0JBRHJCLEtBQUs7Z0JBY0YsYUFBYTtzQkFEaEIsS0FBSztnQkFjRixPQUFPO3NCQURWLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLFlBQVk7c0JBRGYsS0FBSztnQkFjSSxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBUUcsV0FBVztzQkFBcEIsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLFdBQVc7c0JBQXBCLE1BQU07Z0JBUUcsZUFBZTtzQkFBeEIsTUFBTTtnQkFRRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLG9CQUFvQjtzQkFBN0IsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLGlCQUFpQjtzQkFBMUIsTUFBTTtnQkFPRyw2QkFBNkI7c0JBQXRDLE1BQU07Z0JBT0cscUJBQXFCO3NCQUE5QixNQUFNO2dCQU9HLGlCQUFpQjtzQkFBMUIsTUFBTTtnQkFPRyx1QkFBdUI7c0JBQWhDLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU9HLHVCQUF1QjtzQkFBaEMsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLFlBQVk7c0JBQXJCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csbUJBQW1CO3NCQUE1QixNQUFNO2dCQU9HLGlCQUFpQjtzQkFBMUIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLFVBQVU7c0JBQW5CLE1BQU07Z0JBT0csVUFBVTtzQkFBbkIsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csbUJBQW1CO3NCQUE1QixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBTUgsYUFBYTtzQkFEaEIsZUFBZTt1QkFBQyxnQkFBZ0I7O0FBcUpyQyxNQUFNLE9BQU8sc0JBQXNCOzJIQUF0QixzQkFBc0I7NEhBQXRCLHNCQUFzQixpQkExM0J0Qix5QkFBeUIsYUFtMUJsQyx3QkFBd0I7WUFDeEIsa0JBQWtCO1lBQ2xCLGFBQWE7WUFDYixhQUFhO1lBQ2IsaUJBQWlCO1lBQ2pCLFdBQVc7WUFDWCx1QkFBdUI7WUFDdkIsa0JBQWtCO1lBQ2xCLFdBQVc7WUFDWCxlQUFlO1lBQ2YsV0FBVztZQUNYLGFBQWE7WUFDYixvQkFBb0I7WUFDcEIsYUFBYTtZQUNiLG1CQUFtQjtZQUNuQixnQkFBZ0IsYUFsMkJQLHlCQUF5QixFQXkyQmxDLHdCQUF3QjtZQUN4QixrQkFBa0I7WUFDbEIsYUFBYTtZQUNiLGFBQWE7WUFDYixpQkFBaUI7WUFDakIsV0FBVztZQUNYLHVCQUF1QjtZQUN2QixrQkFBa0I7WUFDbEIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsYUFBYTtZQUNiLG9CQUFvQjtZQUNwQixhQUFhO1lBQ2IsZ0JBQWdCOzRIQUdQLHNCQUFzQixZQXZDL0Isd0JBQXdCO1lBQ3hCLGtCQUFrQjtZQUNsQixhQUFhO1lBQ2IsYUFBYTtZQUNiLGlCQUFpQjtZQUNqQixXQUFXO1lBQ1gsdUJBQXVCO1lBQ3ZCLGtCQUFrQjtZQUNsQixXQUFXO1lBQ1gsZUFBZTtZQUNmLFdBQVc7WUFDWCxhQUFhO1lBQ2Isb0JBQW9CO1lBQ3BCLGFBQWE7WUFDYixtQkFBbUI7WUFDbkIsZ0JBQWdCLEVBT2hCLHdCQUF3QjtZQUN4QixrQkFBa0I7WUFDbEIsYUFBYTtZQUNiLGFBQWE7WUFDYixpQkFBaUI7WUFDakIsV0FBVztZQUNYLHVCQUF1QjtZQUN2QixrQkFBa0I7WUFDbEIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsYUFBYTtZQUNiLG9CQUFvQjtZQUNwQixhQUFhO1lBQ2IsZ0JBQWdCOzs0RkFHUCxzQkFBc0I7a0JBekNsQyxRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRTt3QkFDUCx3QkFBd0I7d0JBQ3hCLGtCQUFrQjt3QkFDbEIsYUFBYTt3QkFDYixhQUFhO3dCQUNiLGlCQUFpQjt3QkFDakIsV0FBVzt3QkFDWCx1QkFBdUI7d0JBQ3ZCLGtCQUFrQjt3QkFDbEIsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsYUFBYTt3QkFDYixvQkFBb0I7d0JBQ3BCLGFBQWE7d0JBQ2IsbUJBQW1CO3dCQUNuQixnQkFBZ0I7cUJBQ2pCO29CQUNELFlBQVksRUFBRTt3QkFDWix5QkFBeUI7cUJBQzFCO29CQUNELE9BQU8sRUFBRTt3QkFDUCx5QkFBeUI7d0JBQ3pCLHdCQUF3Qjt3QkFDeEIsa0JBQWtCO3dCQUNsQixhQUFhO3dCQUNiLGFBQWE7d0JBQ2IsaUJBQWlCO3dCQUNqQixXQUFXO3dCQUNYLHVCQUF1Qjt3QkFDdkIsa0JBQWtCO3dCQUNsQixXQUFXO3dCQUNYLGVBQWU7d0JBQ2YsV0FBVzt3QkFDWCxhQUFhO3dCQUNiLG9CQUFvQjt3QkFDcEIsYUFBYTt3QkFDYixnQkFBZ0I7cUJBQ2pCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG5cbmltcG9ydCB7XG4gICAgVHJhbnNmZXJTdGF0ZSxcbiAgICBDb21wb25lbnQsXG4gICAgTmdNb2R1bGUsXG4gICAgRWxlbWVudFJlZixcbiAgICBOZ1pvbmUsXG4gICAgUExBVEZPUk1fSUQsXG4gICAgSW5qZWN0LFxuXG4gICAgSW5wdXQsXG4gICAgT3V0cHV0LFxuICAgIE9uRGVzdHJveSxcbiAgICBFdmVudEVtaXR0ZXIsXG4gICAgT25DaGFuZ2VzLFxuICAgIERvQ2hlY2ssXG4gICAgU2ltcGxlQ2hhbmdlcyxcbiAgICBDb250ZW50Q2hpbGRyZW4sXG4gICAgUXVlcnlMaXN0XG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cbmltcG9ydCB7IEJ1dHRvblN0eWxlLCBCdXR0b25UeXBlIH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24nO1xuaW1wb3J0IHsgU3RvcmUgfSBmcm9tICdkZXZleHRyZW1lL2RhdGEnO1xuaW1wb3J0IERhdGFTb3VyY2UsIHsgT3B0aW9ucyBhcyBEYXRhU291cmNlT3B0aW9ucyB9IGZyb20gJ2RldmV4dHJlbWUvZGF0YS9kYXRhX3NvdXJjZSc7XG5pbXBvcnQgeyBCdXR0b25DbGlja0V2ZW50LCBDb250ZW50UmVhZHlFdmVudCwgRGlzcG9zaW5nRXZlbnQsIGR4RHJvcERvd25CdXR0b25JdGVtLCBJbml0aWFsaXplZEV2ZW50LCBJdGVtQ2xpY2tFdmVudCwgT3B0aW9uQ2hhbmdlZEV2ZW50LCBTZWxlY3Rpb25DaGFuZ2VkRXZlbnQgfSBmcm9tICdkZXZleHRyZW1lL3VpL2Ryb3BfZG93bl9idXR0b24nO1xuaW1wb3J0IHsgUHJvcGVydGllcyBhcyBkeFBvcHVwT3B0aW9ucyB9IGZyb20gJ2RldmV4dHJlbWUvdWkvcG9wdXAnO1xuXG5pbXBvcnQgRHhEcm9wRG93bkJ1dHRvbiBmcm9tICdkZXZleHRyZW1lL3VpL2Ryb3BfZG93bl9idXR0b24nO1xuXG5cbmltcG9ydCB7XG4gICAgRHhDb21wb25lbnQsXG4gICAgRHhUZW1wbGF0ZUhvc3QsXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlLFxuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgSXRlcmFibGVEaWZmZXJIZWxwZXIsXG4gICAgV2F0Y2hlckhlbHBlclxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IER4b0Ryb3BEb3duT3B0aW9uc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvQW5pbWF0aW9uTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9IaWRlTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Gcm9tTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Qb3NpdGlvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvQXRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0JvdW5kYXJ5T2Zmc2V0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Db2xsaXNpb25Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b015TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9PZmZzZXRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1RvTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9TaG93TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlUb29sYmFySXRlbU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpSXRlbU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuXG5pbXBvcnQgeyBEeGlJdGVtQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5cblxuXG4vKipcbiAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uXVxuXG4gKi9cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHgtZHJvcC1kb3duLWJ1dHRvbicsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgV2F0Y2hlckhlbHBlcixcbiAgICAgICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4RHJvcERvd25CdXR0b25Db21wb25lbnQgZXh0ZW5kcyBEeENvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25DaGFuZ2VzLCBEb0NoZWNrIHtcbiAgICBpbnN0YW5jZTogRHhEcm9wRG93bkJ1dHRvbiA9IG51bGw7XG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5hY2Nlc3NLZXldXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYWNjZXNzS2V5KCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FjY2Vzc0tleScpO1xuICAgIH1cbiAgICBzZXQgYWNjZXNzS2V5KHZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhY2Nlc3NLZXknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5hY3RpdmVTdGF0ZUVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYWN0aXZlU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhY3RpdmVTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGFjdGl2ZVN0YXRlRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjdGl2ZVN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5kYXRhU291cmNlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRhdGFTb3VyY2UoKTogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8ZHhEcm9wRG93bkJ1dHRvbkl0ZW0gfCBhbnk+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGF0YVNvdXJjZScpO1xuICAgIH1cbiAgICBzZXQgZGF0YVNvdXJjZSh2YWx1ZTogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8ZHhEcm9wRG93bkJ1dHRvbkl0ZW0gfCBhbnk+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGF0YVNvdXJjZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5kZWZlclJlbmRlcmluZ11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkZWZlclJlbmRlcmluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGVmZXJSZW5kZXJpbmcnKTtcbiAgICB9XG4gICAgc2V0IGRlZmVyUmVuZGVyaW5nKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGVmZXJSZW5kZXJpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5kaXNhYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGRpc2FibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMuZGlzcGxheUV4cHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZGlzcGxheUV4cHIoKTogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkaXNwbGF5RXhwcicpO1xuICAgIH1cbiAgICBzZXQgZGlzcGxheUV4cHIodmFsdWU6IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzcGxheUV4cHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMuZHJvcERvd25Db250ZW50VGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZHJvcERvd25Db250ZW50VGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZHJvcERvd25Db250ZW50VGVtcGxhdGUnKTtcbiAgICB9XG4gICAgc2V0IGRyb3BEb3duQ29udGVudFRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkcm9wRG93bkNvbnRlbnRUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5kcm9wRG93bk9wdGlvbnNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZHJvcERvd25PcHRpb25zKCk6IGR4UG9wdXBPcHRpb25zIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZHJvcERvd25PcHRpb25zJyk7XG4gICAgfVxuICAgIHNldCBkcm9wRG93bk9wdGlvbnModmFsdWU6IGR4UG9wdXBPcHRpb25zKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZHJvcERvd25PcHRpb25zJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMuZWxlbWVudEF0dHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZWxlbWVudEF0dHIoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcbiAgICB9XG4gICAgc2V0IGVsZW1lbnRBdHRyKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5mb2N1c1N0YXRlRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBmb2N1c1N0YXRlRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGZvY3VzU3RhdGVFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5oZWlnaHRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGVpZ2h0KCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCBoZWlnaHQodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMuaGludF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBoaW50KCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hpbnQnKTtcbiAgICB9XG4gICAgc2V0IGhpbnQodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hpbnQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMuaG92ZXJTdGF0ZUVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaG92ZXJTdGF0ZUVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hvdmVyU3RhdGVFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBob3ZlclN0YXRlRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hvdmVyU3RhdGVFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLmljb25dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaWNvbigpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpY29uJyk7XG4gICAgfVxuICAgIHNldCBpY29uKHZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpY29uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLml0ZW1zXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGl0ZW1zKCk6IEFycmF5PGFueSB8IHsgYmFkZ2U/OiBzdHJpbmcsIGRpc2FibGVkPzogYm9vbGVhbiwgaHRtbD86IHN0cmluZywgaWNvbj86IHN0cmluZywgb25DbGljaz86IEZ1bmN0aW9uLCB0ZW1wbGF0ZT86IGFueSwgdGV4dD86IHN0cmluZywgdmlzaWJsZT86IGJvb2xlYW4gfT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtcycpO1xuICAgIH1cbiAgICBzZXQgaXRlbXModmFsdWU6IEFycmF5PGFueSB8IHsgYmFkZ2U/OiBzdHJpbmcsIGRpc2FibGVkPzogYm9vbGVhbiwgaHRtbD86IHN0cmluZywgaWNvbj86IHN0cmluZywgb25DbGljaz86IEZ1bmN0aW9uLCB0ZW1wbGF0ZT86IGFueSwgdGV4dD86IHN0cmluZywgdmlzaWJsZT86IGJvb2xlYW4gfT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtcycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5pdGVtVGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaXRlbVRlbXBsYXRlKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2l0ZW1UZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgaXRlbVRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtVGVtcGxhdGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMua2V5RXhwcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBrZXlFeHByKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2tleUV4cHInKTtcbiAgICB9XG4gICAgc2V0IGtleUV4cHIodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2tleUV4cHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMubm9EYXRhVGV4dF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBub0RhdGFUZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ25vRGF0YVRleHQnKTtcbiAgICB9XG4gICAgc2V0IG5vRGF0YVRleHQodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ25vRGF0YVRleHQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMub3BlbmVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG9wZW5lZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb3BlbmVkJyk7XG4gICAgfVxuICAgIHNldCBvcGVuZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdvcGVuZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5ydGxFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJ0bEVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3J0bEVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHJ0bEVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdydGxFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLnNlbGVjdGVkSXRlbV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzZWxlY3RlZEl0ZW0oKTogYW55IHwgbnVtYmVyIHwgc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2VsZWN0ZWRJdGVtJyk7XG4gICAgfVxuICAgIHNldCBzZWxlY3RlZEl0ZW0odmFsdWU6IGFueSB8IG51bWJlciB8IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NlbGVjdGVkSXRlbScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5zZWxlY3RlZEl0ZW1LZXldXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2VsZWN0ZWRJdGVtS2V5KCk6IG51bWJlciB8IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NlbGVjdGVkSXRlbUtleScpO1xuICAgIH1cbiAgICBzZXQgc2VsZWN0ZWRJdGVtS2V5KHZhbHVlOiBudW1iZXIgfCBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzZWxlY3RlZEl0ZW1LZXknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMuc2hvd0Fycm93SWNvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93QXJyb3dJY29uKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaG93QXJyb3dJY29uJyk7XG4gICAgfVxuICAgIHNldCBzaG93QXJyb3dJY29uKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd0Fycm93SWNvbicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5zcGxpdEJ1dHRvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzcGxpdEJ1dHRvbigpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc3BsaXRCdXR0b24nKTtcbiAgICB9XG4gICAgc2V0IHNwbGl0QnV0dG9uKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc3BsaXRCdXR0b24nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMuc3R5bGluZ01vZGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc3R5bGluZ01vZGUoKTogQnV0dG9uU3R5bGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzdHlsaW5nTW9kZScpO1xuICAgIH1cbiAgICBzZXQgc3R5bGluZ01vZGUodmFsdWU6IEJ1dHRvblN0eWxlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc3R5bGluZ01vZGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy50YWJJbmRleF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0YWJJbmRleCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0YWJJbmRleCcpO1xuICAgIH1cbiAgICBzZXQgdGFiSW5kZXgodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RhYkluZGV4JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLnRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRlbXBsYXRlKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RlbXBsYXRlJyk7XG4gICAgfVxuICAgIHNldCB0ZW1wbGF0ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGVtcGxhdGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMudGV4dF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0ZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RleHQnKTtcbiAgICB9XG4gICAgc2V0IHRleHQodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RleHQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMudHlwZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0eXBlKCk6IEJ1dHRvblR5cGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0eXBlJyk7XG4gICAgfVxuICAgIHNldCB0eXBlKHZhbHVlOiBCdXR0b25UeXBlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndHlwZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy51c2VJdGVtVGV4dEFzVGl0bGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdXNlSXRlbVRleHRBc1RpdGxlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd1c2VJdGVtVGV4dEFzVGl0bGUnKTtcbiAgICB9XG4gICAgc2V0IHVzZUl0ZW1UZXh0QXNUaXRsZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3VzZUl0ZW1UZXh0QXNUaXRsZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy51c2VTZWxlY3RNb2RlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHVzZVNlbGVjdE1vZGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3VzZVNlbGVjdE1vZGUnKTtcbiAgICB9XG4gICAgc2V0IHVzZVNlbGVjdE1vZGUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd1c2VTZWxlY3RNb2RlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMudmlzaWJsZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB2aXNpYmxlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2aXNpYmxlJyk7XG4gICAgfVxuICAgIHNldCB2aXNpYmxlKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlzaWJsZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnRPcHRpb25zLndpZHRoXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHdpZHRoKCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignd2lkdGgnKTtcbiAgICB9XG4gICAgc2V0IHdpZHRoKHZhbHVlOiBudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3dpZHRoJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLndyYXBJdGVtVGV4dF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB3cmFwSXRlbVRleHQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3dyYXBJdGVtVGV4dCcpO1xuICAgIH1cbiAgICBzZXQgd3JhcEl0ZW1UZXh0KHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignd3JhcEl0ZW1UZXh0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5vbkJ1dHRvbkNsaWNrXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkJ1dHRvbkNsaWNrOiBFdmVudEVtaXR0ZXI8QnV0dG9uQ2xpY2tFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMub25Db250ZW50UmVhZHldXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ29udGVudFJlYWR5OiBFdmVudEVtaXR0ZXI8Q29udGVudFJlYWR5RXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLm9uRGlzcG9zaW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkRpc3Bvc2luZzogRXZlbnRFbWl0dGVyPERpc3Bvc2luZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5vbkluaXRpYWxpemVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkluaXRpYWxpemVkOiBFdmVudEVtaXR0ZXI8SW5pdGlhbGl6ZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkJ1dHRvbk9wdGlvbnMub25JdGVtQ2xpY2tdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uSXRlbUNsaWNrOiBFdmVudEVtaXR0ZXI8SXRlbUNsaWNrRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25CdXR0b25PcHRpb25zLm9uT3B0aW9uQ2hhbmdlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25PcHRpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8T3B0aW9uQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duQnV0dG9uT3B0aW9ucy5vblNlbGVjdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uU2VsZWN0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPFNlbGVjdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBhY2Nlc3NLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkYXRhU291cmNlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8U3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8ZHhEcm9wRG93bkJ1dHRvbkl0ZW0gfCBhbnk+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRlZmVyUmVuZGVyaW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkaXNhYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZGlzcGxheUV4cHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkcm9wRG93bkNvbnRlbnRUZW1wbGF0ZUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkcm9wRG93bk9wdGlvbnNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxkeFBvcHVwT3B0aW9ucz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBlbGVtZW50QXR0ckNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBmb2N1c1N0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGludENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBob3ZlclN0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaWNvbkNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBpdGVtc0NoYW5nZTogRXZlbnRFbWl0dGVyPEFycmF5PGFueSB8IHsgYmFkZ2U/OiBzdHJpbmcsIGRpc2FibGVkPzogYm9vbGVhbiwgaHRtbD86IHN0cmluZywgaWNvbj86IHN0cmluZywgb25DbGljaz86IEZ1bmN0aW9uLCB0ZW1wbGF0ZT86IGFueSwgdGV4dD86IHN0cmluZywgdmlzaWJsZT86IGJvb2xlYW4gfT4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaXRlbVRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGtleUV4cHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbm9EYXRhVGV4dENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvcGVuZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJ0bEVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNlbGVjdGVkSXRlbUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueSB8IG51bWJlciB8IHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzZWxlY3RlZEl0ZW1LZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCBzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd0Fycm93SWNvbkNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc3BsaXRCdXR0b25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHN0eWxpbmdNb2RlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QnV0dG9uU3R5bGU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGFiSW5kZXhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGVtcGxhdGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGV4dENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0eXBlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QnV0dG9uVHlwZT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB1c2VJdGVtVGV4dEFzVGl0bGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHVzZVNlbGVjdE1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZpc2libGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHdpZHRoQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgd3JhcEl0ZW1UZXh0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cblxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKER4aUl0ZW1Db21wb25lbnQpXG4gICAgZ2V0IGl0ZW1zQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUl0ZW1Db21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaXRlbXMnKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1zQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignaXRlbXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cblxuXG4gICAgY29uc3RydWN0b3IoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgbmdab25lOiBOZ1pvbmUsIHRlbXBsYXRlSG9zdDogRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIF93YXRjaGVySGVscGVyOiBXYXRjaGVySGVscGVyLFxuICAgICAgICAgICAgcHJpdmF0ZSBfaWRoOiBJdGVyYWJsZURpZmZlckhlbHBlcixcbiAgICAgICAgICAgIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICB0cmFuc2ZlclN0YXRlOiBUcmFuc2ZlclN0YXRlLFxuICAgICAgICAgICAgQEluamVjdChQTEFURk9STV9JRCkgcGxhdGZvcm1JZDogYW55KSB7XG5cbiAgICAgICAgc3VwZXIoZWxlbWVudFJlZiwgbmdab25lLCB0ZW1wbGF0ZUhvc3QsIF93YXRjaGVySGVscGVyLCB0cmFuc2ZlclN0YXRlLCBwbGF0Zm9ybUlkKTtcblxuICAgICAgICB0aGlzLl9jcmVhdGVFdmVudEVtaXR0ZXJzKFtcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnYnV0dG9uQ2xpY2snLCBlbWl0OiAnb25CdXR0b25DbGljaycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnY29udGVudFJlYWR5JywgZW1pdDogJ29uQ29udGVudFJlYWR5JyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkaXNwb3NpbmcnLCBlbWl0OiAnb25EaXNwb3NpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2luaXRpYWxpemVkJywgZW1pdDogJ29uSW5pdGlhbGl6ZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2l0ZW1DbGljaycsIGVtaXQ6ICdvbkl0ZW1DbGljaycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnb3B0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvbk9wdGlvbkNoYW5nZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3NlbGVjdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25TZWxlY3Rpb25DaGFuZ2VkJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWNjZXNzS2V5Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGF0YVNvdXJjZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2RlZmVyUmVuZGVyaW5nQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGlzYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdkaXNwbGF5RXhwckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2Ryb3BEb3duQ29udGVudFRlbXBsYXRlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZHJvcERvd25PcHRpb25zQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZWxlbWVudEF0dHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdmb2N1c1N0YXRlRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hlaWdodENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hpbnRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdob3ZlclN0YXRlRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2ljb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdpdGVtc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2l0ZW1UZW1wbGF0ZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2tleUV4cHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdub0RhdGFUZXh0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnb3BlbmVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncnRsRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NlbGVjdGVkSXRlbUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NlbGVjdGVkSXRlbUtleUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dBcnJvd0ljb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzcGxpdEJ1dHRvbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3N0eWxpbmdNb2RlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGFiSW5kZXhDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0ZW1wbGF0ZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3RleHRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0eXBlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndXNlSXRlbVRleHRBc1RpdGxlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndXNlU2VsZWN0TW9kZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Zpc2libGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd3aWR0aENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3dyYXBJdGVtVGV4dENoYW5nZScgfVxuICAgICAgICBdKTtcblxuICAgICAgICB0aGlzLl9pZGguc2V0SG9zdCh0aGlzKTtcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBfY3JlYXRlSW5zdGFuY2UoZWxlbWVudCwgb3B0aW9ucykge1xuXG4gICAgICAgIHJldHVybiBuZXcgRHhEcm9wRG93bkJ1dHRvbihlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2RhdGFTb3VyY2UnLCBjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2l0ZW1zJywgY2hhbmdlcyk7XG4gICAgfVxuXG4gICAgc2V0dXBDaGFuZ2VzKHByb3A6IHN0cmluZywgY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoIShwcm9wIGluIHRoaXMuX29wdGlvbnNUb1VwZGF0ZSkpIHtcbiAgICAgICAgICAgIHRoaXMuX2lkaC5zZXR1cChwcm9wLCBjaGFuZ2VzKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nRG9DaGVjaygpIHtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2RhdGFTb3VyY2UnKTtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2l0ZW1zJyk7XG4gICAgICAgIHRoaXMuX3dhdGNoZXJIZWxwZXIuY2hlY2tXYXRjaGVycygpO1xuICAgICAgICBzdXBlci5uZ0RvQ2hlY2soKTtcbiAgICAgICAgc3VwZXIuY2xlYXJDaGFuZ2VkT3B0aW9ucygpO1xuICAgIH1cblxuICAgIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XG4gICAgICAgIGxldCBpc1NldHVwID0gdGhpcy5faWRoLnNldHVwU2luZ2xlKG5hbWUsIHZhbHVlKTtcbiAgICAgICAgbGV0IGlzQ2hhbmdlZCA9IHRoaXMuX2lkaC5nZXRDaGFuZ2VzKG5hbWUsIHZhbHVlKSAhPT0gbnVsbDtcblxuICAgICAgICBpZiAoaXNTZXR1cCB8fCBpc0NoYW5nZWQpIHtcbiAgICAgICAgICAgIHN1cGVyLl9zZXRPcHRpb24obmFtZSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgRHhvRHJvcERvd25PcHRpb25zTW9kdWxlLFxuICAgIER4b0FuaW1hdGlvbk1vZHVsZSxcbiAgICBEeG9IaWRlTW9kdWxlLFxuICAgIER4b0Zyb21Nb2R1bGUsXG4gICAgRHhvUG9zaXRpb25Nb2R1bGUsXG4gICAgRHhvQXRNb2R1bGUsXG4gICAgRHhvQm91bmRhcnlPZmZzZXRNb2R1bGUsXG4gICAgRHhvQ29sbGlzaW9uTW9kdWxlLFxuICAgIER4b015TW9kdWxlLFxuICAgIER4b09mZnNldE1vZHVsZSxcbiAgICBEeG9Ub01vZHVsZSxcbiAgICBEeG9TaG93TW9kdWxlLFxuICAgIER4aVRvb2xiYXJJdGVtTW9kdWxlLFxuICAgIER4aUl0ZW1Nb2R1bGUsXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlXG4gIF0sXG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4RHJvcERvd25CdXR0b25Db21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4RHJvcERvd25CdXR0b25Db21wb25lbnQsXG4gICAgRHhvRHJvcERvd25PcHRpb25zTW9kdWxlLFxuICAgIER4b0FuaW1hdGlvbk1vZHVsZSxcbiAgICBEeG9IaWRlTW9kdWxlLFxuICAgIER4b0Zyb21Nb2R1bGUsXG4gICAgRHhvUG9zaXRpb25Nb2R1bGUsXG4gICAgRHhvQXRNb2R1bGUsXG4gICAgRHhvQm91bmRhcnlPZmZzZXRNb2R1bGUsXG4gICAgRHhvQ29sbGlzaW9uTW9kdWxlLFxuICAgIER4b015TW9kdWxlLFxuICAgIER4b09mZnNldE1vZHVsZSxcbiAgICBEeG9Ub01vZHVsZSxcbiAgICBEeG9TaG93TW9kdWxlLFxuICAgIER4aVRvb2xiYXJJdGVtTW9kdWxlLFxuICAgIER4aUl0ZW1Nb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZVxuICBdXG59KVxuZXhwb3J0IGNsYXNzIER4RHJvcERvd25CdXR0b25Nb2R1bGUgeyB9XG5cbmltcG9ydCB0eXBlICogYXMgRHhEcm9wRG93bkJ1dHRvblR5cGVzIGZyb20gXCJkZXZleHRyZW1lL3VpL2Ryb3BfZG93bl9idXR0b25fdHlwZXNcIjtcbmV4cG9ydCB7IER4RHJvcERvd25CdXR0b25UeXBlcyB9O1xuXG5cbiJdfQ==