/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import DxVectorMap from 'devextreme/viz/vector_map';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxiAnnotationModule } from 'devextreme-angular/ui/nested';
import { DxoBorderModule } from 'devextreme-angular/ui/nested';
import { DxoFontModule } from 'devextreme-angular/ui/nested';
import { DxoImageModule } from 'devextreme-angular/ui/nested';
import { DxoShadowModule } from 'devextreme-angular/ui/nested';
import { DxoBackgroundModule } from 'devextreme-angular/ui/nested';
import { DxoCommonAnnotationSettingsModule } from 'devextreme-angular/ui/nested';
import { DxoControlBarModule } from 'devextreme-angular/ui/nested';
import { DxoExportModule } from 'devextreme-angular/ui/nested';
import { DxiLayerModule } from 'devextreme-angular/ui/nested';
import { DxoLabelModule } from 'devextreme-angular/ui/nested';
import { DxiLegendModule } from 'devextreme-angular/ui/nested';
import { DxoMarginModule } from 'devextreme-angular/ui/nested';
import { DxoSourceModule } from 'devextreme-angular/ui/nested';
import { DxoTitleModule } from 'devextreme-angular/ui/nested';
import { DxoSubtitleModule } from 'devextreme-angular/ui/nested';
import { DxoLoadingIndicatorModule } from 'devextreme-angular/ui/nested';
import { DxoProjectionModule } from 'devextreme-angular/ui/nested';
import { DxoSizeModule } from 'devextreme-angular/ui/nested';
import { DxoTooltipModule } from 'devextreme-angular/ui/nested';
import { DxiAnnotationComponent } from 'devextreme-angular/ui/nested';
import { DxiLayerComponent } from 'devextreme-angular/ui/nested';
import { DxiLegendComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxVectorMap]

 */
export class DxVectorMapComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:dxVectorMapOptions.annotations]
    
     */
    get annotations() {
        return this._getOption('annotations');
    }
    set annotations(value) {
        this._setOption('annotations', value);
    }
    /**
     * [descr:dxVectorMapOptions.background]
    
     */
    get background() {
        return this._getOption('background');
    }
    set background(value) {
        this._setOption('background', value);
    }
    /**
     * [descr:dxVectorMapOptions.bounds]
    
     */
    get bounds() {
        return this._getOption('bounds');
    }
    set bounds(value) {
        this._setOption('bounds', value);
    }
    /**
     * [descr:dxVectorMapOptions.center]
    
     */
    get center() {
        return this._getOption('center');
    }
    set center(value) {
        this._setOption('center', value);
    }
    /**
     * [descr:dxVectorMapOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings() {
        return this._getOption('commonAnnotationSettings');
    }
    set commonAnnotationSettings(value) {
        this._setOption('commonAnnotationSettings', value);
    }
    /**
     * [descr:dxVectorMapOptions.controlBar]
    
     */
    get controlBar() {
        return this._getOption('controlBar');
    }
    set controlBar(value) {
        this._setOption('controlBar', value);
    }
    /**
     * [descr:dxVectorMapOptions.customizeAnnotation]
    
     */
    get customizeAnnotation() {
        return this._getOption('customizeAnnotation');
    }
    set customizeAnnotation(value) {
        this._setOption('customizeAnnotation', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxVectorMapOptions.layers]
    
     */
    get layers() {
        return this._getOption('layers');
    }
    set layers(value) {
        this._setOption('layers', value);
    }
    /**
     * [descr:dxVectorMapOptions.legends]
    
     */
    get legends() {
        return this._getOption('legends');
    }
    set legends(value) {
        this._setOption('legends', value);
    }
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:dxVectorMapOptions.maxZoomFactor]
    
     */
    get maxZoomFactor() {
        return this._getOption('maxZoomFactor');
    }
    set maxZoomFactor(value) {
        this._setOption('maxZoomFactor', value);
    }
    /**
     * [descr:dxVectorMapOptions.panningEnabled]
    
     */
    get panningEnabled() {
        return this._getOption('panningEnabled');
    }
    set panningEnabled(value) {
        this._setOption('panningEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:dxVectorMapOptions.projection]
    
     */
    get projection() {
        return this._getOption('projection');
    }
    set projection(value) {
        this._setOption('projection', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxVectorMapOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxVectorMapOptions.touchEnabled]
    
     */
    get touchEnabled() {
        return this._getOption('touchEnabled');
    }
    set touchEnabled(value) {
        this._setOption('touchEnabled', value);
    }
    /**
     * [descr:dxVectorMapOptions.wheelEnabled]
    
     */
    get wheelEnabled() {
        return this._getOption('wheelEnabled');
    }
    set wheelEnabled(value) {
        this._setOption('wheelEnabled', value);
    }
    /**
     * [descr:dxVectorMapOptions.zoomFactor]
    
     */
    get zoomFactor() {
        return this._getOption('zoomFactor');
    }
    set zoomFactor(value) {
        this._setOption('zoomFactor', value);
    }
    /**
     * [descr:dxVectorMapOptions.zoomingEnabled]
    
     */
    get zoomingEnabled() {
        return this._getOption('zoomingEnabled');
    }
    set zoomingEnabled(value) {
        this._setOption('zoomingEnabled', value);
    }
    /**
    
     * [descr:dxVectorMapOptions.onCenterChanged]
    
    
     */
    onCenterChanged;
    /**
    
     * [descr:dxVectorMapOptions.onClick]
    
    
     */
    onClick;
    /**
    
     * [descr:dxVectorMapOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxVectorMapOptions.onDrawn]
    
    
     */
    onDrawn;
    /**
    
     * [descr:dxVectorMapOptions.onExported]
    
    
     */
    onExported;
    /**
    
     * [descr:dxVectorMapOptions.onExporting]
    
    
     */
    onExporting;
    /**
    
     * [descr:dxVectorMapOptions.onFileSaving]
    
    
     */
    onFileSaving;
    /**
    
     * [descr:dxVectorMapOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred;
    /**
    
     * [descr:dxVectorMapOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxVectorMapOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxVectorMapOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * [descr:dxVectorMapOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden;
    /**
    
     * [descr:dxVectorMapOptions.onTooltipShown]
    
    
     */
    onTooltipShown;
    /**
    
     * [descr:dxVectorMapOptions.onZoomFactorChanged]
    
    
     */
    onZoomFactorChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    annotationsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    backgroundChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    boundsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAnnotationSettingsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    controlBarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeAnnotationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layersChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxZoomFactorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    panningEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    projectionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    touchEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wheelEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomFactorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomingEnabledChange;
    get annotationsChildren() {
        return this._getOption('annotations');
    }
    set annotationsChildren(value) {
        this.setChildren('annotations', value);
    }
    get layersChildren() {
        return this._getOption('layers');
    }
    set layersChildren(value) {
        this.setChildren('layers', value);
    }
    get legendsChildren() {
        return this._getOption('legends');
    }
    set legendsChildren(value) {
        this.setChildren('legends', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'centerChanged', emit: 'onCenterChanged' },
            { subscribe: 'click', emit: 'onClick' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { subscribe: 'zoomFactorChanged', emit: 'onZoomFactorChanged' },
            { emit: 'annotationsChange' },
            { emit: 'backgroundChange' },
            { emit: 'boundsChange' },
            { emit: 'centerChange' },
            { emit: 'commonAnnotationSettingsChange' },
            { emit: 'controlBarChange' },
            { emit: 'customizeAnnotationChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'exportChange' },
            { emit: 'layersChange' },
            { emit: 'legendsChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'maxZoomFactorChange' },
            { emit: 'panningEnabledChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'projectionChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'sizeChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'touchEnabledChange' },
            { emit: 'wheelEnabledChange' },
            { emit: 'zoomFactorChange' },
            { emit: 'zoomingEnabledChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxVectorMap(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('annotations', changes);
        this.setupChanges('bounds', changes);
        this.setupChanges('center', changes);
        this.setupChanges('layers', changes);
        this.setupChanges('legends', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('annotations');
        this._idh.doCheck('bounds');
        this._idh.doCheck('center');
        this._idh.doCheck('layers');
        this._idh.doCheck('legends');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxVectorMapComponent, selector: "dx-vector-map", inputs: { annotations: "annotations", background: "background", bounds: "bounds", center: "center", commonAnnotationSettings: "commonAnnotationSettings", controlBar: "controlBar", customizeAnnotation: "customizeAnnotation", disabled: "disabled", elementAttr: "elementAttr", export: "export", layers: "layers", legends: "legends", loadingIndicator: "loadingIndicator", maxZoomFactor: "maxZoomFactor", panningEnabled: "panningEnabled", pathModified: "pathModified", projection: "projection", redrawOnResize: "redrawOnResize", rtlEnabled: "rtlEnabled", size: "size", theme: "theme", title: "title", tooltip: "tooltip", touchEnabled: "touchEnabled", wheelEnabled: "wheelEnabled", zoomFactor: "zoomFactor", zoomingEnabled: "zoomingEnabled" }, outputs: { onCenterChanged: "onCenterChanged", onClick: "onClick", onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", onZoomFactorChanged: "onZoomFactorChanged", annotationsChange: "annotationsChange", backgroundChange: "backgroundChange", boundsChange: "boundsChange", centerChange: "centerChange", commonAnnotationSettingsChange: "commonAnnotationSettingsChange", controlBarChange: "controlBarChange", customizeAnnotationChange: "customizeAnnotationChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", exportChange: "exportChange", layersChange: "layersChange", legendsChange: "legendsChange", loadingIndicatorChange: "loadingIndicatorChange", maxZoomFactorChange: "maxZoomFactorChange", panningEnabledChange: "panningEnabledChange", pathModifiedChange: "pathModifiedChange", projectionChange: "projectionChange", redrawOnResizeChange: "redrawOnResizeChange", rtlEnabledChange: "rtlEnabledChange", sizeChange: "sizeChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", touchEnabledChange: "touchEnabledChange", wheelEnabledChange: "wheelEnabledChange", zoomFactorChange: "zoomFactorChange", zoomingEnabledChange: "zoomingEnabledChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "annotationsChildren", predicate: DxiAnnotationComponent }, { propertyName: "layersChildren", predicate: DxiLayerComponent }, { propertyName: "legendsChildren", predicate: DxiLegendComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-vector-map', template: '', providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { annotations: [{
                type: Input
            }], background: [{
                type: Input
            }], bounds: [{
                type: Input
            }], center: [{
                type: Input
            }], commonAnnotationSettings: [{
                type: Input
            }], controlBar: [{
                type: Input
            }], customizeAnnotation: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], export: [{
                type: Input
            }], layers: [{
                type: Input
            }], legends: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], maxZoomFactor: [{
                type: Input
            }], panningEnabled: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], projection: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], size: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], touchEnabled: [{
                type: Input
            }], wheelEnabled: [{
                type: Input
            }], zoomFactor: [{
                type: Input
            }], zoomingEnabled: [{
                type: Input
            }], onCenterChanged: [{
                type: Output
            }], onClick: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], onZoomFactorChanged: [{
                type: Output
            }], annotationsChange: [{
                type: Output
            }], backgroundChange: [{
                type: Output
            }], boundsChange: [{
                type: Output
            }], centerChange: [{
                type: Output
            }], commonAnnotationSettingsChange: [{
                type: Output
            }], controlBarChange: [{
                type: Output
            }], customizeAnnotationChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], layersChange: [{
                type: Output
            }], legendsChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], maxZoomFactorChange: [{
                type: Output
            }], panningEnabledChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], projectionChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], touchEnabledChange: [{
                type: Output
            }], wheelEnabledChange: [{
                type: Output
            }], zoomFactorChange: [{
                type: Output
            }], zoomingEnabledChange: [{
                type: Output
            }], annotationsChildren: [{
                type: ContentChildren,
                args: [DxiAnnotationComponent]
            }], layersChildren: [{
                type: ContentChildren,
                args: [DxiLayerComponent]
            }], legendsChildren: [{
                type: ContentChildren,
                args: [DxiLegendComponent]
            }] } });
export class DxVectorMapModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, declarations: [DxVectorMapComponent], imports: [DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxVectorMapComponent, DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, imports: [DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxIntegrationModule,
            DxTemplateModule, DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoBackgroundModule,
            DxoCommonAnnotationSettingsModule,
            DxoControlBarModule,
            DxoExportModule,
            DxiLayerModule,
            DxoLabelModule,
            DxiLegendModule,
            DxoMarginModule,
            DxoSourceModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoProjectionModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxVectorMapModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiAnnotationModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoImageModule,
                        DxoShadowModule,
                        DxoBackgroundModule,
                        DxoCommonAnnotationSettingsModule,
                        DxoControlBarModule,
                        DxoExportModule,
                        DxiLayerModule,
                        DxoLabelModule,
                        DxiLegendModule,
                        DxoMarginModule,
                        DxoSourceModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoProjectionModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxVectorMapComponent
                    ],
                    exports: [
                        DxVectorMapComponent,
                        DxiAnnotationModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoImageModule,
                        DxoShadowModule,
                        DxoBackgroundModule,
                        DxoCommonAnnotationSettingsModule,
                        DxoControlBarModule,
                        DxoExportModule,
                        DxiLayerModule,
                        DxoLabelModule,
                        DxiLegendModule,
                        DxoMarginModule,
                        DxoSourceModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoProjectionModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL3ZlY3Rvci1tYXAvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUNILGFBQWEsRUFDYixTQUFTLEVBQ1QsUUFBUSxFQUNSLFVBQVUsRUFDVixNQUFNLEVBQ04sV0FBVyxFQUNYLE1BQU0sRUFFTixLQUFLLEVBQ0wsTUFBTSxFQUVOLFlBQVksRUFJWixlQUFlLEVBQ2YsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBV3ZCLE9BQU8sV0FBVyxNQUFNLDJCQUEyQixDQUFDO0FBR3BELE9BQU8sRUFDSCxXQUFXLEVBQ1gsY0FBYyxFQUNkLG1CQUFtQixFQUNuQixnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2hCLE1BQU0seUJBQXlCLENBQUM7QUFFakMsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbkUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxpQ0FBaUMsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2pGLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzlELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNqRSxPQUFPLEVBQUUseUJBQXlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUN6RSxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNuRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFFaEUsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDdEUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDakUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7OztBQUlsRTs7O0dBR0c7QUFZSCxNQUFNLE9BQU8sb0JBQXFCLFNBQVEsV0FBVztJQTZxQmpDO0lBQ0E7SUE3cUJoQixRQUFRLEdBQWdCLElBQUksQ0FBQztJQUU3Qjs7O09BR0c7SUFDSCxJQUNJLFdBQVc7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNELElBQUksV0FBVyxDQUFDLEtBQStDO1FBQzNELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQStDO1FBQzFELElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQW9CO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQW9CO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLHdCQUF3QjtRQUN4QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBQ0QsSUFBSSx3QkFBd0IsQ0FBQyxLQUF3QztRQUNqRSxJQUFJLENBQUMsVUFBVSxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQStOO1FBQzFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBSSxtQkFBbUIsQ0FBQyxLQUEyQjtRQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBVTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUE4TDtRQUNyTSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUF3M0I7UUFDLzNCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQTJ0QztRQUNudUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksZ0JBQWdCO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQWtHO1FBQ25ILElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYTtRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQWM7UUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUFjO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQXFFO1FBQ2hGLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBYztRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBa0U7UUFDdkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBWTtRQUNsQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUE4WjtRQUNwYSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUEraUI7UUFDdmpCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQWM7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBYztRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFhO1FBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBYztRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7O09BS0c7SUFDTyxPQUFPLENBQTJCO0lBRTVDOzs7OztPQUtHO0lBQ08sV0FBVyxDQUErQjtJQUVwRDs7Ozs7T0FLRztJQUNPLE9BQU8sQ0FBMkI7SUFFNUM7Ozs7O09BS0c7SUFDTyxVQUFVLENBQThCO0lBRWxEOzs7OztPQUtHO0lBQ08sV0FBVyxDQUErQjtJQUVwRDs7Ozs7T0FLRztJQUNPLFlBQVksQ0FBZ0M7SUFFdEQ7Ozs7O09BS0c7SUFDTyxrQkFBa0IsQ0FBc0M7SUFFbEU7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7Ozs7T0FLRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7OztPQUtHO0lBQ08sbUJBQW1CLENBQXVDO0lBRXBFOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBeUQ7SUFFcEY7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF5RDtJQUVuRjs7OztPQUlHO0lBQ08sWUFBWSxDQUE4QjtJQUVwRDs7OztPQUlHO0lBQ08sWUFBWSxDQUE4QjtJQUVwRDs7OztPQUlHO0lBQ08sOEJBQThCLENBQWtEO0lBRTFGOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBeU87SUFFblE7Ozs7T0FJRztJQUNPLHlCQUF5QixDQUFxQztJQUV4RTs7OztPQUlHO0lBQ08sY0FBYyxDQUF3QjtJQUVoRDs7OztPQUlHO0lBQ08saUJBQWlCLENBQW9CO0lBRS9DOzs7O09BSUc7SUFDTyxZQUFZLENBQXdNO0lBRTlOOzs7O09BSUc7SUFDTyxZQUFZLENBQWs0QjtJQUV4NUI7Ozs7T0FJRztJQUNPLGFBQWEsQ0FBcXVDO0lBRTV2Qzs7OztPQUlHO0lBQ08sc0JBQXNCLENBQTRHO0lBRTVJOzs7O09BSUc7SUFDTyxtQkFBbUIsQ0FBdUI7SUFFcEQ7Ozs7T0FJRztJQUNPLG9CQUFvQixDQUF3QjtJQUV0RDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXdCO0lBRXBEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBK0U7SUFFekc7Ozs7T0FJRztJQUNPLG9CQUFvQixDQUF3QjtJQUV0RDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQXdCO0lBRWxEOzs7O09BSUc7SUFDTyxVQUFVLENBQTRFO0lBRWhHOzs7O09BSUc7SUFDTyxXQUFXLENBQXNCO0lBRTNDOzs7O09BSUc7SUFDTyxXQUFXLENBQXdhO0lBRTdiOzs7O09BSUc7SUFDTyxhQUFhLENBQXlqQjtJQUVobEI7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUF3QjtJQUVwRDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXdCO0lBRXBEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBdUI7SUFFakQ7Ozs7T0FJRztJQUNPLG9CQUFvQixDQUF3QjtJQUt0RCxJQUNJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNELElBQUksbUJBQW1CLENBQUMsS0FBSztRQUN6QixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFLO1FBQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQUs7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUtELFlBQVksVUFBc0IsRUFBRSxNQUFjLEVBQUUsWUFBNEIsRUFDaEUsY0FBNkIsRUFDN0IsSUFBMEIsRUFDbEMsVUFBNEIsRUFDNUIsYUFBNEIsRUFDUCxVQUFlO1FBRXhDLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBTnZFLG1CQUFjLEdBQWQsY0FBYyxDQUFlO1FBQzdCLFNBQUksR0FBSixJQUFJLENBQXNCO1FBT3RDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUN0QixFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3ZDLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3ZDLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQzdDLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ2pELEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM3RCxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNuRCxFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM3RCxFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9ELEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUN4QixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsZ0NBQWdDLEVBQUU7WUFDMUMsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUU7WUFDckMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUN4QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDbEMsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQ3RCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1NBQ25DLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hCLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVTLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUV0QyxPQUFPLElBQUksV0FBVyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBR0QsV0FBVztRQUNQLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQzlCLEtBQUssQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELFlBQVksQ0FBQyxJQUFZLEVBQUUsT0FBc0I7UUFDN0MsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsQztJQUNMLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNwQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbEIsS0FBSyxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxJQUFZLEVBQUUsS0FBVTtRQUMvQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDakQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztRQUUzRCxJQUFJLE9BQU8sSUFBSSxTQUFTLEVBQUU7WUFDdEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDOzJIQWh4QlEsb0JBQW9CLDhOQWlyQmIsV0FBVzsrR0FqckJsQixvQkFBb0IsdXZFQVBsQjtZQUNQLGNBQWM7WUFDZCxhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtTQUN2Qiw4REFtcEJnQixzQkFBc0IsaURBUXRCLGlCQUFpQixrREFRakIsa0JBQWtCLHlFQTFxQnpCLEVBQUU7OzRGQVNILG9CQUFvQjtrQkFYaEMsU0FBUzsrQkFDSSxlQUFlLFlBQ2YsRUFBRSxhQUVEO3dCQUNQLGNBQWM7d0JBQ2QsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLG9CQUFvQjtxQkFDdkI7OzBCQW1yQlEsTUFBTTsyQkFBQyxXQUFXOzRDQXpxQnZCLFdBQVc7c0JBRGQsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsTUFBTTtzQkFEVCxLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRix3QkFBd0I7c0JBRDNCLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLG1CQUFtQjtzQkFEdEIsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixNQUFNO3NCQURULEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFjRixhQUFhO3NCQURoQixLQUFLO2dCQWNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixjQUFjO3NCQURqQixLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixPQUFPO3NCQURWLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLFlBQVk7c0JBRGYsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsY0FBYztzQkFEakIsS0FBSztnQkFjSSxlQUFlO3NCQUF4QixNQUFNO2dCQVFHLE9BQU87c0JBQWhCLE1BQU07Z0JBUUcsV0FBVztzQkFBcEIsTUFBTTtnQkFRRyxPQUFPO3NCQUFoQixNQUFNO2dCQVFHLFVBQVU7c0JBQW5CLE1BQU07Z0JBUUcsV0FBVztzQkFBcEIsTUFBTTtnQkFRRyxZQUFZO3NCQUFyQixNQUFNO2dCQVFHLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLGVBQWU7c0JBQXhCLE1BQU07Z0JBUUcsa0JBQWtCO3NCQUEzQixNQUFNO2dCQVFHLGVBQWU7c0JBQXhCLE1BQU07Z0JBUUcsY0FBYztzQkFBdkIsTUFBTTtnQkFRRyxtQkFBbUI7c0JBQTVCLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLGdCQUFnQjtzQkFBekIsTUFBTTtnQkFPRyxZQUFZO3NCQUFyQixNQUFNO2dCQU9HLFlBQVk7c0JBQXJCLE1BQU07Z0JBT0csOEJBQThCO3NCQUF2QyxNQUFNO2dCQU9HLGdCQUFnQjtzQkFBekIsTUFBTTtnQkFPRyx5QkFBeUI7c0JBQWxDLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxZQUFZO3NCQUFyQixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csc0JBQXNCO3NCQUEvQixNQUFNO2dCQU9HLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFPRyxvQkFBb0I7c0JBQTdCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGdCQUFnQjtzQkFBekIsTUFBTTtnQkFPRyxvQkFBb0I7c0JBQTdCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLFVBQVU7c0JBQW5CLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPRyxXQUFXO3NCQUFwQixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQU1ILG1CQUFtQjtzQkFEdEIsZUFBZTt1QkFBQyxzQkFBc0I7Z0JBU25DLGNBQWM7c0JBRGpCLGVBQWU7dUJBQUMsaUJBQWlCO2dCQVM5QixlQUFlO3NCQURsQixlQUFlO3VCQUFDLGtCQUFrQjs7QUF1S3ZDLE1BQU0sT0FBTyxpQkFBaUI7MkhBQWpCLGlCQUFpQjs0SEFBakIsaUJBQWlCLGlCQXgwQmpCLG9CQUFvQixhQXF4QjdCLG1CQUFtQjtZQUNuQixlQUFlO1lBQ2YsYUFBYTtZQUNiLGNBQWM7WUFDZCxlQUFlO1lBQ2YsbUJBQW1CO1lBQ25CLGlDQUFpQztZQUNqQyxtQkFBbUI7WUFDbkIsZUFBZTtZQUNmLGNBQWM7WUFDZCxjQUFjO1lBQ2QsZUFBZTtZQUNmLGVBQWU7WUFDZixlQUFlO1lBQ2YsY0FBYztZQUNkLGlCQUFpQjtZQUNqQix5QkFBeUI7WUFDekIsbUJBQW1CO1lBQ25CLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsbUJBQW1CO1lBQ25CLGdCQUFnQixhQTF5QlAsb0JBQW9CLEVBaXpCN0IsbUJBQW1CO1lBQ25CLGVBQWU7WUFDZixhQUFhO1lBQ2IsY0FBYztZQUNkLGVBQWU7WUFDZixtQkFBbUI7WUFDbkIsaUNBQWlDO1lBQ2pDLG1CQUFtQjtZQUNuQixlQUFlO1lBQ2YsY0FBYztZQUNkLGNBQWM7WUFDZCxlQUFlO1lBQ2YsZUFBZTtZQUNmLGVBQWU7WUFDZixjQUFjO1lBQ2QsaUJBQWlCO1lBQ2pCLHlCQUF5QjtZQUN6QixtQkFBbUI7WUFDbkIsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQixnQkFBZ0I7NEhBR1AsaUJBQWlCLFlBbkQxQixtQkFBbUI7WUFDbkIsZUFBZTtZQUNmLGFBQWE7WUFDYixjQUFjO1lBQ2QsZUFBZTtZQUNmLG1CQUFtQjtZQUNuQixpQ0FBaUM7WUFDakMsbUJBQW1CO1lBQ25CLGVBQWU7WUFDZixjQUFjO1lBQ2QsY0FBYztZQUNkLGVBQWU7WUFDZixlQUFlO1lBQ2YsZUFBZTtZQUNmLGNBQWM7WUFDZCxpQkFBaUI7WUFDakIseUJBQXlCO1lBQ3pCLG1CQUFtQjtZQUNuQixhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixnQkFBZ0IsRUFPaEIsbUJBQW1CO1lBQ25CLGVBQWU7WUFDZixhQUFhO1lBQ2IsY0FBYztZQUNkLGVBQWU7WUFDZixtQkFBbUI7WUFDbkIsaUNBQWlDO1lBQ2pDLG1CQUFtQjtZQUNuQixlQUFlO1lBQ2YsY0FBYztZQUNkLGNBQWM7WUFDZCxlQUFlO1lBQ2YsZUFBZTtZQUNmLGVBQWU7WUFDZixjQUFjO1lBQ2QsaUJBQWlCO1lBQ2pCLHlCQUF5QjtZQUN6QixtQkFBbUI7WUFDbkIsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQixnQkFBZ0I7OzRGQUdQLGlCQUFpQjtrQkFyRDdCLFFBQVE7bUJBQUM7b0JBQ1IsT0FBTyxFQUFFO3dCQUNQLG1CQUFtQjt3QkFDbkIsZUFBZTt3QkFDZixhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsZUFBZTt3QkFDZixtQkFBbUI7d0JBQ25CLGlDQUFpQzt3QkFDakMsbUJBQW1CO3dCQUNuQixlQUFlO3dCQUNmLGNBQWM7d0JBQ2QsY0FBYzt3QkFDZCxlQUFlO3dCQUNmLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixjQUFjO3dCQUNkLGlCQUFpQjt3QkFDakIseUJBQXlCO3dCQUN6QixtQkFBbUI7d0JBQ25CLGFBQWE7d0JBQ2IsZ0JBQWdCO3dCQUNoQixtQkFBbUI7d0JBQ25CLGdCQUFnQjtxQkFDakI7b0JBQ0QsWUFBWSxFQUFFO3dCQUNaLG9CQUFvQjtxQkFDckI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLG9CQUFvQjt3QkFDcEIsbUJBQW1CO3dCQUNuQixlQUFlO3dCQUNmLGFBQWE7d0JBQ2IsY0FBYzt3QkFDZCxlQUFlO3dCQUNmLG1CQUFtQjt3QkFDbkIsaUNBQWlDO3dCQUNqQyxtQkFBbUI7d0JBQ25CLGVBQWU7d0JBQ2YsY0FBYzt3QkFDZCxjQUFjO3dCQUNkLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixlQUFlO3dCQUNmLGNBQWM7d0JBQ2QsaUJBQWlCO3dCQUNqQix5QkFBeUI7d0JBQ3pCLG1CQUFtQjt3QkFDbkIsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLGdCQUFnQjtxQkFDakI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cblxuaW1wb3J0IHtcbiAgICBUcmFuc2ZlclN0YXRlLFxuICAgIENvbXBvbmVudCxcbiAgICBOZ01vZHVsZSxcbiAgICBFbGVtZW50UmVmLFxuICAgIE5nWm9uZSxcbiAgICBQTEFURk9STV9JRCxcbiAgICBJbmplY3QsXG5cbiAgICBJbnB1dCxcbiAgICBPdXRwdXQsXG4gICAgT25EZXN0cm95LFxuICAgIEV2ZW50RW1pdHRlcixcbiAgICBPbkNoYW5nZXMsXG4gICAgRG9DaGVjayxcbiAgICBTaW1wbGVDaGFuZ2VzLFxuICAgIENvbnRlbnRDaGlsZHJlbixcbiAgICBRdWVyeUxpc3Rcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuaW1wb3J0IHsgRXhwb3J0Rm9ybWF0LCBIb3Jpem9udGFsQWxpZ25tZW50LCBPcmllbnRhdGlvbiwgUG9zaXRpb24sIFNpbmdsZU11bHRpcGxlT3JOb25lLCBWZXJ0aWNhbEVkZ2UgfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbic7XG5pbXBvcnQgeyBEYXNoU3R5bGUsIEZvbnQsIFBhbGV0dGUsIFRleHRPdmVyZmxvdywgVGhlbWUsIFdvcmRXcmFwIH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24vY2hhcnRzJztcbmltcG9ydCB7IFVzZXJEZWZpbmVkRWxlbWVudCB9IGZyb20gJ2RldmV4dHJlbWUvY29yZS9lbGVtZW50JztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSAnZGV2ZXh0cmVtZS9kYXRhJztcbmltcG9ydCBEYXRhU291cmNlLCB7IE9wdGlvbnMgYXMgRGF0YVNvdXJjZU9wdGlvbnMgfSBmcm9tICdkZXZleHRyZW1lL2RhdGEvZGF0YV9zb3VyY2UnO1xuaW1wb3J0IHsgQ2VudGVyQ2hhbmdlZEV2ZW50LCBDbGlja0V2ZW50LCBEaXNwb3NpbmdFdmVudCwgRHJhd25FdmVudCwgZHhWZWN0b3JNYXBBbm5vdGF0aW9uQ29uZmlnLCBkeFZlY3Rvck1hcENvbW1vbkFubm90YXRpb25Db25maWcsIEV4cG9ydGVkRXZlbnQsIEV4cG9ydGluZ0V2ZW50LCBGaWxlU2F2aW5nRXZlbnQsIEluY2lkZW50T2NjdXJyZWRFdmVudCwgSW5pdGlhbGl6ZWRFdmVudCwgT3B0aW9uQ2hhbmdlZEV2ZW50LCBTZWxlY3Rpb25DaGFuZ2VkRXZlbnQsIFRvb2x0aXBIaWRkZW5FdmVudCwgVG9vbHRpcFNob3duRXZlbnQsIFZlY3Rvck1hcExheWVyVHlwZSwgVmVjdG9yTWFwTWFya2VyU2hhcGUsIFZlY3Rvck1hcE1hcmtlclR5cGUsIFpvb21GYWN0b3JDaGFuZ2VkRXZlbnQgfSBmcm9tICdkZXZleHRyZW1lL3Zpei92ZWN0b3JfbWFwJztcbmltcG9ydCB7IFZlY3Rvck1hcFByb2plY3Rpb24sIFZlY3Rvck1hcFByb2plY3Rpb25Db25maWcgfSBmcm9tICdkZXZleHRyZW1lL3Zpei92ZWN0b3JfbWFwL3Byb2plY3Rpb24nO1xuXG5pbXBvcnQgRHhWZWN0b3JNYXAgZnJvbSAnZGV2ZXh0cmVtZS92aXovdmVjdG9yX21hcCc7XG5cblxuaW1wb3J0IHtcbiAgICBEeENvbXBvbmVudCxcbiAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGUsXG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICBJdGVyYWJsZURpZmZlckhlbHBlcixcbiAgICBXYXRjaGVySGVscGVyXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRHhpQW5ub3RhdGlvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvQm9yZGVyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Gb250TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9JbWFnZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2hhZG93TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9CYWNrZ3JvdW5kTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Db21tb25Bbm5vdGF0aW9uU2V0dGluZ3NNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0NvbnRyb2xCYXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0V4cG9ydE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpTGF5ZXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0xhYmVsTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlMZWdlbmRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b01hcmdpbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU291cmNlTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9UaXRsZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU3VidGl0bGVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0xvYWRpbmdJbmRpY2F0b3JNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Byb2plY3Rpb25Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1NpemVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Rvb2x0aXBNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcblxuaW1wb3J0IHsgRHhpQW5ub3RhdGlvbkNvbXBvbmVudCB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpTGF5ZXJDb21wb25lbnQgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aUxlZ2VuZENvbXBvbmVudCB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuXG5cblxuLyoqXG4gKiBbZGVzY3I6ZHhWZWN0b3JNYXBdXG5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeC12ZWN0b3ItbWFwJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbICcgOmhvc3QgeyAgZGlzcGxheTogYmxvY2s7IH0nXSxcbiAgICBwcm92aWRlcnM6IFtcbiAgICAgICAgRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgIFdhdGNoZXJIZWxwZXIsXG4gICAgICAgIE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgIEl0ZXJhYmxlRGlmZmVySGVscGVyXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeFZlY3Rvck1hcENvbXBvbmVudCBleHRlbmRzIER4Q29tcG9uZW50IGltcGxlbWVudHMgT25EZXN0cm95LCBPbkNoYW5nZXMsIERvQ2hlY2sge1xuICAgIGluc3RhbmNlOiBEeFZlY3Rvck1hcCA9IG51bGw7XG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLmFubm90YXRpb25zXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFubm90YXRpb25zKCk6IEFycmF5PGR4VmVjdG9yTWFwQW5ub3RhdGlvbkNvbmZpZyB8IGFueT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbm5vdGF0aW9ucycpO1xuICAgIH1cbiAgICBzZXQgYW5ub3RhdGlvbnModmFsdWU6IEFycmF5PGR4VmVjdG9yTWFwQW5ub3RhdGlvbkNvbmZpZyB8IGFueT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbm5vdGF0aW9ucycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMuYmFja2dyb3VuZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBiYWNrZ3JvdW5kKCk6IHsgYm9yZGVyQ29sb3I/OiBzdHJpbmcsIGNvbG9yPzogc3RyaW5nIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdiYWNrZ3JvdW5kJyk7XG4gICAgfVxuICAgIHNldCBiYWNrZ3JvdW5kKHZhbHVlOiB7IGJvcmRlckNvbG9yPzogc3RyaW5nLCBjb2xvcj86IHN0cmluZyB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmFja2dyb3VuZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMuYm91bmRzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGJvdW5kcygpOiBBcnJheTxudW1iZXI+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYm91bmRzJyk7XG4gICAgfVxuICAgIHNldCBib3VuZHModmFsdWU6IEFycmF5PG51bWJlcj4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdib3VuZHMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLmNlbnRlcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBjZW50ZXIoKTogQXJyYXk8bnVtYmVyPiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NlbnRlcicpO1xuICAgIH1cbiAgICBzZXQgY2VudGVyKHZhbHVlOiBBcnJheTxudW1iZXI+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY2VudGVyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5jb21tb25Bbm5vdGF0aW9uU2V0dGluZ3NdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY29tbW9uQW5ub3RhdGlvblNldHRpbmdzKCk6IGR4VmVjdG9yTWFwQ29tbW9uQW5ub3RhdGlvbkNvbmZpZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbW1vbkFubm90YXRpb25TZXR0aW5ncycpO1xuICAgIH1cbiAgICBzZXQgY29tbW9uQW5ub3RhdGlvblNldHRpbmdzKHZhbHVlOiBkeFZlY3Rvck1hcENvbW1vbkFubm90YXRpb25Db25maWcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb21tb25Bbm5vdGF0aW9uU2V0dGluZ3MnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLmNvbnRyb2xCYXJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY29udHJvbEJhcigpOiB7IGJvcmRlckNvbG9yPzogc3RyaW5nLCBjb2xvcj86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50LCBtYXJnaW4/OiBudW1iZXIsIG9wYWNpdHk/OiBudW1iZXIsIHBhblZpc2libGU/OiBib29sZWFuLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgem9vbVZpc2libGU/OiBib29sZWFuIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjb250cm9sQmFyJyk7XG4gICAgfVxuICAgIHNldCBjb250cm9sQmFyKHZhbHVlOiB7IGJvcmRlckNvbG9yPzogc3RyaW5nLCBjb2xvcj86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50LCBtYXJnaW4/OiBudW1iZXIsIG9wYWNpdHk/OiBudW1iZXIsIHBhblZpc2libGU/OiBib29sZWFuLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgem9vbVZpc2libGU/OiBib29sZWFuIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb250cm9sQmFyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5jdXN0b21pemVBbm5vdGF0aW9uXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGN1c3RvbWl6ZUFubm90YXRpb24oKTogRnVuY3Rpb24gfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjdXN0b21pemVBbm5vdGF0aW9uJyk7XG4gICAgfVxuICAgIHNldCBjdXN0b21pemVBbm5vdGF0aW9uKHZhbHVlOiBGdW5jdGlvbiB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2N1c3RvbWl6ZUFubm90YXRpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMuZGlzYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Rpc2FibGVkJyk7XG4gICAgfVxuICAgIHNldCBkaXNhYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Rpc2FibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMuZWxlbWVudEF0dHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZWxlbWVudEF0dHIoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcbiAgICB9XG4gICAgc2V0IGVsZW1lbnRBdHRyKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpCYXNlV2lkZ2V0T3B0aW9ucy5leHBvcnRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZXhwb3J0KCk6IHsgYmFja2dyb3VuZENvbG9yPzogc3RyaW5nLCBlbmFibGVkPzogYm9vbGVhbiwgZmlsZU5hbWU/OiBzdHJpbmcsIGZvcm1hdHM/OiBhbnkgfCBBcnJheTxFeHBvcnRGb3JtYXQ+LCBtYXJnaW4/OiBudW1iZXIsIHByaW50aW5nRW5hYmxlZD86IGJvb2xlYW4sIHN2Z1RvQ2FudmFzPzogRnVuY3Rpb24gfCB1bmRlZmluZWQgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2V4cG9ydCcpO1xuICAgIH1cbiAgICBzZXQgZXhwb3J0KHZhbHVlOiB7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGZpbGVOYW1lPzogc3RyaW5nLCBmb3JtYXRzPzogYW55IHwgQXJyYXk8RXhwb3J0Rm9ybWF0PiwgbWFyZ2luPzogbnVtYmVyLCBwcmludGluZ0VuYWJsZWQ/OiBib29sZWFuLCBzdmdUb0NhbnZhcz86IEZ1bmN0aW9uIHwgdW5kZWZpbmVkIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdleHBvcnQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLmxheWVyc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBsYXllcnMoKTogQXJyYXk8YW55IHwgeyBib3JkZXJDb2xvcj86IHN0cmluZywgYm9yZGVyV2lkdGg/OiBudW1iZXIsIGNvbG9yPzogc3RyaW5nLCBjb2xvckdyb3VwaW5nRmllbGQ/OiBzdHJpbmcgfCB1bmRlZmluZWQsIGNvbG9yR3JvdXBzPzogQXJyYXk8bnVtYmVyPiwgY3VzdG9taXplPzogRnVuY3Rpb24sIGRhdGFGaWVsZD86IHN0cmluZyB8IHVuZGVmaW5lZCwgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgYW55IHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGVsZW1lbnRUeXBlPzogVmVjdG9yTWFwTWFya2VyVHlwZSwgaG92ZXJlZEJvcmRlckNvbG9yPzogc3RyaW5nLCBob3ZlcmVkQm9yZGVyV2lkdGg/OiBudW1iZXIsIGhvdmVyZWRDb2xvcj86IHN0cmluZywgaG92ZXJFbmFibGVkPzogYm9vbGVhbiwgbGFiZWw/OiB7IGRhdGFGaWVsZD86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGZvbnQ/OiBGb250IH0sIG1heFNpemU/OiBudW1iZXIsIG1pblNpemU/OiBudW1iZXIsIG5hbWU/OiBzdHJpbmcsIG9wYWNpdHk/OiBudW1iZXIsIHBhbGV0dGU/OiBQYWxldHRlIHwgc3RyaW5nIHwgQXJyYXk8c3RyaW5nPiwgcGFsZXR0ZUluZGV4PzogbnVtYmVyLCBwYWxldHRlU2l6ZT86IG51bWJlciwgc2VsZWN0ZWRCb3JkZXJDb2xvcj86IHN0cmluZywgc2VsZWN0ZWRCb3JkZXJXaWR0aD86IG51bWJlciwgc2VsZWN0ZWRDb2xvcj86IHN0cmluZywgc2VsZWN0aW9uTW9kZT86IFNpbmdsZU11bHRpcGxlT3JOb25lLCBzaXplPzogbnVtYmVyLCBzaXplR3JvdXBpbmdGaWVsZD86IHN0cmluZyB8IHVuZGVmaW5lZCwgc2l6ZUdyb3Vwcz86IEFycmF5PG51bWJlcj4sIHR5cGU/OiBWZWN0b3JNYXBMYXllclR5cGUgfT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdsYXllcnMnKTtcbiAgICB9XG4gICAgc2V0IGxheWVycyh2YWx1ZTogQXJyYXk8YW55IHwgeyBib3JkZXJDb2xvcj86IHN0cmluZywgYm9yZGVyV2lkdGg/OiBudW1iZXIsIGNvbG9yPzogc3RyaW5nLCBjb2xvckdyb3VwaW5nRmllbGQ/OiBzdHJpbmcgfCB1bmRlZmluZWQsIGNvbG9yR3JvdXBzPzogQXJyYXk8bnVtYmVyPiwgY3VzdG9taXplPzogRnVuY3Rpb24sIGRhdGFGaWVsZD86IHN0cmluZyB8IHVuZGVmaW5lZCwgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgYW55IHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGVsZW1lbnRUeXBlPzogVmVjdG9yTWFwTWFya2VyVHlwZSwgaG92ZXJlZEJvcmRlckNvbG9yPzogc3RyaW5nLCBob3ZlcmVkQm9yZGVyV2lkdGg/OiBudW1iZXIsIGhvdmVyZWRDb2xvcj86IHN0cmluZywgaG92ZXJFbmFibGVkPzogYm9vbGVhbiwgbGFiZWw/OiB7IGRhdGFGaWVsZD86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGZvbnQ/OiBGb250IH0sIG1heFNpemU/OiBudW1iZXIsIG1pblNpemU/OiBudW1iZXIsIG5hbWU/OiBzdHJpbmcsIG9wYWNpdHk/OiBudW1iZXIsIHBhbGV0dGU/OiBQYWxldHRlIHwgc3RyaW5nIHwgQXJyYXk8c3RyaW5nPiwgcGFsZXR0ZUluZGV4PzogbnVtYmVyLCBwYWxldHRlU2l6ZT86IG51bWJlciwgc2VsZWN0ZWRCb3JkZXJDb2xvcj86IHN0cmluZywgc2VsZWN0ZWRCb3JkZXJXaWR0aD86IG51bWJlciwgc2VsZWN0ZWRDb2xvcj86IHN0cmluZywgc2VsZWN0aW9uTW9kZT86IFNpbmdsZU11bHRpcGxlT3JOb25lLCBzaXplPzogbnVtYmVyLCBzaXplR3JvdXBpbmdGaWVsZD86IHN0cmluZyB8IHVuZGVmaW5lZCwgc2l6ZUdyb3Vwcz86IEFycmF5PG51bWJlcj4sIHR5cGU/OiBWZWN0b3JNYXBMYXllclR5cGUgfT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdsYXllcnMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLmxlZ2VuZHNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbGVnZW5kcygpOiBBcnJheTxhbnkgfCB7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgYm9yZGVyPzogeyBjb2xvcj86IHN0cmluZywgY29ybmVyUmFkaXVzPzogbnVtYmVyLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2x1bW5Db3VudD86IG51bWJlciwgY29sdW1uSXRlbVNwYWNpbmc/OiBudW1iZXIsIGN1c3RvbWl6ZUhpbnQ/OiBGdW5jdGlvbiwgY3VzdG9taXplSXRlbXM/OiBGdW5jdGlvbiwgY3VzdG9taXplVGV4dD86IEZ1bmN0aW9uLCBmb250PzogRm9udCwgaG9yaXpvbnRhbEFsaWdubWVudD86IEhvcml6b250YWxBbGlnbm1lbnQsIGl0ZW1zQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgaXRlbVRleHRQb3NpdGlvbj86IFBvc2l0aW9uIHwgdW5kZWZpbmVkLCBtYXJnaW4/OiBudW1iZXIgfCB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBtYXJrZXJDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgbWFya2VyU2hhcGU/OiBWZWN0b3JNYXBNYXJrZXJTaGFwZSwgbWFya2VyU2l6ZT86IG51bWJlciwgbWFya2VyVGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIG9yaWVudGF0aW9uPzogT3JpZW50YXRpb24gfCB1bmRlZmluZWQsIHBhZGRpbmdMZWZ0UmlnaHQ/OiBudW1iZXIsIHBhZGRpbmdUb3BCb3R0b20/OiBudW1iZXIsIHJvd0NvdW50PzogbnVtYmVyLCByb3dJdGVtU3BhY2luZz86IG51bWJlciwgc291cmNlPzogeyBncm91cGluZz86IHN0cmluZywgbGF5ZXI/OiBzdHJpbmcgfSwgdGl0bGU/OiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgbWFyZ2luPzogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZyB9LCB0ZXh0Pzogc3RyaW5nLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSB9LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgdmlzaWJsZT86IGJvb2xlYW4gfT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdsZWdlbmRzJyk7XG4gICAgfVxuICAgIHNldCBsZWdlbmRzKHZhbHVlOiBBcnJheTxhbnkgfCB7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgYm9yZGVyPzogeyBjb2xvcj86IHN0cmluZywgY29ybmVyUmFkaXVzPzogbnVtYmVyLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2x1bW5Db3VudD86IG51bWJlciwgY29sdW1uSXRlbVNwYWNpbmc/OiBudW1iZXIsIGN1c3RvbWl6ZUhpbnQ/OiBGdW5jdGlvbiwgY3VzdG9taXplSXRlbXM/OiBGdW5jdGlvbiwgY3VzdG9taXplVGV4dD86IEZ1bmN0aW9uLCBmb250PzogRm9udCwgaG9yaXpvbnRhbEFsaWdubWVudD86IEhvcml6b250YWxBbGlnbm1lbnQsIGl0ZW1zQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgaXRlbVRleHRQb3NpdGlvbj86IFBvc2l0aW9uIHwgdW5kZWZpbmVkLCBtYXJnaW4/OiBudW1iZXIgfCB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBtYXJrZXJDb2xvcj86IHN0cmluZyB8IHVuZGVmaW5lZCwgbWFya2VyU2hhcGU/OiBWZWN0b3JNYXBNYXJrZXJTaGFwZSwgbWFya2VyU2l6ZT86IG51bWJlciwgbWFya2VyVGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIG9yaWVudGF0aW9uPzogT3JpZW50YXRpb24gfCB1bmRlZmluZWQsIHBhZGRpbmdMZWZ0UmlnaHQ/OiBudW1iZXIsIHBhZGRpbmdUb3BCb3R0b20/OiBudW1iZXIsIHJvd0NvdW50PzogbnVtYmVyLCByb3dJdGVtU3BhY2luZz86IG51bWJlciwgc291cmNlPzogeyBncm91cGluZz86IHN0cmluZywgbGF5ZXI/OiBzdHJpbmcgfSwgdGl0bGU/OiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgbWFyZ2luPzogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZyB9LCB0ZXh0Pzogc3RyaW5nLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSB9LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgdmlzaWJsZT86IGJvb2xlYW4gfT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdsZWdlbmRzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkJhc2VXaWRnZXRPcHRpb25zLmxvYWRpbmdJbmRpY2F0b3JdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbG9hZGluZ0luZGljYXRvcigpOiB7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGZvbnQ/OiBGb250LCBzaG93PzogYm9vbGVhbiwgdGV4dD86IHN0cmluZyB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbG9hZGluZ0luZGljYXRvcicpO1xuICAgIH1cbiAgICBzZXQgbG9hZGluZ0luZGljYXRvcih2YWx1ZTogeyBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcsIGVuYWJsZWQ/OiBib29sZWFuLCBmb250PzogRm9udCwgc2hvdz86IGJvb2xlYW4sIHRleHQ/OiBzdHJpbmcgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2xvYWRpbmdJbmRpY2F0b3InLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLm1heFpvb21GYWN0b3JdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbWF4Wm9vbUZhY3RvcigpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtYXhab29tRmFjdG9yJyk7XG4gICAgfVxuICAgIHNldCBtYXhab29tRmFjdG9yKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdtYXhab29tRmFjdG9yJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5wYW5uaW5nRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBwYW5uaW5nRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncGFubmluZ0VuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHBhbm5pbmdFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncGFubmluZ0VuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMucGF0aE1vZGlmaWVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBhdGhNb2RpZmllZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncGF0aE1vZGlmaWVkJyk7XG4gICAgfVxuICAgIHNldCBwYXRoTW9kaWZpZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdwYXRoTW9kaWZpZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLnByb2plY3Rpb25dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcHJvamVjdGlvbigpOiBWZWN0b3JNYXBQcm9qZWN0aW9uIHwgVmVjdG9yTWFwUHJvamVjdGlvbkNvbmZpZyB8IGFueSB8IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Byb2plY3Rpb24nKTtcbiAgICB9XG4gICAgc2V0IHByb2plY3Rpb24odmFsdWU6IFZlY3Rvck1hcFByb2plY3Rpb24gfCBWZWN0b3JNYXBQcm9qZWN0aW9uQ29uZmlnIHwgYW55IHwgc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncHJvamVjdGlvbicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpCYXNlV2lkZ2V0T3B0aW9ucy5yZWRyYXdPblJlc2l6ZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCByZWRyYXdPblJlc2l6ZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVkcmF3T25SZXNpemUnKTtcbiAgICB9XG4gICAgc2V0IHJlZHJhd09uUmVzaXplKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncmVkcmF3T25SZXNpemUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMucnRsRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBydGxFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdydGxFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBydGxFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncnRsRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpCYXNlV2lkZ2V0T3B0aW9ucy5zaXplXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNpemUoKTogeyBoZWlnaHQ/OiBudW1iZXIgfCB1bmRlZmluZWQsIHdpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaXplJyk7XG4gICAgfVxuICAgIHNldCBzaXplKHZhbHVlOiB7IGhlaWdodD86IG51bWJlciB8IHVuZGVmaW5lZCwgd2lkdGg/OiBudW1iZXIgfCB1bmRlZmluZWQgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NpemUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMudGhlbWVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdGhlbWUoKTogVGhlbWUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0aGVtZScpO1xuICAgIH1cbiAgICBzZXQgdGhlbWUodmFsdWU6IFRoZW1lKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGhlbWUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6QmFzZVdpZGdldE9wdGlvbnMudGl0bGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdGl0bGUoKTogc3RyaW5nIHwgeyBmb250PzogRm9udCwgaG9yaXpvbnRhbEFsaWdubWVudD86IEhvcml6b250YWxBbGlnbm1lbnQsIG1hcmdpbj86IG51bWJlciB8IHsgYm90dG9tPzogbnVtYmVyLCBsZWZ0PzogbnVtYmVyLCByaWdodD86IG51bWJlciwgdG9wPzogbnVtYmVyIH0sIHBsYWNlaG9sZGVyU2l6ZT86IG51bWJlciB8IHVuZGVmaW5lZCwgc3VidGl0bGU/OiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBvZmZzZXQ/OiBudW1iZXIsIHRleHQ/OiBzdHJpbmcsIHRleHRPdmVyZmxvdz86IFRleHRPdmVyZmxvdywgd29yZFdyYXA/OiBXb3JkV3JhcCB9LCB0ZXh0Pzogc3RyaW5nLCB0ZXh0T3ZlcmZsb3c/OiBUZXh0T3ZlcmZsb3csIHZlcnRpY2FsQWxpZ25tZW50PzogVmVydGljYWxFZGdlLCB3b3JkV3JhcD86IFdvcmRXcmFwIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0aXRsZScpO1xuICAgIH1cbiAgICBzZXQgdGl0bGUodmFsdWU6IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50LCBtYXJnaW4/OiBudW1iZXIgfCB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBwbGFjZWhvbGRlclNpemU/OiBudW1iZXIgfCB1bmRlZmluZWQsIHN1YnRpdGxlPzogc3RyaW5nIHwgeyBmb250PzogRm9udCwgb2Zmc2V0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nLCB0ZXh0T3ZlcmZsb3c/OiBUZXh0T3ZlcmZsb3csIHdvcmRXcmFwPzogV29yZFdyYXAgfSwgdGV4dD86IHN0cmluZywgdGV4dE92ZXJmbG93PzogVGV4dE92ZXJmbG93LCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgd29yZFdyYXA/OiBXb3JkV3JhcCB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGl0bGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLnRvb2x0aXBdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdG9vbHRpcCgpOiB7IGFycm93TGVuZ3RoPzogbnVtYmVyLCBib3JkZXI/OiB7IGNvbG9yPzogc3RyaW5nLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2xvcj86IHN0cmluZywgY29udGFpbmVyPzogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBjb250ZW50VGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIGNvcm5lclJhZGl1cz86IG51bWJlciwgY3VzdG9taXplVG9vbHRpcD86IEZ1bmN0aW9uIHwgdW5kZWZpbmVkLCBlbmFibGVkPzogYm9vbGVhbiwgZm9udD86IEZvbnQsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHBhZGRpbmdMZWZ0UmlnaHQ/OiBudW1iZXIsIHBhZGRpbmdUb3BCb3R0b20/OiBudW1iZXIsIHNoYWRvdz86IHsgYmx1cj86IG51bWJlciwgY29sb3I/OiBzdHJpbmcsIG9mZnNldFg/OiBudW1iZXIsIG9mZnNldFk/OiBudW1iZXIsIG9wYWNpdHk/OiBudW1iZXIgfSwgekluZGV4PzogbnVtYmVyIHwgdW5kZWZpbmVkIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0b29sdGlwJyk7XG4gICAgfVxuICAgIHNldCB0b29sdGlwKHZhbHVlOiB7IGFycm93TGVuZ3RoPzogbnVtYmVyLCBib3JkZXI/OiB7IGNvbG9yPzogc3RyaW5nLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9LCBjb2xvcj86IHN0cmluZywgY29udGFpbmVyPzogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBjb250ZW50VGVtcGxhdGU/OiBhbnkgfCB1bmRlZmluZWQsIGNvcm5lclJhZGl1cz86IG51bWJlciwgY3VzdG9taXplVG9vbHRpcD86IEZ1bmN0aW9uIHwgdW5kZWZpbmVkLCBlbmFibGVkPzogYm9vbGVhbiwgZm9udD86IEZvbnQsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHBhZGRpbmdMZWZ0UmlnaHQ/OiBudW1iZXIsIHBhZGRpbmdUb3BCb3R0b20/OiBudW1iZXIsIHNoYWRvdz86IHsgYmx1cj86IG51bWJlciwgY29sb3I/OiBzdHJpbmcsIG9mZnNldFg/OiBudW1iZXIsIG9mZnNldFk/OiBudW1iZXIsIG9wYWNpdHk/OiBudW1iZXIgfSwgekluZGV4PzogbnVtYmVyIHwgdW5kZWZpbmVkIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0b29sdGlwJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy50b3VjaEVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdG91Y2hFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0b3VjaEVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHRvdWNoRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RvdWNoRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMud2hlZWxFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHdoZWVsRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignd2hlZWxFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCB3aGVlbEVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd3aGVlbEVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLnpvb21GYWN0b3JdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgem9vbUZhY3RvcigpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd6b29tRmFjdG9yJyk7XG4gICAgfVxuICAgIHNldCB6b29tRmFjdG9yKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd6b29tRmFjdG9yJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy56b29taW5nRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB6b29taW5nRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignem9vbWluZ0VuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHpvb21pbmdFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignem9vbWluZ0VuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5vbkNlbnRlckNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ2VudGVyQ2hhbmdlZDogRXZlbnRFbWl0dGVyPENlbnRlckNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLm9uQ2xpY2tdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ2xpY2s6IEV2ZW50RW1pdHRlcjxDbGlja0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMub25EaXNwb3NpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRGlzcG9zaW5nOiBFdmVudEVtaXR0ZXI8RGlzcG9zaW5nRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5vbkRyYXduXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkRyYXduOiBFdmVudEVtaXR0ZXI8RHJhd25FdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLm9uRXhwb3J0ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRXhwb3J0ZWQ6IEV2ZW50RW1pdHRlcjxFeHBvcnRlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMub25FeHBvcnRpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRXhwb3J0aW5nOiBFdmVudEVtaXR0ZXI8RXhwb3J0aW5nRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5vbkZpbGVTYXZpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRmlsZVNhdmluZzogRXZlbnRFbWl0dGVyPEZpbGVTYXZpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLm9uSW5jaWRlbnRPY2N1cnJlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25JbmNpZGVudE9jY3VycmVkOiBFdmVudEVtaXR0ZXI8SW5jaWRlbnRPY2N1cnJlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMub25Jbml0aWFsaXplZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25Jbml0aWFsaXplZDogRXZlbnRFbWl0dGVyPEluaXRpYWxpemVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5vbk9wdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uT3B0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPE9wdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLm9uU2VsZWN0aW9uQ2hhbmdlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25TZWxlY3Rpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8U2VsZWN0aW9uQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFZlY3Rvck1hcE9wdGlvbnMub25Ub29sdGlwSGlkZGVuXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblRvb2x0aXBIaWRkZW46IEV2ZW50RW1pdHRlcjxUb29sdGlwSGlkZGVuRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4VmVjdG9yTWFwT3B0aW9ucy5vblRvb2x0aXBTaG93bl1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25Ub29sdGlwU2hvd246IEV2ZW50RW1pdHRlcjxUb29sdGlwU2hvd25FdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhWZWN0b3JNYXBPcHRpb25zLm9uWm9vbUZhY3RvckNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uWm9vbUZhY3RvckNoYW5nZWQ6IEV2ZW50RW1pdHRlcjxab29tRmFjdG9yQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGFubm90YXRpb25zQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8ZHhWZWN0b3JNYXBBbm5vdGF0aW9uQ29uZmlnIHwgYW55Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBiYWNrZ3JvdW5kQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBib3JkZXJDb2xvcj86IHN0cmluZywgY29sb3I/OiBzdHJpbmcgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBib3VuZHNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxBcnJheTxudW1iZXI+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGNlbnRlckNoYW5nZTogRXZlbnRFbWl0dGVyPEFycmF5PG51bWJlcj4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY29tbW9uQW5ub3RhdGlvblNldHRpbmdzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8ZHhWZWN0b3JNYXBDb21tb25Bbm5vdGF0aW9uQ29uZmlnPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGNvbnRyb2xCYXJDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGJvcmRlckNvbG9yPzogc3RyaW5nLCBjb2xvcj86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50LCBtYXJnaW4/OiBudW1iZXIsIG9wYWNpdHk/OiBudW1iZXIsIHBhblZpc2libGU/OiBib29sZWFuLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSwgem9vbVZpc2libGU/OiBib29sZWFuIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY3VzdG9taXplQW5ub3RhdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPEZ1bmN0aW9uIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRpc2FibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBlbGVtZW50QXR0ckNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBleHBvcnRDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGJhY2tncm91bmRDb2xvcj86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGZpbGVOYW1lPzogc3RyaW5nLCBmb3JtYXRzPzogYW55IHwgQXJyYXk8RXhwb3J0Rm9ybWF0PiwgbWFyZ2luPzogbnVtYmVyLCBwcmludGluZ0VuYWJsZWQ/OiBib29sZWFuLCBzdmdUb0NhbnZhcz86IEZ1bmN0aW9uIHwgdW5kZWZpbmVkIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbGF5ZXJzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8YW55IHwgeyBib3JkZXJDb2xvcj86IHN0cmluZywgYm9yZGVyV2lkdGg/OiBudW1iZXIsIGNvbG9yPzogc3RyaW5nLCBjb2xvckdyb3VwaW5nRmllbGQ/OiBzdHJpbmcgfCB1bmRlZmluZWQsIGNvbG9yR3JvdXBzPzogQXJyYXk8bnVtYmVyPiwgY3VzdG9taXplPzogRnVuY3Rpb24sIGRhdGFGaWVsZD86IHN0cmluZyB8IHVuZGVmaW5lZCwgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgYW55IHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGVsZW1lbnRUeXBlPzogVmVjdG9yTWFwTWFya2VyVHlwZSwgaG92ZXJlZEJvcmRlckNvbG9yPzogc3RyaW5nLCBob3ZlcmVkQm9yZGVyV2lkdGg/OiBudW1iZXIsIGhvdmVyZWRDb2xvcj86IHN0cmluZywgaG92ZXJFbmFibGVkPzogYm9vbGVhbiwgbGFiZWw/OiB7IGRhdGFGaWVsZD86IHN0cmluZywgZW5hYmxlZD86IGJvb2xlYW4sIGZvbnQ/OiBGb250IH0sIG1heFNpemU/OiBudW1iZXIsIG1pblNpemU/OiBudW1iZXIsIG5hbWU/OiBzdHJpbmcsIG9wYWNpdHk/OiBudW1iZXIsIHBhbGV0dGU/OiBQYWxldHRlIHwgc3RyaW5nIHwgQXJyYXk8c3RyaW5nPiwgcGFsZXR0ZUluZGV4PzogbnVtYmVyLCBwYWxldHRlU2l6ZT86IG51bWJlciwgc2VsZWN0ZWRCb3JkZXJDb2xvcj86IHN0cmluZywgc2VsZWN0ZWRCb3JkZXJXaWR0aD86IG51bWJlciwgc2VsZWN0ZWRDb2xvcj86IHN0cmluZywgc2VsZWN0aW9uTW9kZT86IFNpbmdsZU11bHRpcGxlT3JOb25lLCBzaXplPzogbnVtYmVyLCBzaXplR3JvdXBpbmdGaWVsZD86IHN0cmluZyB8IHVuZGVmaW5lZCwgc2l6ZUdyb3Vwcz86IEFycmF5PG51bWJlcj4sIHR5cGU/OiBWZWN0b3JNYXBMYXllclR5cGUgfT4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbGVnZW5kc0NoYW5nZTogRXZlbnRFbWl0dGVyPEFycmF5PGFueSB8IHsgYmFja2dyb3VuZENvbG9yPzogc3RyaW5nIHwgdW5kZWZpbmVkLCBib3JkZXI/OiB7IGNvbG9yPzogc3RyaW5nLCBjb3JuZXJSYWRpdXM/OiBudW1iZXIsIGRhc2hTdHlsZT86IERhc2hTdHlsZSwgb3BhY2l0eT86IG51bWJlciB8IHVuZGVmaW5lZCwgdmlzaWJsZT86IGJvb2xlYW4sIHdpZHRoPzogbnVtYmVyIH0sIGNvbHVtbkNvdW50PzogbnVtYmVyLCBjb2x1bW5JdGVtU3BhY2luZz86IG51bWJlciwgY3VzdG9taXplSGludD86IEZ1bmN0aW9uLCBjdXN0b21pemVJdGVtcz86IEZ1bmN0aW9uLCBjdXN0b21pemVUZXh0PzogRnVuY3Rpb24sIGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCwgaXRlbXNBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50IHwgdW5kZWZpbmVkLCBpdGVtVGV4dFBvc2l0aW9uPzogUG9zaXRpb24gfCB1bmRlZmluZWQsIG1hcmdpbj86IG51bWJlciB8IHsgYm90dG9tPzogbnVtYmVyLCBsZWZ0PzogbnVtYmVyLCByaWdodD86IG51bWJlciwgdG9wPzogbnVtYmVyIH0sIG1hcmtlckNvbG9yPzogc3RyaW5nIHwgdW5kZWZpbmVkLCBtYXJrZXJTaGFwZT86IFZlY3Rvck1hcE1hcmtlclNoYXBlLCBtYXJrZXJTaXplPzogbnVtYmVyLCBtYXJrZXJUZW1wbGF0ZT86IGFueSB8IHVuZGVmaW5lZCwgb3JpZW50YXRpb24/OiBPcmllbnRhdGlvbiB8IHVuZGVmaW5lZCwgcGFkZGluZ0xlZnRSaWdodD86IG51bWJlciwgcGFkZGluZ1RvcEJvdHRvbT86IG51bWJlciwgcm93Q291bnQ/OiBudW1iZXIsIHJvd0l0ZW1TcGFjaW5nPzogbnVtYmVyLCBzb3VyY2U/OiB7IGdyb3VwaW5nPzogc3RyaW5nLCBsYXllcj86IHN0cmluZyB9LCB0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIGhvcml6b250YWxBbGlnbm1lbnQ/OiBIb3Jpem9udGFsQWxpZ25tZW50IHwgdW5kZWZpbmVkLCBtYXJnaW4/OiB7IGJvdHRvbT86IG51bWJlciwgbGVmdD86IG51bWJlciwgcmlnaHQ/OiBudW1iZXIsIHRvcD86IG51bWJlciB9LCBwbGFjZWhvbGRlclNpemU/OiBudW1iZXIgfCB1bmRlZmluZWQsIHN1YnRpdGxlPzogc3RyaW5nIHwgeyBmb250PzogRm9udCwgb2Zmc2V0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nIH0sIHRleHQ/OiBzdHJpbmcsIHZlcnRpY2FsQWxpZ25tZW50PzogVmVydGljYWxFZGdlIH0sIHZlcnRpY2FsQWxpZ25tZW50PzogVmVydGljYWxFZGdlLCB2aXNpYmxlPzogYm9vbGVhbiB9Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBsb2FkaW5nSW5kaWNhdG9yQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcsIGVuYWJsZWQ/OiBib29sZWFuLCBmb250PzogRm9udCwgc2hvdz86IGJvb2xlYW4sIHRleHQ/OiBzdHJpbmcgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBtYXhab29tRmFjdG9yQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHBhbm5pbmdFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBwYXRoTW9kaWZpZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHByb2plY3Rpb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxWZWN0b3JNYXBQcm9qZWN0aW9uIHwgVmVjdG9yTWFwUHJvamVjdGlvbkNvbmZpZyB8IGFueSB8IHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSByZWRyYXdPblJlc2l6ZUNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcnRsRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2l6ZUNoYW5nZTogRXZlbnRFbWl0dGVyPHsgaGVpZ2h0PzogbnVtYmVyIHwgdW5kZWZpbmVkLCB3aWR0aD86IG51bWJlciB8IHVuZGVmaW5lZCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRoZW1lQ2hhbmdlOiBFdmVudEVtaXR0ZXI8VGhlbWU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGl0bGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCwgbWFyZ2luPzogbnVtYmVyIHwgeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZywgdGV4dE92ZXJmbG93PzogVGV4dE92ZXJmbG93LCB3b3JkV3JhcD86IFdvcmRXcmFwIH0sIHRleHQ/OiBzdHJpbmcsIHRleHRPdmVyZmxvdz86IFRleHRPdmVyZmxvdywgdmVydGljYWxBbGlnbm1lbnQ/OiBWZXJ0aWNhbEVkZ2UsIHdvcmRXcmFwPzogV29yZFdyYXAgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0b29sdGlwQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBhcnJvd0xlbmd0aD86IG51bWJlciwgYm9yZGVyPzogeyBjb2xvcj86IHN0cmluZywgZGFzaFN0eWxlPzogRGFzaFN0eWxlLCBvcGFjaXR5PzogbnVtYmVyIHwgdW5kZWZpbmVkLCB2aXNpYmxlPzogYm9vbGVhbiwgd2lkdGg/OiBudW1iZXIgfSwgY29sb3I/OiBzdHJpbmcsIGNvbnRhaW5lcj86IFVzZXJEZWZpbmVkRWxlbWVudCB8IHN0cmluZyB8IHVuZGVmaW5lZCwgY29udGVudFRlbXBsYXRlPzogYW55IHwgdW5kZWZpbmVkLCBjb3JuZXJSYWRpdXM/OiBudW1iZXIsIGN1c3RvbWl6ZVRvb2x0aXA/OiBGdW5jdGlvbiB8IHVuZGVmaW5lZCwgZW5hYmxlZD86IGJvb2xlYW4sIGZvbnQ/OiBGb250LCBvcGFjaXR5PzogbnVtYmVyIHwgdW5kZWZpbmVkLCBwYWRkaW5nTGVmdFJpZ2h0PzogbnVtYmVyLCBwYWRkaW5nVG9wQm90dG9tPzogbnVtYmVyLCBzaGFkb3c/OiB7IGJsdXI/OiBudW1iZXIsIGNvbG9yPzogc3RyaW5nLCBvZmZzZXRYPzogbnVtYmVyLCBvZmZzZXRZPzogbnVtYmVyLCBvcGFjaXR5PzogbnVtYmVyIH0sIHpJbmRleD86IG51bWJlciB8IHVuZGVmaW5lZCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRvdWNoRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgd2hlZWxFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB6b29tRmFjdG9yQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHpvb21pbmdFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cblxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKER4aUFubm90YXRpb25Db21wb25lbnQpXG4gICAgZ2V0IGFubm90YXRpb25zQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUFubm90YXRpb25Db21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYW5ub3RhdGlvbnMnKTtcbiAgICB9XG4gICAgc2V0IGFubm90YXRpb25zQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignYW5ub3RhdGlvbnMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihEeGlMYXllckNvbXBvbmVudClcbiAgICBnZXQgbGF5ZXJzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUxheWVyQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2xheWVycycpO1xuICAgIH1cbiAgICBzZXQgbGF5ZXJzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignbGF5ZXJzJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oRHhpTGVnZW5kQ29tcG9uZW50KVxuICAgIGdldCBsZWdlbmRzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUxlZ2VuZENvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdsZWdlbmRzJyk7XG4gICAgfVxuICAgIHNldCBsZWdlbmRzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignbGVnZW5kcycsIHZhbHVlKTtcbiAgICB9XG5cblxuXG5cbiAgICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmLCBuZ1pvbmU6IE5nWm9uZSwgdGVtcGxhdGVIb3N0OiBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgICAgIHByaXZhdGUgX3dhdGNoZXJIZWxwZXI6IFdhdGNoZXJIZWxwZXIsXG4gICAgICAgICAgICBwcml2YXRlIF9pZGg6IEl0ZXJhYmxlRGlmZmVySGVscGVyLFxuICAgICAgICAgICAgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgICAgIHRyYW5zZmVyU3RhdGU6IFRyYW5zZmVyU3RhdGUsXG4gICAgICAgICAgICBASW5qZWN0KFBMQVRGT1JNX0lEKSBwbGF0Zm9ybUlkOiBhbnkpIHtcblxuICAgICAgICBzdXBlcihlbGVtZW50UmVmLCBuZ1pvbmUsIHRlbXBsYXRlSG9zdCwgX3dhdGNoZXJIZWxwZXIsIHRyYW5zZmVyU3RhdGUsIHBsYXRmb3JtSWQpO1xuXG4gICAgICAgIHRoaXMuX2NyZWF0ZUV2ZW50RW1pdHRlcnMoW1xuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdjZW50ZXJDaGFuZ2VkJywgZW1pdDogJ29uQ2VudGVyQ2hhbmdlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnY2xpY2snLCBlbWl0OiAnb25DbGljaycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZGlzcG9zaW5nJywgZW1pdDogJ29uRGlzcG9zaW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkcmF3bicsIGVtaXQ6ICdvbkRyYXduJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdleHBvcnRlZCcsIGVtaXQ6ICdvbkV4cG9ydGVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdleHBvcnRpbmcnLCBlbWl0OiAnb25FeHBvcnRpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2ZpbGVTYXZpbmcnLCBlbWl0OiAnb25GaWxlU2F2aW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdpbmNpZGVudE9jY3VycmVkJywgZW1pdDogJ29uSW5jaWRlbnRPY2N1cnJlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5pdGlhbGl6ZWQnLCBlbWl0OiAnb25Jbml0aWFsaXplZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnb3B0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvbk9wdGlvbkNoYW5nZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3NlbGVjdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25TZWxlY3Rpb25DaGFuZ2VkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0b29sdGlwSGlkZGVuJywgZW1pdDogJ29uVG9vbHRpcEhpZGRlbicgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAndG9vbHRpcFNob3duJywgZW1pdDogJ29uVG9vbHRpcFNob3duJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd6b29tRmFjdG9yQ2hhbmdlZCcsIGVtaXQ6ICdvblpvb21GYWN0b3JDaGFuZ2VkJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYW5ub3RhdGlvbnNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdiYWNrZ3JvdW5kQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYm91bmRzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnY2VudGVyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnY29tbW9uQW5ub3RhdGlvblNldHRpbmdzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnY29udHJvbEJhckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2N1c3RvbWl6ZUFubm90YXRpb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdkaXNhYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2VsZW1lbnRBdHRyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZXhwb3J0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnbGF5ZXJzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnbGVnZW5kc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2xvYWRpbmdJbmRpY2F0b3JDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdtYXhab29tRmFjdG9yQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncGFubmluZ0VuYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdwYXRoTW9kaWZpZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdwcm9qZWN0aW9uQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncmVkcmF3T25SZXNpemVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdydGxFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2l6ZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3RoZW1lQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGl0bGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0b29sdGlwQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndG91Y2hFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnd2hlZWxFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnem9vbUZhY3RvckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3pvb21pbmdFbmFibGVkQ2hhbmdlJyB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIHRoaXMuX2lkaC5zZXRIb3N0KHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcyk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9jcmVhdGVJbnN0YW5jZShlbGVtZW50LCBvcHRpb25zKSB7XG5cbiAgICAgICAgcmV0dXJuIG5ldyBEeFZlY3Rvck1hcChlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2Fubm90YXRpb25zJywgY2hhbmdlcyk7XG4gICAgICAgIHRoaXMuc2V0dXBDaGFuZ2VzKCdib3VuZHMnLCBjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2NlbnRlcicsIGNoYW5nZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygnbGF5ZXJzJywgY2hhbmdlcyk7XG4gICAgICAgIHRoaXMuc2V0dXBDaGFuZ2VzKCdsZWdlbmRzJywgY2hhbmdlcyk7XG4gICAgfVxuXG4gICAgc2V0dXBDaGFuZ2VzKHByb3A6IHN0cmluZywgY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoIShwcm9wIGluIHRoaXMuX29wdGlvbnNUb1VwZGF0ZSkpIHtcbiAgICAgICAgICAgIHRoaXMuX2lkaC5zZXR1cChwcm9wLCBjaGFuZ2VzKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nRG9DaGVjaygpIHtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2Fubm90YXRpb25zJyk7XG4gICAgICAgIHRoaXMuX2lkaC5kb0NoZWNrKCdib3VuZHMnKTtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2NlbnRlcicpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnbGF5ZXJzJyk7XG4gICAgICAgIHRoaXMuX2lkaC5kb0NoZWNrKCdsZWdlbmRzJyk7XG4gICAgICAgIHRoaXMuX3dhdGNoZXJIZWxwZXIuY2hlY2tXYXRjaGVycygpO1xuICAgICAgICBzdXBlci5uZ0RvQ2hlY2soKTtcbiAgICAgICAgc3VwZXIuY2xlYXJDaGFuZ2VkT3B0aW9ucygpO1xuICAgIH1cblxuICAgIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XG4gICAgICAgIGxldCBpc1NldHVwID0gdGhpcy5faWRoLnNldHVwU2luZ2xlKG5hbWUsIHZhbHVlKTtcbiAgICAgICAgbGV0IGlzQ2hhbmdlZCA9IHRoaXMuX2lkaC5nZXRDaGFuZ2VzKG5hbWUsIHZhbHVlKSAhPT0gbnVsbDtcblxuICAgICAgICBpZiAoaXNTZXR1cCB8fCBpc0NoYW5nZWQpIHtcbiAgICAgICAgICAgIHN1cGVyLl9zZXRPcHRpb24obmFtZSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgRHhpQW5ub3RhdGlvbk1vZHVsZSxcbiAgICBEeG9Cb3JkZXJNb2R1bGUsXG4gICAgRHhvRm9udE1vZHVsZSxcbiAgICBEeG9JbWFnZU1vZHVsZSxcbiAgICBEeG9TaGFkb3dNb2R1bGUsXG4gICAgRHhvQmFja2dyb3VuZE1vZHVsZSxcbiAgICBEeG9Db21tb25Bbm5vdGF0aW9uU2V0dGluZ3NNb2R1bGUsXG4gICAgRHhvQ29udHJvbEJhck1vZHVsZSxcbiAgICBEeG9FeHBvcnRNb2R1bGUsXG4gICAgRHhpTGF5ZXJNb2R1bGUsXG4gICAgRHhvTGFiZWxNb2R1bGUsXG4gICAgRHhpTGVnZW5kTW9kdWxlLFxuICAgIER4b01hcmdpbk1vZHVsZSxcbiAgICBEeG9Tb3VyY2VNb2R1bGUsXG4gICAgRHhvVGl0bGVNb2R1bGUsXG4gICAgRHhvU3VidGl0bGVNb2R1bGUsXG4gICAgRHhvTG9hZGluZ0luZGljYXRvck1vZHVsZSxcbiAgICBEeG9Qcm9qZWN0aW9uTW9kdWxlLFxuICAgIER4b1NpemVNb2R1bGUsXG4gICAgRHhvVG9vbHRpcE1vZHVsZSxcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGVcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhWZWN0b3JNYXBDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4VmVjdG9yTWFwQ29tcG9uZW50LFxuICAgIER4aUFubm90YXRpb25Nb2R1bGUsXG4gICAgRHhvQm9yZGVyTW9kdWxlLFxuICAgIER4b0ZvbnRNb2R1bGUsXG4gICAgRHhvSW1hZ2VNb2R1bGUsXG4gICAgRHhvU2hhZG93TW9kdWxlLFxuICAgIER4b0JhY2tncm91bmRNb2R1bGUsXG4gICAgRHhvQ29tbW9uQW5ub3RhdGlvblNldHRpbmdzTW9kdWxlLFxuICAgIER4b0NvbnRyb2xCYXJNb2R1bGUsXG4gICAgRHhvRXhwb3J0TW9kdWxlLFxuICAgIER4aUxheWVyTW9kdWxlLFxuICAgIER4b0xhYmVsTW9kdWxlLFxuICAgIER4aUxlZ2VuZE1vZHVsZSxcbiAgICBEeG9NYXJnaW5Nb2R1bGUsXG4gICAgRHhvU291cmNlTW9kdWxlLFxuICAgIER4b1RpdGxlTW9kdWxlLFxuICAgIER4b1N1YnRpdGxlTW9kdWxlLFxuICAgIER4b0xvYWRpbmdJbmRpY2F0b3JNb2R1bGUsXG4gICAgRHhvUHJvamVjdGlvbk1vZHVsZSxcbiAgICBEeG9TaXplTW9kdWxlLFxuICAgIER4b1Rvb2x0aXBNb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZVxuICBdXG59KVxuZXhwb3J0IGNsYXNzIER4VmVjdG9yTWFwTW9kdWxlIHsgfVxuXG5pbXBvcnQgdHlwZSAqIGFzIER4VmVjdG9yTWFwVHlwZXMgZnJvbSBcImRldmV4dHJlbWUvdml6L3ZlY3Rvcl9tYXBfdHlwZXNcIjtcbmV4cG9ydCB7IER4VmVjdG9yTWFwVHlwZXMgfTtcblxuXG4iXX0=