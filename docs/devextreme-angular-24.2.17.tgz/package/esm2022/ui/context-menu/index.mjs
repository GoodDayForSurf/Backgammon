/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import DxContextMenu from 'devextreme/ui/context_menu';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxoAnimationModule } from 'devextreme-angular/ui/nested';
import { DxoHideModule } from 'devextreme-angular/ui/nested';
import { DxoFromModule } from 'devextreme-angular/ui/nested';
import { DxoPositionModule } from 'devextreme-angular/ui/nested';
import { DxoAtModule } from 'devextreme-angular/ui/nested';
import { DxoBoundaryOffsetModule } from 'devextreme-angular/ui/nested';
import { DxoCollisionModule } from 'devextreme-angular/ui/nested';
import { DxoMyModule } from 'devextreme-angular/ui/nested';
import { DxoOffsetModule } from 'devextreme-angular/ui/nested';
import { DxoToModule } from 'devextreme-angular/ui/nested';
import { DxoShowModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoShowEventModule } from 'devextreme-angular/ui/nested';
import { DxoShowSubmenuModeModule } from 'devextreme-angular/ui/nested';
import { DxoDelayModule } from 'devextreme-angular/ui/nested';
import { DxiItemComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxContextMenu]

 */
export class DxContextMenuComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxMenuBaseOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxMenuBaseOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxContextMenuOptions.closeOnOutsideClick]
    
     * @deprecated [depNote:dxContextMenuOptions.closeOnOutsideClick]
    
     */
    get closeOnOutsideClick() {
        return this._getOption('closeOnOutsideClick');
    }
    set closeOnOutsideClick(value) {
        this._setOption('closeOnOutsideClick', value);
    }
    /**
     * [descr:dxMenuBaseOptions.cssClass]
    
     */
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    /**
     * [descr:dxContextMenuOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.disabledExpr]
    
     */
    get disabledExpr() {
        return this._getOption('disabledExpr');
    }
    set disabledExpr(value) {
        this._setOption('disabledExpr', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxContextMenuOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxContextMenuOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.itemsExpr]
    
     */
    get itemsExpr() {
        return this._getOption('itemsExpr');
    }
    set itemsExpr(value) {
        this._setOption('itemsExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxContextMenuOptions.position]
    
     */
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxMenuBaseOptions.selectByClick]
    
     */
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.selectedExpr]
    
     */
    get selectedExpr() {
        return this._getOption('selectedExpr');
    }
    set selectedExpr(value) {
        this._setOption('selectedExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:dxMenuBaseOptions.selectionMode]
    
     */
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    /**
     * [descr:dxContextMenuOptions.showEvent]
    
     */
    get showEvent() {
        return this._getOption('showEvent');
    }
    set showEvent(value) {
        this._setOption('showEvent', value);
    }
    /**
     * [descr:dxMenuBaseOptions.showSubmenuMode]
    
     */
    get showSubmenuMode() {
        return this._getOption('showSubmenuMode');
    }
    set showSubmenuMode(value) {
        this._setOption('showSubmenuMode', value);
    }
    /**
     * [descr:dxContextMenuOptions.submenuDirection]
    
     */
    get submenuDirection() {
        return this._getOption('submenuDirection');
    }
    set submenuDirection(value) {
        this._setOption('submenuDirection', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxContextMenuOptions.target]
    
     */
    get target() {
        return this._getOption('target');
    }
    set target(value) {
        this._setOption('target', value);
    }
    /**
     * [descr:dxContextMenuOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxContextMenuOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxContextMenuOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxContextMenuOptions.onHidden]
    
    
     */
    onHidden;
    /**
    
     * [descr:dxContextMenuOptions.onHiding]
    
    
     */
    onHiding;
    /**
    
     * [descr:dxContextMenuOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxContextMenuOptions.onItemClick]
    
    
     */
    onItemClick;
    /**
    
     * [descr:dxContextMenuOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu;
    /**
    
     * [descr:dxContextMenuOptions.onItemRendered]
    
    
     */
    onItemRendered;
    /**
    
     * [descr:dxContextMenuOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxContextMenuOptions.onPositioning]
    
    
     */
    onPositioning;
    /**
    
     * [descr:dxContextMenuOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * [descr:dxContextMenuOptions.onShowing]
    
    
     */
    onShowing;
    /**
    
     * [descr:dxContextMenuOptions.onShown]
    
    
     */
    onShown;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    closeOnOutsideClickChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cssClassChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnOutsideClickChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectByClickChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showEventChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showSubmenuModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    submenuDirectionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    get itemsChildren() {
        return this._getOption('items');
    }
    set itemsChildren(value) {
        this.setChildren('items', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'hidden', emit: 'onHidden' },
            { subscribe: 'hiding', emit: 'onHiding' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemContextMenu', emit: 'onItemContextMenu' },
            { subscribe: 'itemRendered', emit: 'onItemRendered' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'positioning', emit: 'onPositioning' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'showing', emit: 'onShowing' },
            { subscribe: 'shown', emit: 'onShown' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'animationChange' },
            { emit: 'closeOnOutsideClickChange' },
            { emit: 'cssClassChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'disabledExprChange' },
            { emit: 'displayExprChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hideOnOutsideClickChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'itemsChange' },
            { emit: 'itemsExprChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'positionChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'selectByClickChange' },
            { emit: 'selectedExprChange' },
            { emit: 'selectedItemChange' },
            { emit: 'selectionModeChange' },
            { emit: 'showEventChange' },
            { emit: 'showSubmenuModeChange' },
            { emit: 'submenuDirectionChange' },
            { emit: 'tabIndexChange' },
            { emit: 'targetChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxContextMenu(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxContextMenuComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxContextMenuComponent, selector: "dx-context-menu", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animation: "animation", closeOnOutsideClick: "closeOnOutsideClick", cssClass: "cssClass", dataSource: "dataSource", disabled: "disabled", disabledExpr: "disabledExpr", displayExpr: "displayExpr", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hint: "hint", hoverStateEnabled: "hoverStateEnabled", items: "items", itemsExpr: "itemsExpr", itemTemplate: "itemTemplate", position: "position", rtlEnabled: "rtlEnabled", selectByClick: "selectByClick", selectedExpr: "selectedExpr", selectedItem: "selectedItem", selectionMode: "selectionMode", showEvent: "showEvent", showSubmenuMode: "showSubmenuMode", submenuDirection: "submenuDirection", tabIndex: "tabIndex", target: "target", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", onPositioning: "onPositioning", onSelectionChanged: "onSelectionChanged", onShowing: "onShowing", onShown: "onShown", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", animationChange: "animationChange", closeOnOutsideClickChange: "closeOnOutsideClickChange", cssClassChange: "cssClassChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", disabledExprChange: "disabledExprChange", displayExprChange: "displayExprChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hideOnOutsideClickChange: "hideOnOutsideClickChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", itemsChange: "itemsChange", itemsExprChange: "itemsExprChange", itemTemplateChange: "itemTemplateChange", positionChange: "positionChange", rtlEnabledChange: "rtlEnabledChange", selectByClickChange: "selectByClickChange", selectedExprChange: "selectedExprChange", selectedItemChange: "selectedItemChange", selectionModeChange: "selectionModeChange", showEventChange: "showEventChange", showSubmenuModeChange: "showSubmenuModeChange", submenuDirectionChange: "submenuDirectionChange", tabIndexChange: "tabIndexChange", targetChange: "targetChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "itemsChildren", predicate: DxiItemComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxContextMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-context-menu',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animation: [{
                type: Input
            }], closeOnOutsideClick: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], disabledExpr: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], items: [{
                type: Input
            }], itemsExpr: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], position: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }], selectedExpr: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], showEvent: [{
                type: Input
            }], showSubmenuMode: [{
                type: Input
            }], submenuDirection: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], target: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onHidden: [{
                type: Output
            }], onHiding: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemContextMenu: [{
                type: Output
            }], onItemRendered: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onPositioning: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onShowing: [{
                type: Output
            }], onShown: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], closeOnOutsideClickChange: [{
                type: Output
            }], cssClassChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], disabledExprChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hideOnOutsideClickChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemsExprChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], selectByClickChange: [{
                type: Output
            }], selectedExprChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], selectionModeChange: [{
                type: Output
            }], showEventChange: [{
                type: Output
            }], showSubmenuModeChange: [{
                type: Output
            }], submenuDirectionChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], targetChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], itemsChildren: [{
                type: ContentChildren,
                args: [DxiItemComponent]
            }] } });
export class DxContextMenuModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxContextMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxContextMenuModule, declarations: [DxContextMenuComponent], imports: [DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxContextMenuComponent, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxContextMenuModule, imports: [DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxContextMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiItemModule,
                        DxoShowEventModule,
                        DxoShowSubmenuModeModule,
                        DxoDelayModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxContextMenuComponent
                    ],
                    exports: [
                        DxContextMenuComponent,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiItemModule,
                        DxoShowEventModule,
                        DxoShowSubmenuModeModule,
                        DxoDelayModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL2NvbnRleHQtbWVudS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUdwQyxPQUFPLEVBQ0gsYUFBYSxFQUNiLFNBQVMsRUFDVCxRQUFRLEVBQ1IsVUFBVSxFQUNWLE1BQU0sRUFDTixXQUFXLEVBQ1gsTUFBTSxFQUVOLEtBQUssRUFDTCxNQUFNLEVBRU4sWUFBWSxFQUlaLGVBQWUsRUFDZixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFZdkIsT0FBTyxhQUFhLE1BQU0sNEJBQTRCLENBQUM7QUFHdkQsT0FBTyxFQUNILFdBQVcsRUFDWCxjQUFjLEVBQ2QsbUJBQW1CLEVBQ25CLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsb0JBQW9CLEVBQ3BCLGFBQWEsRUFDaEIsTUFBTSx5QkFBeUIsQ0FBQztBQUVqQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUN2RSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDM0QsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUU5RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQzs7O0FBSWhFOzs7R0FHRztBQVdILE1BQU0sT0FBTyxzQkFBbUMsU0FBUSxXQUFXO0lBdXVCL0M7SUFDQTtJQXZ1QmhCLFFBQVEsR0FBd0IsSUFBSSxDQUFDO0lBRXJDOzs7T0FHRztJQUNILElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBeUI7UUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQWM7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUF5RDtRQUNuRSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7Ozs7O09BS0c7SUFDSCxJQUNJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBSSxtQkFBbUIsQ0FBQyxLQUF5QjtRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWE7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBd0Y7UUFDbkcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYztRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUF3QjtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUF3QjtRQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFVO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBNkM7UUFDcEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQXlCO1FBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBeUI7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksaUJBQWlCO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDRCxJQUFJLGlCQUFpQixDQUFDLEtBQWM7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUErQjtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUF3QjtRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUFVO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQXFCO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUF3QjtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUFVO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGFBQWE7UUFDYixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksYUFBYSxDQUFDLEtBQW1CO1FBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQXlFO1FBQ25GLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBc0c7UUFDdEgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBOEI7UUFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQThDO1FBQ3JELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBNkM7UUFDbkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFrQztJQUUxRDs7Ozs7T0FLRztJQUNPLFdBQVcsQ0FBK0I7SUFFcEQ7Ozs7O09BS0c7SUFDTyxRQUFRLENBQTRCO0lBRTlDOzs7OztPQUtHO0lBQ08sUUFBUSxDQUE0QjtJQUU5Qzs7Ozs7T0FLRztJQUNPLGFBQWEsQ0FBaUM7SUFFeEQ7Ozs7O09BS0c7SUFDTyxXQUFXLENBQStCO0lBRXBEOzs7OztPQUtHO0lBQ08saUJBQWlCLENBQXFDO0lBRWhFOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFrQztJQUUxRDs7Ozs7T0FLRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sa0JBQWtCLENBQXNDO0lBRWxFOzs7OztPQUtHO0lBQ08sU0FBUyxDQUE2QjtJQUVoRDs7Ozs7T0FLRztJQUNPLE9BQU8sQ0FBMkI7SUFFNUM7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7T0FJRztJQUNPLHdCQUF3QixDQUF3QjtJQUUxRDs7OztPQUlHO0lBQ08sZUFBZSxDQUFtRTtJQUU1Rjs7OztPQUlHO0lBQ08seUJBQXlCLENBQW1DO0lBRXRFOzs7O09BSUc7SUFDTyxjQUFjLENBQXVCO0lBRS9DOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBa0c7SUFFNUg7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBd0I7SUFFaEQ7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFrQztJQUU5RDs7OztPQUlHO0lBQ08saUJBQWlCLENBQWtDO0lBRTdEOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBb0I7SUFFL0M7Ozs7T0FJRztJQUNPLHVCQUF1QixDQUF3QjtJQUV6RDs7OztPQUlHO0lBQ08sWUFBWSxDQUF1RDtJQUU3RTs7OztPQUlHO0lBQ08sd0JBQXdCLENBQW1DO0lBRXJFOzs7O09BSUc7SUFDTyxVQUFVLENBQW1DO0lBRXZEOzs7O09BSUc7SUFDTyx1QkFBdUIsQ0FBd0I7SUFFekQ7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBeUM7SUFFOUQ7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBa0M7SUFFM0Q7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFvQjtJQUVoRDs7OztPQUlHO0lBQ08sY0FBYyxDQUErQjtJQUV2RDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQXdCO0lBRWxEOzs7O09BSUc7SUFDTyxtQkFBbUIsQ0FBd0I7SUFFckQ7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFrQztJQUU5RDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQW9CO0lBRWhEOzs7O09BSUc7SUFDTyxtQkFBbUIsQ0FBNkI7SUFFMUQ7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBbUY7SUFFNUc7Ozs7T0FJRztJQUNPLHFCQUFxQixDQUFnSDtJQUUvSTs7OztPQUlHO0lBQ08sc0JBQXNCLENBQXdDO0lBRXhFOzs7O09BSUc7SUFDTyxjQUFjLENBQXVCO0lBRS9DOzs7O09BSUc7SUFDTyxZQUFZLENBQXdEO0lBRTlFOzs7O09BSUc7SUFDTyxhQUFhLENBQXdCO0lBRS9DOzs7O09BSUc7SUFDTyxXQUFXLENBQXVEO0lBSzVFLElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBSztRQUNuQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBS0QsWUFBWSxVQUFzQixFQUFFLE1BQWMsRUFBRSxZQUE0QixFQUNoRSxjQUE2QixFQUM3QixJQUEwQixFQUNsQyxVQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFFeEMsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFOdkUsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFDN0IsU0FBSSxHQUFKLElBQUksQ0FBc0I7UUFPdEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDL0MsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUU7WUFDekMsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUU7WUFDekMsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDbkQsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDL0MsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzNELEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNuRCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7WUFDM0MsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7WUFDdkMsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUU7WUFDcEMsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUU7WUFDckMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLDBCQUEwQixFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUNuQyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0IsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDakMsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDbEMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7U0FDMUIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRVMsZUFBZSxDQUFDLE9BQU8sRUFBRSxPQUFPO1FBRXRDLE9BQU8sSUFBSSxhQUFhLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFHRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDOUIsS0FBSyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsWUFBWSxDQUFDLElBQVksRUFBRSxPQUFzQjtRQUM3QyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ2xDO0lBQ0wsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3BDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNsQixLQUFLLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRUQsVUFBVSxDQUFDLElBQVksRUFBRSxLQUFVO1FBQy9CLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNqRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDO1FBRTNELElBQUksT0FBTyxJQUFJLFNBQVMsRUFBRTtZQUN0QixLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7MkhBdjBCUSxzQkFBc0IsOE5BMnVCZixXQUFXOytHQTN1QmxCLHNCQUFzQix5L0VBUHBCO1lBQ1AsY0FBYztZQUNkLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsb0JBQW9CO1NBQ3ZCLHdEQTZ0QmdCLGdCQUFnQix5RUFudUJ2QixFQUFFOzs0RkFRSCxzQkFBc0I7a0JBVmxDLFNBQVM7bUJBQUM7b0JBQ1AsUUFBUSxFQUFFLGlCQUFpQjtvQkFDM0IsUUFBUSxFQUFFLEVBQUU7b0JBQ1osU0FBUyxFQUFFO3dCQUNQLGNBQWM7d0JBQ2QsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLG9CQUFvQjtxQkFDdkI7aUJBQ0o7OzBCQTR1QlksTUFBTTsyQkFBQyxXQUFXOzRDQW51QnZCLFNBQVM7c0JBRFosS0FBSztnQkFjRixrQkFBa0I7c0JBRHJCLEtBQUs7Z0JBY0YsU0FBUztzQkFEWixLQUFLO2dCQWdCRixtQkFBbUI7c0JBRHRCLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLFdBQVc7c0JBRGQsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsaUJBQWlCO3NCQURwQixLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixrQkFBa0I7c0JBRHJCLEtBQUs7Z0JBY0YsSUFBSTtzQkFEUCxLQUFLO2dCQWNGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFjRixLQUFLO3NCQURSLEtBQUs7Z0JBY0YsU0FBUztzQkFEWixLQUFLO2dCQWNGLFlBQVk7c0JBRGYsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLFlBQVk7c0JBRGYsS0FBSztnQkFjRixhQUFhO3NCQURoQixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixlQUFlO3NCQURsQixLQUFLO2dCQWNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsTUFBTTtzQkFEVCxLQUFLO2dCQWNGLE9BQU87c0JBRFYsS0FBSztnQkFjRixLQUFLO3NCQURSLEtBQUs7Z0JBY0ksY0FBYztzQkFBdkIsTUFBTTtnQkFRRyxXQUFXO3NCQUFwQixNQUFNO2dCQVFHLFFBQVE7c0JBQWpCLE1BQU07Z0JBUUcsUUFBUTtzQkFBakIsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLFdBQVc7c0JBQXBCLE1BQU07Z0JBUUcsaUJBQWlCO3NCQUExQixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBUUcsZUFBZTtzQkFBeEIsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFRRyxTQUFTO3NCQUFsQixNQUFNO2dCQVFHLE9BQU87c0JBQWhCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyx5QkFBeUI7c0JBQWxDLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLGlCQUFpQjtzQkFBMUIsTUFBTTtnQkFPRyx1QkFBdUI7c0JBQWhDLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csVUFBVTtzQkFBbkIsTUFBTTtnQkFPRyx1QkFBdUI7c0JBQWhDLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPRyxlQUFlO3NCQUF4QixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLGdCQUFnQjtzQkFBekIsTUFBTTtnQkFPRyxtQkFBbUI7c0JBQTVCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxtQkFBbUI7c0JBQTVCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csc0JBQXNCO3NCQUEvQixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxhQUFhO3NCQUF0QixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBTUgsYUFBYTtzQkFEaEIsZUFBZTt1QkFBQyxnQkFBZ0I7O0FBMEpyQyxNQUFNLE9BQU8sbUJBQW1COzJIQUFuQixtQkFBbUI7NEhBQW5CLG1CQUFtQixpQkFyM0JuQixzQkFBc0IsYUE0MEIvQixrQkFBa0I7WUFDbEIsYUFBYTtZQUNiLGFBQWE7WUFDYixpQkFBaUI7WUFDakIsV0FBVztZQUNYLHVCQUF1QjtZQUN2QixrQkFBa0I7WUFDbEIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsYUFBYTtZQUNiLGFBQWE7WUFDYixrQkFBa0I7WUFDbEIsd0JBQXdCO1lBQ3hCLGNBQWM7WUFDZCxtQkFBbUI7WUFDbkIsZ0JBQWdCLGFBNTFCUCxzQkFBc0IsRUFtMkIvQixrQkFBa0I7WUFDbEIsYUFBYTtZQUNiLGFBQWE7WUFDYixpQkFBaUI7WUFDakIsV0FBVztZQUNYLHVCQUF1QjtZQUN2QixrQkFBa0I7WUFDbEIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsYUFBYTtZQUNiLGFBQWE7WUFDYixrQkFBa0I7WUFDbEIsd0JBQXdCO1lBQ3hCLGNBQWM7WUFDZCxnQkFBZ0I7NEhBR1AsbUJBQW1CLFlBekM1QixrQkFBa0I7WUFDbEIsYUFBYTtZQUNiLGFBQWE7WUFDYixpQkFBaUI7WUFDakIsV0FBVztZQUNYLHVCQUF1QjtZQUN2QixrQkFBa0I7WUFDbEIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsYUFBYTtZQUNiLGFBQWE7WUFDYixrQkFBa0I7WUFDbEIsd0JBQXdCO1lBQ3hCLGNBQWM7WUFDZCxtQkFBbUI7WUFDbkIsZ0JBQWdCLEVBT2hCLGtCQUFrQjtZQUNsQixhQUFhO1lBQ2IsYUFBYTtZQUNiLGlCQUFpQjtZQUNqQixXQUFXO1lBQ1gsdUJBQXVCO1lBQ3ZCLGtCQUFrQjtZQUNsQixXQUFXO1lBQ1gsZUFBZTtZQUNmLFdBQVc7WUFDWCxhQUFhO1lBQ2IsYUFBYTtZQUNiLGtCQUFrQjtZQUNsQix3QkFBd0I7WUFDeEIsY0FBYztZQUNkLGdCQUFnQjs7NEZBR1AsbUJBQW1CO2tCQTNDL0IsUUFBUTttQkFBQztvQkFDUixPQUFPLEVBQUU7d0JBQ1Asa0JBQWtCO3dCQUNsQixhQUFhO3dCQUNiLGFBQWE7d0JBQ2IsaUJBQWlCO3dCQUNqQixXQUFXO3dCQUNYLHVCQUF1Qjt3QkFDdkIsa0JBQWtCO3dCQUNsQixXQUFXO3dCQUNYLGVBQWU7d0JBQ2YsV0FBVzt3QkFDWCxhQUFhO3dCQUNiLGFBQWE7d0JBQ2Isa0JBQWtCO3dCQUNsQix3QkFBd0I7d0JBQ3hCLGNBQWM7d0JBQ2QsbUJBQW1CO3dCQUNuQixnQkFBZ0I7cUJBQ2pCO29CQUNELFlBQVksRUFBRTt3QkFDWixzQkFBc0I7cUJBQ3ZCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxzQkFBc0I7d0JBQ3RCLGtCQUFrQjt3QkFDbEIsYUFBYTt3QkFDYixhQUFhO3dCQUNiLGlCQUFpQjt3QkFDakIsV0FBVzt3QkFDWCx1QkFBdUI7d0JBQ3ZCLGtCQUFrQjt3QkFDbEIsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsYUFBYTt3QkFDYixhQUFhO3dCQUNiLGtCQUFrQjt3QkFDbEIsd0JBQXdCO3dCQUN4QixjQUFjO3dCQUNkLGdCQUFnQjtxQkFDakI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cblxuaW1wb3J0IHtcbiAgICBUcmFuc2ZlclN0YXRlLFxuICAgIENvbXBvbmVudCxcbiAgICBOZ01vZHVsZSxcbiAgICBFbGVtZW50UmVmLFxuICAgIE5nWm9uZSxcbiAgICBQTEFURk9STV9JRCxcbiAgICBJbmplY3QsXG5cbiAgICBJbnB1dCxcbiAgICBPdXRwdXQsXG4gICAgT25EZXN0cm95LFxuICAgIEV2ZW50RW1pdHRlcixcbiAgICBPbkNoYW5nZXMsXG4gICAgRG9DaGVjayxcbiAgICBTaW1wbGVDaGFuZ2VzLFxuICAgIENvbnRlbnRDaGlsZHJlbixcbiAgICBRdWVyeUxpc3Rcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmV4cG9ydCB7IEV4cGxpY2l0VHlwZXMgfSBmcm9tICdkZXZleHRyZW1lL3VpL2NvbnRleHRfbWVudSc7XG5cbmltcG9ydCB7IEFuaW1hdGlvbkNvbmZpZyB9IGZyb20gJ2RldmV4dHJlbWUvYW5pbWF0aW9uL2Z4JztcbmltcG9ydCB7IFBvc2l0aW9uQ29uZmlnIH0gZnJvbSAnZGV2ZXh0cmVtZS9hbmltYXRpb24vcG9zaXRpb24nO1xuaW1wb3J0IHsgU2luZ2xlT3JOb25lLCBTdWJtZW51U2hvd01vZGUgfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbic7XG5pbXBvcnQgeyBVc2VyRGVmaW5lZEVsZW1lbnQgfSBmcm9tICdkZXZleHRyZW1lL2NvcmUvZWxlbWVudCc7XG5pbXBvcnQgeyBTdG9yZSB9IGZyb20gJ2RldmV4dHJlbWUvZGF0YSc7XG5pbXBvcnQgRGF0YVNvdXJjZSwgeyBPcHRpb25zIGFzIERhdGFTb3VyY2VPcHRpb25zIH0gZnJvbSAnZGV2ZXh0cmVtZS9kYXRhL2RhdGFfc291cmNlJztcbmltcG9ydCB7IENvbnRlbnRSZWFkeUV2ZW50LCBDb250ZXh0U3VibWVudURpcmVjdGlvbiwgRGlzcG9zaW5nRXZlbnQsIGR4Q29udGV4dE1lbnVJdGVtLCBIaWRkZW5FdmVudCwgSGlkaW5nRXZlbnQsIEluaXRpYWxpemVkRXZlbnQsIEl0ZW1DbGlja0V2ZW50LCBJdGVtQ29udGV4dE1lbnVFdmVudCwgSXRlbVJlbmRlcmVkRXZlbnQsIE9wdGlvbkNoYW5nZWRFdmVudCwgUG9zaXRpb25pbmdFdmVudCwgU2VsZWN0aW9uQ2hhbmdlZEV2ZW50LCBTaG93aW5nRXZlbnQsIFNob3duRXZlbnQgfSBmcm9tICdkZXZleHRyZW1lL3VpL2NvbnRleHRfbWVudSc7XG5cbmltcG9ydCBEeENvbnRleHRNZW51IGZyb20gJ2RldmV4dHJlbWUvdWkvY29udGV4dF9tZW51JztcblxuXG5pbXBvcnQge1xuICAgIER4Q29tcG9uZW50LFxuICAgIER4VGVtcGxhdGVIb3N0LFxuICAgIER4SW50ZWdyYXRpb25Nb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZSxcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgIEl0ZXJhYmxlRGlmZmVySGVscGVyLFxuICAgIFdhdGNoZXJIZWxwZXJcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBEeG9BbmltYXRpb25Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0hpZGVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0Zyb21Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Bvc2l0aW9uTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9BdE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvQm91bmRhcnlPZmZzZXRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0NvbGxpc2lvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvTXlNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b09mZnNldE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVG9Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Nob3dNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aUl0ZW1Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Nob3dFdmVudE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2hvd1N1Ym1lbnVNb2RlTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9EZWxheU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuXG5pbXBvcnQgeyBEeGlJdGVtQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5cblxuXG4vKipcbiAqIFtkZXNjcjpkeENvbnRleHRNZW51XVxuXG4gKi9cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHgtY29udGV4dC1tZW51JyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgcHJvdmlkZXJzOiBbXG4gICAgICAgIER4VGVtcGxhdGVIb3N0LFxuICAgICAgICBXYXRjaGVySGVscGVyLFxuICAgICAgICBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICBJdGVyYWJsZURpZmZlckhlbHBlclxuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhDb250ZXh0TWVudUNvbXBvbmVudDxUS2V5ID0gYW55PiBleHRlbmRzIER4Q29tcG9uZW50IGltcGxlbWVudHMgT25EZXN0cm95LCBPbkNoYW5nZXMsIERvQ2hlY2sge1xuICAgIGluc3RhbmNlOiBEeENvbnRleHRNZW51PFRLZXk+ID0gbnVsbDtcblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmFjY2Vzc0tleV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBhY2Nlc3NLZXkoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWNjZXNzS2V5Jyk7XG4gICAgfVxuICAgIHNldCBhY2Nlc3NLZXkodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjY2Vzc0tleScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeE1lbnVCYXNlT3B0aW9ucy5hY3RpdmVTdGF0ZUVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYWN0aXZlU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhY3RpdmVTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGFjdGl2ZVN0YXRlRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjdGl2ZVN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeE1lbnVCYXNlT3B0aW9ucy5hbmltYXRpb25dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYW5pbWF0aW9uKCk6IHsgaGlkZT86IEFuaW1hdGlvbkNvbmZpZywgc2hvdz86IEFuaW1hdGlvbkNvbmZpZyB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYW5pbWF0aW9uJyk7XG4gICAgfVxuICAgIHNldCBhbmltYXRpb24odmFsdWU6IHsgaGlkZT86IEFuaW1hdGlvbkNvbmZpZywgc2hvdz86IEFuaW1hdGlvbkNvbmZpZyB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYW5pbWF0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLmNsb3NlT25PdXRzaWRlQ2xpY2tdXG4gICAgXG4gICAgICogQGRlcHJlY2F0ZWQgW2RlcE5vdGU6ZHhDb250ZXh0TWVudU9wdGlvbnMuY2xvc2VPbk91dHNpZGVDbGlja11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBjbG9zZU9uT3V0c2lkZUNsaWNrKCk6IGJvb2xlYW4gfCBGdW5jdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Nsb3NlT25PdXRzaWRlQ2xpY2snKTtcbiAgICB9XG4gICAgc2V0IGNsb3NlT25PdXRzaWRlQ2xpY2sodmFsdWU6IGJvb2xlYW4gfCBGdW5jdGlvbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Nsb3NlT25PdXRzaWRlQ2xpY2snLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNZW51QmFzZU9wdGlvbnMuY3NzQ2xhc3NdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY3NzQ2xhc3MoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY3NzQ2xhc3MnKTtcbiAgICB9XG4gICAgc2V0IGNzc0NsYXNzKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjc3NDbGFzcycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeENvbnRleHRNZW51T3B0aW9ucy5kYXRhU291cmNlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRhdGFTb3VyY2UoKTogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8ZHhDb250ZXh0TWVudUl0ZW0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGF0YVNvdXJjZScpO1xuICAgIH1cbiAgICBzZXQgZGF0YVNvdXJjZSh2YWx1ZTogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8ZHhDb250ZXh0TWVudUl0ZW0+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGF0YVNvdXJjZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmRpc2FibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRpc2FibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkaXNhYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgZGlzYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkaXNhYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpIaWVyYXJjaGljYWxDb2xsZWN0aW9uV2lkZ2V0T3B0aW9ucy5kaXNhYmxlZEV4cHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZGlzYWJsZWRFeHByKCk6IEZ1bmN0aW9uIHwgc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzYWJsZWRFeHByJyk7XG4gICAgfVxuICAgIHNldCBkaXNhYmxlZEV4cHIodmFsdWU6IEZ1bmN0aW9uIHwgc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzYWJsZWRFeHByJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkhpZXJhcmNoaWNhbENvbGxlY3Rpb25XaWRnZXRPcHRpb25zLmRpc3BsYXlFeHByXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRpc3BsYXlFeHByKCk6IEZ1bmN0aW9uIHwgc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzcGxheUV4cHInKTtcbiAgICB9XG4gICAgc2V0IGRpc3BsYXlFeHByKHZhbHVlOiBGdW5jdGlvbiB8IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Rpc3BsYXlFeHByJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMuZWxlbWVudEF0dHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZWxlbWVudEF0dHIoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcbiAgICB9XG4gICAgc2V0IGVsZW1lbnRBdHRyKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpIaWVyYXJjaGljYWxDb2xsZWN0aW9uV2lkZ2V0T3B0aW9ucy5mb2N1c1N0YXRlRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBmb2N1c1N0YXRlRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGZvY3VzU3RhdGVFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5oZWlnaHRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGVpZ2h0KCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCBoZWlnaHQodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLmhpZGVPbk91dHNpZGVDbGlja11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBoaWRlT25PdXRzaWRlQ2xpY2soKTogYm9vbGVhbiB8IEZ1bmN0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGlkZU9uT3V0c2lkZUNsaWNrJyk7XG4gICAgfVxuICAgIHNldCBoaWRlT25PdXRzaWRlQ2xpY2sodmFsdWU6IGJvb2xlYW4gfCBGdW5jdGlvbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hpZGVPbk91dHNpZGVDbGljaycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmhpbnRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGludCgpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdoaW50Jyk7XG4gICAgfVxuICAgIHNldCBoaW50KHZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoaW50JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkhpZXJhcmNoaWNhbENvbGxlY3Rpb25XaWRnZXRPcHRpb25zLmhvdmVyU3RhdGVFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhvdmVyU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdob3ZlclN0YXRlRW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgaG92ZXJTdGF0ZUVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdob3ZlclN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeENvbnRleHRNZW51T3B0aW9ucy5pdGVtc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBpdGVtcygpOiBBcnJheTxkeENvbnRleHRNZW51SXRlbT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtcycpO1xuICAgIH1cbiAgICBzZXQgaXRlbXModmFsdWU6IEFycmF5PGR4Q29udGV4dE1lbnVJdGVtPikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2l0ZW1zJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkhpZXJhcmNoaWNhbENvbGxlY3Rpb25XaWRnZXRPcHRpb25zLml0ZW1zRXhwcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBpdGVtc0V4cHIoKTogRnVuY3Rpb24gfCBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtc0V4cHInKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1zRXhwcih2YWx1ZTogRnVuY3Rpb24gfCBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtc0V4cHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6Q29sbGVjdGlvbldpZGdldE9wdGlvbnMuaXRlbVRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGl0ZW1UZW1wbGF0ZSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtVGVtcGxhdGUnKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1UZW1wbGF0ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaXRlbVRlbXBsYXRlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLnBvc2l0aW9uXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBvc2l0aW9uKCk6IFBvc2l0aW9uQ29uZmlnIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncG9zaXRpb24nKTtcbiAgICB9XG4gICAgc2V0IHBvc2l0aW9uKHZhbHVlOiBQb3NpdGlvbkNvbmZpZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Bvc2l0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMucnRsRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBydGxFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdydGxFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBydGxFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncnRsRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeE1lbnVCYXNlT3B0aW9ucy5zZWxlY3RCeUNsaWNrXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNlbGVjdEJ5Q2xpY2soKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NlbGVjdEJ5Q2xpY2snKTtcbiAgICB9XG4gICAgc2V0IHNlbGVjdEJ5Q2xpY2sodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzZWxlY3RCeUNsaWNrJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkhpZXJhcmNoaWNhbENvbGxlY3Rpb25XaWRnZXRPcHRpb25zLnNlbGVjdGVkRXhwcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzZWxlY3RlZEV4cHIoKTogRnVuY3Rpb24gfCBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzZWxlY3RlZEV4cHInKTtcbiAgICB9XG4gICAgc2V0IHNlbGVjdGVkRXhwcih2YWx1ZTogRnVuY3Rpb24gfCBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzZWxlY3RlZEV4cHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6Q29sbGVjdGlvbldpZGdldE9wdGlvbnMuc2VsZWN0ZWRJdGVtXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNlbGVjdGVkSXRlbSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzZWxlY3RlZEl0ZW0nKTtcbiAgICB9XG4gICAgc2V0IHNlbGVjdGVkSXRlbSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2VsZWN0ZWRJdGVtJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4TWVudUJhc2VPcHRpb25zLnNlbGVjdGlvbk1vZGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2VsZWN0aW9uTW9kZSgpOiBTaW5nbGVPck5vbmUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzZWxlY3Rpb25Nb2RlJyk7XG4gICAgfVxuICAgIHNldCBzZWxlY3Rpb25Nb2RlKHZhbHVlOiBTaW5nbGVPck5vbmUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzZWxlY3Rpb25Nb2RlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLnNob3dFdmVudF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93RXZlbnQoKTogc3RyaW5nIHwgeyBkZWxheT86IG51bWJlciB8IHVuZGVmaW5lZCwgbmFtZT86IHN0cmluZyB8IHVuZGVmaW5lZCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd0V2ZW50Jyk7XG4gICAgfVxuICAgIHNldCBzaG93RXZlbnQodmFsdWU6IHN0cmluZyB8IHsgZGVsYXk/OiBudW1iZXIgfCB1bmRlZmluZWQsIG5hbWU/OiBzdHJpbmcgfCB1bmRlZmluZWQgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Nob3dFdmVudCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeE1lbnVCYXNlT3B0aW9ucy5zaG93U3VibWVudU1vZGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2hvd1N1Ym1lbnVNb2RlKCk6IFN1Ym1lbnVTaG93TW9kZSB8IHsgZGVsYXk/OiBudW1iZXIgfCB7IGhpZGU/OiBudW1iZXIsIHNob3c/OiBudW1iZXIgfSwgbmFtZT86IFN1Ym1lbnVTaG93TW9kZSB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd1N1Ym1lbnVNb2RlJyk7XG4gICAgfVxuICAgIHNldCBzaG93U3VibWVudU1vZGUodmFsdWU6IFN1Ym1lbnVTaG93TW9kZSB8IHsgZGVsYXk/OiBudW1iZXIgfCB7IGhpZGU/OiBudW1iZXIsIHNob3c/OiBudW1iZXIgfSwgbmFtZT86IFN1Ym1lbnVTaG93TW9kZSB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd1N1Ym1lbnVNb2RlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLnN1Ym1lbnVEaXJlY3Rpb25dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc3VibWVudURpcmVjdGlvbigpOiBDb250ZXh0U3VibWVudURpcmVjdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3N1Ym1lbnVEaXJlY3Rpb24nKTtcbiAgICB9XG4gICAgc2V0IHN1Ym1lbnVEaXJlY3Rpb24odmFsdWU6IENvbnRleHRTdWJtZW51RGlyZWN0aW9uKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc3VibWVudURpcmVjdGlvbicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLnRhYkluZGV4XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRhYkluZGV4KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RhYkluZGV4Jyk7XG4gICAgfVxuICAgIHNldCB0YWJJbmRleCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFiSW5kZXgnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhDb250ZXh0TWVudU9wdGlvbnMudGFyZ2V0XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRhcmdldCgpOiBVc2VyRGVmaW5lZEVsZW1lbnQgfCBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0YXJnZXQnKTtcbiAgICB9XG4gICAgc2V0IHRhcmdldCh2YWx1ZTogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFyZ2V0JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLnZpc2libGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmlzaWJsZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlzaWJsZScpO1xuICAgIH1cbiAgICBzZXQgdmlzaWJsZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Zpc2libGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy53aWR0aF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB3aWR0aCgpOiBudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3dpZHRoJyk7XG4gICAgfVxuICAgIHNldCB3aWR0aCh2YWx1ZTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd3aWR0aCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhDb250ZXh0TWVudU9wdGlvbnMub25Db250ZW50UmVhZHldXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ29udGVudFJlYWR5OiBFdmVudEVtaXR0ZXI8Q29udGVudFJlYWR5RXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLm9uRGlzcG9zaW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkRpc3Bvc2luZzogRXZlbnRFbWl0dGVyPERpc3Bvc2luZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeENvbnRleHRNZW51T3B0aW9ucy5vbkhpZGRlbl1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25IaWRkZW46IEV2ZW50RW1pdHRlcjxIaWRkZW5FdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhDb250ZXh0TWVudU9wdGlvbnMub25IaWRpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uSGlkaW5nOiBFdmVudEVtaXR0ZXI8SGlkaW5nRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLm9uSW5pdGlhbGl6ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uSW5pdGlhbGl6ZWQ6IEV2ZW50RW1pdHRlcjxJbml0aWFsaXplZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeENvbnRleHRNZW51T3B0aW9ucy5vbkl0ZW1DbGlja11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25JdGVtQ2xpY2s6IEV2ZW50RW1pdHRlcjxJdGVtQ2xpY2tFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhDb250ZXh0TWVudU9wdGlvbnMub25JdGVtQ29udGV4dE1lbnVdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uSXRlbUNvbnRleHRNZW51OiBFdmVudEVtaXR0ZXI8SXRlbUNvbnRleHRNZW51RXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLm9uSXRlbVJlbmRlcmVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkl0ZW1SZW5kZXJlZDogRXZlbnRFbWl0dGVyPEl0ZW1SZW5kZXJlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeENvbnRleHRNZW51T3B0aW9ucy5vbk9wdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uT3B0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPE9wdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhDb250ZXh0TWVudU9wdGlvbnMub25Qb3NpdGlvbmluZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25Qb3NpdGlvbmluZzogRXZlbnRFbWl0dGVyPFBvc2l0aW9uaW5nRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4Q29udGV4dE1lbnVPcHRpb25zLm9uU2VsZWN0aW9uQ2hhbmdlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25TZWxlY3Rpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8U2VsZWN0aW9uQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeENvbnRleHRNZW51T3B0aW9ucy5vblNob3dpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uU2hvd2luZzogRXZlbnRFbWl0dGVyPFNob3dpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhDb250ZXh0TWVudU9wdGlvbnMub25TaG93bl1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25TaG93bjogRXZlbnRFbWl0dGVyPFNob3duRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgYWNjZXNzS2V5Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGFjdGl2ZVN0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgYW5pbWF0aW9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBoaWRlPzogQW5pbWF0aW9uQ29uZmlnLCBzaG93PzogQW5pbWF0aW9uQ29uZmlnIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY2xvc2VPbk91dHNpZGVDbGlja0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4gfCBGdW5jdGlvbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBjc3NDbGFzc0NoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkYXRhU291cmNlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8U3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8ZHhDb250ZXh0TWVudUl0ZW0+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRpc2FibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkaXNhYmxlZEV4cHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxGdW5jdGlvbiB8IHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkaXNwbGF5RXhwckNoYW5nZTogRXZlbnRFbWl0dGVyPEZ1bmN0aW9uIHwgc3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGVsZW1lbnRBdHRyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGZvY3VzU3RhdGVFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBoZWlnaHRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBoaWRlT25PdXRzaWRlQ2xpY2tDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuIHwgRnVuY3Rpb24+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGludENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBob3ZlclN0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaXRlbXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxBcnJheTxkeENvbnRleHRNZW51SXRlbT4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaXRlbXNFeHByQ2hhbmdlOiBFdmVudEVtaXR0ZXI8RnVuY3Rpb24gfCBzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaXRlbVRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHBvc2l0aW9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8UG9zaXRpb25Db25maWc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcnRsRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2VsZWN0QnlDbGlja0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2VsZWN0ZWRFeHByQ2hhbmdlOiBFdmVudEVtaXR0ZXI8RnVuY3Rpb24gfCBzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2VsZWN0ZWRJdGVtQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNlbGVjdGlvbk1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxTaW5nbGVPck5vbmU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd0V2ZW50Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nIHwgeyBkZWxheT86IG51bWJlciB8IHVuZGVmaW5lZCwgbmFtZT86IHN0cmluZyB8IHVuZGVmaW5lZCB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNob3dTdWJtZW51TW9kZUNoYW5nZTogRXZlbnRFbWl0dGVyPFN1Ym1lbnVTaG93TW9kZSB8IHsgZGVsYXk/OiBudW1iZXIgfCB7IGhpZGU/OiBudW1iZXIsIHNob3c/OiBudW1iZXIgfSwgbmFtZT86IFN1Ym1lbnVTaG93TW9kZSB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHN1Ym1lbnVEaXJlY3Rpb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxDb250ZXh0U3VibWVudURpcmVjdGlvbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0YWJJbmRleENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlcj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0YXJnZXRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxVc2VyRGVmaW5lZEVsZW1lbnQgfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdmlzaWJsZUNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgd2lkdGhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZD47XG5cblxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKER4aUl0ZW1Db21wb25lbnQpXG4gICAgZ2V0IGl0ZW1zQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUl0ZW1Db21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaXRlbXMnKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1zQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignaXRlbXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cblxuXG4gICAgY29uc3RydWN0b3IoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgbmdab25lOiBOZ1pvbmUsIHRlbXBsYXRlSG9zdDogRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIF93YXRjaGVySGVscGVyOiBXYXRjaGVySGVscGVyLFxuICAgICAgICAgICAgcHJpdmF0ZSBfaWRoOiBJdGVyYWJsZURpZmZlckhlbHBlcixcbiAgICAgICAgICAgIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICB0cmFuc2ZlclN0YXRlOiBUcmFuc2ZlclN0YXRlLFxuICAgICAgICAgICAgQEluamVjdChQTEFURk9STV9JRCkgcGxhdGZvcm1JZDogYW55KSB7XG5cbiAgICAgICAgc3VwZXIoZWxlbWVudFJlZiwgbmdab25lLCB0ZW1wbGF0ZUhvc3QsIF93YXRjaGVySGVscGVyLCB0cmFuc2ZlclN0YXRlLCBwbGF0Zm9ybUlkKTtcblxuICAgICAgICB0aGlzLl9jcmVhdGVFdmVudEVtaXR0ZXJzKFtcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnY29udGVudFJlYWR5JywgZW1pdDogJ29uQ29udGVudFJlYWR5JyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkaXNwb3NpbmcnLCBlbWl0OiAnb25EaXNwb3NpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2hpZGRlbicsIGVtaXQ6ICdvbkhpZGRlbicgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaGlkaW5nJywgZW1pdDogJ29uSGlkaW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdpbml0aWFsaXplZCcsIGVtaXQ6ICdvbkluaXRpYWxpemVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdpdGVtQ2xpY2snLCBlbWl0OiAnb25JdGVtQ2xpY2snIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2l0ZW1Db250ZXh0TWVudScsIGVtaXQ6ICdvbkl0ZW1Db250ZXh0TWVudScgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaXRlbVJlbmRlcmVkJywgZW1pdDogJ29uSXRlbVJlbmRlcmVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdvcHRpb25DaGFuZ2VkJywgZW1pdDogJ29uT3B0aW9uQ2hhbmdlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncG9zaXRpb25pbmcnLCBlbWl0OiAnb25Qb3NpdGlvbmluZycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnc2VsZWN0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvblNlbGVjdGlvbkNoYW5nZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Nob3dpbmcnLCBlbWl0OiAnb25TaG93aW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdzaG93bicsIGVtaXQ6ICdvblNob3duJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWNjZXNzS2V5Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYW5pbWF0aW9uQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnY2xvc2VPbk91dHNpZGVDbGlja0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2Nzc0NsYXNzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGF0YVNvdXJjZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2Rpc2FibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGlzYWJsZWRFeHByQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGlzcGxheUV4cHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdlbGVtZW50QXR0ckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2ZvY3VzU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGVpZ2h0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGlkZU9uT3V0c2lkZUNsaWNrQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGludENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hvdmVyU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaXRlbXNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdpdGVtc0V4cHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdpdGVtVGVtcGxhdGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdwb3NpdGlvbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3J0bEVuYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzZWxlY3RCeUNsaWNrQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2VsZWN0ZWRFeHByQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2VsZWN0ZWRJdGVtQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2VsZWN0aW9uTW9kZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dFdmVudENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dTdWJtZW51TW9kZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3N1Ym1lbnVEaXJlY3Rpb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0YWJJbmRleENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3RhcmdldENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Zpc2libGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd3aWR0aENoYW5nZScgfVxuICAgICAgICBdKTtcblxuICAgICAgICB0aGlzLl9pZGguc2V0SG9zdCh0aGlzKTtcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBfY3JlYXRlSW5zdGFuY2UoZWxlbWVudCwgb3B0aW9ucykge1xuXG4gICAgICAgIHJldHVybiBuZXcgRHhDb250ZXh0TWVudShlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2RhdGFTb3VyY2UnLCBjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2l0ZW1zJywgY2hhbmdlcyk7XG4gICAgfVxuXG4gICAgc2V0dXBDaGFuZ2VzKHByb3A6IHN0cmluZywgY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoIShwcm9wIGluIHRoaXMuX29wdGlvbnNUb1VwZGF0ZSkpIHtcbiAgICAgICAgICAgIHRoaXMuX2lkaC5zZXR1cChwcm9wLCBjaGFuZ2VzKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nRG9DaGVjaygpIHtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2RhdGFTb3VyY2UnKTtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2l0ZW1zJyk7XG4gICAgICAgIHRoaXMuX3dhdGNoZXJIZWxwZXIuY2hlY2tXYXRjaGVycygpO1xuICAgICAgICBzdXBlci5uZ0RvQ2hlY2soKTtcbiAgICAgICAgc3VwZXIuY2xlYXJDaGFuZ2VkT3B0aW9ucygpO1xuICAgIH1cblxuICAgIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XG4gICAgICAgIGxldCBpc1NldHVwID0gdGhpcy5faWRoLnNldHVwU2luZ2xlKG5hbWUsIHZhbHVlKTtcbiAgICAgICAgbGV0IGlzQ2hhbmdlZCA9IHRoaXMuX2lkaC5nZXRDaGFuZ2VzKG5hbWUsIHZhbHVlKSAhPT0gbnVsbDtcblxuICAgICAgICBpZiAoaXNTZXR1cCB8fCBpc0NoYW5nZWQpIHtcbiAgICAgICAgICAgIHN1cGVyLl9zZXRPcHRpb24obmFtZSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgRHhvQW5pbWF0aW9uTW9kdWxlLFxuICAgIER4b0hpZGVNb2R1bGUsXG4gICAgRHhvRnJvbU1vZHVsZSxcbiAgICBEeG9Qb3NpdGlvbk1vZHVsZSxcbiAgICBEeG9BdE1vZHVsZSxcbiAgICBEeG9Cb3VuZGFyeU9mZnNldE1vZHVsZSxcbiAgICBEeG9Db2xsaXNpb25Nb2R1bGUsXG4gICAgRHhvTXlNb2R1bGUsXG4gICAgRHhvT2Zmc2V0TW9kdWxlLFxuICAgIER4b1RvTW9kdWxlLFxuICAgIER4b1Nob3dNb2R1bGUsXG4gICAgRHhpSXRlbU1vZHVsZSxcbiAgICBEeG9TaG93RXZlbnRNb2R1bGUsXG4gICAgRHhvU2hvd1N1Ym1lbnVNb2RlTW9kdWxlLFxuICAgIER4b0RlbGF5TW9kdWxlLFxuICAgIER4SW50ZWdyYXRpb25Nb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZVxuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeENvbnRleHRNZW51Q29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeENvbnRleHRNZW51Q29tcG9uZW50LFxuICAgIER4b0FuaW1hdGlvbk1vZHVsZSxcbiAgICBEeG9IaWRlTW9kdWxlLFxuICAgIER4b0Zyb21Nb2R1bGUsXG4gICAgRHhvUG9zaXRpb25Nb2R1bGUsXG4gICAgRHhvQXRNb2R1bGUsXG4gICAgRHhvQm91bmRhcnlPZmZzZXRNb2R1bGUsXG4gICAgRHhvQ29sbGlzaW9uTW9kdWxlLFxuICAgIER4b015TW9kdWxlLFxuICAgIER4b09mZnNldE1vZHVsZSxcbiAgICBEeG9Ub01vZHVsZSxcbiAgICBEeG9TaG93TW9kdWxlLFxuICAgIER4aUl0ZW1Nb2R1bGUsXG4gICAgRHhvU2hvd0V2ZW50TW9kdWxlLFxuICAgIER4b1Nob3dTdWJtZW51TW9kZU1vZHVsZSxcbiAgICBEeG9EZWxheU1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlXG4gIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhDb250ZXh0TWVudU1vZHVsZSB7IH1cblxuaW1wb3J0IHR5cGUgKiBhcyBEeENvbnRleHRNZW51VHlwZXMgZnJvbSBcImRldmV4dHJlbWUvdWkvY29udGV4dF9tZW51X3R5cGVzXCI7XG5leHBvcnQgeyBEeENvbnRleHRNZW51VHlwZXMgfTtcblxuXG4iXX0=