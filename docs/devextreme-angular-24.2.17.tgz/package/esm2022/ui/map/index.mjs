/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import DxMap from 'devextreme/ui/map';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxoApiKeyModule } from 'devextreme-angular/ui/nested';
import { DxiCenterModule } from 'devextreme-angular/ui/nested';
import { DxiMarkerModule } from 'devextreme-angular/ui/nested';
import { DxiLocationModule } from 'devextreme-angular/ui/nested';
import { DxoTooltipModule } from 'devextreme-angular/ui/nested';
import { DxiRouteModule } from 'devextreme-angular/ui/nested';
import { DxiCenterComponent } from 'devextreme-angular/ui/nested';
import { DxiMarkerComponent } from 'devextreme-angular/ui/nested';
import { DxiRouteComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxMap]

 */
export class DxMapComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxMapOptions.apiKey]
    
     */
    get apiKey() {
        return this._getOption('apiKey');
    }
    set apiKey(value) {
        this._setOption('apiKey', value);
    }
    /**
     * [descr:dxMapOptions.autoAdjust]
    
     */
    get autoAdjust() {
        return this._getOption('autoAdjust');
    }
    set autoAdjust(value) {
        this._setOption('autoAdjust', value);
    }
    /**
     * [descr:dxMapOptions.center]
    
     */
    get center() {
        return this._getOption('center');
    }
    set center(value) {
        this._setOption('center', value);
    }
    /**
     * [descr:dxMapOptions.controls]
    
     */
    get controls() {
        return this._getOption('controls');
    }
    set controls(value) {
        this._setOption('controls', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxMapOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxMapOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxMapOptions.markerIconSrc]
    
     */
    get markerIconSrc() {
        return this._getOption('markerIconSrc');
    }
    set markerIconSrc(value) {
        this._setOption('markerIconSrc', value);
    }
    /**
     * [descr:dxMapOptions.markers]
    
     */
    get markers() {
        return this._getOption('markers');
    }
    set markers(value) {
        this._setOption('markers', value);
    }
    /**
     * [descr:dxMapOptions.provider]
    
     */
    get provider() {
        return this._getOption('provider');
    }
    set provider(value) {
        this._setOption('provider', value);
    }
    /**
     * [descr:dxMapOptions.routes]
    
     */
    get routes() {
        return this._getOption('routes');
    }
    set routes(value) {
        this._setOption('routes', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxMapOptions.type]
    
     */
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:dxMapOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxMapOptions.zoom]
    
     */
    get zoom() {
        return this._getOption('zoom');
    }
    set zoom(value) {
        this._setOption('zoom', value);
    }
    /**
    
     * [descr:dxMapOptions.onClick]
    
    
     */
    onClick;
    /**
    
     * [descr:dxMapOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxMapOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxMapOptions.onMarkerAdded]
    
    
     */
    onMarkerAdded;
    /**
    
     * [descr:dxMapOptions.onMarkerRemoved]
    
    
     */
    onMarkerRemoved;
    /**
    
     * [descr:dxMapOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxMapOptions.onReady]
    
    
     */
    onReady;
    /**
    
     * [descr:dxMapOptions.onRouteAdded]
    
    
     */
    onRouteAdded;
    /**
    
     * [descr:dxMapOptions.onRouteRemoved]
    
    
     */
    onRouteRemoved;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    apiKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoAdjustChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    controlsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    markerIconSrcChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    markersChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    providerChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    routesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomChange;
    get centerChildren() {
        return this._getOption('center');
    }
    set centerChildren(value) {
        this.setChildren('center', value);
    }
    get markersChildren() {
        return this._getOption('markers');
    }
    set markersChildren(value) {
        this.setChildren('markers', value);
    }
    get routesChildren() {
        return this._getOption('routes');
    }
    set routesChildren(value) {
        this.setChildren('routes', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'click', emit: 'onClick' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'markerAdded', emit: 'onMarkerAdded' },
            { subscribe: 'markerRemoved', emit: 'onMarkerRemoved' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'ready', emit: 'onReady' },
            { subscribe: 'routeAdded', emit: 'onRouteAdded' },
            { subscribe: 'routeRemoved', emit: 'onRouteRemoved' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'apiKeyChange' },
            { emit: 'autoAdjustChange' },
            { emit: 'centerChange' },
            { emit: 'controlsChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'markerIconSrcChange' },
            { emit: 'markersChange' },
            { emit: 'providerChange' },
            { emit: 'routesChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'tabIndexChange' },
            { emit: 'typeChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'zoomChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxMap(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('center', changes);
        this.setupChanges('markers', changes);
        this.setupChanges('routes', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('center');
        this._idh.doCheck('markers');
        this._idh.doCheck('routes');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxMapComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxMapComponent, selector: "dx-map", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", apiKey: "apiKey", autoAdjust: "autoAdjust", center: "center", controls: "controls", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", markerIconSrc: "markerIconSrc", markers: "markers", provider: "provider", routes: "routes", rtlEnabled: "rtlEnabled", tabIndex: "tabIndex", type: "type", visible: "visible", width: "width", zoom: "zoom" }, outputs: { onClick: "onClick", onDisposing: "onDisposing", onInitialized: "onInitialized", onMarkerAdded: "onMarkerAdded", onMarkerRemoved: "onMarkerRemoved", onOptionChanged: "onOptionChanged", onReady: "onReady", onRouteAdded: "onRouteAdded", onRouteRemoved: "onRouteRemoved", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", apiKeyChange: "apiKeyChange", autoAdjustChange: "autoAdjustChange", centerChange: "centerChange", controlsChange: "controlsChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", markerIconSrcChange: "markerIconSrcChange", markersChange: "markersChange", providerChange: "providerChange", routesChange: "routesChange", rtlEnabledChange: "rtlEnabledChange", tabIndexChange: "tabIndexChange", typeChange: "typeChange", visibleChange: "visibleChange", widthChange: "widthChange", zoomChange: "zoomChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "centerChildren", predicate: DxiCenterComponent }, { propertyName: "markersChildren", predicate: DxiMarkerComponent }, { propertyName: "routesChildren", predicate: DxiRouteComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxMapComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-map',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], apiKey: [{
                type: Input
            }], autoAdjust: [{
                type: Input
            }], center: [{
                type: Input
            }], controls: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], markerIconSrc: [{
                type: Input
            }], markers: [{
                type: Input
            }], provider: [{
                type: Input
            }], routes: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], type: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], zoom: [{
                type: Input
            }], onClick: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onMarkerAdded: [{
                type: Output
            }], onMarkerRemoved: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onReady: [{
                type: Output
            }], onRouteAdded: [{
                type: Output
            }], onRouteRemoved: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], apiKeyChange: [{
                type: Output
            }], autoAdjustChange: [{
                type: Output
            }], centerChange: [{
                type: Output
            }], controlsChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], markerIconSrcChange: [{
                type: Output
            }], markersChange: [{
                type: Output
            }], providerChange: [{
                type: Output
            }], routesChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], typeChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], zoomChange: [{
                type: Output
            }], centerChildren: [{
                type: ContentChildren,
                args: [DxiCenterComponent]
            }], markersChildren: [{
                type: ContentChildren,
                args: [DxiMarkerComponent]
            }], routesChildren: [{
                type: ContentChildren,
                args: [DxiRouteComponent]
            }] } });
export class DxMapModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxMapModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxMapModule, declarations: [DxMapComponent], imports: [DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxiRouteModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxMapComponent, DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxiRouteModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxMapModule, imports: [DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxiRouteModule,
            DxIntegrationModule,
            DxTemplateModule, DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxiRouteModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxMapModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoApiKeyModule,
                        DxiCenterModule,
                        DxiMarkerModule,
                        DxiLocationModule,
                        DxoTooltipModule,
                        DxiRouteModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxMapComponent
                    ],
                    exports: [
                        DxMapComponent,
                        DxoApiKeyModule,
                        DxiCenterModule,
                        DxiMarkerModule,
                        DxiLocationModule,
                        DxoTooltipModule,
                        DxiRouteModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL21hcC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUdwQyxPQUFPLEVBQ0gsYUFBYSxFQUNiLFNBQVMsRUFDVCxRQUFRLEVBQ1IsVUFBVSxFQUNWLE1BQU0sRUFDTixXQUFXLEVBQ1gsTUFBTSxFQUVOLEtBQUssRUFDTCxNQUFNLEVBRU4sWUFBWSxFQUlaLGVBQWUsRUFDZixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFLdkIsT0FBTyxLQUFLLE1BQU0sbUJBQW1CLENBQUM7QUFHdEMsT0FBTyxFQUNILFdBQVcsRUFDWCxjQUFjLEVBQ2QsbUJBQW1CLEVBQ25CLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsb0JBQW9CLEVBQ3BCLGFBQWEsRUFDaEIsTUFBTSx5QkFBeUIsQ0FBQztBQUVqQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNqRSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFFOUQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sOEJBQThCLENBQUM7OztBQUlqRTs7O0dBR0c7QUFXSCxNQUFNLE9BQU8sY0FBZSxTQUFRLFdBQVc7SUFpaUIzQjtJQUNBO0lBamlCaEIsUUFBUSxHQUFVLElBQUksQ0FBQztJQUV2Qjs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQXlCO1FBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGtCQUFrQjtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsSUFBSSxrQkFBa0IsQ0FBQyxLQUFjO1FBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBeUU7UUFDaEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUE4RDtRQUNyRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFjO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBVTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxpQkFBaUI7UUFDakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQUksaUJBQWlCLENBQUMsS0FBYztRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQWlDO1FBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQXlCO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYTtRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUF5TDtRQUNqTSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFrQjtRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUFvSjtRQUMzSixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFjO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWE7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBYztRQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQWlDO1FBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQWE7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sT0FBTyxDQUEyQjtJQUU1Qzs7Ozs7T0FLRztJQUNPLFdBQVcsQ0FBK0I7SUFFcEQ7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sYUFBYSxDQUFpQztJQUV4RDs7Ozs7T0FLRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7O09BS0c7SUFDTyxlQUFlLENBQW1DO0lBRTVEOzs7OztPQUtHO0lBQ08sT0FBTyxDQUEyQjtJQUU1Qzs7Ozs7T0FLRztJQUNPLFlBQVksQ0FBZ0M7SUFFdEQ7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7O09BSUc7SUFDTyxlQUFlLENBQW1DO0lBRTVEOzs7O09BSUc7SUFDTyx3QkFBd0IsQ0FBd0I7SUFFMUQ7Ozs7T0FJRztJQUNPLFlBQVksQ0FBbUY7SUFFekc7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF3QjtJQUVsRDs7OztPQUlHO0lBQ08sWUFBWSxDQUF3RTtJQUU5Rjs7OztPQUlHO0lBQ08sY0FBYyxDQUF3QjtJQUVoRDs7OztPQUlHO0lBQ08sY0FBYyxDQUF3QjtJQUVoRDs7OztPQUlHO0lBQ08saUJBQWlCLENBQW9CO0lBRS9DOzs7O09BSUc7SUFDTyx1QkFBdUIsQ0FBd0I7SUFFekQ7Ozs7T0FJRztJQUNPLFlBQVksQ0FBMkM7SUFFakU7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBbUM7SUFFdkQ7Ozs7T0FJRztJQUNPLHVCQUF1QixDQUF3QjtJQUV6RDs7OztPQUlHO0lBQ08sbUJBQW1CLENBQXVCO0lBRXBEOzs7O09BSUc7SUFDTyxhQUFhLENBQW1NO0lBRTFOOzs7O09BSUc7SUFDTyxjQUFjLENBQTRCO0lBRXBEOzs7O09BSUc7SUFDTyxZQUFZLENBQThKO0lBRXBMOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBd0I7SUFFbEQ7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBdUI7SUFFL0M7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBd0I7SUFFNUM7Ozs7T0FJRztJQUNPLGFBQWEsQ0FBd0I7SUFFL0M7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBMkM7SUFFaEU7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBdUI7SUFLM0MsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFLO1FBQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQUs7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBSztRQUNwQixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBS0QsWUFBWSxVQUFzQixFQUFFLE1BQWMsRUFBRSxZQUE0QixFQUNoRSxjQUE2QixFQUM3QixJQUEwQixFQUNsQyxVQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFFeEMsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFOdkUsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFDN0IsU0FBSSxHQUFKLElBQUksQ0FBc0I7UUFPdEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3ZDLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ25ELEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ25ELEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDdkQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRTtZQUN2QyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUNqRCxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLDBCQUEwQixFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUN4QixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUNuQyxFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvQixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtTQUN6QixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFUyxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU87UUFFdEMsT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdELFdBQVc7UUFDUCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBWSxFQUFFLE9BQXNCO1FBQzdDLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDbEM7SUFDTCxDQUFDO0lBRUQsU0FBUztRQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDcEMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2xCLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxVQUFVLENBQUMsSUFBWSxFQUFFLEtBQVU7UUFDL0IsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUM7UUFFM0QsSUFBSSxPQUFPLElBQUksU0FBUyxFQUFFO1lBQ3RCLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQzsySEF0bkJRLGNBQWMsOE5BcWlCUCxXQUFXOytHQXJpQmxCLGNBQWMsc2xEQVBaO1lBQ1AsY0FBYztZQUNkLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsb0JBQW9CO1NBQ3ZCLHlEQXVnQmdCLGtCQUFrQixrREFRbEIsa0JBQWtCLGlEQVFsQixpQkFBaUIseUVBN2hCeEIsRUFBRTs7NEZBUUgsY0FBYztrQkFWMUIsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsUUFBUTtvQkFDbEIsUUFBUSxFQUFFLEVBQUU7b0JBQ1osU0FBUyxFQUFFO3dCQUNQLGNBQWM7d0JBQ2QsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLG9CQUFvQjtxQkFDdkI7aUJBQ0o7OzBCQXNpQlksTUFBTTsyQkFBQyxXQUFXOzRDQTdoQnZCLFNBQVM7c0JBRFosS0FBSztnQkFjRixrQkFBa0I7c0JBRHJCLEtBQUs7Z0JBY0YsTUFBTTtzQkFEVCxLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixNQUFNO3NCQURULEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsaUJBQWlCO3NCQURwQixLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsaUJBQWlCO3NCQURwQixLQUFLO2dCQWNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixNQUFNO3NCQURULEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0ksT0FBTztzQkFBaEIsTUFBTTtnQkFRRyxXQUFXO3NCQUFwQixNQUFNO2dCQVFHLGFBQWE7c0JBQXRCLE1BQU07Z0JBUUcsYUFBYTtzQkFBdEIsTUFBTTtnQkFRRyxlQUFlO3NCQUF4QixNQUFNO2dCQVFHLGVBQWU7c0JBQXhCLE1BQU07Z0JBUUcsT0FBTztzQkFBaEIsTUFBTTtnQkFRRyxZQUFZO3NCQUFyQixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLHVCQUF1QjtzQkFBaEMsTUFBTTtnQkFPRyxZQUFZO3NCQUFyQixNQUFNO2dCQU9HLFVBQVU7c0JBQW5CLE1BQU07Z0JBT0csdUJBQXVCO3NCQUFoQyxNQUFNO2dCQU9HLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFPRyxhQUFhO3NCQUF0QixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU1ILGNBQWM7c0JBRGpCLGVBQWU7dUJBQUMsa0JBQWtCO2dCQVMvQixlQUFlO3NCQURsQixlQUFlO3VCQUFDLGtCQUFrQjtnQkFTL0IsY0FBYztzQkFEakIsZUFBZTt1QkFBQyxpQkFBaUI7O0FBNkh0QyxNQUFNLE9BQU8sV0FBVzsySEFBWCxXQUFXOzRIQUFYLFdBQVcsaUJBbHBCWCxjQUFjLGFBMm5CdkIsZUFBZTtZQUNmLGVBQWU7WUFDZixlQUFlO1lBQ2YsaUJBQWlCO1lBQ2pCLGdCQUFnQjtZQUNoQixjQUFjO1lBQ2QsbUJBQW1CO1lBQ25CLGdCQUFnQixhQWxvQlAsY0FBYyxFQXlvQnZCLGVBQWU7WUFDZixlQUFlO1lBQ2YsZUFBZTtZQUNmLGlCQUFpQjtZQUNqQixnQkFBZ0I7WUFDaEIsY0FBYztZQUNkLGdCQUFnQjs0SEFHUCxXQUFXLFlBdkJwQixlQUFlO1lBQ2YsZUFBZTtZQUNmLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsZ0JBQWdCO1lBQ2hCLGNBQWM7WUFDZCxtQkFBbUI7WUFDbkIsZ0JBQWdCLEVBT2hCLGVBQWU7WUFDZixlQUFlO1lBQ2YsZUFBZTtZQUNmLGlCQUFpQjtZQUNqQixnQkFBZ0I7WUFDaEIsY0FBYztZQUNkLGdCQUFnQjs7NEZBR1AsV0FBVztrQkF6QnZCLFFBQVE7bUJBQUM7b0JBQ1IsT0FBTyxFQUFFO3dCQUNQLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixlQUFlO3dCQUNmLGlCQUFpQjt3QkFDakIsZ0JBQWdCO3dCQUNoQixjQUFjO3dCQUNkLG1CQUFtQjt3QkFDbkIsZ0JBQWdCO3FCQUNqQjtvQkFDRCxZQUFZLEVBQUU7d0JBQ1osY0FBYztxQkFDZjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsY0FBYzt3QkFDZCxlQUFlO3dCQUNmLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixpQkFBaUI7d0JBQ2pCLGdCQUFnQjt3QkFDaEIsY0FBYzt3QkFDZCxnQkFBZ0I7cUJBQ2pCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG5cbmltcG9ydCB7XG4gICAgVHJhbnNmZXJTdGF0ZSxcbiAgICBDb21wb25lbnQsXG4gICAgTmdNb2R1bGUsXG4gICAgRWxlbWVudFJlZixcbiAgICBOZ1pvbmUsXG4gICAgUExBVEZPUk1fSUQsXG4gICAgSW5qZWN0LFxuXG4gICAgSW5wdXQsXG4gICAgT3V0cHV0LFxuICAgIE9uRGVzdHJveSxcbiAgICBFdmVudEVtaXR0ZXIsXG4gICAgT25DaGFuZ2VzLFxuICAgIERvQ2hlY2ssXG4gICAgU2ltcGxlQ2hhbmdlcyxcbiAgICBDb250ZW50Q2hpbGRyZW4sXG4gICAgUXVlcnlMaXN0XG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cbmltcG9ydCB7IENsaWNrRXZlbnQsIERpc3Bvc2luZ0V2ZW50LCBJbml0aWFsaXplZEV2ZW50LCBNYXBQcm92aWRlciwgTWFwVHlwZSwgTWFya2VyQWRkZWRFdmVudCwgTWFya2VyUmVtb3ZlZEV2ZW50LCBPcHRpb25DaGFuZ2VkRXZlbnQsIFJlYWR5RXZlbnQsIFJvdXRlQWRkZWRFdmVudCwgUm91dGVNb2RlLCBSb3V0ZVJlbW92ZWRFdmVudCB9IGZyb20gJ2RldmV4dHJlbWUvdWkvbWFwJztcblxuaW1wb3J0IER4TWFwIGZyb20gJ2RldmV4dHJlbWUvdWkvbWFwJztcblxuXG5pbXBvcnQge1xuICAgIER4Q29tcG9uZW50LFxuICAgIER4VGVtcGxhdGVIb3N0LFxuICAgIER4SW50ZWdyYXRpb25Nb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZSxcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgIEl0ZXJhYmxlRGlmZmVySGVscGVyLFxuICAgIFdhdGNoZXJIZWxwZXJcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBEeG9BcGlLZXlNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aUNlbnRlck1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpTWFya2VyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlMb2NhdGlvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVG9vbHRpcE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpUm91dGVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcblxuaW1wb3J0IHsgRHhpQ2VudGVyQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlNYXJrZXJDb21wb25lbnQgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aVJvdXRlQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5cblxuXG4vKipcbiAqIFtkZXNjcjpkeE1hcF1cblxuICovXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4LW1hcCcsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgV2F0Y2hlckhlbHBlcixcbiAgICAgICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4TWFwQ29tcG9uZW50IGV4dGVuZHMgRHhDb21wb25lbnQgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uQ2hhbmdlcywgRG9DaGVjayB7XG4gICAgaW5zdGFuY2U6IER4TWFwID0gbnVsbDtcblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmFjY2Vzc0tleV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBhY2Nlc3NLZXkoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWNjZXNzS2V5Jyk7XG4gICAgfVxuICAgIHNldCBhY2Nlc3NLZXkodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjY2Vzc0tleScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmFjdGl2ZVN0YXRlRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBhY3RpdmVTdGF0ZUVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FjdGl2ZVN0YXRlRW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgYWN0aXZlU3RhdGVFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWN0aXZlU3RhdGVFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5hcGlLZXldXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYXBpS2V5KCk6IHN0cmluZyB8IHsgYmluZz86IHN0cmluZywgZ29vZ2xlPzogc3RyaW5nLCBnb29nbGVTdGF0aWM/OiBzdHJpbmcgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FwaUtleScpO1xuICAgIH1cbiAgICBzZXQgYXBpS2V5KHZhbHVlOiBzdHJpbmcgfCB7IGJpbmc/OiBzdHJpbmcsIGdvb2dsZT86IHN0cmluZywgZ29vZ2xlU3RhdGljPzogc3RyaW5nIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhcGlLZXknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLmF1dG9BZGp1c3RdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYXV0b0FkanVzdCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYXV0b0FkanVzdCcpO1xuICAgIH1cbiAgICBzZXQgYXV0b0FkanVzdCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2F1dG9BZGp1c3QnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLmNlbnRlcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBjZW50ZXIoKTogc3RyaW5nIHwgQXJyYXk8bnVtYmVyIHwgeyBsYXQ/OiBudW1iZXIsIGxuZz86IG51bWJlciB9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NlbnRlcicpO1xuICAgIH1cbiAgICBzZXQgY2VudGVyKHZhbHVlOiBzdHJpbmcgfCBBcnJheTxudW1iZXIgfCB7IGxhdD86IG51bWJlciwgbG5nPzogbnVtYmVyIH0+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY2VudGVyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5jb250cm9sc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBjb250cm9scygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29udHJvbHMnKTtcbiAgICB9XG4gICAgc2V0IGNvbnRyb2xzKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY29udHJvbHMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5kaXNhYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGRpc2FibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5lbGVtZW50QXR0cl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBlbGVtZW50QXR0cigpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdlbGVtZW50QXR0cicpO1xuICAgIH1cbiAgICBzZXQgZWxlbWVudEF0dHIodmFsdWU6IGFueSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2VsZW1lbnRBdHRyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5mb2N1c1N0YXRlRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBmb2N1c1N0YXRlRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGZvY3VzU3RhdGVFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLmhlaWdodF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBoZWlnaHQoKTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdoZWlnaHQnKTtcbiAgICB9XG4gICAgc2V0IGhlaWdodCh2YWx1ZTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoZWlnaHQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5oaW50XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhpbnQoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGludCcpO1xuICAgIH1cbiAgICBzZXQgaGludCh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGludCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmhvdmVyU3RhdGVFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhvdmVyU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdob3ZlclN0YXRlRW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgaG92ZXJTdGF0ZUVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdob3ZlclN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeE1hcE9wdGlvbnMubWFya2VySWNvblNyY11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBtYXJrZXJJY29uU3JjKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21hcmtlckljb25TcmMnKTtcbiAgICB9XG4gICAgc2V0IG1hcmtlckljb25TcmModmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21hcmtlckljb25TcmMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLm1hcmtlcnNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbWFya2VycygpOiBBcnJheTxhbnkgfCB7IGljb25TcmM/OiBzdHJpbmcsIGxvY2F0aW9uPzogc3RyaW5nIHwgQXJyYXk8bnVtYmVyIHwgeyBsYXQ/OiBudW1iZXIsIGxuZz86IG51bWJlciB9Piwgb25DbGljaz86IEZ1bmN0aW9uLCB0b29sdGlwPzogc3RyaW5nIHwgeyBpc1Nob3duPzogYm9vbGVhbiwgdGV4dD86IHN0cmluZyB9IH0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbWFya2VycycpO1xuICAgIH1cbiAgICBzZXQgbWFya2Vycyh2YWx1ZTogQXJyYXk8YW55IHwgeyBpY29uU3JjPzogc3RyaW5nLCBsb2NhdGlvbj86IHN0cmluZyB8IEFycmF5PG51bWJlciB8IHsgbGF0PzogbnVtYmVyLCBsbmc/OiBudW1iZXIgfT4sIG9uQ2xpY2s/OiBGdW5jdGlvbiwgdG9vbHRpcD86IHN0cmluZyB8IHsgaXNTaG93bj86IGJvb2xlYW4sIHRleHQ/OiBzdHJpbmcgfSB9Pikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21hcmtlcnMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLnByb3ZpZGVyXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHByb3ZpZGVyKCk6IE1hcFByb3ZpZGVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncHJvdmlkZXInKTtcbiAgICB9XG4gICAgc2V0IHByb3ZpZGVyKHZhbHVlOiBNYXBQcm92aWRlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Byb3ZpZGVyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5yb3V0ZXNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcm91dGVzKCk6IEFycmF5PGFueSB8IHsgY29sb3I/OiBzdHJpbmcsIGxvY2F0aW9ucz86IEFycmF5PGFueSB8IHsgbGF0PzogbnVtYmVyLCBsbmc/OiBudW1iZXIgfT4sIG1vZGU/OiBSb3V0ZU1vZGUsIG9wYWNpdHk/OiBudW1iZXIsIHdlaWdodD86IG51bWJlciB9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3JvdXRlcycpO1xuICAgIH1cbiAgICBzZXQgcm91dGVzKHZhbHVlOiBBcnJheTxhbnkgfCB7IGNvbG9yPzogc3RyaW5nLCBsb2NhdGlvbnM/OiBBcnJheTxhbnkgfCB7IGxhdD86IG51bWJlciwgbG5nPzogbnVtYmVyIH0+LCBtb2RlPzogUm91dGVNb2RlLCBvcGFjaXR5PzogbnVtYmVyLCB3ZWlnaHQ/OiBudW1iZXIgfT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdyb3V0ZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5ydGxFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJ0bEVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3J0bEVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHJ0bEVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdydGxFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMudGFiSW5kZXhdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdGFiSW5kZXgoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFiSW5kZXgnKTtcbiAgICB9XG4gICAgc2V0IHRhYkluZGV4KHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0YWJJbmRleCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeE1hcE9wdGlvbnMudHlwZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0eXBlKCk6IE1hcFR5cGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0eXBlJyk7XG4gICAgfVxuICAgIHNldCB0eXBlKHZhbHVlOiBNYXBUeXBlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndHlwZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLnZpc2libGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmlzaWJsZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlzaWJsZScpO1xuICAgIH1cbiAgICBzZXQgdmlzaWJsZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Zpc2libGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLndpZHRoXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHdpZHRoKCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignd2lkdGgnKTtcbiAgICB9XG4gICAgc2V0IHdpZHRoKHZhbHVlOiBudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3dpZHRoJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy56b29tXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHpvb20oKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignem9vbScpO1xuICAgIH1cbiAgICBzZXQgem9vbSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignem9vbScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLm9uQ2xpY2tdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ2xpY2s6IEV2ZW50RW1pdHRlcjxDbGlja0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeE1hcE9wdGlvbnMub25EaXNwb3NpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRGlzcG9zaW5nOiBFdmVudEVtaXR0ZXI8RGlzcG9zaW5nRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5vbkluaXRpYWxpemVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkluaXRpYWxpemVkOiBFdmVudEVtaXR0ZXI8SW5pdGlhbGl6ZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLm9uTWFya2VyQWRkZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uTWFya2VyQWRkZWQ6IEV2ZW50RW1pdHRlcjxNYXJrZXJBZGRlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeE1hcE9wdGlvbnMub25NYXJrZXJSZW1vdmVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbk1hcmtlclJlbW92ZWQ6IEV2ZW50RW1pdHRlcjxNYXJrZXJSZW1vdmVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5vbk9wdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uT3B0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPE9wdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhNYXBPcHRpb25zLm9uUmVhZHldXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVhZHk6IEV2ZW50RW1pdHRlcjxSZWFkeUV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeE1hcE9wdGlvbnMub25Sb3V0ZUFkZGVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblJvdXRlQWRkZWQ6IEV2ZW50RW1pdHRlcjxSb3V0ZUFkZGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4TWFwT3B0aW9ucy5vblJvdXRlUmVtb3ZlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25Sb3V0ZVJlbW92ZWQ6IEV2ZW50RW1pdHRlcjxSb3V0ZVJlbW92ZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBhY2Nlc3NLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBhcGlLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmcgfCB7IGJpbmc/OiBzdHJpbmcsIGdvb2dsZT86IHN0cmluZywgZ29vZ2xlU3RhdGljPzogc3RyaW5nIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgYXV0b0FkanVzdENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY2VudGVyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nIHwgQXJyYXk8bnVtYmVyIHwgeyBsYXQ/OiBudW1iZXIsIGxuZz86IG51bWJlciB9Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBjb250cm9sc0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZGlzYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGVsZW1lbnRBdHRyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGZvY3VzU3RhdGVFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBoZWlnaHRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBoaW50Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGhvdmVyU3RhdGVFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBtYXJrZXJJY29uU3JjQ2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG1hcmtlcnNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxBcnJheTxhbnkgfCB7IGljb25TcmM/OiBzdHJpbmcsIGxvY2F0aW9uPzogc3RyaW5nIHwgQXJyYXk8bnVtYmVyIHwgeyBsYXQ/OiBudW1iZXIsIGxuZz86IG51bWJlciB9Piwgb25DbGljaz86IEZ1bmN0aW9uLCB0b29sdGlwPzogc3RyaW5nIHwgeyBpc1Nob3duPzogYm9vbGVhbiwgdGV4dD86IHN0cmluZyB9IH0+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHByb3ZpZGVyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8TWFwUHJvdmlkZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcm91dGVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8YW55IHwgeyBjb2xvcj86IHN0cmluZywgbG9jYXRpb25zPzogQXJyYXk8YW55IHwgeyBsYXQ/OiBudW1iZXIsIGxuZz86IG51bWJlciB9PiwgbW9kZT86IFJvdXRlTW9kZSwgb3BhY2l0eT86IG51bWJlciwgd2VpZ2h0PzogbnVtYmVyIH0+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJ0bEVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRhYkluZGV4Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHR5cGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxNYXBUeXBlPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZpc2libGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHdpZHRoQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgem9vbUNoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlcj47XG5cblxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKER4aUNlbnRlckNvbXBvbmVudClcbiAgICBnZXQgY2VudGVyQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUNlbnRlckNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjZW50ZXInKTtcbiAgICB9XG4gICAgc2V0IGNlbnRlckNoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2NlbnRlcicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBAQ29udGVudENoaWxkcmVuKER4aU1hcmtlckNvbXBvbmVudClcbiAgICBnZXQgbWFya2Vyc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlNYXJrZXJDb21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbWFya2VycycpO1xuICAgIH1cbiAgICBzZXQgbWFya2Vyc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ21hcmtlcnMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihEeGlSb3V0ZUNvbXBvbmVudClcbiAgICBnZXQgcm91dGVzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aVJvdXRlQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3JvdXRlcycpO1xuICAgIH1cbiAgICBzZXQgcm91dGVzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbigncm91dGVzJywgdmFsdWUpO1xuICAgIH1cblxuXG5cblxuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIG5nWm9uZTogTmdab25lLCB0ZW1wbGF0ZUhvc3Q6IER4VGVtcGxhdGVIb3N0LFxuICAgICAgICAgICAgcHJpdmF0ZSBfd2F0Y2hlckhlbHBlcjogV2F0Y2hlckhlbHBlcixcbiAgICAgICAgICAgIHByaXZhdGUgX2lkaDogSXRlcmFibGVEaWZmZXJIZWxwZXIsXG4gICAgICAgICAgICBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgdHJhbnNmZXJTdGF0ZTogVHJhbnNmZXJTdGF0ZSxcbiAgICAgICAgICAgIEBJbmplY3QoUExBVEZPUk1fSUQpIHBsYXRmb3JtSWQ6IGFueSkge1xuXG4gICAgICAgIHN1cGVyKGVsZW1lbnRSZWYsIG5nWm9uZSwgdGVtcGxhdGVIb3N0LCBfd2F0Y2hlckhlbHBlciwgdHJhbnNmZXJTdGF0ZSwgcGxhdGZvcm1JZCk7XG5cbiAgICAgICAgdGhpcy5fY3JlYXRlRXZlbnRFbWl0dGVycyhbXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2NsaWNrJywgZW1pdDogJ29uQ2xpY2snIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2Rpc3Bvc2luZycsIGVtaXQ6ICdvbkRpc3Bvc2luZycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5pdGlhbGl6ZWQnLCBlbWl0OiAnb25Jbml0aWFsaXplZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnbWFya2VyQWRkZWQnLCBlbWl0OiAnb25NYXJrZXJBZGRlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnbWFya2VyUmVtb3ZlZCcsIGVtaXQ6ICdvbk1hcmtlclJlbW92ZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ29wdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25PcHRpb25DaGFuZ2VkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdyZWFkeScsIGVtaXQ6ICdvblJlYWR5JyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdyb3V0ZUFkZGVkJywgZW1pdDogJ29uUm91dGVBZGRlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncm91dGVSZW1vdmVkJywgZW1pdDogJ29uUm91dGVSZW1vdmVkJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWNjZXNzS2V5Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYXBpS2V5Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYXV0b0FkanVzdENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2NlbnRlckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2NvbnRyb2xzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGlzYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdlbGVtZW50QXR0ckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2ZvY3VzU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGVpZ2h0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGludENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hvdmVyU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnbWFya2VySWNvblNyY0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ21hcmtlcnNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdwcm92aWRlckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3JvdXRlc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3J0bEVuYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0YWJJbmRleENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3R5cGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2aXNpYmxlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnd2lkdGhDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd6b29tQ2hhbmdlJyB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIHRoaXMuX2lkaC5zZXRIb3N0KHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcyk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9jcmVhdGVJbnN0YW5jZShlbGVtZW50LCBvcHRpb25zKSB7XG5cbiAgICAgICAgcmV0dXJuIG5ldyBEeE1hcChlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2NlbnRlcicsIGNoYW5nZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygnbWFya2VycycsIGNoYW5nZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygncm91dGVzJywgY2hhbmdlcyk7XG4gICAgfVxuXG4gICAgc2V0dXBDaGFuZ2VzKHByb3A6IHN0cmluZywgY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoIShwcm9wIGluIHRoaXMuX29wdGlvbnNUb1VwZGF0ZSkpIHtcbiAgICAgICAgICAgIHRoaXMuX2lkaC5zZXR1cChwcm9wLCBjaGFuZ2VzKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nRG9DaGVjaygpIHtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ2NlbnRlcicpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnbWFya2VycycpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygncm91dGVzJyk7XG4gICAgICAgIHRoaXMuX3dhdGNoZXJIZWxwZXIuY2hlY2tXYXRjaGVycygpO1xuICAgICAgICBzdXBlci5uZ0RvQ2hlY2soKTtcbiAgICAgICAgc3VwZXIuY2xlYXJDaGFuZ2VkT3B0aW9ucygpO1xuICAgIH1cblxuICAgIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XG4gICAgICAgIGxldCBpc1NldHVwID0gdGhpcy5faWRoLnNldHVwU2luZ2xlKG5hbWUsIHZhbHVlKTtcbiAgICAgICAgbGV0IGlzQ2hhbmdlZCA9IHRoaXMuX2lkaC5nZXRDaGFuZ2VzKG5hbWUsIHZhbHVlKSAhPT0gbnVsbDtcblxuICAgICAgICBpZiAoaXNTZXR1cCB8fCBpc0NoYW5nZWQpIHtcbiAgICAgICAgICAgIHN1cGVyLl9zZXRPcHRpb24obmFtZSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgRHhvQXBpS2V5TW9kdWxlLFxuICAgIER4aUNlbnRlck1vZHVsZSxcbiAgICBEeGlNYXJrZXJNb2R1bGUsXG4gICAgRHhpTG9jYXRpb25Nb2R1bGUsXG4gICAgRHhvVG9vbHRpcE1vZHVsZSxcbiAgICBEeGlSb3V0ZU1vZHVsZSxcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGVcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhNYXBDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4TWFwQ29tcG9uZW50LFxuICAgIER4b0FwaUtleU1vZHVsZSxcbiAgICBEeGlDZW50ZXJNb2R1bGUsXG4gICAgRHhpTWFya2VyTW9kdWxlLFxuICAgIER4aUxvY2F0aW9uTW9kdWxlLFxuICAgIER4b1Rvb2x0aXBNb2R1bGUsXG4gICAgRHhpUm91dGVNb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZVxuICBdXG59KVxuZXhwb3J0IGNsYXNzIER4TWFwTW9kdWxlIHsgfVxuXG5pbXBvcnQgdHlwZSAqIGFzIER4TWFwVHlwZXMgZnJvbSBcImRldmV4dHJlbWUvdWkvbWFwX3R5cGVzXCI7XG5leHBvcnQgeyBEeE1hcFR5cGVzIH07XG5cblxuIl19