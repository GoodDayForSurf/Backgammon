/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiFileManagerToolbarItem } from './base/file-manager-toolbar-item-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiFileSelectionItemComponent extends DxiFileManagerToolbarItem {
    get _optionPath() {
        return 'fileSelectionItems';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileSelectionItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiFileSelectionItemComponent, selector: "dxi-file-selection-item", inputs: { cssClass: "cssClass", disabled: "disabled", icon: "icon", locateInMenu: "locateInMenu", location: "location", name: "name", options: "options", showText: "showText", text: "text", visible: "visible", widget: "widget" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileSelectionItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-file-selection-item', template: '', providers: [NestedOptionHost], inputs: [
                        'cssClass',
                        'disabled',
                        'icon',
                        'locateInMenu',
                        'location',
                        'name',
                        'options',
                        'showText',
                        'text',
                        'visible',
                        'widget'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxiFileSelectionItemModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileSelectionItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiFileSelectionItemModule, declarations: [DxiFileSelectionItemComponent], exports: [DxiFileSelectionItemComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileSelectionItemModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileSelectionItemModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiFileSelectionItemComponent
                    ],
                    exports: [
                        DxiFileSelectionItemComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1zZWxlY3Rpb24taXRlbS1keGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9maWxlLXNlbGVjdGlvbi1pdGVtLWR4aS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFDVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFFBQVEsRUFDWCxNQUFNLGVBQWUsQ0FBQztBQU12QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0sc0NBQXNDLENBQUM7OztBQXNCakYsTUFBTSxPQUFPLDZCQUE4QixTQUFRLHlCQUF5QjtJQUV4RSxJQUFjLFdBQVc7UUFDckIsT0FBTyxvQkFBb0IsQ0FBQztJQUNoQyxDQUFDO0lBR0QsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBQ1IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUlELFdBQVc7UUFDUCxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7SUFDdkQsQ0FBQzsySEFsQlEsNkJBQTZCOytHQUE3Qiw2QkFBNkIsd1JBZjNCLENBQUMsZ0JBQWdCLENBQUMsaURBRm5CLEVBQUU7OzRGQWlCSCw2QkFBNkI7a0JBbkJ6QyxTQUFTOytCQUNJLHlCQUF5QixZQUN6QixFQUFFLGFBRUQsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUNyQjt3QkFDSixVQUFVO3dCQUNWLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixjQUFjO3dCQUNkLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixTQUFTO3dCQUNULFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixTQUFTO3dCQUNULFFBQVE7cUJBQ1g7OzBCQVNZLFFBQVE7OzBCQUFJLElBQUk7OzBCQUNwQixJQUFJOztBQXNCakIsTUFBTSxPQUFPLDBCQUEwQjsySEFBMUIsMEJBQTBCOzRIQUExQiwwQkFBMEIsaUJBOUIxQiw2QkFBNkIsYUFBN0IsNkJBQTZCOzRIQThCN0IsMEJBQTBCOzs0RkFBMUIsMEJBQTBCO2tCQVJ0QyxRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWiw2QkFBNkI7cUJBQzlCO29CQUNELE9BQU8sRUFBRTt3QkFDUCw2QkFBNkI7cUJBQzlCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeGlGaWxlTWFuYWdlclRvb2xiYXJJdGVtIH0gZnJvbSAnLi9iYXNlL2ZpbGUtbWFuYWdlci10b29sYmFyLWl0ZW0tZHhpJztcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4aS1maWxlLXNlbGVjdGlvbi1pdGVtJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnY3NzQ2xhc3MnLFxuICAgICAgICAnZGlzYWJsZWQnLFxuICAgICAgICAnaWNvbicsXG4gICAgICAgICdsb2NhdGVJbk1lbnUnLFxuICAgICAgICAnbG9jYXRpb24nLFxuICAgICAgICAnbmFtZScsXG4gICAgICAgICdvcHRpb25zJyxcbiAgICAgICAgJ3Nob3dUZXh0JyxcbiAgICAgICAgJ3RleHQnLFxuICAgICAgICAndmlzaWJsZScsXG4gICAgICAgICd3aWRnZXQnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeGlGaWxlU2VsZWN0aW9uSXRlbUNvbXBvbmVudCBleHRlbmRzIER4aUZpbGVNYW5hZ2VyVG9vbGJhckl0ZW0ge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdmaWxlU2VsZWN0aW9uSXRlbXMnO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZWxldGVSZW1vdmVkT3B0aW9ucyh0aGlzLl9mdWxsT3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cbn1cblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhpRmlsZVNlbGVjdGlvbkl0ZW1Db21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4aUZpbGVTZWxlY3Rpb25JdGVtQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4aUZpbGVTZWxlY3Rpb25JdGVtTW9kdWxlIHsgfVxuIl19