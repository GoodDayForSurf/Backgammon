/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf, Output, EventEmitter } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoFileUploaderOptions } from './base/file-uploader-options';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoFileUploaderOptionsComponent extends DxoFileUploaderOptions {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange;
    get _optionPath() {
        return 'fileUploaderOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileUploaderOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoFileUploaderOptionsComponent, selector: "dxo-file-uploader-options", inputs: { abortUpload: "abortUpload", accept: "accept", accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowCanceling: "allowCanceling", allowedFileExtensions: "allowedFileExtensions", chunkSize: "chunkSize", dialogTrigger: "dialogTrigger", disabled: "disabled", dropZone: "dropZone", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", inputAttr: "inputAttr", invalidFileExtensionMessage: "invalidFileExtensionMessage", invalidMaxFileSizeMessage: "invalidMaxFileSizeMessage", invalidMinFileSizeMessage: "invalidMinFileSizeMessage", isDirty: "isDirty", isValid: "isValid", labelText: "labelText", maxFileSize: "maxFileSize", minFileSize: "minFileSize", multiple: "multiple", name: "name", onBeforeSend: "onBeforeSend", onContentReady: "onContentReady", onDisposing: "onDisposing", onDropZoneEnter: "onDropZoneEnter", onDropZoneLeave: "onDropZoneLeave", onFilesUploaded: "onFilesUploaded", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onProgress: "onProgress", onUploadAborted: "onUploadAborted", onUploaded: "onUploaded", onUploadError: "onUploadError", onUploadStarted: "onUploadStarted", onValueChanged: "onValueChanged", progress: "progress", readOnly: "readOnly", readyToUploadMessage: "readyToUploadMessage", rtlEnabled: "rtlEnabled", selectButtonText: "selectButtonText", showFileList: "showFileList", tabIndex: "tabIndex", uploadAbortedMessage: "uploadAbortedMessage", uploadButtonText: "uploadButtonText", uploadChunk: "uploadChunk", uploadCustomData: "uploadCustomData", uploadedMessage: "uploadedMessage", uploadFailedMessage: "uploadFailedMessage", uploadFile: "uploadFile", uploadHeaders: "uploadHeaders", uploadMethod: "uploadMethod", uploadMode: "uploadMode", uploadUrl: "uploadUrl", validationError: "validationError", validationErrors: "validationErrors", validationStatus: "validationStatus", value: "value", visible: "visible", width: "width" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileUploaderOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-file-uploader-options', template: '', providers: [NestedOptionHost], inputs: [
                        'abortUpload',
                        'accept',
                        'accessKey',
                        'activeStateEnabled',
                        'allowCanceling',
                        'allowedFileExtensions',
                        'chunkSize',
                        'dialogTrigger',
                        'disabled',
                        'dropZone',
                        'elementAttr',
                        'focusStateEnabled',
                        'height',
                        'hint',
                        'hoverStateEnabled',
                        'inputAttr',
                        'invalidFileExtensionMessage',
                        'invalidMaxFileSizeMessage',
                        'invalidMinFileSizeMessage',
                        'isDirty',
                        'isValid',
                        'labelText',
                        'maxFileSize',
                        'minFileSize',
                        'multiple',
                        'name',
                        'onBeforeSend',
                        'onContentReady',
                        'onDisposing',
                        'onDropZoneEnter',
                        'onDropZoneLeave',
                        'onFilesUploaded',
                        'onInitialized',
                        'onOptionChanged',
                        'onProgress',
                        'onUploadAborted',
                        'onUploaded',
                        'onUploadError',
                        'onUploadStarted',
                        'onValueChanged',
                        'progress',
                        'readOnly',
                        'readyToUploadMessage',
                        'rtlEnabled',
                        'selectButtonText',
                        'showFileList',
                        'tabIndex',
                        'uploadAbortedMessage',
                        'uploadButtonText',
                        'uploadChunk',
                        'uploadCustomData',
                        'uploadedMessage',
                        'uploadFailedMessage',
                        'uploadFile',
                        'uploadHeaders',
                        'uploadMethod',
                        'uploadMode',
                        'uploadUrl',
                        'validationError',
                        'validationErrors',
                        'validationStatus',
                        'value',
                        'visible',
                        'width'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { valueChange: [{
                type: Output
            }] } });
export class DxoFileUploaderOptionsModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileUploaderOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoFileUploaderOptionsModule, declarations: [DxoFileUploaderOptionsComponent], exports: [DxoFileUploaderOptionsComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileUploaderOptionsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileUploaderOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoFileUploaderOptionsComponent
                    ],
                    exports: [
                        DxoFileUploaderOptionsComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS11cGxvYWRlci1vcHRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvZmlsZS11cGxvYWRlci1vcHRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUdULFFBQVEsRUFDUixJQUFJLEVBQ0osUUFBUSxFQUNSLE1BQU0sRUFDTixZQUFZLEVBQ2YsTUFBTSxlQUFlLENBQUM7QUFNdkIsT0FBTyxFQUNILGdCQUFnQixHQUNuQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDOzs7QUEyRXRFLE1BQU0sT0FBTywrQkFBZ0MsU0FBUSxzQkFBc0I7SUFFdkU7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBMkI7SUFDaEQsSUFBYyxXQUFXO1FBQ3JCLE9BQU8scUJBQXFCLENBQUM7SUFDakMsQ0FBQztJQUdELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUVSLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUN0QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7U0FDMUIsQ0FBQyxDQUFDO1FBRUgsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUdELFFBQVE7UUFDSixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDOzJIQWhDUSwrQkFBK0I7K0dBQS9CLCtCQUErQix1aUVBcEU3QixDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkFzRUgsK0JBQStCO2tCQXhFM0MsU0FBUzsrQkFDSSwyQkFBMkIsWUFDM0IsRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUMsVUFDckI7d0JBQ0osYUFBYTt3QkFDYixRQUFRO3dCQUNSLFdBQVc7d0JBQ1gsb0JBQW9CO3dCQUNwQixnQkFBZ0I7d0JBQ2hCLHVCQUF1Qjt3QkFDdkIsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLFVBQVU7d0JBQ1YsVUFBVTt3QkFDVixhQUFhO3dCQUNiLG1CQUFtQjt3QkFDbkIsUUFBUTt3QkFDUixNQUFNO3dCQUNOLG1CQUFtQjt3QkFDbkIsV0FBVzt3QkFDWCw2QkFBNkI7d0JBQzdCLDJCQUEyQjt3QkFDM0IsMkJBQTJCO3dCQUMzQixTQUFTO3dCQUNULFNBQVM7d0JBQ1QsV0FBVzt3QkFDWCxhQUFhO3dCQUNiLGFBQWE7d0JBQ2IsVUFBVTt3QkFDVixNQUFNO3dCQUNOLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixhQUFhO3dCQUNiLGlCQUFpQjt3QkFDakIsaUJBQWlCO3dCQUNqQixpQkFBaUI7d0JBQ2pCLGVBQWU7d0JBQ2YsaUJBQWlCO3dCQUNqQixZQUFZO3dCQUNaLGlCQUFpQjt3QkFDakIsWUFBWTt3QkFDWixlQUFlO3dCQUNmLGlCQUFpQjt3QkFDakIsZ0JBQWdCO3dCQUNoQixVQUFVO3dCQUNWLFVBQVU7d0JBQ1Ysc0JBQXNCO3dCQUN0QixZQUFZO3dCQUNaLGtCQUFrQjt3QkFDbEIsY0FBYzt3QkFDZCxVQUFVO3dCQUNWLHNCQUFzQjt3QkFDdEIsa0JBQWtCO3dCQUNsQixhQUFhO3dCQUNiLGtCQUFrQjt3QkFDbEIsaUJBQWlCO3dCQUNqQixxQkFBcUI7d0JBQ3JCLFlBQVk7d0JBQ1osZUFBZTt3QkFDZixjQUFjO3dCQUNkLFlBQVk7d0JBQ1osV0FBVzt3QkFDWCxpQkFBaUI7d0JBQ2pCLGtCQUFrQjt3QkFDbEIsa0JBQWtCO3dCQUNsQixPQUFPO3dCQUNQLFNBQVM7d0JBQ1QsT0FBTztxQkFDVjs7MEJBZVksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7NENBUEgsV0FBVztzQkFBcEIsTUFBTTs7QUFzQ1gsTUFBTSxPQUFPLDRCQUE0QjsySEFBNUIsNEJBQTRCOzRIQUE1Qiw0QkFBNEIsaUJBN0M1QiwrQkFBK0IsYUFBL0IsK0JBQStCOzRIQTZDL0IsNEJBQTRCOzs0RkFBNUIsNEJBQTRCO2tCQVJ4QyxRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWiwrQkFBK0I7cUJBQ2hDO29CQUNELE9BQU8sRUFBRTt3QkFDUCwrQkFBK0I7cUJBQ2hDO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE9uSW5pdCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBTa2lwU2VsZixcbiAgICBPdXRwdXQsXG4gICAgRXZlbnRFbWl0dGVyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cblxuXG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhvRmlsZVVwbG9hZGVyT3B0aW9ucyB9IGZyb20gJy4vYmFzZS9maWxlLXVwbG9hZGVyLW9wdGlvbnMnO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhvLWZpbGUtdXBsb2FkZXItb3B0aW9ucycsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHN0eWxlczogWycnXSxcbiAgICBwcm92aWRlcnM6IFtOZXN0ZWRPcHRpb25Ib3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2Fib3J0VXBsb2FkJyxcbiAgICAgICAgJ2FjY2VwdCcsXG4gICAgICAgICdhY2Nlc3NLZXknLFxuICAgICAgICAnYWN0aXZlU3RhdGVFbmFibGVkJyxcbiAgICAgICAgJ2FsbG93Q2FuY2VsaW5nJyxcbiAgICAgICAgJ2FsbG93ZWRGaWxlRXh0ZW5zaW9ucycsXG4gICAgICAgICdjaHVua1NpemUnLFxuICAgICAgICAnZGlhbG9nVHJpZ2dlcicsXG4gICAgICAgICdkaXNhYmxlZCcsXG4gICAgICAgICdkcm9wWm9uZScsXG4gICAgICAgICdlbGVtZW50QXR0cicsXG4gICAgICAgICdmb2N1c1N0YXRlRW5hYmxlZCcsXG4gICAgICAgICdoZWlnaHQnLFxuICAgICAgICAnaGludCcsXG4gICAgICAgICdob3ZlclN0YXRlRW5hYmxlZCcsXG4gICAgICAgICdpbnB1dEF0dHInLFxuICAgICAgICAnaW52YWxpZEZpbGVFeHRlbnNpb25NZXNzYWdlJyxcbiAgICAgICAgJ2ludmFsaWRNYXhGaWxlU2l6ZU1lc3NhZ2UnLFxuICAgICAgICAnaW52YWxpZE1pbkZpbGVTaXplTWVzc2FnZScsXG4gICAgICAgICdpc0RpcnR5JyxcbiAgICAgICAgJ2lzVmFsaWQnLFxuICAgICAgICAnbGFiZWxUZXh0JyxcbiAgICAgICAgJ21heEZpbGVTaXplJyxcbiAgICAgICAgJ21pbkZpbGVTaXplJyxcbiAgICAgICAgJ211bHRpcGxlJyxcbiAgICAgICAgJ25hbWUnLFxuICAgICAgICAnb25CZWZvcmVTZW5kJyxcbiAgICAgICAgJ29uQ29udGVudFJlYWR5JyxcbiAgICAgICAgJ29uRGlzcG9zaW5nJyxcbiAgICAgICAgJ29uRHJvcFpvbmVFbnRlcicsXG4gICAgICAgICdvbkRyb3Bab25lTGVhdmUnLFxuICAgICAgICAnb25GaWxlc1VwbG9hZGVkJyxcbiAgICAgICAgJ29uSW5pdGlhbGl6ZWQnLFxuICAgICAgICAnb25PcHRpb25DaGFuZ2VkJyxcbiAgICAgICAgJ29uUHJvZ3Jlc3MnLFxuICAgICAgICAnb25VcGxvYWRBYm9ydGVkJyxcbiAgICAgICAgJ29uVXBsb2FkZWQnLFxuICAgICAgICAnb25VcGxvYWRFcnJvcicsXG4gICAgICAgICdvblVwbG9hZFN0YXJ0ZWQnLFxuICAgICAgICAnb25WYWx1ZUNoYW5nZWQnLFxuICAgICAgICAncHJvZ3Jlc3MnLFxuICAgICAgICAncmVhZE9ubHknLFxuICAgICAgICAncmVhZHlUb1VwbG9hZE1lc3NhZ2UnLFxuICAgICAgICAncnRsRW5hYmxlZCcsXG4gICAgICAgICdzZWxlY3RCdXR0b25UZXh0JyxcbiAgICAgICAgJ3Nob3dGaWxlTGlzdCcsXG4gICAgICAgICd0YWJJbmRleCcsXG4gICAgICAgICd1cGxvYWRBYm9ydGVkTWVzc2FnZScsXG4gICAgICAgICd1cGxvYWRCdXR0b25UZXh0JyxcbiAgICAgICAgJ3VwbG9hZENodW5rJyxcbiAgICAgICAgJ3VwbG9hZEN1c3RvbURhdGEnLFxuICAgICAgICAndXBsb2FkZWRNZXNzYWdlJyxcbiAgICAgICAgJ3VwbG9hZEZhaWxlZE1lc3NhZ2UnLFxuICAgICAgICAndXBsb2FkRmlsZScsXG4gICAgICAgICd1cGxvYWRIZWFkZXJzJyxcbiAgICAgICAgJ3VwbG9hZE1ldGhvZCcsXG4gICAgICAgICd1cGxvYWRNb2RlJyxcbiAgICAgICAgJ3VwbG9hZFVybCcsXG4gICAgICAgICd2YWxpZGF0aW9uRXJyb3InLFxuICAgICAgICAndmFsaWRhdGlvbkVycm9ycycsXG4gICAgICAgICd2YWxpZGF0aW9uU3RhdHVzJyxcbiAgICAgICAgJ3ZhbHVlJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAnd2lkdGgnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeG9GaWxlVXBsb2FkZXJPcHRpb25zQ29tcG9uZW50IGV4dGVuZHMgRHhvRmlsZVVwbG9hZGVyT3B0aW9ucyBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25Jbml0ICB7XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWx1ZUNoYW5nZTogRXZlbnRFbWl0dGVyPEFycmF5PGFueT4+O1xuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnZmlsZVVwbG9hZGVyT3B0aW9ucyc7XG4gICAgfVxuXG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcblxuICAgICAgICB0aGlzLl9jcmVhdGVFdmVudEVtaXR0ZXJzKFtcbiAgICAgICAgICAgIHsgZW1pdDogJ3ZhbHVlQ2hhbmdlJyB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9GaWxlVXBsb2FkZXJPcHRpb25zQ29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeG9GaWxlVXBsb2FkZXJPcHRpb25zQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4b0ZpbGVVcGxvYWRlck9wdGlvbnNNb2R1bGUgeyB9XG4iXX0=