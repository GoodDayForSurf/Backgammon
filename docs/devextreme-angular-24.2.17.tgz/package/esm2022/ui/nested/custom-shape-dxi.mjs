/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { Component, NgModule, Host, ElementRef, Renderer2, Inject, SkipSelf, Input, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { NestedOptionHost, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { CollectionNestedOption } from 'devextreme-angular/core';
import { DxiConnectionPointComponent } from './connection-point-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiCustomShapeComponent extends CollectionNestedOption {
    renderer;
    document;
    element;
    get allowEditImage() {
        return this._getOption('allowEditImage');
    }
    set allowEditImage(value) {
        this._setOption('allowEditImage', value);
    }
    get allowEditText() {
        return this._getOption('allowEditText');
    }
    set allowEditText(value) {
        this._setOption('allowEditText', value);
    }
    get allowResize() {
        return this._getOption('allowResize');
    }
    set allowResize(value) {
        this._setOption('allowResize', value);
    }
    get backgroundImageHeight() {
        return this._getOption('backgroundImageHeight');
    }
    set backgroundImageHeight(value) {
        this._setOption('backgroundImageHeight', value);
    }
    get backgroundImageLeft() {
        return this._getOption('backgroundImageLeft');
    }
    set backgroundImageLeft(value) {
        this._setOption('backgroundImageLeft', value);
    }
    get backgroundImageToolboxUrl() {
        return this._getOption('backgroundImageToolboxUrl');
    }
    set backgroundImageToolboxUrl(value) {
        this._setOption('backgroundImageToolboxUrl', value);
    }
    get backgroundImageTop() {
        return this._getOption('backgroundImageTop');
    }
    set backgroundImageTop(value) {
        this._setOption('backgroundImageTop', value);
    }
    get backgroundImageUrl() {
        return this._getOption('backgroundImageUrl');
    }
    set backgroundImageUrl(value) {
        this._setOption('backgroundImageUrl', value);
    }
    get backgroundImageWidth() {
        return this._getOption('backgroundImageWidth');
    }
    set backgroundImageWidth(value) {
        this._setOption('backgroundImageWidth', value);
    }
    get baseType() {
        return this._getOption('baseType');
    }
    set baseType(value) {
        this._setOption('baseType', value);
    }
    get category() {
        return this._getOption('category');
    }
    set category(value) {
        this._setOption('category', value);
    }
    get connectionPoints() {
        return this._getOption('connectionPoints');
    }
    set connectionPoints(value) {
        this._setOption('connectionPoints', value);
    }
    get defaultHeight() {
        return this._getOption('defaultHeight');
    }
    set defaultHeight(value) {
        this._setOption('defaultHeight', value);
    }
    get defaultImageUrl() {
        return this._getOption('defaultImageUrl');
    }
    set defaultImageUrl(value) {
        this._setOption('defaultImageUrl', value);
    }
    get defaultText() {
        return this._getOption('defaultText');
    }
    set defaultText(value) {
        this._setOption('defaultText', value);
    }
    get defaultWidth() {
        return this._getOption('defaultWidth');
    }
    set defaultWidth(value) {
        this._setOption('defaultWidth', value);
    }
    get imageHeight() {
        return this._getOption('imageHeight');
    }
    set imageHeight(value) {
        this._setOption('imageHeight', value);
    }
    get imageLeft() {
        return this._getOption('imageLeft');
    }
    set imageLeft(value) {
        this._setOption('imageLeft', value);
    }
    get imageTop() {
        return this._getOption('imageTop');
    }
    set imageTop(value) {
        this._setOption('imageTop', value);
    }
    get imageWidth() {
        return this._getOption('imageWidth');
    }
    set imageWidth(value) {
        this._setOption('imageWidth', value);
    }
    get keepRatioOnAutoSize() {
        return this._getOption('keepRatioOnAutoSize');
    }
    set keepRatioOnAutoSize(value) {
        this._setOption('keepRatioOnAutoSize', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get templateHeight() {
        return this._getOption('templateHeight');
    }
    set templateHeight(value) {
        this._setOption('templateHeight', value);
    }
    get templateLeft() {
        return this._getOption('templateLeft');
    }
    set templateLeft(value) {
        this._setOption('templateLeft', value);
    }
    get templateTop() {
        return this._getOption('templateTop');
    }
    set templateTop(value) {
        this._setOption('templateTop', value);
    }
    get templateWidth() {
        return this._getOption('templateWidth');
    }
    set templateWidth(value) {
        this._setOption('templateWidth', value);
    }
    get textHeight() {
        return this._getOption('textHeight');
    }
    set textHeight(value) {
        this._setOption('textHeight', value);
    }
    get textLeft() {
        return this._getOption('textLeft');
    }
    set textLeft(value) {
        this._setOption('textLeft', value);
    }
    get textTop() {
        return this._getOption('textTop');
    }
    set textTop(value) {
        this._setOption('textTop', value);
    }
    get textWidth() {
        return this._getOption('textWidth');
    }
    set textWidth(value) {
        this._setOption('textWidth', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get toolboxTemplate() {
        return this._getOption('toolboxTemplate');
    }
    set toolboxTemplate(value) {
        this._setOption('toolboxTemplate', value);
    }
    get toolboxWidthToHeightRatio() {
        return this._getOption('toolboxWidthToHeightRatio');
    }
    set toolboxWidthToHeightRatio(value) {
        this._setOption('toolboxWidthToHeightRatio', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'customShapes';
    }
    get connectionPointsChildren() {
        return this._getOption('connectionPoints');
    }
    set connectionPointsChildren(value) {
        this.setChildren('connectionPoints', value);
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiCustomShapeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiCustomShapeComponent, selector: "dxi-custom-shape", inputs: { allowEditImage: "allowEditImage", allowEditText: "allowEditText", allowResize: "allowResize", backgroundImageHeight: "backgroundImageHeight", backgroundImageLeft: "backgroundImageLeft", backgroundImageToolboxUrl: "backgroundImageToolboxUrl", backgroundImageTop: "backgroundImageTop", backgroundImageUrl: "backgroundImageUrl", backgroundImageWidth: "backgroundImageWidth", baseType: "baseType", category: "category", connectionPoints: "connectionPoints", defaultHeight: "defaultHeight", defaultImageUrl: "defaultImageUrl", defaultText: "defaultText", defaultWidth: "defaultWidth", imageHeight: "imageHeight", imageLeft: "imageLeft", imageTop: "imageTop", imageWidth: "imageWidth", keepRatioOnAutoSize: "keepRatioOnAutoSize", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", template: "template", templateHeight: "templateHeight", templateLeft: "templateLeft", templateTop: "templateTop", templateWidth: "templateWidth", textHeight: "textHeight", textLeft: "textLeft", textTop: "textTop", textWidth: "textWidth", title: "title", toolboxTemplate: "toolboxTemplate", toolboxWidthToHeightRatio: "toolboxWidthToHeightRatio", type: "type" }, providers: [NestedOptionHost, DxTemplateHost], queries: [{ propertyName: "connectionPointsChildren", predicate: i0.forwardRef(function () { return DxiConnectionPointComponent; }) }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiCustomShapeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-custom-shape', template: '<ng-content></ng-content>', providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }]; }, propDecorators: { allowEditImage: [{
                type: Input
            }], allowEditText: [{
                type: Input
            }], allowResize: [{
                type: Input
            }], backgroundImageHeight: [{
                type: Input
            }], backgroundImageLeft: [{
                type: Input
            }], backgroundImageToolboxUrl: [{
                type: Input
            }], backgroundImageTop: [{
                type: Input
            }], backgroundImageUrl: [{
                type: Input
            }], backgroundImageWidth: [{
                type: Input
            }], baseType: [{
                type: Input
            }], category: [{
                type: Input
            }], connectionPoints: [{
                type: Input
            }], defaultHeight: [{
                type: Input
            }], defaultImageUrl: [{
                type: Input
            }], defaultText: [{
                type: Input
            }], defaultWidth: [{
                type: Input
            }], imageHeight: [{
                type: Input
            }], imageLeft: [{
                type: Input
            }], imageTop: [{
                type: Input
            }], imageWidth: [{
                type: Input
            }], keepRatioOnAutoSize: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], template: [{
                type: Input
            }], templateHeight: [{
                type: Input
            }], templateLeft: [{
                type: Input
            }], templateTop: [{
                type: Input
            }], templateWidth: [{
                type: Input
            }], textHeight: [{
                type: Input
            }], textLeft: [{
                type: Input
            }], textTop: [{
                type: Input
            }], textWidth: [{
                type: Input
            }], title: [{
                type: Input
            }], toolboxTemplate: [{
                type: Input
            }], toolboxWidthToHeightRatio: [{
                type: Input
            }], type: [{
                type: Input
            }], connectionPointsChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiConnectionPointComponent)]
            }] } });
export class DxiCustomShapeModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiCustomShapeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiCustomShapeModule, declarations: [DxiCustomShapeComponent], exports: [DxiCustomShapeComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiCustomShapeModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiCustomShapeModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiCustomShapeComponent
                    ],
                    exports: [
                        DxiCustomShapeComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tLXNoYXBlLWR4aS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2N1c3RvbS1zaGFwZS1keGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUNILFNBQVMsRUFDVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFVBQVUsRUFDVixTQUFTLEVBQ1QsTUFBTSxFQUVOLFFBQVEsRUFDUixLQUFLLEVBQ0wsZUFBZSxFQUNmLFVBQVUsRUFDVixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBSzNDLE9BQU8sRUFDSCxnQkFBZ0IsRUFDaEIsZUFBZSxFQUdmLGNBQWMsRUFDakIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUNqRSxPQUFPLEVBQUUsMkJBQTJCLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQzs7O0FBU3JFLE1BQU0sT0FBTyx1QkFBd0IsU0FBUSxzQkFBc0I7SUFrVS9DO0lBQ2tCO0lBRWxCO0lBblVoQixJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBYztRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRCxJQUNJLGFBQWE7UUFDYixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksYUFBYSxDQUFDLEtBQWM7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBYztRQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsSUFDSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBYTtRQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxJQUNJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBSSxtQkFBbUIsQ0FBQyxLQUFhO1FBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELElBQ0kseUJBQXlCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFJLHlCQUF5QixDQUFDLEtBQWE7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRUQsSUFDSSxrQkFBa0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDakQsQ0FBQztJQUNELElBQUksa0JBQWtCLENBQUMsS0FBYTtRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFRCxJQUNJLGtCQUFrQjtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsSUFBSSxrQkFBa0IsQ0FBQyxLQUFhO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVELElBQ0ksb0JBQW9CO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxJQUFJLG9CQUFvQixDQUFDLEtBQWE7UUFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUF5QjtRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUNJLGdCQUFnQjtRQUNoQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBQ0QsSUFBSSxnQkFBZ0IsQ0FBQyxLQUE4QztRQUMvRCxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUNJLGFBQWE7UUFDYixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksYUFBYSxDQUFDLEtBQWE7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQ0ksZUFBZTtRQUNmLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFDRCxJQUFJLGVBQWUsQ0FBQyxLQUFhO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBYTtRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsSUFDSSxZQUFZO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxLQUFhO1FBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRCxJQUNJLFdBQVc7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNELElBQUksV0FBVyxDQUFDLEtBQWE7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBYTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWE7UUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUVELElBQ0ksbUJBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFJLG1CQUFtQixDQUFDLEtBQWM7UUFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFhO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWE7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBYTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQVU7UUFDbkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFhO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBYTtRQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFRCxJQUNJLGFBQWE7UUFDYixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksYUFBYSxDQUFDLEtBQWE7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYTtRQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBRUQsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWE7UUFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBYTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFhO1FBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBVTtRQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRCxJQUNJLHlCQUF5QjtRQUN6QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBSSx5QkFBeUIsQ0FBQyxLQUFhO1FBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0QsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFHRCxJQUNJLHdCQUF3QjtRQUN4QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBQ0QsSUFBSSx3QkFBd0IsQ0FBQyxLQUFLO1FBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QixFQUM1QixRQUFtQixFQUNELFFBQWEsRUFDL0IsWUFBNEIsRUFDNUIsT0FBbUI7UUFDL0IsS0FBSyxFQUFFLENBQUM7UUFKSSxhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ0QsYUFBUSxHQUFSLFFBQVEsQ0FBSztRQUUvQixZQUFPLEdBQVAsT0FBTyxDQUFZO1FBRS9CLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzFELFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELFdBQVcsQ0FBQyxRQUE2QjtRQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUM3QixDQUFDO0lBQ0QsZUFBZTtRQUNYLGVBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBSUQsV0FBVztRQUNQLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDOzJIQXZWUSx1QkFBdUIsbUpBbVVoQixRQUFROytHQW5VZix1QkFBdUIsK3NDQUZyQixDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxzR0EwVFgsMkJBQTJCLHdEQTVUbkQsMkJBQTJCOzs0RkFJNUIsdUJBQXVCO2tCQU5uQyxTQUFTOytCQUNJLGtCQUFrQixZQUNsQiwyQkFBMkIsYUFFMUIsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUM7OzBCQWtVaEMsUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7OzBCQUVKLE1BQU07MkJBQUMsUUFBUTs7MEJBQ2YsSUFBSTtxRUFqVVQsY0FBYztzQkFEakIsS0FBSztnQkFTRixhQUFhO3NCQURoQixLQUFLO2dCQVNGLFdBQVc7c0JBRGQsS0FBSztnQkFTRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBU0YsbUJBQW1CO3NCQUR0QixLQUFLO2dCQVNGLHlCQUF5QjtzQkFENUIsS0FBSztnQkFTRixrQkFBa0I7c0JBRHJCLEtBQUs7Z0JBU0Ysa0JBQWtCO3NCQURyQixLQUFLO2dCQVNGLG9CQUFvQjtzQkFEdkIsS0FBSztnQkFTRixRQUFRO3NCQURYLEtBQUs7Z0JBU0YsUUFBUTtzQkFEWCxLQUFLO2dCQVNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFTRixhQUFhO3NCQURoQixLQUFLO2dCQVNGLGVBQWU7c0JBRGxCLEtBQUs7Z0JBU0YsV0FBVztzQkFEZCxLQUFLO2dCQVNGLFlBQVk7c0JBRGYsS0FBSztnQkFTRixXQUFXO3NCQURkLEtBQUs7Z0JBU0YsU0FBUztzQkFEWixLQUFLO2dCQVNGLFFBQVE7c0JBRFgsS0FBSztnQkFTRixVQUFVO3NCQURiLEtBQUs7Z0JBU0YsbUJBQW1CO3NCQUR0QixLQUFLO2dCQVNGLFNBQVM7c0JBRFosS0FBSztnQkFTRixRQUFRO3NCQURYLEtBQUs7Z0JBU0YsU0FBUztzQkFEWixLQUFLO2dCQVNGLFFBQVE7c0JBRFgsS0FBSztnQkFTRixRQUFRO3NCQURYLEtBQUs7Z0JBU0YsY0FBYztzQkFEakIsS0FBSztnQkFTRixZQUFZO3NCQURmLEtBQUs7Z0JBU0YsV0FBVztzQkFEZCxLQUFLO2dCQVNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBU0YsVUFBVTtzQkFEYixLQUFLO2dCQVNGLFFBQVE7c0JBRFgsS0FBSztnQkFTRixPQUFPO3NCQURWLEtBQUs7Z0JBU0YsU0FBUztzQkFEWixLQUFLO2dCQVNGLEtBQUs7c0JBRFIsS0FBSztnQkFTRixlQUFlO3NCQURsQixLQUFLO2dCQVNGLHlCQUF5QjtzQkFENUIsS0FBSztnQkFTRixJQUFJO3NCQURQLEtBQUs7Z0JBZUYsd0JBQXdCO3NCQUQzQixlQUFlO3VCQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQywyQkFBMkIsQ0FBQzs7QUEyQ2xFLE1BQU0sT0FBTyxvQkFBb0I7MkhBQXBCLG9CQUFvQjs0SEFBcEIsb0JBQW9CLGlCQW5XcEIsdUJBQXVCLGFBQXZCLHVCQUF1Qjs0SEFtV3ZCLG9CQUFvQjs7NEZBQXBCLG9CQUFvQjtrQkFSaEMsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osdUJBQXVCO3FCQUN4QjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsdUJBQXVCO3FCQUN4QjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuXG5pbXBvcnQge1xuICAgIENvbXBvbmVudCxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIEVsZW1lbnRSZWYsXG4gICAgUmVuZGVyZXIyLFxuICAgIEluamVjdCxcbiAgICBBZnRlclZpZXdJbml0LFxuICAgIFNraXBTZWxmLFxuICAgIElucHV0LFxuICAgIENvbnRlbnRDaGlsZHJlbixcbiAgICBmb3J3YXJkUmVmLFxuICAgIFF1ZXJ5TGlzdFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuXG5cbmltcG9ydCB7IFNoYXBlVHlwZSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvZGlhZ3JhbSc7XG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICBleHRyYWN0VGVtcGxhdGUsXG4gICAgRHhUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJRHhUZW1wbGF0ZUhvc3QsXG4gICAgRHhUZW1wbGF0ZUhvc3Rcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29sbGVjdGlvbk5lc3RlZE9wdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IER4aUNvbm5lY3Rpb25Qb2ludENvbXBvbmVudCB9IGZyb20gJy4vY29ubmVjdGlvbi1wb2ludC1keGknO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhpLWN1c3RvbS1zaGFwZScsXG4gICAgdGVtcGxhdGU6ICc8bmctY29udGVudD48L25nLWNvbnRlbnQ+JyxcbiAgICBzdHlsZXM6IFsnOmhvc3QgeyBkaXNwbGF5OiBibG9jazsgfSddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3QsIER4VGVtcGxhdGVIb3N0XVxufSlcbmV4cG9ydCBjbGFzcyBEeGlDdXN0b21TaGFwZUNvbXBvbmVudCBleHRlbmRzIENvbGxlY3Rpb25OZXN0ZWRPcHRpb24gaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LFxuICAgIElEeFRlbXBsYXRlSG9zdCB7XG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dFZGl0SW1hZ2UoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93RWRpdEltYWdlJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd0VkaXRJbWFnZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93RWRpdEltYWdlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93RWRpdFRleHQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93RWRpdFRleHQnKTtcbiAgICB9XG4gICAgc2V0IGFsbG93RWRpdFRleHQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd0VkaXRUZXh0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93UmVzaXplKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd1Jlc2l6ZScpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dSZXNpemUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd1Jlc2l6ZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBiYWNrZ3JvdW5kSW1hZ2VIZWlnaHQoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYmFja2dyb3VuZEltYWdlSGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCBiYWNrZ3JvdW5kSW1hZ2VIZWlnaHQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JhY2tncm91bmRJbWFnZUhlaWdodCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBiYWNrZ3JvdW5kSW1hZ2VMZWZ0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2JhY2tncm91bmRJbWFnZUxlZnQnKTtcbiAgICB9XG4gICAgc2V0IGJhY2tncm91bmRJbWFnZUxlZnQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JhY2tncm91bmRJbWFnZUxlZnQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYmFja2dyb3VuZEltYWdlVG9vbGJveFVybCgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdiYWNrZ3JvdW5kSW1hZ2VUb29sYm94VXJsJyk7XG4gICAgfVxuICAgIHNldCBiYWNrZ3JvdW5kSW1hZ2VUb29sYm94VXJsKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdiYWNrZ3JvdW5kSW1hZ2VUb29sYm94VXJsJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGJhY2tncm91bmRJbWFnZVRvcCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdiYWNrZ3JvdW5kSW1hZ2VUb3AnKTtcbiAgICB9XG4gICAgc2V0IGJhY2tncm91bmRJbWFnZVRvcCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmFja2dyb3VuZEltYWdlVG9wJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGJhY2tncm91bmRJbWFnZVVybCgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdiYWNrZ3JvdW5kSW1hZ2VVcmwnKTtcbiAgICB9XG4gICAgc2V0IGJhY2tncm91bmRJbWFnZVVybCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmFja2dyb3VuZEltYWdlVXJsJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGJhY2tncm91bmRJbWFnZVdpZHRoKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2JhY2tncm91bmRJbWFnZVdpZHRoJyk7XG4gICAgfVxuICAgIHNldCBiYWNrZ3JvdW5kSW1hZ2VXaWR0aCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmFja2dyb3VuZEltYWdlV2lkdGgnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYmFzZVR5cGUoKTogU2hhcGVUeXBlIHwgc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYmFzZVR5cGUnKTtcbiAgICB9XG4gICAgc2V0IGJhc2VUeXBlKHZhbHVlOiBTaGFwZVR5cGUgfCBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdiYXNlVHlwZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBjYXRlZ29yeSgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjYXRlZ29yeScpO1xuICAgIH1cbiAgICBzZXQgY2F0ZWdvcnkodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NhdGVnb3J5JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGNvbm5lY3Rpb25Qb2ludHMoKTogQXJyYXk8YW55IHwgeyB4PzogbnVtYmVyLCB5PzogbnVtYmVyIH0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29ubmVjdGlvblBvaW50cycpO1xuICAgIH1cbiAgICBzZXQgY29ubmVjdGlvblBvaW50cyh2YWx1ZTogQXJyYXk8YW55IHwgeyB4PzogbnVtYmVyLCB5PzogbnVtYmVyIH0+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY29ubmVjdGlvblBvaW50cycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBkZWZhdWx0SGVpZ2h0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2RlZmF1bHRIZWlnaHQnKTtcbiAgICB9XG4gICAgc2V0IGRlZmF1bHRIZWlnaHQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2RlZmF1bHRIZWlnaHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgZGVmYXVsdEltYWdlVXJsKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2RlZmF1bHRJbWFnZVVybCcpO1xuICAgIH1cbiAgICBzZXQgZGVmYXVsdEltYWdlVXJsKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkZWZhdWx0SW1hZ2VVcmwnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgZGVmYXVsdFRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGVmYXVsdFRleHQnKTtcbiAgICB9XG4gICAgc2V0IGRlZmF1bHRUZXh0KHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkZWZhdWx0VGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBkZWZhdWx0V2lkdGgoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGVmYXVsdFdpZHRoJyk7XG4gICAgfVxuICAgIHNldCBkZWZhdWx0V2lkdGgodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2RlZmF1bHRXaWR0aCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBpbWFnZUhlaWdodCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpbWFnZUhlaWdodCcpO1xuICAgIH1cbiAgICBzZXQgaW1hZ2VIZWlnaHQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2ltYWdlSGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGltYWdlTGVmdCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpbWFnZUxlZnQnKTtcbiAgICB9XG4gICAgc2V0IGltYWdlTGVmdCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaW1hZ2VMZWZ0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGltYWdlVG9wKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2ltYWdlVG9wJyk7XG4gICAgfVxuICAgIHNldCBpbWFnZVRvcCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaW1hZ2VUb3AnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgaW1hZ2VXaWR0aCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpbWFnZVdpZHRoJyk7XG4gICAgfVxuICAgIHNldCBpbWFnZVdpZHRoKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpbWFnZVdpZHRoJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGtlZXBSYXRpb09uQXV0b1NpemUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2tlZXBSYXRpb09uQXV0b1NpemUnKTtcbiAgICB9XG4gICAgc2V0IGtlZXBSYXRpb09uQXV0b1NpemUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdrZWVwUmF0aW9PbkF1dG9TaXplJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG1heEhlaWdodCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtYXhIZWlnaHQnKTtcbiAgICB9XG4gICAgc2V0IG1heEhlaWdodCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbWF4SGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG1heFdpZHRoKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21heFdpZHRoJyk7XG4gICAgfVxuICAgIHNldCBtYXhXaWR0aCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbWF4V2lkdGgnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgbWluSGVpZ2h0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21pbkhlaWdodCcpO1xuICAgIH1cbiAgICBzZXQgbWluSGVpZ2h0KHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdtaW5IZWlnaHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgbWluV2lkdGgoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbWluV2lkdGgnKTtcbiAgICB9XG4gICAgc2V0IG1pbldpZHRoKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdtaW5XaWR0aCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCB0ZW1wbGF0ZSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0ZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgdGVtcGxhdGUodmFsdWU6IGFueSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RlbXBsYXRlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRlbXBsYXRlSGVpZ2h0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RlbXBsYXRlSGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCB0ZW1wbGF0ZUhlaWdodCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGVtcGxhdGVIZWlnaHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdGVtcGxhdGVMZWZ0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RlbXBsYXRlTGVmdCcpO1xuICAgIH1cbiAgICBzZXQgdGVtcGxhdGVMZWZ0KHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0ZW1wbGF0ZUxlZnQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdGVtcGxhdGVUb3AoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGVtcGxhdGVUb3AnKTtcbiAgICB9XG4gICAgc2V0IHRlbXBsYXRlVG9wKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0ZW1wbGF0ZVRvcCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCB0ZW1wbGF0ZVdpZHRoKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RlbXBsYXRlV2lkdGgnKTtcbiAgICB9XG4gICAgc2V0IHRlbXBsYXRlV2lkdGgodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RlbXBsYXRlV2lkdGgnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdGV4dEhlaWdodCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0ZXh0SGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCB0ZXh0SGVpZ2h0KHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0ZXh0SGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRleHRMZWZ0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RleHRMZWZ0Jyk7XG4gICAgfVxuICAgIHNldCB0ZXh0TGVmdCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGV4dExlZnQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdGV4dFRvcCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0ZXh0VG9wJyk7XG4gICAgfVxuICAgIHNldCB0ZXh0VG9wKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0ZXh0VG9wJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRleHRXaWR0aCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0ZXh0V2lkdGgnKTtcbiAgICB9XG4gICAgc2V0IHRleHRXaWR0aCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGV4dFdpZHRoJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRpdGxlKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RpdGxlJyk7XG4gICAgfVxuICAgIHNldCB0aXRsZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGl0bGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdG9vbGJveFRlbXBsYXRlKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Rvb2xib3hUZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgdG9vbGJveFRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0b29sYm94VGVtcGxhdGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdG9vbGJveFdpZHRoVG9IZWlnaHRSYXRpbygpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0b29sYm94V2lkdGhUb0hlaWdodFJhdGlvJyk7XG4gICAgfVxuICAgIHNldCB0b29sYm94V2lkdGhUb0hlaWdodFJhdGlvKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0b29sYm94V2lkdGhUb0hlaWdodFJhdGlvJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHR5cGUoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndHlwZScpO1xuICAgIH1cbiAgICBzZXQgdHlwZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndHlwZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnY3VzdG9tU2hhcGVzJztcbiAgICB9XG5cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oZm9yd2FyZFJlZigoKSA9PiBEeGlDb25uZWN0aW9uUG9pbnRDb21wb25lbnQpKVxuICAgIGdldCBjb25uZWN0aW9uUG9pbnRzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUNvbm5lY3Rpb25Qb2ludENvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjb25uZWN0aW9uUG9pbnRzJyk7XG4gICAgfVxuICAgIHNldCBjb25uZWN0aW9uUG9pbnRzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignY29ubmVjdGlvblBvaW50cycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgICAgICAgICBASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBhbnksXG4gICAgICAgICAgICBASG9zdCgpIHRlbXBsYXRlSG9zdDogRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIGVsZW1lbnQ6IEVsZW1lbnRSZWYpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGVtcGxhdGVIb3N0LnNldEhvc3QodGhpcyk7XG4gICAgfVxuXG4gICAgc2V0VGVtcGxhdGUodGVtcGxhdGU6IER4VGVtcGxhdGVEaXJlY3RpdmUpIHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZSA9IHRlbXBsYXRlO1xuICAgIH1cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIGV4dHJhY3RUZW1wbGF0ZSh0aGlzLCB0aGlzLmVsZW1lbnQsIHRoaXMucmVuZGVyZXIsIHRoaXMuZG9jdW1lbnQpO1xuICAgIH1cblxuXG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fZGVsZXRlUmVtb3ZlZE9wdGlvbnModGhpcy5fZnVsbE9wdGlvblBhdGgoKSk7XG4gICAgfVxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4aUN1c3RvbVNoYXBlQ29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeGlDdXN0b21TaGFwZUNvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeGlDdXN0b21TaGFwZU1vZHVsZSB7IH1cbiJdfQ==