/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoChartCommonSeriesSettings } from './base/chart-common-series-settings';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoBubbleComponent extends DxoChartCommonSeriesSettings {
    get _optionPath() {
        return 'bubble';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoBubbleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoBubbleComponent, selector: "dxo-bubble", inputs: { aggregation: "aggregation", area: "area", argumentField: "argumentField", axis: "axis", bar: "bar", barOverlapGroup: "barOverlapGroup", barPadding: "barPadding", barWidth: "barWidth", border: "border", bubble: "bubble", candlestick: "candlestick", closeValueField: "closeValueField", color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", fullstackedarea: "fullstackedarea", fullstackedbar: "fullstackedbar", fullstackedline: "fullstackedline", fullstackedspline: "fullstackedspline", fullstackedsplinearea: "fullstackedsplinearea", highValueField: "highValueField", hoverMode: "hoverMode", hoverStyle: "hoverStyle", ignoreEmptyPoints: "ignoreEmptyPoints", innerColor: "innerColor", label: "label", line: "line", lowValueField: "lowValueField", maxLabelCount: "maxLabelCount", minBarSize: "minBarSize", opacity: "opacity", openValueField: "openValueField", pane: "pane", point: "point", rangearea: "rangearea", rangebar: "rangebar", rangeValue1Field: "rangeValue1Field", rangeValue2Field: "rangeValue2Field", reduction: "reduction", scatter: "scatter", selectionMode: "selectionMode", selectionStyle: "selectionStyle", showInLegend: "showInLegend", sizeField: "sizeField", spline: "spline", splinearea: "splinearea", stack: "stack", stackedarea: "stackedarea", stackedbar: "stackedbar", stackedline: "stackedline", stackedspline: "stackedspline", stackedsplinearea: "stackedsplinearea", steparea: "steparea", stepline: "stepline", stock: "stock", tagField: "tagField", type: "type", valueErrorBar: "valueErrorBar", valueField: "valueField", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoBubbleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-bubble', template: '', providers: [NestedOptionHost], inputs: [
                        'aggregation',
                        'area',
                        'argumentField',
                        'axis',
                        'bar',
                        'barOverlapGroup',
                        'barPadding',
                        'barWidth',
                        'border',
                        'bubble',
                        'candlestick',
                        'closeValueField',
                        'color',
                        'cornerRadius',
                        'dashStyle',
                        'fullstackedarea',
                        'fullstackedbar',
                        'fullstackedline',
                        'fullstackedspline',
                        'fullstackedsplinearea',
                        'highValueField',
                        'hoverMode',
                        'hoverStyle',
                        'ignoreEmptyPoints',
                        'innerColor',
                        'label',
                        'line',
                        'lowValueField',
                        'maxLabelCount',
                        'minBarSize',
                        'opacity',
                        'openValueField',
                        'pane',
                        'point',
                        'rangearea',
                        'rangebar',
                        'rangeValue1Field',
                        'rangeValue2Field',
                        'reduction',
                        'scatter',
                        'selectionMode',
                        'selectionStyle',
                        'showInLegend',
                        'sizeField',
                        'spline',
                        'splinearea',
                        'stack',
                        'stackedarea',
                        'stackedbar',
                        'stackedline',
                        'stackedspline',
                        'stackedsplinearea',
                        'steparea',
                        'stepline',
                        'stock',
                        'tagField',
                        'type',
                        'valueErrorBar',
                        'valueField',
                        'visible',
                        'width'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoBubbleModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoBubbleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoBubbleModule, declarations: [DxoBubbleComponent], exports: [DxoBubbleComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoBubbleModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoBubbleModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoBubbleComponent
                    ],
                    exports: [
                        DxoBubbleComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnViYmxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvYnViYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUdULFFBQVEsRUFDUixJQUFJLEVBQ0osUUFBUSxFQUNYLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsNEJBQTRCLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQzs7O0FBd0VuRixNQUFNLE9BQU8sa0JBQW1CLFNBQVEsNEJBQTRCO0lBRWhFLElBQWMsV0FBVztRQUNyQixPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBR0QsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBQ1IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUdELFFBQVE7UUFDSixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDOzJIQXJCUSxrQkFBa0I7K0dBQWxCLGtCQUFrQix5bURBakVoQixDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkFtRUgsa0JBQWtCO2tCQXJFOUIsU0FBUzsrQkFDSSxZQUFZLFlBQ1osRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUMsVUFDckI7d0JBQ0osYUFBYTt3QkFDYixNQUFNO3dCQUNOLGVBQWU7d0JBQ2YsTUFBTTt3QkFDTixLQUFLO3dCQUNMLGlCQUFpQjt3QkFDakIsWUFBWTt3QkFDWixVQUFVO3dCQUNWLFFBQVE7d0JBQ1IsUUFBUTt3QkFDUixhQUFhO3dCQUNiLGlCQUFpQjt3QkFDakIsT0FBTzt3QkFDUCxjQUFjO3dCQUNkLFdBQVc7d0JBQ1gsaUJBQWlCO3dCQUNqQixnQkFBZ0I7d0JBQ2hCLGlCQUFpQjt3QkFDakIsbUJBQW1CO3dCQUNuQix1QkFBdUI7d0JBQ3ZCLGdCQUFnQjt3QkFDaEIsV0FBVzt3QkFDWCxZQUFZO3dCQUNaLG1CQUFtQjt3QkFDbkIsWUFBWTt3QkFDWixPQUFPO3dCQUNQLE1BQU07d0JBQ04sZUFBZTt3QkFDZixlQUFlO3dCQUNmLFlBQVk7d0JBQ1osU0FBUzt3QkFDVCxnQkFBZ0I7d0JBQ2hCLE1BQU07d0JBQ04sT0FBTzt3QkFDUCxXQUFXO3dCQUNYLFVBQVU7d0JBQ1Ysa0JBQWtCO3dCQUNsQixrQkFBa0I7d0JBQ2xCLFdBQVc7d0JBQ1gsU0FBUzt3QkFDVCxlQUFlO3dCQUNmLGdCQUFnQjt3QkFDaEIsY0FBYzt3QkFDZCxXQUFXO3dCQUNYLFFBQVE7d0JBQ1IsWUFBWTt3QkFDWixPQUFPO3dCQUNQLGFBQWE7d0JBQ2IsWUFBWTt3QkFDWixhQUFhO3dCQUNiLGVBQWU7d0JBQ2YsbUJBQW1CO3dCQUNuQixVQUFVO3dCQUNWLFVBQVU7d0JBQ1YsT0FBTzt3QkFDUCxVQUFVO3dCQUNWLE1BQU07d0JBQ04sZUFBZTt3QkFDZixZQUFZO3dCQUNaLFNBQVM7d0JBQ1QsT0FBTztxQkFDVjs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBMEJqQixNQUFNLE9BQU8sZUFBZTsySEFBZixlQUFlOzRIQUFmLGVBQWUsaUJBbENmLGtCQUFrQixhQUFsQixrQkFBa0I7NEhBa0NsQixlQUFlOzs0RkFBZixlQUFlO2tCQVIzQixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWixrQkFBa0I7cUJBQ25CO29CQUNELE9BQU8sRUFBRTt3QkFDUCxrQkFBa0I7cUJBQ25CO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE9uSW5pdCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBTa2lwU2VsZlxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG5cblxuXG5pbXBvcnQge1xuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IER4b0NoYXJ0Q29tbW9uU2VyaWVzU2V0dGluZ3MgfSBmcm9tICcuL2Jhc2UvY2hhcnQtY29tbW9uLXNlcmllcy1zZXR0aW5ncyc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeG8tYnViYmxlJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnYWdncmVnYXRpb24nLFxuICAgICAgICAnYXJlYScsXG4gICAgICAgICdhcmd1bWVudEZpZWxkJyxcbiAgICAgICAgJ2F4aXMnLFxuICAgICAgICAnYmFyJyxcbiAgICAgICAgJ2Jhck92ZXJsYXBHcm91cCcsXG4gICAgICAgICdiYXJQYWRkaW5nJyxcbiAgICAgICAgJ2JhcldpZHRoJyxcbiAgICAgICAgJ2JvcmRlcicsXG4gICAgICAgICdidWJibGUnLFxuICAgICAgICAnY2FuZGxlc3RpY2snLFxuICAgICAgICAnY2xvc2VWYWx1ZUZpZWxkJyxcbiAgICAgICAgJ2NvbG9yJyxcbiAgICAgICAgJ2Nvcm5lclJhZGl1cycsXG4gICAgICAgICdkYXNoU3R5bGUnLFxuICAgICAgICAnZnVsbHN0YWNrZWRhcmVhJyxcbiAgICAgICAgJ2Z1bGxzdGFja2VkYmFyJyxcbiAgICAgICAgJ2Z1bGxzdGFja2VkbGluZScsXG4gICAgICAgICdmdWxsc3RhY2tlZHNwbGluZScsXG4gICAgICAgICdmdWxsc3RhY2tlZHNwbGluZWFyZWEnLFxuICAgICAgICAnaGlnaFZhbHVlRmllbGQnLFxuICAgICAgICAnaG92ZXJNb2RlJyxcbiAgICAgICAgJ2hvdmVyU3R5bGUnLFxuICAgICAgICAnaWdub3JlRW1wdHlQb2ludHMnLFxuICAgICAgICAnaW5uZXJDb2xvcicsXG4gICAgICAgICdsYWJlbCcsXG4gICAgICAgICdsaW5lJyxcbiAgICAgICAgJ2xvd1ZhbHVlRmllbGQnLFxuICAgICAgICAnbWF4TGFiZWxDb3VudCcsXG4gICAgICAgICdtaW5CYXJTaXplJyxcbiAgICAgICAgJ29wYWNpdHknLFxuICAgICAgICAnb3BlblZhbHVlRmllbGQnLFxuICAgICAgICAncGFuZScsXG4gICAgICAgICdwb2ludCcsXG4gICAgICAgICdyYW5nZWFyZWEnLFxuICAgICAgICAncmFuZ2ViYXInLFxuICAgICAgICAncmFuZ2VWYWx1ZTFGaWVsZCcsXG4gICAgICAgICdyYW5nZVZhbHVlMkZpZWxkJyxcbiAgICAgICAgJ3JlZHVjdGlvbicsXG4gICAgICAgICdzY2F0dGVyJyxcbiAgICAgICAgJ3NlbGVjdGlvbk1vZGUnLFxuICAgICAgICAnc2VsZWN0aW9uU3R5bGUnLFxuICAgICAgICAnc2hvd0luTGVnZW5kJyxcbiAgICAgICAgJ3NpemVGaWVsZCcsXG4gICAgICAgICdzcGxpbmUnLFxuICAgICAgICAnc3BsaW5lYXJlYScsXG4gICAgICAgICdzdGFjaycsXG4gICAgICAgICdzdGFja2VkYXJlYScsXG4gICAgICAgICdzdGFja2VkYmFyJyxcbiAgICAgICAgJ3N0YWNrZWRsaW5lJyxcbiAgICAgICAgJ3N0YWNrZWRzcGxpbmUnLFxuICAgICAgICAnc3RhY2tlZHNwbGluZWFyZWEnLFxuICAgICAgICAnc3RlcGFyZWEnLFxuICAgICAgICAnc3RlcGxpbmUnLFxuICAgICAgICAnc3RvY2snLFxuICAgICAgICAndGFnRmllbGQnLFxuICAgICAgICAndHlwZScsXG4gICAgICAgICd2YWx1ZUVycm9yQmFyJyxcbiAgICAgICAgJ3ZhbHVlRmllbGQnLFxuICAgICAgICAndmlzaWJsZScsXG4gICAgICAgICd3aWR0aCdcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4b0J1YmJsZUNvbXBvbmVudCBleHRlbmRzIER4b0NoYXJ0Q29tbW9uU2VyaWVzU2V0dGluZ3MgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uSW5pdCAge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdidWJibGUnO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9CdWJibGVDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4b0J1YmJsZUNvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9CdWJibGVNb2R1bGUgeyB9XG4iXX0=