/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { Component, NgModule, Host, SkipSelf, Input } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { NestedOption } from 'devextreme-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoLegendComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get columnCount() {
        return this._getOption('columnCount');
    }
    set columnCount(value) {
        this._setOption('columnCount', value);
    }
    get columnItemSpacing() {
        return this._getOption('columnItemSpacing');
    }
    set columnItemSpacing(value) {
        this._setOption('columnItemSpacing', value);
    }
    get customizeHint() {
        return this._getOption('customizeHint');
    }
    set customizeHint(value) {
        this._setOption('customizeHint', value);
    }
    get customizeItems() {
        return this._getOption('customizeItems');
    }
    set customizeItems(value) {
        this._setOption('customizeItems', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get itemsAlignment() {
        return this._getOption('itemsAlignment');
    }
    set itemsAlignment(value) {
        this._setOption('itemsAlignment', value);
    }
    get itemTextFormat() {
        return this._getOption('itemTextFormat');
    }
    set itemTextFormat(value) {
        this._setOption('itemTextFormat', value);
    }
    get itemTextPosition() {
        return this._getOption('itemTextPosition');
    }
    set itemTextPosition(value) {
        this._setOption('itemTextPosition', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get markerSize() {
        return this._getOption('markerSize');
    }
    set markerSize(value) {
        this._setOption('markerSize', value);
    }
    get markerTemplate() {
        return this._getOption('markerTemplate');
    }
    set markerTemplate(value) {
        this._setOption('markerTemplate', value);
    }
    get orientation() {
        return this._getOption('orientation');
    }
    set orientation(value) {
        this._setOption('orientation', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get rowCount() {
        return this._getOption('rowCount');
    }
    set rowCount(value) {
        this._setOption('rowCount', value);
    }
    get rowItemSpacing() {
        return this._getOption('rowItemSpacing');
    }
    set rowItemSpacing(value) {
        this._setOption('rowItemSpacing', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get hoverMode() {
        return this._getOption('hoverMode');
    }
    set hoverMode(value) {
        this._setOption('hoverMode', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get _optionPath() {
        return 'legend';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoLegendComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoLegendComponent, selector: "dxo-legend", inputs: { backgroundColor: "backgroundColor", border: "border", columnCount: "columnCount", columnItemSpacing: "columnItemSpacing", customizeHint: "customizeHint", customizeItems: "customizeItems", customizeText: "customizeText", font: "font", horizontalAlignment: "horizontalAlignment", itemsAlignment: "itemsAlignment", itemTextFormat: "itemTextFormat", itemTextPosition: "itemTextPosition", margin: "margin", markerSize: "markerSize", markerTemplate: "markerTemplate", orientation: "orientation", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", rowCount: "rowCount", rowItemSpacing: "rowItemSpacing", title: "title", verticalAlignment: "verticalAlignment", visible: "visible", hoverMode: "hoverMode", position: "position" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoLegendComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-legend', template: '', providers: [NestedOptionHost] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }], columnCount: [{
                type: Input
            }], columnItemSpacing: [{
                type: Input
            }], customizeHint: [{
                type: Input
            }], customizeItems: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], itemsAlignment: [{
                type: Input
            }], itemTextFormat: [{
                type: Input
            }], itemTextPosition: [{
                type: Input
            }], margin: [{
                type: Input
            }], markerSize: [{
                type: Input
            }], markerTemplate: [{
                type: Input
            }], orientation: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], rowCount: [{
                type: Input
            }], rowItemSpacing: [{
                type: Input
            }], title: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }], hoverMode: [{
                type: Input
            }], position: [{
                type: Input
            }] } });
export class DxoLegendModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoLegendModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoLegendModule, declarations: [DxoLegendComponent], exports: [DxoLegendComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoLegendModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoLegendModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoLegendComponent
                    ],
                    exports: [
                        DxoLegendComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGVnZW5kLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvbGVnZW5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBR3BDLE9BQU8sRUFDSCxTQUFTLEVBR1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1IsS0FBSyxFQUNSLE1BQU0sZUFBZSxDQUFDO0FBVXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0seUJBQXlCLENBQUM7OztBQVN2RCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsWUFBWTtJQUNoRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBeUI7UUFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUF3STtRQUMvSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFRCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFhO1FBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBZTtRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQWU7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFlO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFRCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQVc7UUFDaEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVELElBQ0ksbUJBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFJLG1CQUFtQixDQUFDLEtBQTBCO1FBQzlDLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFzQztRQUNyRCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBa0M7UUFDakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBMkI7UUFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUFnRjtRQUN2RixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFhO1FBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBc0I7UUFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUE4QjtRQUMxQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBYTtRQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUNJLGdCQUFnQjtRQUNoQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBQ0QsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFhO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQWE7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUE2VDtRQUNuVSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsSUFDSSxpQkFBaUI7UUFDakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQUksaUJBQWlCLENBQUMsS0FBbUI7UUFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQWdEO1FBQzFELElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQXVCO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRCxJQUFjLFdBQVc7UUFDckIsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUdELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUNSLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFHRCxRQUFRO1FBQ0osSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7SUFDbEQsQ0FBQzsySEE3TlEsa0JBQWtCOytHQUFsQixrQkFBa0IseXhCQUZoQixDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkFJSCxrQkFBa0I7a0JBTjlCLFNBQVM7K0JBQ0ksWUFBWSxZQUNaLEVBQUUsYUFFRCxDQUFDLGdCQUFnQixDQUFDOzswQkFpTmhCLFFBQVE7OzBCQUFJLElBQUk7OzBCQUNwQixJQUFJOzRDQTlNVCxlQUFlO3NCQURsQixLQUFLO2dCQVNGLE1BQU07c0JBRFQsS0FBSztnQkFTRixXQUFXO3NCQURkLEtBQUs7Z0JBU0YsaUJBQWlCO3NCQURwQixLQUFLO2dCQVNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBU0YsY0FBYztzQkFEakIsS0FBSztnQkFTRixhQUFhO3NCQURoQixLQUFLO2dCQVNGLElBQUk7c0JBRFAsS0FBSztnQkFTRixtQkFBbUI7c0JBRHRCLEtBQUs7Z0JBU0YsY0FBYztzQkFEakIsS0FBSztnQkFTRixjQUFjO3NCQURqQixLQUFLO2dCQVNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFTRixNQUFNO3NCQURULEtBQUs7Z0JBU0YsVUFBVTtzQkFEYixLQUFLO2dCQVNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBU0YsV0FBVztzQkFEZCxLQUFLO2dCQVNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFTRixnQkFBZ0I7c0JBRG5CLEtBQUs7Z0JBU0YsUUFBUTtzQkFEWCxLQUFLO2dCQVNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBU0YsS0FBSztzQkFEUixLQUFLO2dCQVNGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFTRixPQUFPO3NCQURWLEtBQUs7Z0JBU0YsU0FBUztzQkFEWixLQUFLO2dCQVNGLFFBQVE7c0JBRFgsS0FBSzs7QUF5Q1YsTUFBTSxPQUFPLGVBQWU7MkhBQWYsZUFBZTs0SEFBZixlQUFlLGlCQTFPZixrQkFBa0IsYUFBbEIsa0JBQWtCOzRIQTBPbEIsZUFBZTs7NEZBQWYsZUFBZTtrQkFSM0IsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osa0JBQWtCO3FCQUNuQjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1Asa0JBQWtCO3FCQUNuQjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuXG5pbXBvcnQge1xuICAgIENvbXBvbmVudCxcbiAgICBPbkluaXQsXG4gICAgT25EZXN0cm95LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGYsXG4gICAgSW5wdXRcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cbmltcG9ydCB7IEhvcml6b250YWxBbGlnbm1lbnQsIE9yaWVudGF0aW9uLCBQb3NpdGlvbiwgVmVydGljYWxFZGdlIH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24nO1xuaW1wb3J0IHsgRGFzaFN0eWxlLCBGb250LCBMZWdlbmRIb3Zlck1vZGUsIFJlbGF0aXZlUG9zaXRpb24gfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbi9jaGFydHMnO1xuaW1wb3J0IHsgRm9ybWF0IH0gZnJvbSAnZGV2ZXh0cmVtZS9sb2NhbGl6YXRpb24nO1xuaW1wb3J0IHsgUGllQ2hhcnRMZWdlbmRIb3Zlck1vZGUgfSBmcm9tICdkZXZleHRyZW1lL3Zpei9waWVfY2hhcnQnO1xuXG5pbXBvcnQge1xuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5lc3RlZE9wdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4by1sZWdlbmQnLFxuICAgIHRlbXBsYXRlOiAnJyxcbiAgICBzdHlsZXM6IFsnJ10sXG4gICAgcHJvdmlkZXJzOiBbTmVzdGVkT3B0aW9uSG9zdF1cbn0pXG5leHBvcnQgY2xhc3MgRHhvTGVnZW5kQ29tcG9uZW50IGV4dGVuZHMgTmVzdGVkT3B0aW9uIGltcGxlbWVudHMgT25EZXN0cm95LCBPbkluaXQgIHtcbiAgICBASW5wdXQoKVxuICAgIGdldCBiYWNrZ3JvdW5kQ29sb3IoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYmFja2dyb3VuZENvbG9yJyk7XG4gICAgfVxuICAgIHNldCBiYWNrZ3JvdW5kQ29sb3IodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JhY2tncm91bmRDb2xvcicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBib3JkZXIoKTogeyBjb2xvcj86IHN0cmluZywgY29ybmVyUmFkaXVzPzogbnVtYmVyLCBkYXNoU3R5bGU/OiBEYXNoU3R5bGUsIG9wYWNpdHk/OiBudW1iZXIgfCB1bmRlZmluZWQsIHZpc2libGU/OiBib29sZWFuLCB3aWR0aD86IG51bWJlciB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYm9yZGVyJyk7XG4gICAgfVxuICAgIHNldCBib3JkZXIodmFsdWU6IHsgY29sb3I/OiBzdHJpbmcsIGNvcm5lclJhZGl1cz86IG51bWJlciwgZGFzaFN0eWxlPzogRGFzaFN0eWxlLCBvcGFjaXR5PzogbnVtYmVyIHwgdW5kZWZpbmVkLCB2aXNpYmxlPzogYm9vbGVhbiwgd2lkdGg/OiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2JvcmRlcicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBjb2x1bW5Db3VudCgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjb2x1bW5Db3VudCcpO1xuICAgIH1cbiAgICBzZXQgY29sdW1uQ291bnQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbHVtbkNvdW50JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGNvbHVtbkl0ZW1TcGFjaW5nKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbHVtbkl0ZW1TcGFjaW5nJyk7XG4gICAgfVxuICAgIHNldCBjb2x1bW5JdGVtU3BhY2luZyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY29sdW1uSXRlbVNwYWNpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgY3VzdG9taXplSGludCgpOiBGdW5jdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2N1c3RvbWl6ZUhpbnQnKTtcbiAgICB9XG4gICAgc2V0IGN1c3RvbWl6ZUhpbnQodmFsdWU6IEZ1bmN0aW9uKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY3VzdG9taXplSGludCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBjdXN0b21pemVJdGVtcygpOiBGdW5jdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2N1c3RvbWl6ZUl0ZW1zJyk7XG4gICAgfVxuICAgIHNldCBjdXN0b21pemVJdGVtcyh2YWx1ZTogRnVuY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjdXN0b21pemVJdGVtcycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBjdXN0b21pemVUZXh0KCk6IEZ1bmN0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY3VzdG9taXplVGV4dCcpO1xuICAgIH1cbiAgICBzZXQgY3VzdG9taXplVGV4dCh2YWx1ZTogRnVuY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjdXN0b21pemVUZXh0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGZvbnQoKTogRm9udCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2ZvbnQnKTtcbiAgICB9XG4gICAgc2V0IGZvbnQodmFsdWU6IEZvbnQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdmb250JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhvcml6b250YWxBbGlnbm1lbnQoKTogSG9yaXpvbnRhbEFsaWdubWVudCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hvcml6b250YWxBbGlnbm1lbnQnKTtcbiAgICB9XG4gICAgc2V0IGhvcml6b250YWxBbGlnbm1lbnQodmFsdWU6IEhvcml6b250YWxBbGlnbm1lbnQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdob3Jpem9udGFsQWxpZ25tZW50JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGl0ZW1zQWxpZ25tZW50KCk6IEhvcml6b250YWxBbGlnbm1lbnQgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtc0FsaWdubWVudCcpO1xuICAgIH1cbiAgICBzZXQgaXRlbXNBbGlnbm1lbnQodmFsdWU6IEhvcml6b250YWxBbGlnbm1lbnQgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtc0FsaWdubWVudCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBpdGVtVGV4dEZvcm1hdCgpOiBGb3JtYXQgfCBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtVGV4dEZvcm1hdCcpO1xuICAgIH1cbiAgICBzZXQgaXRlbVRleHRGb3JtYXQodmFsdWU6IEZvcm1hdCB8IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2l0ZW1UZXh0Rm9ybWF0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGl0ZW1UZXh0UG9zaXRpb24oKTogUG9zaXRpb24gfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtVGV4dFBvc2l0aW9uJyk7XG4gICAgfVxuICAgIHNldCBpdGVtVGV4dFBvc2l0aW9uKHZhbHVlOiBQb3NpdGlvbiB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2l0ZW1UZXh0UG9zaXRpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgbWFyZ2luKCk6IG51bWJlciB8IHsgYm90dG9tPzogbnVtYmVyLCBsZWZ0PzogbnVtYmVyLCByaWdodD86IG51bWJlciwgdG9wPzogbnVtYmVyIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtYXJnaW4nKTtcbiAgICB9XG4gICAgc2V0IG1hcmdpbih2YWx1ZTogbnVtYmVyIHwgeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21hcmdpbicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBtYXJrZXJTaXplKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21hcmtlclNpemUnKTtcbiAgICB9XG4gICAgc2V0IG1hcmtlclNpemUodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21hcmtlclNpemUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgbWFya2VyVGVtcGxhdGUoKTogYW55IHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbWFya2VyVGVtcGxhdGUnKTtcbiAgICB9XG4gICAgc2V0IG1hcmtlclRlbXBsYXRlKHZhbHVlOiBhbnkgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdtYXJrZXJUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBvcmllbnRhdGlvbigpOiBPcmllbnRhdGlvbiB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ29yaWVudGF0aW9uJyk7XG4gICAgfVxuICAgIHNldCBvcmllbnRhdGlvbih2YWx1ZTogT3JpZW50YXRpb24gfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdvcmllbnRhdGlvbicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBwYWRkaW5nTGVmdFJpZ2h0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3BhZGRpbmdMZWZ0UmlnaHQnKTtcbiAgICB9XG4gICAgc2V0IHBhZGRpbmdMZWZ0UmlnaHQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BhZGRpbmdMZWZ0UmlnaHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgcGFkZGluZ1RvcEJvdHRvbSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdwYWRkaW5nVG9wQm90dG9tJyk7XG4gICAgfVxuICAgIHNldCBwYWRkaW5nVG9wQm90dG9tKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdwYWRkaW5nVG9wQm90dG9tJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJvd0NvdW50KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Jvd0NvdW50Jyk7XG4gICAgfVxuICAgIHNldCByb3dDb3VudCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncm93Q291bnQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgcm93SXRlbVNwYWNpbmcoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncm93SXRlbVNwYWNpbmcnKTtcbiAgICB9XG4gICAgc2V0IHJvd0l0ZW1TcGFjaW5nKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdyb3dJdGVtU3BhY2luZycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCB0aXRsZSgpOiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgbWFyZ2luPzogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZyB9LCB0ZXh0Pzogc3RyaW5nLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGl0bGUnKTtcbiAgICB9XG4gICAgc2V0IHRpdGxlKHZhbHVlOiBzdHJpbmcgfCB7IGZvbnQ/OiBGb250LCBob3Jpem9udGFsQWxpZ25tZW50PzogSG9yaXpvbnRhbEFsaWdubWVudCB8IHVuZGVmaW5lZCwgbWFyZ2luPzogeyBib3R0b20/OiBudW1iZXIsIGxlZnQ/OiBudW1iZXIsIHJpZ2h0PzogbnVtYmVyLCB0b3A/OiBudW1iZXIgfSwgcGxhY2Vob2xkZXJTaXplPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdWJ0aXRsZT86IHN0cmluZyB8IHsgZm9udD86IEZvbnQsIG9mZnNldD86IG51bWJlciwgdGV4dD86IHN0cmluZyB9LCB0ZXh0Pzogc3RyaW5nLCB2ZXJ0aWNhbEFsaWdubWVudD86IFZlcnRpY2FsRWRnZSB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGl0bGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdmVydGljYWxBbGlnbm1lbnQoKTogVmVydGljYWxFZGdlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmVydGljYWxBbGlnbm1lbnQnKTtcbiAgICB9XG4gICAgc2V0IHZlcnRpY2FsQWxpZ25tZW50KHZhbHVlOiBWZXJ0aWNhbEVkZ2UpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2ZXJ0aWNhbEFsaWdubWVudCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCB2aXNpYmxlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2aXNpYmxlJyk7XG4gICAgfVxuICAgIHNldCB2aXNpYmxlKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlzaWJsZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBob3Zlck1vZGUoKTogTGVnZW5kSG92ZXJNb2RlIHwgUGllQ2hhcnRMZWdlbmRIb3Zlck1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdob3Zlck1vZGUnKTtcbiAgICB9XG4gICAgc2V0IGhvdmVyTW9kZSh2YWx1ZTogTGVnZW5kSG92ZXJNb2RlIHwgUGllQ2hhcnRMZWdlbmRIb3Zlck1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdob3Zlck1vZGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgcG9zaXRpb24oKTogUmVsYXRpdmVQb3NpdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Bvc2l0aW9uJyk7XG4gICAgfVxuICAgIHNldCBwb3NpdGlvbih2YWx1ZTogUmVsYXRpdmVQb3NpdGlvbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Bvc2l0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdsZWdlbmQnO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9MZWdlbmRDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4b0xlZ2VuZENvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9MZWdlbmRNb2R1bGUgeyB9XG4iXX0=