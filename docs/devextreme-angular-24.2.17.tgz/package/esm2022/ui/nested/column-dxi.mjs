/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf, Output, EventEmitter, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiDataGridColumn } from './base/data-grid-column-dxi';
import { DxiButtonComponent } from './button-dxi';
import { DxiValidationRuleComponent } from './validation-rule-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiColumnComponent extends DxiDataGridColumn {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValuesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedFilterOperationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortOrderChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleIndexChange;
    get _optionPath() {
        return 'columns';
    }
    get buttonsChildren() {
        return this._getOption('buttons');
    }
    set buttonsChildren(value) {
        this.setChildren('buttons', value);
    }
    get columnsChildren() {
        return this._getOption('columns');
    }
    set columnsChildren(value) {
        this.setChildren('columns', value);
    }
    get validationRulesChildren() {
        return this._getOption('validationRules');
    }
    set validationRulesChildren(value) {
        this.setChildren('validationRules', value);
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'filterValueChange' },
            { emit: 'filterValuesChange' },
            { emit: 'groupIndexChange' },
            { emit: 'selectedFilterOperationChange' },
            { emit: 'sortIndexChange' },
            { emit: 'sortOrderChange' },
            { emit: 'visibleChange' },
            { emit: 'visibleIndexChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiColumnComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiColumnComponent, selector: "dxi-column", inputs: { alignment: "alignment", allowEditing: "allowEditing", allowExporting: "allowExporting", allowFiltering: "allowFiltering", allowFixing: "allowFixing", allowGrouping: "allowGrouping", allowHeaderFiltering: "allowHeaderFiltering", allowHiding: "allowHiding", allowReordering: "allowReordering", allowResizing: "allowResizing", allowSearch: "allowSearch", allowSorting: "allowSorting", autoExpandGroup: "autoExpandGroup", buttons: "buttons", calculateCellValue: "calculateCellValue", calculateDisplayValue: "calculateDisplayValue", calculateFilterExpression: "calculateFilterExpression", calculateGroupValue: "calculateGroupValue", calculateSortValue: "calculateSortValue", caption: "caption", cellTemplate: "cellTemplate", columns: "columns", cssClass: "cssClass", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editCellTemplate: "editCellTemplate", editorOptions: "editorOptions", encodeHtml: "encodeHtml", falseText: "falseText", filterOperations: "filterOperations", filterType: "filterType", filterValue: "filterValue", filterValues: "filterValues", fixed: "fixed", fixedPosition: "fixedPosition", format: "format", formItem: "formItem", groupCellTemplate: "groupCellTemplate", groupIndex: "groupIndex", headerCellTemplate: "headerCellTemplate", headerFilter: "headerFilter", hidingPriority: "hidingPriority", isBand: "isBand", lookup: "lookup", minWidth: "minWidth", name: "name", ownerBand: "ownerBand", renderAsync: "renderAsync", selectedFilterOperation: "selectedFilterOperation", setCellValue: "setCellValue", showEditorAlways: "showEditorAlways", showInColumnChooser: "showInColumnChooser", showWhenGrouped: "showWhenGrouped", sortIndex: "sortIndex", sortingMethod: "sortingMethod", sortOrder: "sortOrder", trueText: "trueText", type: "type", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex", width: "width" }, outputs: { filterValueChange: "filterValueChange", filterValuesChange: "filterValuesChange", groupIndexChange: "groupIndexChange", selectedFilterOperationChange: "selectedFilterOperationChange", sortIndexChange: "sortIndexChange", sortOrderChange: "sortOrderChange", visibleChange: "visibleChange", visibleIndexChange: "visibleIndexChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "buttonsChildren", predicate: i0.forwardRef(function () { return DxiButtonComponent; }) }, { propertyName: "columnsChildren", predicate: i0.forwardRef(function () { return DxiColumnComponent; }) }, { propertyName: "validationRulesChildren", predicate: i0.forwardRef(function () { return DxiValidationRuleComponent; }) }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-column', template: '', providers: [NestedOptionHost], inputs: [
                        'alignment',
                        'allowEditing',
                        'allowExporting',
                        'allowFiltering',
                        'allowFixing',
                        'allowGrouping',
                        'allowHeaderFiltering',
                        'allowHiding',
                        'allowReordering',
                        'allowResizing',
                        'allowSearch',
                        'allowSorting',
                        'autoExpandGroup',
                        'buttons',
                        'calculateCellValue',
                        'calculateDisplayValue',
                        'calculateFilterExpression',
                        'calculateGroupValue',
                        'calculateSortValue',
                        'caption',
                        'cellTemplate',
                        'columns',
                        'cssClass',
                        'customizeText',
                        'dataField',
                        'dataType',
                        'editCellTemplate',
                        'editorOptions',
                        'encodeHtml',
                        'falseText',
                        'filterOperations',
                        'filterType',
                        'filterValue',
                        'filterValues',
                        'fixed',
                        'fixedPosition',
                        'format',
                        'formItem',
                        'groupCellTemplate',
                        'groupIndex',
                        'headerCellTemplate',
                        'headerFilter',
                        'hidingPriority',
                        'isBand',
                        'lookup',
                        'minWidth',
                        'name',
                        'ownerBand',
                        'renderAsync',
                        'selectedFilterOperation',
                        'setCellValue',
                        'showEditorAlways',
                        'showInColumnChooser',
                        'showWhenGrouped',
                        'sortIndex',
                        'sortingMethod',
                        'sortOrder',
                        'trueText',
                        'type',
                        'validationRules',
                        'visible',
                        'visibleIndex',
                        'width'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { filterValueChange: [{
                type: Output
            }], filterValuesChange: [{
                type: Output
            }], groupIndexChange: [{
                type: Output
            }], selectedFilterOperationChange: [{
                type: Output
            }], sortIndexChange: [{
                type: Output
            }], sortOrderChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], visibleIndexChange: [{
                type: Output
            }], buttonsChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiButtonComponent)]
            }], columnsChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiColumnComponent)]
            }], validationRulesChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiValidationRuleComponent)]
            }] } });
export class DxiColumnModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiColumnModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiColumnModule, declarations: [DxiColumnComponent], exports: [DxiColumnComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiColumnModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiColumnModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiColumnComponent
                    ],
                    exports: [
                        DxiColumnComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sdW1uLWR4aS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2NvbHVtbi1keGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsaURBQWlEO0FBRWpELE9BQU8sRUFDSCxTQUFTLEVBQ1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1IsTUFBTSxFQUNOLFlBQVksRUFDWixlQUFlLEVBQ2YsVUFBVSxFQUNWLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQVF2QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ2xELE9BQU8sRUFBRSwwQkFBMEIsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUEwRW5FLE1BQU0sT0FBTyxrQkFBbUIsU0FBUSxpQkFBaUI7SUFFckQ7Ozs7T0FJRztJQUNPLGlCQUFpQixDQUFnQztJQUUzRDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQTJCO0lBRXZEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBbUM7SUFFN0Q7Ozs7T0FJRztJQUNPLDZCQUE2QixDQUFvRDtJQUUzRjs7OztPQUlHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7OztPQUlHO0lBQ08sZUFBZSxDQUErQztJQUV4RTs7OztPQUlHO0lBQ08sYUFBYSxDQUF3QjtJQUUvQzs7OztPQUlHO0lBQ08sa0JBQWtCLENBQW1DO0lBQy9ELElBQWMsV0FBVztRQUNyQixPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBR0QsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLGVBQWUsQ0FBQyxLQUFLO1FBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQUs7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQ0ksdUJBQXVCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFDRCxJQUFJLHVCQUF1QixDQUFDLEtBQUs7UUFDN0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBRVIsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLCtCQUErQixFQUFFO1lBQ3pDLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtTQUNqQyxDQUFDLENBQUM7UUFFSCxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBSUQsV0FBVztRQUNQLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDOzJIQTdHUSxrQkFBa0I7K0dBQWxCLGtCQUFrQixvdUVBbkVoQixDQUFDLGdCQUFnQixDQUFDLDZGQWlJSyxrQkFBa0IseUZBUWxCLGtCQUFrQixpR0FRbEIsMEJBQTBCLHdEQW5KbEQsRUFBRTs7NEZBcUVILGtCQUFrQjtrQkF2RTlCLFNBQVM7K0JBQ0ksWUFBWSxZQUNaLEVBQUUsYUFFRCxDQUFDLGdCQUFnQixDQUFDLFVBQ3JCO3dCQUNKLFdBQVc7d0JBQ1gsY0FBYzt3QkFDZCxnQkFBZ0I7d0JBQ2hCLGdCQUFnQjt3QkFDaEIsYUFBYTt3QkFDYixlQUFlO3dCQUNmLHNCQUFzQjt3QkFDdEIsYUFBYTt3QkFDYixpQkFBaUI7d0JBQ2pCLGVBQWU7d0JBQ2YsYUFBYTt3QkFDYixjQUFjO3dCQUNkLGlCQUFpQjt3QkFDakIsU0FBUzt3QkFDVCxvQkFBb0I7d0JBQ3BCLHVCQUF1Qjt3QkFDdkIsMkJBQTJCO3dCQUMzQixxQkFBcUI7d0JBQ3JCLG9CQUFvQjt3QkFDcEIsU0FBUzt3QkFDVCxjQUFjO3dCQUNkLFNBQVM7d0JBQ1QsVUFBVTt3QkFDVixlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsVUFBVTt3QkFDVixrQkFBa0I7d0JBQ2xCLGVBQWU7d0JBQ2YsWUFBWTt3QkFDWixXQUFXO3dCQUNYLGtCQUFrQjt3QkFDbEIsWUFBWTt3QkFDWixhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsT0FBTzt3QkFDUCxlQUFlO3dCQUNmLFFBQVE7d0JBQ1IsVUFBVTt3QkFDVixtQkFBbUI7d0JBQ25CLFlBQVk7d0JBQ1osb0JBQW9CO3dCQUNwQixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsUUFBUTt3QkFDUixRQUFRO3dCQUNSLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixXQUFXO3dCQUNYLGFBQWE7d0JBQ2IseUJBQXlCO3dCQUN6QixjQUFjO3dCQUNkLGtCQUFrQjt3QkFDbEIscUJBQXFCO3dCQUNyQixpQkFBaUI7d0JBQ2pCLFdBQVc7d0JBQ1gsZUFBZTt3QkFDZixXQUFXO3dCQUNYLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixpQkFBaUI7d0JBQ2pCLFNBQVM7d0JBQ1QsY0FBYzt3QkFDZCxPQUFPO3FCQUNWOzswQkF3RlksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7NENBaEZILGlCQUFpQjtzQkFBMUIsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLDZCQUE2QjtzQkFBdEMsTUFBTTtnQkFPRyxlQUFlO3NCQUF4QixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0gsZUFBZTtzQkFEbEIsZUFBZTt1QkFBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsa0JBQWtCLENBQUM7Z0JBU2pELGVBQWU7c0JBRGxCLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLGtCQUFrQixDQUFDO2dCQVNqRCx1QkFBdUI7c0JBRDFCLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLDBCQUEwQixDQUFDOztBQTJDakUsTUFBTSxPQUFPLGVBQWU7MkhBQWYsZUFBZTs0SEFBZixlQUFlLGlCQXpIZixrQkFBa0IsYUFBbEIsa0JBQWtCOzRIQXlIbEIsZUFBZTs7NEZBQWYsZUFBZTtrQkFSM0IsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osa0JBQWtCO3FCQUNuQjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1Asa0JBQWtCO3FCQUNuQjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuLyogdHNsaW50OmRpc2FibGU6dXNlLWlucHV0LXByb3BlcnR5LWRlY29yYXRvciAqL1xuXG5pbXBvcnQge1xuICAgIENvbXBvbmVudCxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIFNraXBTZWxmLFxuICAgIE91dHB1dCxcbiAgICBFdmVudEVtaXR0ZXIsXG4gICAgQ29udGVudENoaWxkcmVuLFxuICAgIGZvcndhcmRSZWYsXG4gICAgUXVlcnlMaXN0XG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cblxuXG5pbXBvcnQgeyBTb3J0T3JkZXIgfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbic7XG5pbXBvcnQgeyBTZWxlY3RlZEZpbHRlck9wZXJhdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uL2dyaWRzJztcblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeGlEYXRhR3JpZENvbHVtbiB9IGZyb20gJy4vYmFzZS9kYXRhLWdyaWQtY29sdW1uLWR4aSc7XG5pbXBvcnQgeyBEeGlCdXR0b25Db21wb25lbnQgfSBmcm9tICcuL2J1dHRvbi1keGknO1xuaW1wb3J0IHsgRHhpVmFsaWRhdGlvblJ1bGVDb21wb25lbnQgfSBmcm9tICcuL3ZhbGlkYXRpb24tcnVsZS1keGknO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhpLWNvbHVtbicsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHN0eWxlczogWycnXSxcbiAgICBwcm92aWRlcnM6IFtOZXN0ZWRPcHRpb25Ib3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2FsaWdubWVudCcsXG4gICAgICAgICdhbGxvd0VkaXRpbmcnLFxuICAgICAgICAnYWxsb3dFeHBvcnRpbmcnLFxuICAgICAgICAnYWxsb3dGaWx0ZXJpbmcnLFxuICAgICAgICAnYWxsb3dGaXhpbmcnLFxuICAgICAgICAnYWxsb3dHcm91cGluZycsXG4gICAgICAgICdhbGxvd0hlYWRlckZpbHRlcmluZycsXG4gICAgICAgICdhbGxvd0hpZGluZycsXG4gICAgICAgICdhbGxvd1Jlb3JkZXJpbmcnLFxuICAgICAgICAnYWxsb3dSZXNpemluZycsXG4gICAgICAgICdhbGxvd1NlYXJjaCcsXG4gICAgICAgICdhbGxvd1NvcnRpbmcnLFxuICAgICAgICAnYXV0b0V4cGFuZEdyb3VwJyxcbiAgICAgICAgJ2J1dHRvbnMnLFxuICAgICAgICAnY2FsY3VsYXRlQ2VsbFZhbHVlJyxcbiAgICAgICAgJ2NhbGN1bGF0ZURpc3BsYXlWYWx1ZScsXG4gICAgICAgICdjYWxjdWxhdGVGaWx0ZXJFeHByZXNzaW9uJyxcbiAgICAgICAgJ2NhbGN1bGF0ZUdyb3VwVmFsdWUnLFxuICAgICAgICAnY2FsY3VsYXRlU29ydFZhbHVlJyxcbiAgICAgICAgJ2NhcHRpb24nLFxuICAgICAgICAnY2VsbFRlbXBsYXRlJyxcbiAgICAgICAgJ2NvbHVtbnMnLFxuICAgICAgICAnY3NzQ2xhc3MnLFxuICAgICAgICAnY3VzdG9taXplVGV4dCcsXG4gICAgICAgICdkYXRhRmllbGQnLFxuICAgICAgICAnZGF0YVR5cGUnLFxuICAgICAgICAnZWRpdENlbGxUZW1wbGF0ZScsXG4gICAgICAgICdlZGl0b3JPcHRpb25zJyxcbiAgICAgICAgJ2VuY29kZUh0bWwnLFxuICAgICAgICAnZmFsc2VUZXh0JyxcbiAgICAgICAgJ2ZpbHRlck9wZXJhdGlvbnMnLFxuICAgICAgICAnZmlsdGVyVHlwZScsXG4gICAgICAgICdmaWx0ZXJWYWx1ZScsXG4gICAgICAgICdmaWx0ZXJWYWx1ZXMnLFxuICAgICAgICAnZml4ZWQnLFxuICAgICAgICAnZml4ZWRQb3NpdGlvbicsXG4gICAgICAgICdmb3JtYXQnLFxuICAgICAgICAnZm9ybUl0ZW0nLFxuICAgICAgICAnZ3JvdXBDZWxsVGVtcGxhdGUnLFxuICAgICAgICAnZ3JvdXBJbmRleCcsXG4gICAgICAgICdoZWFkZXJDZWxsVGVtcGxhdGUnLFxuICAgICAgICAnaGVhZGVyRmlsdGVyJyxcbiAgICAgICAgJ2hpZGluZ1ByaW9yaXR5JyxcbiAgICAgICAgJ2lzQmFuZCcsXG4gICAgICAgICdsb29rdXAnLFxuICAgICAgICAnbWluV2lkdGgnLFxuICAgICAgICAnbmFtZScsXG4gICAgICAgICdvd25lckJhbmQnLFxuICAgICAgICAncmVuZGVyQXN5bmMnLFxuICAgICAgICAnc2VsZWN0ZWRGaWx0ZXJPcGVyYXRpb24nLFxuICAgICAgICAnc2V0Q2VsbFZhbHVlJyxcbiAgICAgICAgJ3Nob3dFZGl0b3JBbHdheXMnLFxuICAgICAgICAnc2hvd0luQ29sdW1uQ2hvb3NlcicsXG4gICAgICAgICdzaG93V2hlbkdyb3VwZWQnLFxuICAgICAgICAnc29ydEluZGV4JyxcbiAgICAgICAgJ3NvcnRpbmdNZXRob2QnLFxuICAgICAgICAnc29ydE9yZGVyJyxcbiAgICAgICAgJ3RydWVUZXh0JyxcbiAgICAgICAgJ3R5cGUnLFxuICAgICAgICAndmFsaWRhdGlvblJ1bGVzJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAndmlzaWJsZUluZGV4JyxcbiAgICAgICAgJ3dpZHRoJ1xuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhpQ29sdW1uQ29tcG9uZW50IGV4dGVuZHMgRHhpRGF0YUdyaWRDb2x1bW4ge1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZmlsdGVyVmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnkgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZmlsdGVyVmFsdWVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8YW55Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBncm91cEluZGV4Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNlbGVjdGVkRmlsdGVyT3BlcmF0aW9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8U2VsZWN0ZWRGaWx0ZXJPcGVyYXRpb24gfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc29ydEluZGV4Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNvcnRPcmRlckNoYW5nZTogRXZlbnRFbWl0dGVyPFNvcnRPcmRlciB8IHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2aXNpYmxlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2aXNpYmxlSW5kZXhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCB1bmRlZmluZWQ+O1xuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnY29sdW1ucyc7XG4gICAgfVxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKGZvcndhcmRSZWYoKCkgPT4gRHhpQnV0dG9uQ29tcG9uZW50KSlcbiAgICBnZXQgYnV0dG9uc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlCdXR0b25Db21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYnV0dG9ucycpO1xuICAgIH1cbiAgICBzZXQgYnV0dG9uc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2J1dHRvbnMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihmb3J3YXJkUmVmKCgpID0+IER4aUNvbHVtbkNvbXBvbmVudCkpXG4gICAgZ2V0IGNvbHVtbnNDaGlsZHJlbigpOiBRdWVyeUxpc3Q8RHhpQ29sdW1uQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbHVtbnMnKTtcbiAgICB9XG4gICAgc2V0IGNvbHVtbnNDaGlsZHJlbih2YWx1ZSkge1xuICAgICAgICB0aGlzLnNldENoaWxkcmVuKCdjb2x1bW5zJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oZm9yd2FyZFJlZigoKSA9PiBEeGlWYWxpZGF0aW9uUnVsZUNvbXBvbmVudCkpXG4gICAgZ2V0IHZhbGlkYXRpb25SdWxlc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlWYWxpZGF0aW9uUnVsZUNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2YWxpZGF0aW9uUnVsZXMnKTtcbiAgICB9XG4gICAgc2V0IHZhbGlkYXRpb25SdWxlc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ3ZhbGlkYXRpb25SdWxlcycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcblxuICAgICAgICB0aGlzLl9jcmVhdGVFdmVudEVtaXR0ZXJzKFtcbiAgICAgICAgICAgIHsgZW1pdDogJ2ZpbHRlclZhbHVlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZmlsdGVyVmFsdWVzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZ3JvdXBJbmRleENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NlbGVjdGVkRmlsdGVyT3BlcmF0aW9uQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc29ydEluZGV4Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc29ydE9yZGVyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmlzaWJsZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Zpc2libGVJbmRleENoYW5nZScgfVxuICAgICAgICBdKTtcblxuICAgICAgICBwYXJlbnRPcHRpb25Ib3N0LnNldE5lc3RlZE9wdGlvbih0aGlzKTtcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMsIHRoaXMuX2Z1bGxPcHRpb25QYXRoLmJpbmQodGhpcykpO1xuICAgIH1cblxuXG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fZGVsZXRlUmVtb3ZlZE9wdGlvbnModGhpcy5fZnVsbE9wdGlvblBhdGgoKSk7XG4gICAgfVxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4aUNvbHVtbkNvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhpQ29sdW1uQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4aUNvbHVtbk1vZHVsZSB7IH1cbiJdfQ==