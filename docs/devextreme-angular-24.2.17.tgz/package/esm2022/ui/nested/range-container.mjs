/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { Component, NgModule, Host, SkipSelf, Input, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { NestedOption } from 'devextreme-angular/core';
import { DxiRangeComponent } from './range-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoRangeContainerComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get orientation() {
        return this._getOption('orientation');
    }
    set orientation(value) {
        this._setOption('orientation', value);
    }
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    get paletteExtensionMode() {
        return this._getOption('paletteExtensionMode');
    }
    set paletteExtensionMode(value) {
        this._setOption('paletteExtensionMode', value);
    }
    get ranges() {
        return this._getOption('ranges');
    }
    set ranges(value) {
        this._setOption('ranges', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get horizontalOrientation() {
        return this._getOption('horizontalOrientation');
    }
    set horizontalOrientation(value) {
        this._setOption('horizontalOrientation', value);
    }
    get verticalOrientation() {
        return this._getOption('verticalOrientation');
    }
    set verticalOrientation(value) {
        this._setOption('verticalOrientation', value);
    }
    get _optionPath() {
        return 'rangeContainer';
    }
    get rangesChildren() {
        return this._getOption('ranges');
    }
    set rangesChildren(value) {
        this.setChildren('ranges', value);
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoRangeContainerComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoRangeContainerComponent, selector: "dxo-range-container", inputs: { backgroundColor: "backgroundColor", offset: "offset", orientation: "orientation", palette: "palette", paletteExtensionMode: "paletteExtensionMode", ranges: "ranges", width: "width", horizontalOrientation: "horizontalOrientation", verticalOrientation: "verticalOrientation" }, providers: [NestedOptionHost], queries: [{ propertyName: "rangesChildren", predicate: i0.forwardRef(function () { return DxiRangeComponent; }) }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoRangeContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-range-container', template: '', providers: [NestedOptionHost] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { backgroundColor: [{
                type: Input
            }], offset: [{
                type: Input
            }], orientation: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteExtensionMode: [{
                type: Input
            }], ranges: [{
                type: Input
            }], width: [{
                type: Input
            }], horizontalOrientation: [{
                type: Input
            }], verticalOrientation: [{
                type: Input
            }], rangesChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiRangeComponent)]
            }] } });
export class DxoRangeContainerModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoRangeContainerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoRangeContainerModule, declarations: [DxoRangeContainerComponent], exports: [DxoRangeContainerComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoRangeContainerModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoRangeContainerModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoRangeContainerComponent
                    ],
                    exports: [
                        DxoRangeContainerComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFuZ2UtY29udGFpbmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvcmFuZ2UtY29udGFpbmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBR3BDLE9BQU8sRUFDSCxTQUFTLEVBR1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1IsS0FBSyxFQUNMLGVBQWUsRUFDZixVQUFVLEVBQ1YsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBU3ZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sYUFBYSxDQUFDOzs7QUFTaEQsTUFBTSxPQUFPLDBCQUEyQixTQUFRLFlBQVk7SUFDeEQsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQTJCO1FBQzNDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBYTtRQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFzQztRQUNsRCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUF1QztRQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQsSUFDSSxvQkFBb0I7UUFDcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQUksb0JBQW9CLENBQUMsS0FBMkI7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUE0RjtRQUNuRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFnRDtRQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsSUFDSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBMEI7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQsSUFDSSxtQkFBbUI7UUFDbkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELElBQUksbUJBQW1CLENBQUMsS0FBd0I7UUFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBR0QsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sZ0JBQWdCLENBQUM7SUFDNUIsQ0FBQztJQUdELElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBSztRQUNwQixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBQ1IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUdELFFBQVE7UUFDSixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDOzJIQXJHUSwwQkFBMEI7K0dBQTFCLDBCQUEwQiw0VUFGeEIsQ0FBQyxnQkFBZ0IsQ0FBQyw0RkFpRkssaUJBQWlCLHdEQW5GekMsRUFBRTs7NEZBSUgsMEJBQTBCO2tCQU50QyxTQUFTOytCQUNJLHFCQUFxQixZQUNyQixFQUFFLGFBRUQsQ0FBQyxnQkFBZ0IsQ0FBQzs7MEJBeUZoQixRQUFROzswQkFBSSxJQUFJOzswQkFDcEIsSUFBSTs0Q0F0RlQsZUFBZTtzQkFEbEIsS0FBSztnQkFTRixNQUFNO3NCQURULEtBQUs7Z0JBU0YsV0FBVztzQkFEZCxLQUFLO2dCQVNGLE9BQU87c0JBRFYsS0FBSztnQkFTRixvQkFBb0I7c0JBRHZCLEtBQUs7Z0JBU0YsTUFBTTtzQkFEVCxLQUFLO2dCQVNGLEtBQUs7c0JBRFIsS0FBSztnQkFTRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBU0YsbUJBQW1CO3NCQUR0QixLQUFLO2dCQWVGLGNBQWM7c0JBRGpCLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDOztBQW1DeEQsTUFBTSxPQUFPLHVCQUF1QjsySEFBdkIsdUJBQXVCOzRIQUF2Qix1QkFBdUIsaUJBbEh2QiwwQkFBMEIsYUFBMUIsMEJBQTBCOzRIQWtIMUIsdUJBQXVCOzs0RkFBdkIsdUJBQXVCO2tCQVJuQyxRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWiwwQkFBMEI7cUJBQzNCO29CQUNELE9BQU8sRUFBRTt3QkFDUCwwQkFBMEI7cUJBQzNCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE9uSW5pdCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBTa2lwU2VsZixcbiAgICBJbnB1dCxcbiAgICBDb250ZW50Q2hpbGRyZW4sXG4gICAgZm9yd2FyZFJlZixcbiAgICBRdWVyeUxpc3Rcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cbmltcG9ydCB7IEhvcml6b250YWxBbGlnbm1lbnQsIFZlcnRpY2FsQWxpZ25tZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24nO1xuaW1wb3J0IHsgQ2hhcnRzQ29sb3IsIFBhbGV0dGUsIFBhbGV0dGVFeHRlbnNpb25Nb2RlIH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24vY2hhcnRzJztcbmltcG9ydCB7IENpcmN1bGFyR2F1Z2VFbGVtZW50T3JpZW50YXRpb24gfSBmcm9tICdkZXZleHRyZW1lL3Zpei9jaXJjdWxhcl9nYXVnZSc7XG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmVzdGVkT3B0aW9uIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhpUmFuZ2VDb21wb25lbnQgfSBmcm9tICcuL3JhbmdlLWR4aSc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeG8tcmFuZ2UtY29udGFpbmVyJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdXG59KVxuZXhwb3J0IGNsYXNzIER4b1JhbmdlQ29udGFpbmVyQ29tcG9uZW50IGV4dGVuZHMgTmVzdGVkT3B0aW9uIGltcGxlbWVudHMgT25EZXN0cm95LCBPbkluaXQgIHtcbiAgICBASW5wdXQoKVxuICAgIGdldCBiYWNrZ3JvdW5kQ29sb3IoKTogQ2hhcnRzQ29sb3IgfCBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdiYWNrZ3JvdW5kQ29sb3InKTtcbiAgICB9XG4gICAgc2V0IGJhY2tncm91bmRDb2xvcih2YWx1ZTogQ2hhcnRzQ29sb3IgfCBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdiYWNrZ3JvdW5kQ29sb3InLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgb2Zmc2V0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ29mZnNldCcpO1xuICAgIH1cbiAgICBzZXQgb2Zmc2V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdvZmZzZXQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgb3JpZW50YXRpb24oKTogQ2lyY3VsYXJHYXVnZUVsZW1lbnRPcmllbnRhdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ29yaWVudGF0aW9uJyk7XG4gICAgfVxuICAgIHNldCBvcmllbnRhdGlvbih2YWx1ZTogQ2lyY3VsYXJHYXVnZUVsZW1lbnRPcmllbnRhdGlvbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ29yaWVudGF0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBhbGV0dGUoKTogUGFsZXR0ZSB8IHN0cmluZyB8IEFycmF5PHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdwYWxldHRlJyk7XG4gICAgfVxuICAgIHNldCBwYWxldHRlKHZhbHVlOiBQYWxldHRlIHwgc3RyaW5nIHwgQXJyYXk8c3RyaW5nPikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BhbGV0dGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgcGFsZXR0ZUV4dGVuc2lvbk1vZGUoKTogUGFsZXR0ZUV4dGVuc2lvbk1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdwYWxldHRlRXh0ZW5zaW9uTW9kZScpO1xuICAgIH1cbiAgICBzZXQgcGFsZXR0ZUV4dGVuc2lvbk1vZGUodmFsdWU6IFBhbGV0dGVFeHRlbnNpb25Nb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncGFsZXR0ZUV4dGVuc2lvbk1vZGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgcmFuZ2VzKCk6IEFycmF5PGFueSB8IHsgY29sb3I/OiBDaGFydHNDb2xvciB8IHN0cmluZywgZW5kVmFsdWU/OiBudW1iZXIsIHN0YXJ0VmFsdWU/OiBudW1iZXIgfT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyYW5nZXMnKTtcbiAgICB9XG4gICAgc2V0IHJhbmdlcyh2YWx1ZTogQXJyYXk8YW55IHwgeyBjb2xvcj86IENoYXJ0c0NvbG9yIHwgc3RyaW5nLCBlbmRWYWx1ZT86IG51bWJlciwgc3RhcnRWYWx1ZT86IG51bWJlciB9Pikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3JhbmdlcycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCB3aWR0aCgpOiBudW1iZXIgfCB7IGVuZD86IG51bWJlciwgc3RhcnQ/OiBudW1iZXIgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3dpZHRoJyk7XG4gICAgfVxuICAgIHNldCB3aWR0aCh2YWx1ZTogbnVtYmVyIHwgeyBlbmQ/OiBudW1iZXIsIHN0YXJ0PzogbnVtYmVyIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd3aWR0aCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBob3Jpem9udGFsT3JpZW50YXRpb24oKTogSG9yaXpvbnRhbEFsaWdubWVudCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hvcml6b250YWxPcmllbnRhdGlvbicpO1xuICAgIH1cbiAgICBzZXQgaG9yaXpvbnRhbE9yaWVudGF0aW9uKHZhbHVlOiBIb3Jpem9udGFsQWxpZ25tZW50KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaG9yaXpvbnRhbE9yaWVudGF0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHZlcnRpY2FsT3JpZW50YXRpb24oKTogVmVydGljYWxBbGlnbm1lbnQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2ZXJ0aWNhbE9yaWVudGF0aW9uJyk7XG4gICAgfVxuICAgIHNldCB2ZXJ0aWNhbE9yaWVudGF0aW9uKHZhbHVlOiBWZXJ0aWNhbEFsaWdubWVudCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3ZlcnRpY2FsT3JpZW50YXRpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICBwcm90ZWN0ZWQgZ2V0IF9vcHRpb25QYXRoKCkge1xuICAgICAgICByZXR1cm4gJ3JhbmdlQ29udGFpbmVyJztcbiAgICB9XG5cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oZm9yd2FyZFJlZigoKSA9PiBEeGlSYW5nZUNvbXBvbmVudCkpXG4gICAgZ2V0IHJhbmdlc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlSYW5nZUNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyYW5nZXMnKTtcbiAgICB9XG4gICAgc2V0IHJhbmdlc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ3JhbmdlcycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLl9hZGRSZWNyZWF0ZWRDb21wb25lbnQoKTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVtb3ZlZE9wdGlvbih0aGlzLl9nZXRPcHRpb25QYXRoKCkpO1xuICAgIH1cblxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4b1JhbmdlQ29udGFpbmVyQ29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeG9SYW5nZUNvbnRhaW5lckNvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9SYW5nZUNvbnRhaW5lck1vZHVsZSB7IH1cbiJdfQ==