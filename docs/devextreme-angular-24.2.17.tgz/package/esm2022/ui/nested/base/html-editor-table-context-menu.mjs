/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoHtmlEditorTableContextMenu extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoHtmlEditorTableContextMenu, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoHtmlEditorTableContextMenu, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoHtmlEditorTableContextMenu, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHRtbC1lZGl0b3ItdGFibGUtY29udGV4dC1tZW51LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvYmFzZS9odG1sLWVkaXRvci10YWJsZS1jb250ZXh0LW1lbnUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3ZELE9BQU8sRUFDSCxTQUFTLEdBQ1osTUFBTSxlQUFlLENBQUM7O0FBT3ZCLE1BQU0sT0FBZ0IsNkJBQThCLFNBQVEsWUFBWTtJQUNwRSxJQUFJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELElBQUksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBK1Y7UUFDclcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQzsySEFiaUIsNkJBQTZCOytHQUE3Qiw2QkFBNkIsMkVBRnJDLEVBQUU7OzRGQUVNLDZCQUE2QjtrQkFIbEQsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsRUFBRTtpQkFDZiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuaW1wb3J0IHsgTmVzdGVkT3B0aW9uIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBIdG1sRWRpdG9yUHJlZGVmaW5lZENvbnRleHRNZW51SXRlbSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvaHRtbF9lZGl0b3InO1xuXG5AQ29tcG9uZW50KHtcbiAgICB0ZW1wbGF0ZTogJydcbn0pXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgRHhvSHRtbEVkaXRvclRhYmxlQ29udGV4dE1lbnUgZXh0ZW5kcyBOZXN0ZWRPcHRpb24ge1xuICAgIGdldCBlbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdlbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBlbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgaXRlbXMoKTogQXJyYXk8SHRtbEVkaXRvclByZWRlZmluZWRDb250ZXh0TWVudUl0ZW0gfCBhbnkgfCB7IGJlZ2luR3JvdXA/OiBib29sZWFuLCBjbG9zZU1lbnVPbkNsaWNrPzogYm9vbGVhbiwgZGlzYWJsZWQ/OiBib29sZWFuLCBpY29uPzogc3RyaW5nLCBpdGVtcz86IEFycmF5PEh0bWxFZGl0b3JQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIHwgYW55PiwgbmFtZT86IEh0bWxFZGl0b3JQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIHwgdW5kZWZpbmVkLCBzZWxlY3RhYmxlPzogYm9vbGVhbiwgc2VsZWN0ZWQ/OiBib29sZWFuLCB0ZW1wbGF0ZT86IGFueSwgdGV4dD86IHN0cmluZywgdmlzaWJsZT86IGJvb2xlYW4gfT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtcycpO1xuICAgIH1cbiAgICBzZXQgaXRlbXModmFsdWU6IEFycmF5PEh0bWxFZGl0b3JQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIHwgYW55IHwgeyBiZWdpbkdyb3VwPzogYm9vbGVhbiwgY2xvc2VNZW51T25DbGljaz86IGJvb2xlYW4sIGRpc2FibGVkPzogYm9vbGVhbiwgaWNvbj86IHN0cmluZywgaXRlbXM/OiBBcnJheTxIdG1sRWRpdG9yUHJlZGVmaW5lZENvbnRleHRNZW51SXRlbSB8IGFueT4sIG5hbWU/OiBIdG1sRWRpdG9yUHJlZGVmaW5lZENvbnRleHRNZW51SXRlbSB8IHVuZGVmaW5lZCwgc2VsZWN0YWJsZT86IGJvb2xlYW4sIHNlbGVjdGVkPzogYm9vbGVhbiwgdGVtcGxhdGU/OiBhbnksIHRleHQ/OiBzdHJpbmcsIHZpc2libGU/OiBib29sZWFuIH0+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaXRlbXMnLCB2YWx1ZSk7XG4gICAgfVxufVxuIl19