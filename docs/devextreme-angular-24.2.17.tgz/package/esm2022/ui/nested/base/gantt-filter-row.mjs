/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoGanttFilterRow extends NestedOption {
    get applyFilter() {
        return this._getOption('applyFilter');
    }
    set applyFilter(value) {
        this._setOption('applyFilter', value);
    }
    get applyFilterText() {
        return this._getOption('applyFilterText');
    }
    set applyFilterText(value) {
        this._setOption('applyFilterText', value);
    }
    get betweenEndText() {
        return this._getOption('betweenEndText');
    }
    set betweenEndText(value) {
        this._setOption('betweenEndText', value);
    }
    get betweenStartText() {
        return this._getOption('betweenStartText');
    }
    set betweenStartText(value) {
        this._setOption('betweenStartText', value);
    }
    get operationDescriptions() {
        return this._getOption('operationDescriptions');
    }
    set operationDescriptions(value) {
        this._setOption('operationDescriptions', value);
    }
    get resetOperationText() {
        return this._getOption('resetOperationText');
    }
    set resetOperationText(value) {
        this._setOption('resetOperationText', value);
    }
    get showAllText() {
        return this._getOption('showAllText');
    }
    set showAllText(value) {
        this._setOption('showAllText', value);
    }
    get showOperationChooser() {
        return this._getOption('showOperationChooser');
    }
    set showOperationChooser(value) {
        this._setOption('showOperationChooser', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoGanttFilterRow, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoGanttFilterRow, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoGanttFilterRow, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2FudHQtZmlsdGVyLXJvdy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2Jhc2UvZ2FudHQtZmlsdGVyLXJvdy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdkQsT0FBTyxFQUNILFNBQVMsR0FDWixNQUFNLGVBQWUsQ0FBQzs7QUFRdkIsTUFBTSxPQUFnQixpQkFBa0IsU0FBUSxZQUFZO0lBQ3hELElBQUksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBc0I7UUFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELElBQUksZUFBZTtRQUNmLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFDRCxJQUFJLGVBQWUsQ0FBQyxLQUFhO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELElBQUksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFhO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELElBQUksZ0JBQWdCO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQWE7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsSUFBSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBdVI7UUFDN1MsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQsSUFBSSxrQkFBa0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDakQsQ0FBQztJQUNELElBQUksa0JBQWtCLENBQUMsS0FBYTtRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFRCxJQUFJLFdBQVc7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUNELElBQUksV0FBVyxDQUFDLEtBQWE7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELElBQUksb0JBQW9CO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxJQUFJLG9CQUFvQixDQUFDLEtBQWM7UUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFBSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7MkhBOURpQixpQkFBaUI7K0dBQWpCLGlCQUFpQiwyRUFGekIsRUFBRTs7NEZBRU0saUJBQWlCO2tCQUh0QyxTQUFTO21CQUFDO29CQUNQLFFBQVEsRUFBRSxFQUFFO2lCQUNmIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG5pbXBvcnQgeyBOZXN0ZWRPcHRpb24gfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICAgIENvbXBvbmVudCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IEFwcGx5RmlsdGVyTW9kZSB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uL2dyaWRzJztcbmltcG9ydCB7IGR4R2FudHRGaWx0ZXJSb3dPcGVyYXRpb25EZXNjcmlwdGlvbnMgfSBmcm9tICdkZXZleHRyZW1lL3VpL2dhbnR0JztcblxuQENvbXBvbmVudCh7XG4gICAgdGVtcGxhdGU6ICcnXG59KVxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIER4b0dhbnR0RmlsdGVyUm93IGV4dGVuZHMgTmVzdGVkT3B0aW9uIHtcbiAgICBnZXQgYXBwbHlGaWx0ZXIoKTogQXBwbHlGaWx0ZXJNb2RlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYXBwbHlGaWx0ZXInKTtcbiAgICB9XG4gICAgc2V0IGFwcGx5RmlsdGVyKHZhbHVlOiBBcHBseUZpbHRlck1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhcHBseUZpbHRlcicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgYXBwbHlGaWx0ZXJUZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FwcGx5RmlsdGVyVGV4dCcpO1xuICAgIH1cbiAgICBzZXQgYXBwbHlGaWx0ZXJUZXh0KHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhcHBseUZpbHRlclRleHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGJldHdlZW5FbmRUZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2JldHdlZW5FbmRUZXh0Jyk7XG4gICAgfVxuICAgIHNldCBiZXR3ZWVuRW5kVGV4dCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmV0d2VlbkVuZFRleHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGJldHdlZW5TdGFydFRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYmV0d2VlblN0YXJ0VGV4dCcpO1xuICAgIH1cbiAgICBzZXQgYmV0d2VlblN0YXJ0VGV4dCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYmV0d2VlblN0YXJ0VGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgb3BlcmF0aW9uRGVzY3JpcHRpb25zKCk6IHsgYmV0d2Vlbj86IHN0cmluZywgY29udGFpbnM/OiBzdHJpbmcsIGVuZHNXaXRoPzogc3RyaW5nLCBlcXVhbD86IHN0cmluZywgZ3JlYXRlclRoYW4/OiBzdHJpbmcsIGdyZWF0ZXJUaGFuT3JFcXVhbD86IHN0cmluZywgbGVzc1RoYW4/OiBzdHJpbmcsIGxlc3NUaGFuT3JFcXVhbD86IHN0cmluZywgbm90Q29udGFpbnM/OiBzdHJpbmcsIG5vdEVxdWFsPzogc3RyaW5nLCBzdGFydHNXaXRoPzogc3RyaW5nIH0gfCBkeEdhbnR0RmlsdGVyUm93T3BlcmF0aW9uRGVzY3JpcHRpb25zIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb3BlcmF0aW9uRGVzY3JpcHRpb25zJyk7XG4gICAgfVxuICAgIHNldCBvcGVyYXRpb25EZXNjcmlwdGlvbnModmFsdWU6IHsgYmV0d2Vlbj86IHN0cmluZywgY29udGFpbnM/OiBzdHJpbmcsIGVuZHNXaXRoPzogc3RyaW5nLCBlcXVhbD86IHN0cmluZywgZ3JlYXRlclRoYW4/OiBzdHJpbmcsIGdyZWF0ZXJUaGFuT3JFcXVhbD86IHN0cmluZywgbGVzc1RoYW4/OiBzdHJpbmcsIGxlc3NUaGFuT3JFcXVhbD86IHN0cmluZywgbm90Q29udGFpbnM/OiBzdHJpbmcsIG5vdEVxdWFsPzogc3RyaW5nLCBzdGFydHNXaXRoPzogc3RyaW5nIH0gfCBkeEdhbnR0RmlsdGVyUm93T3BlcmF0aW9uRGVzY3JpcHRpb25zKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignb3BlcmF0aW9uRGVzY3JpcHRpb25zJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCByZXNldE9wZXJhdGlvblRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVzZXRPcGVyYXRpb25UZXh0Jyk7XG4gICAgfVxuICAgIHNldCByZXNldE9wZXJhdGlvblRleHQodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Jlc2V0T3BlcmF0aW9uVGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgc2hvd0FsbFRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd0FsbFRleHQnKTtcbiAgICB9XG4gICAgc2V0IHNob3dBbGxUZXh0KHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzaG93QWxsVGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgc2hvd09wZXJhdGlvbkNob29zZXIoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Nob3dPcGVyYXRpb25DaG9vc2VyJyk7XG4gICAgfVxuICAgIHNldCBzaG93T3BlcmF0aW9uQ2hvb3Nlcih2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Nob3dPcGVyYXRpb25DaG9vc2VyJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCB2aXNpYmxlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2aXNpYmxlJyk7XG4gICAgfVxuICAgIHNldCB2aXNpYmxlKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlzaWJsZScsIHZhbHVlKTtcbiAgICB9XG59XG4iXX0=