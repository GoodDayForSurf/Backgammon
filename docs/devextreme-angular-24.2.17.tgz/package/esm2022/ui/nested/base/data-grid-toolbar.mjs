/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoDataGridToolbar extends NestedOption {
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get fileSelectionItems() {
        return this._getOption('fileSelectionItems');
    }
    set fileSelectionItems(value) {
        this._setOption('fileSelectionItems', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get multiline() {
        return this._getOption('multiline');
    }
    set multiline(value) {
        this._setOption('multiline', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoDataGridToolbar, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoDataGridToolbar, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoDataGridToolbar, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YS1ncmlkLXRvb2xiYXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9iYXNlL2RhdGEtZ3JpZC10b29sYmFyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUN2RCxPQUFPLEVBQ0gsU0FBUyxHQUNaLE1BQU0sZUFBZSxDQUFDOztBQVl2QixNQUFNLE9BQWdCLGtCQUFtQixTQUFRLFlBQVk7SUFDekQsSUFBSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFjO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQXVTO1FBQzdTLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRCxJQUFJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQTBCO1FBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUFJLGtCQUFrQjtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsSUFBSSxrQkFBa0IsQ0FBQyxLQUF5RTtRQUM1RixJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFRCxJQUFJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQWtDO1FBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxJQUFJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQWM7UUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQzsySEF6Q2lCLGtCQUFrQjsrR0FBbEIsa0JBQWtCLDJFQUYxQixFQUFFOzs0RkFFTSxrQkFBa0I7a0JBSHZDLFNBQVM7bUJBQUM7b0JBQ1AsUUFBUSxFQUFFLEVBQUU7aUJBQ2YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbmltcG9ydCB7IE5lc3RlZE9wdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgVXNlckRlZmluZWRFbGVtZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS9jb3JlL2VsZW1lbnQnO1xuaW1wb3J0IHsgRGF0YUdyaWRQcmVkZWZpbmVkVG9vbGJhckl0ZW0sIGR4RGF0YUdyaWRUb29sYmFySXRlbSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvZGF0YV9ncmlkJztcbmltcG9ydCB7IGR4RmlsZU1hbmFnZXJUb29sYmFySXRlbSwgRmlsZU1hbmFnZXJQcmVkZWZpbmVkVG9vbGJhckl0ZW0gfSBmcm9tICdkZXZleHRyZW1lL3VpL2ZpbGVfbWFuYWdlcic7XG5pbXBvcnQgeyBkeEdhbnR0VG9vbGJhckl0ZW0sIEdhbnR0UHJlZGVmaW5lZFRvb2xiYXJJdGVtIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9nYW50dCc7XG5pbXBvcnQgeyBkeEh0bWxFZGl0b3JUb29sYmFySXRlbSwgSHRtbEVkaXRvclByZWRlZmluZWRUb29sYmFySXRlbSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvaHRtbF9lZGl0b3InO1xuaW1wb3J0IHsgZHhUcmVlTGlzdFRvb2xiYXJJdGVtLCBUcmVlTGlzdFByZWRlZmluZWRUb29sYmFySXRlbSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvdHJlZV9saXN0JztcblxuQENvbXBvbmVudCh7XG4gICAgdGVtcGxhdGU6ICcnXG59KVxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIER4b0RhdGFHcmlkVG9vbGJhciBleHRlbmRzIE5lc3RlZE9wdGlvbiB7XG4gICAgZ2V0IGRpc2FibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkaXNhYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgZGlzYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkaXNhYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgaXRlbXMoKTogQXJyYXk8ZHhEYXRhR3JpZFRvb2xiYXJJdGVtIHwgRGF0YUdyaWRQcmVkZWZpbmVkVG9vbGJhckl0ZW0gfCBkeEZpbGVNYW5hZ2VyVG9vbGJhckl0ZW0gfCBGaWxlTWFuYWdlclByZWRlZmluZWRUb29sYmFySXRlbSB8IGR4R2FudHRUb29sYmFySXRlbSB8IEdhbnR0UHJlZGVmaW5lZFRvb2xiYXJJdGVtIHwgZHhIdG1sRWRpdG9yVG9vbGJhckl0ZW0gfCBIdG1sRWRpdG9yUHJlZGVmaW5lZFRvb2xiYXJJdGVtIHwgZHhUcmVlTGlzdFRvb2xiYXJJdGVtIHwgVHJlZUxpc3RQcmVkZWZpbmVkVG9vbGJhckl0ZW0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaXRlbXMnKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1zKHZhbHVlOiBBcnJheTxkeERhdGFHcmlkVG9vbGJhckl0ZW0gfCBEYXRhR3JpZFByZWRlZmluZWRUb29sYmFySXRlbSB8IGR4RmlsZU1hbmFnZXJUb29sYmFySXRlbSB8IEZpbGVNYW5hZ2VyUHJlZGVmaW5lZFRvb2xiYXJJdGVtIHwgZHhHYW50dFRvb2xiYXJJdGVtIHwgR2FudHRQcmVkZWZpbmVkVG9vbGJhckl0ZW0gfCBkeEh0bWxFZGl0b3JUb29sYmFySXRlbSB8IEh0bWxFZGl0b3JQcmVkZWZpbmVkVG9vbGJhckl0ZW0gfCBkeFRyZWVMaXN0VG9vbGJhckl0ZW0gfCBUcmVlTGlzdFByZWRlZmluZWRUb29sYmFySXRlbT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtcycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgdmlzaWJsZSgpOiBib29sZWFuIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlzaWJsZScpO1xuICAgIH1cbiAgICBzZXQgdmlzaWJsZSh2YWx1ZTogYm9vbGVhbiB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Zpc2libGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGZpbGVTZWxlY3Rpb25JdGVtcygpOiBBcnJheTxkeEZpbGVNYW5hZ2VyVG9vbGJhckl0ZW0gfCBGaWxlTWFuYWdlclByZWRlZmluZWRUb29sYmFySXRlbT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdmaWxlU2VsZWN0aW9uSXRlbXMnKTtcbiAgICB9XG4gICAgc2V0IGZpbGVTZWxlY3Rpb25JdGVtcyh2YWx1ZTogQXJyYXk8ZHhGaWxlTWFuYWdlclRvb2xiYXJJdGVtIHwgRmlsZU1hbmFnZXJQcmVkZWZpbmVkVG9vbGJhckl0ZW0+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZmlsZVNlbGVjdGlvbkl0ZW1zJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCBjb250YWluZXIoKTogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29udGFpbmVyJyk7XG4gICAgfVxuICAgIHNldCBjb250YWluZXIodmFsdWU6IFVzZXJEZWZpbmVkRWxlbWVudCB8IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbnRhaW5lcicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgbXVsdGlsaW5lKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtdWx0aWxpbmUnKTtcbiAgICB9XG4gICAgc2V0IG11bHRpbGluZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ211bHRpbGluZScsIHZhbHVlKTtcbiAgICB9XG59XG4iXX0=