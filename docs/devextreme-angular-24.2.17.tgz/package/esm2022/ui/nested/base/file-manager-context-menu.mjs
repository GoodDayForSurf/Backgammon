/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoFileManagerContextMenu extends NestedOption {
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileManagerContextMenu, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoFileManagerContextMenu, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFileManagerContextMenu, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1tYW5hZ2VyLWNvbnRleHQtbWVudS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2Jhc2UvZmlsZS1tYW5hZ2VyLWNvbnRleHQtbWVudS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdkQsT0FBTyxFQUNILFNBQVMsR0FDWixNQUFNLGVBQWUsQ0FBQzs7QUFVdkIsTUFBTSxPQUFnQix5QkFBMEIsU0FBUSxZQUFZO0lBQ2hFLElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBcUM7UUFDOUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQUksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBYztRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFnWTtRQUN0WSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDOzJIQXBCaUIseUJBQXlCOytHQUF6Qix5QkFBeUIsMkVBRmpDLEVBQUU7OzRGQUVNLHlCQUF5QjtrQkFIOUMsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsRUFBRTtpQkFDZiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuaW1wb3J0IHsgTmVzdGVkT3B0aW9uIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBkeENvbnRleHRNZW51SXRlbSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvY29udGV4dF9tZW51JztcbmltcG9ydCB7IENvbW1hbmQsIEN1c3RvbUNvbW1hbmQgfSBmcm9tICdkZXZleHRyZW1lL3VpL2RpYWdyYW0nO1xuaW1wb3J0IHsgZHhGaWxlTWFuYWdlckNvbnRleHRNZW51SXRlbSwgRmlsZU1hbmFnZXJQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9maWxlX21hbmFnZXInO1xuaW1wb3J0IHsgR2FudHRQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9nYW50dCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHRlbXBsYXRlOiAnJ1xufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEeG9GaWxlTWFuYWdlckNvbnRleHRNZW51IGV4dGVuZHMgTmVzdGVkT3B0aW9uIHtcbiAgICBnZXQgY29tbWFuZHMoKTogQXJyYXk8Q3VzdG9tQ29tbWFuZCB8IENvbW1hbmQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29tbWFuZHMnKTtcbiAgICB9XG4gICAgc2V0IGNvbW1hbmRzKHZhbHVlOiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb21tYW5kcycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgZW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgZW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2VuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGl0ZW1zKCk6IEFycmF5PGR4RmlsZU1hbmFnZXJDb250ZXh0TWVudUl0ZW0gfCBGaWxlTWFuYWdlclByZWRlZmluZWRDb250ZXh0TWVudUl0ZW0gfCBHYW50dFByZWRlZmluZWRDb250ZXh0TWVudUl0ZW0gfCBhbnkgfCB7IGJlZ2luR3JvdXA/OiBib29sZWFuLCBjbG9zZU1lbnVPbkNsaWNrPzogYm9vbGVhbiwgZGlzYWJsZWQ/OiBib29sZWFuLCBpY29uPzogc3RyaW5nLCBpdGVtcz86IEFycmF5PGR4Q29udGV4dE1lbnVJdGVtPiwgbmFtZT86IEdhbnR0UHJlZGVmaW5lZENvbnRleHRNZW51SXRlbSB8IHN0cmluZywgc2VsZWN0YWJsZT86IGJvb2xlYW4sIHNlbGVjdGVkPzogYm9vbGVhbiwgdGVtcGxhdGU/OiBhbnksIHRleHQ/OiBzdHJpbmcsIHZpc2libGU/OiBib29sZWFuIH0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaXRlbXMnKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1zKHZhbHVlOiBBcnJheTxkeEZpbGVNYW5hZ2VyQ29udGV4dE1lbnVJdGVtIHwgRmlsZU1hbmFnZXJQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIHwgR2FudHRQcmVkZWZpbmVkQ29udGV4dE1lbnVJdGVtIHwgYW55IHwgeyBiZWdpbkdyb3VwPzogYm9vbGVhbiwgY2xvc2VNZW51T25DbGljaz86IGJvb2xlYW4sIGRpc2FibGVkPzogYm9vbGVhbiwgaWNvbj86IHN0cmluZywgaXRlbXM/OiBBcnJheTxkeENvbnRleHRNZW51SXRlbT4sIG5hbWU/OiBHYW50dFByZWRlZmluZWRDb250ZXh0TWVudUl0ZW0gfCBzdHJpbmcsIHNlbGVjdGFibGU/OiBib29sZWFuLCBzZWxlY3RlZD86IGJvb2xlYW4sIHRlbXBsYXRlPzogYW55LCB0ZXh0Pzogc3RyaW5nLCB2aXNpYmxlPzogYm9vbGVhbiB9Pikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2l0ZW1zJywgdmFsdWUpO1xuICAgIH1cbn1cbiJdfQ==