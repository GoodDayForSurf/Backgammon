/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoPositionConfig extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionConfig, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoPositionConfig, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionConfig, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9zaXRpb24tY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvYmFzZS9wb3NpdGlvbi1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3ZELE9BQU8sRUFDSCxTQUFTLEdBQ1osTUFBTSxlQUFlLENBQUM7O0FBU3ZCLE1BQU0sT0FBZ0IsaUJBQWtCLFNBQVEsWUFBWTtJQUN4RCxJQUFJLEVBQUU7UUFDRixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUNELElBQUksRUFBRSxDQUFDLEtBQTZFO1FBQ2hGLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQTJDO1FBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUFJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBMEM7UUFDekQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFBSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUE0RjtRQUN0RyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsSUFBSSxFQUFFO1FBQ0YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxJQUFJLEVBQUUsQ0FBQyxLQUE2RTtRQUNoRixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsSUFBSSxFQUFFO1FBQ0YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxJQUFJLEVBQUUsQ0FBQyxLQUEyQztRQUM5QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsSUFBSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUEwQztRQUNqRCxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDOzJIQWhEaUIsaUJBQWlCOytHQUFqQixpQkFBaUIsMkVBRnpCLEVBQUU7OzRGQUVNLGlCQUFpQjtrQkFIdEMsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsRUFBRTtpQkFDZiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuaW1wb3J0IHsgTmVzdGVkT3B0aW9uIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBDb2xsaXNpb25SZXNvbHV0aW9uLCBDb2xsaXNpb25SZXNvbHV0aW9uQ29tYmluYXRpb24gfSBmcm9tICdkZXZleHRyZW1lL2FuaW1hdGlvbi9wb3NpdGlvbic7XG5pbXBvcnQgeyBIb3Jpem9udGFsQWxpZ25tZW50LCBQb3NpdGlvbkFsaWdubWVudCwgVmVydGljYWxBbGlnbm1lbnQgfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbic7XG5pbXBvcnQgeyBVc2VyRGVmaW5lZEVsZW1lbnQgfSBmcm9tICdkZXZleHRyZW1lL2NvcmUvZWxlbWVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHRlbXBsYXRlOiAnJ1xufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEeG9Qb3NpdGlvbkNvbmZpZyBleHRlbmRzIE5lc3RlZE9wdGlvbiB7XG4gICAgZ2V0IGF0KCk6IFBvc2l0aW9uQWxpZ25tZW50IHwgeyB4PzogSG9yaXpvbnRhbEFsaWdubWVudCwgeT86IFZlcnRpY2FsQWxpZ25tZW50IH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhdCcpO1xuICAgIH1cbiAgICBzZXQgYXQodmFsdWU6IFBvc2l0aW9uQWxpZ25tZW50IHwgeyB4PzogSG9yaXpvbnRhbEFsaWdubWVudCwgeT86IFZlcnRpY2FsQWxpZ25tZW50IH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhdCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgYm91bmRhcnkoKTogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgV2luZG93IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYm91bmRhcnknKTtcbiAgICB9XG4gICAgc2V0IGJvdW5kYXJ5KHZhbHVlOiBVc2VyRGVmaW5lZEVsZW1lbnQgfCBzdHJpbmcgfCBXaW5kb3cpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdib3VuZGFyeScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgYm91bmRhcnlPZmZzZXQoKTogc3RyaW5nIHwgeyB4PzogbnVtYmVyLCB5PzogbnVtYmVyIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdib3VuZGFyeU9mZnNldCcpO1xuICAgIH1cbiAgICBzZXQgYm91bmRhcnlPZmZzZXQodmFsdWU6IHN0cmluZyB8IHsgeD86IG51bWJlciwgeT86IG51bWJlciB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYm91bmRhcnlPZmZzZXQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGNvbGxpc2lvbigpOiBDb2xsaXNpb25SZXNvbHV0aW9uQ29tYmluYXRpb24gfCB7IHg/OiBDb2xsaXNpb25SZXNvbHV0aW9uLCB5PzogQ29sbGlzaW9uUmVzb2x1dGlvbiB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29sbGlzaW9uJyk7XG4gICAgfVxuICAgIHNldCBjb2xsaXNpb24odmFsdWU6IENvbGxpc2lvblJlc29sdXRpb25Db21iaW5hdGlvbiB8IHsgeD86IENvbGxpc2lvblJlc29sdXRpb24sIHk/OiBDb2xsaXNpb25SZXNvbHV0aW9uIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb2xsaXNpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IG15KCk6IFBvc2l0aW9uQWxpZ25tZW50IHwgeyB4PzogSG9yaXpvbnRhbEFsaWdubWVudCwgeT86IFZlcnRpY2FsQWxpZ25tZW50IH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdteScpO1xuICAgIH1cbiAgICBzZXQgbXkodmFsdWU6IFBvc2l0aW9uQWxpZ25tZW50IHwgeyB4PzogSG9yaXpvbnRhbEFsaWdubWVudCwgeT86IFZlcnRpY2FsQWxpZ25tZW50IH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdteScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgb2YoKTogVXNlckRlZmluZWRFbGVtZW50IHwgc3RyaW5nIHwgV2luZG93IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb2YnKTtcbiAgICB9XG4gICAgc2V0IG9mKHZhbHVlOiBVc2VyRGVmaW5lZEVsZW1lbnQgfCBzdHJpbmcgfCBXaW5kb3cpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdvZicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgb2Zmc2V0KCk6IHN0cmluZyB8IHsgeD86IG51bWJlciwgeT86IG51bWJlciB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb2Zmc2V0Jyk7XG4gICAgfVxuICAgIHNldCBvZmZzZXQodmFsdWU6IHN0cmluZyB8IHsgeD86IG51bWJlciwgeT86IG51bWJlciB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignb2Zmc2V0JywgdmFsdWUpO1xuICAgIH1cbn1cbiJdfQ==