/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoHtmlEditorImageUpload extends NestedOption {
    get fileUploaderOptions() {
        return this._getOption('fileUploaderOptions');
    }
    set fileUploaderOptions(value) {
        this._setOption('fileUploaderOptions', value);
    }
    get fileUploadMode() {
        return this._getOption('fileUploadMode');
    }
    set fileUploadMode(value) {
        this._setOption('fileUploadMode', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get uploadDirectory() {
        return this._getOption('uploadDirectory');
    }
    set uploadDirectory(value) {
        this._setOption('uploadDirectory', value);
    }
    get uploadUrl() {
        return this._getOption('uploadUrl');
    }
    set uploadUrl(value) {
        this._setOption('uploadUrl', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoHtmlEditorImageUpload, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoHtmlEditorImageUpload, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoHtmlEditorImageUpload, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHRtbC1lZGl0b3ItaW1hZ2UtdXBsb2FkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvYmFzZS9odG1sLWVkaXRvci1pbWFnZS11cGxvYWQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3ZELE9BQU8sRUFDSCxTQUFTLEdBQ1osTUFBTSxlQUFlLENBQUM7O0FBUXZCLE1BQU0sT0FBZ0Isd0JBQXlCLFNBQVEsWUFBWTtJQUMvRCxJQUFJLG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBSSxtQkFBbUIsQ0FBQyxLQUE0QjtRQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCxJQUFJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBZ0M7UUFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFBSSxJQUFJO1FBQ0osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxLQUF1RTtRQUM1RSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRUQsSUFBSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQXlCO1FBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELElBQUksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBeUI7UUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQzsySEFsQ2lCLHdCQUF3QjsrR0FBeEIsd0JBQXdCLDJFQUZoQyxFQUFFOzs0RkFFTSx3QkFBd0I7a0JBSDdDLFNBQVM7bUJBQUM7b0JBQ1AsUUFBUSxFQUFFLEVBQUU7aUJBQ2YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbmltcG9ydCB7IE5lc3RlZE9wdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgZHhGaWxlVXBsb2FkZXJPcHRpb25zIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9maWxlX3VwbG9hZGVyJztcbmltcG9ydCB7IGR4SHRtbEVkaXRvckltYWdlVXBsb2FkVGFiSXRlbSwgSHRtbEVkaXRvckltYWdlVXBsb2FkTW9kZSwgSHRtbEVkaXRvckltYWdlVXBsb2FkVGFiIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9odG1sX2VkaXRvcic7XG5cbkBDb21wb25lbnQoe1xuICAgIHRlbXBsYXRlOiAnJ1xufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEeG9IdG1sRWRpdG9ySW1hZ2VVcGxvYWQgZXh0ZW5kcyBOZXN0ZWRPcHRpb24ge1xuICAgIGdldCBmaWxlVXBsb2FkZXJPcHRpb25zKCk6IGR4RmlsZVVwbG9hZGVyT3B0aW9ucyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2ZpbGVVcGxvYWRlck9wdGlvbnMnKTtcbiAgICB9XG4gICAgc2V0IGZpbGVVcGxvYWRlck9wdGlvbnModmFsdWU6IGR4RmlsZVVwbG9hZGVyT3B0aW9ucykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2ZpbGVVcGxvYWRlck9wdGlvbnMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGZpbGVVcGxvYWRNb2RlKCk6IEh0bWxFZGl0b3JJbWFnZVVwbG9hZE1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdmaWxlVXBsb2FkTW9kZScpO1xuICAgIH1cbiAgICBzZXQgZmlsZVVwbG9hZE1vZGUodmFsdWU6IEh0bWxFZGl0b3JJbWFnZVVwbG9hZE1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdmaWxlVXBsb2FkTW9kZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgdGFicygpOiBBcnJheTxkeEh0bWxFZGl0b3JJbWFnZVVwbG9hZFRhYkl0ZW0gfCBIdG1sRWRpdG9ySW1hZ2VVcGxvYWRUYWI+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFicycpO1xuICAgIH1cbiAgICBzZXQgdGFicyh2YWx1ZTogQXJyYXk8ZHhIdG1sRWRpdG9ySW1hZ2VVcGxvYWRUYWJJdGVtIHwgSHRtbEVkaXRvckltYWdlVXBsb2FkVGFiPikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RhYnMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IHVwbG9hZERpcmVjdG9yeSgpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd1cGxvYWREaXJlY3RvcnknKTtcbiAgICB9XG4gICAgc2V0IHVwbG9hZERpcmVjdG9yeSh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndXBsb2FkRGlyZWN0b3J5JywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCB1cGxvYWRVcmwoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndXBsb2FkVXJsJyk7XG4gICAgfVxuICAgIHNldCB1cGxvYWRVcmwodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3VwbG9hZFVybCcsIHZhbHVlKTtcbiAgICB9XG59XG4iXX0=