/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { CollectionNestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxiFileManagerToolbarItem extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileManagerToolbarItem, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiFileManagerToolbarItem, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFileManagerToolbarItem, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1tYW5hZ2VyLXRvb2xiYXItaXRlbS1keGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9iYXNlL2ZpbGUtbWFuYWdlci10b29sYmFyLWl0ZW0tZHhpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ2pFLE9BQU8sRUFDSCxTQUFTLEdBQ1osTUFBTSxlQUFlLENBQUM7O0FBU3ZCLE1BQU0sT0FBZ0IseUJBQTBCLFNBQVEsc0JBQXNCO0lBQzFFLElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBeUI7UUFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYztRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsSUFBSSxJQUFJO1FBQ0osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxLQUFhO1FBQ2xCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxJQUFJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQXVCO1FBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQTBCO1FBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUFJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQWdEO1FBQ3JELElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxJQUFJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQVU7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELElBQUksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBbUI7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQUksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRUQsSUFBSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUEwQjtRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQsSUFBSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUEyQjtRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDOzJIQTVFaUIseUJBQXlCOytHQUF6Qix5QkFBeUIsMkVBRmpDLEVBQUU7OzRGQUVNLHlCQUF5QjtrQkFIOUMsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsRUFBRTtpQkFDZiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuaW1wb3J0IHsgQ29sbGVjdGlvbk5lc3RlZE9wdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgVG9vbGJhckl0ZW1Db21wb25lbnQsIFRvb2xiYXJJdGVtTG9jYXRpb24gfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbic7XG5pbXBvcnQgeyBGaWxlTWFuYWdlclByZWRlZmluZWRUb29sYmFySXRlbSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvZmlsZV9tYW5hZ2VyJztcbmltcG9ydCB7IExvY2F0ZUluTWVudU1vZGUsIFNob3dUZXh0TW9kZSB9IGZyb20gJ2RldmV4dHJlbWUvdWkvdG9vbGJhcic7XG5cbkBDb21wb25lbnQoe1xuICAgIHRlbXBsYXRlOiAnJ1xufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEeGlGaWxlTWFuYWdlclRvb2xiYXJJdGVtIGV4dGVuZHMgQ29sbGVjdGlvbk5lc3RlZE9wdGlvbiB7XG4gICAgZ2V0IGNzc0NsYXNzKCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Nzc0NsYXNzJyk7XG4gICAgfVxuICAgIHNldCBjc3NDbGFzcyh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY3NzQ2xhc3MnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IGRpc2FibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkaXNhYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgZGlzYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkaXNhYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgaWNvbigpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpY29uJyk7XG4gICAgfVxuICAgIHNldCBpY29uKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpY29uJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCBsb2NhdGVJbk1lbnUoKTogTG9jYXRlSW5NZW51TW9kZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2xvY2F0ZUluTWVudScpO1xuICAgIH1cbiAgICBzZXQgbG9jYXRlSW5NZW51KHZhbHVlOiBMb2NhdGVJbk1lbnVNb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbG9jYXRlSW5NZW51JywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCBsb2NhdGlvbigpOiBUb29sYmFySXRlbUxvY2F0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbG9jYXRpb24nKTtcbiAgICB9XG4gICAgc2V0IGxvY2F0aW9uKHZhbHVlOiBUb29sYmFySXRlbUxvY2F0aW9uKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbG9jYXRpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IG5hbWUoKTogRmlsZU1hbmFnZXJQcmVkZWZpbmVkVG9vbGJhckl0ZW0gfCBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCduYW1lJyk7XG4gICAgfVxuICAgIHNldCBuYW1lKHZhbHVlOiBGaWxlTWFuYWdlclByZWRlZmluZWRUb29sYmFySXRlbSB8IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ25hbWUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IG9wdGlvbnMoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb3B0aW9ucycpO1xuICAgIH1cbiAgICBzZXQgb3B0aW9ucyh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignb3B0aW9ucycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgc2hvd1RleHQoKTogU2hvd1RleHRNb2RlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd1RleHQnKTtcbiAgICB9XG4gICAgc2V0IHNob3dUZXh0KHZhbHVlOiBTaG93VGV4dE1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzaG93VGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgdGV4dCgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0ZXh0Jyk7XG4gICAgfVxuICAgIHNldCB0ZXh0KHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0ZXh0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCB2aXNpYmxlKCk6IGJvb2xlYW4gfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2aXNpYmxlJyk7XG4gICAgfVxuICAgIHNldCB2aXNpYmxlKHZhbHVlOiBib29sZWFuIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlzaWJsZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgd2lkZ2V0KCk6IFRvb2xiYXJJdGVtQ29tcG9uZW50IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignd2lkZ2V0Jyk7XG4gICAgfVxuICAgIHNldCB3aWRnZXQodmFsdWU6IFRvb2xiYXJJdGVtQ29tcG9uZW50KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignd2lkZ2V0JywgdmFsdWUpO1xuICAgIH1cbn1cbiJdfQ==