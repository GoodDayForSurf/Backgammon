/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NestedOption } from 'devextreme-angular/core';
import { Component, } from '@angular/core';
import * as i0 from "@angular/core";
export class DxoSchedulerScrolling extends NestedOption {
    get columnRenderingMode() {
        return this._getOption('columnRenderingMode');
    }
    set columnRenderingMode(value) {
        this._setOption('columnRenderingMode', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get preloadEnabled() {
        return this._getOption('preloadEnabled');
    }
    set preloadEnabled(value) {
        this._setOption('preloadEnabled', value);
    }
    get renderAsync() {
        return this._getOption('renderAsync');
    }
    set renderAsync(value) {
        this._setOption('renderAsync', value);
    }
    get rowRenderingMode() {
        return this._getOption('rowRenderingMode');
    }
    set rowRenderingMode(value) {
        this._setOption('rowRenderingMode', value);
    }
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    get scrollByThumb() {
        return this._getOption('scrollByThumb');
    }
    set scrollByThumb(value) {
        this._setOption('scrollByThumb', value);
    }
    get showScrollbar() {
        return this._getOption('showScrollbar');
    }
    set showScrollbar(value) {
        this._setOption('showScrollbar', value);
    }
    get useNative() {
        return this._getOption('useNative');
    }
    set useNative(value) {
        this._setOption('useNative', value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoSchedulerScrolling, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoSchedulerScrolling, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoSchedulerScrolling, decorators: [{
            type: Component,
            args: [{
                    template: ''
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2NoZWR1bGVyLXNjcm9sbGluZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2Jhc2Uvc2NoZWR1bGVyLXNjcm9sbGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdkQsT0FBTyxFQUNILFNBQVMsR0FDWixNQUFNLGVBQWUsQ0FBQzs7QUFTdkIsTUFBTSxPQUFnQixxQkFBc0IsU0FBUSxZQUFZO0lBQzVELElBQUksbUJBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFJLG1CQUFtQixDQUFDLEtBQXFCO1FBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELElBQUksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBc0M7UUFDM0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVELElBQUksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFjO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELElBQUksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBMEI7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELElBQUksZ0JBQWdCO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQXFCO1FBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELElBQUksZUFBZTtRQUNmLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFDRCxJQUFJLGVBQWUsQ0FBQyxLQUFjO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELElBQUksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFBSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFvQjtRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFBSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFxQjtRQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDOzJIQTlEaUIscUJBQXFCOytHQUFyQixxQkFBcUIsMkVBRjdCLEVBQUU7OzRGQUVNLHFCQUFxQjtrQkFIMUMsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsRUFBRTtpQkFDZiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuaW1wb3J0IHsgTmVzdGVkT3B0aW9uIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBNb2RlLCBTY3JvbGxiYXJNb2RlLCBTY3JvbGxNb2RlIH0gZnJvbSAnZGV2ZXh0cmVtZS9jb21tb24nO1xuaW1wb3J0IHsgRGF0YVJlbmRlck1vZGUgfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbi9ncmlkcyc7XG5pbXBvcnQgeyBEYXRhR3JpZFNjcm9sbE1vZGUgfSBmcm9tICdkZXZleHRyZW1lL3VpL2RhdGFfZ3JpZCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHRlbXBsYXRlOiAnJ1xufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEeG9TY2hlZHVsZXJTY3JvbGxpbmcgZXh0ZW5kcyBOZXN0ZWRPcHRpb24ge1xuICAgIGdldCBjb2x1bW5SZW5kZXJpbmdNb2RlKCk6IERhdGFSZW5kZXJNb2RlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29sdW1uUmVuZGVyaW5nTW9kZScpO1xuICAgIH1cbiAgICBzZXQgY29sdW1uUmVuZGVyaW5nTW9kZSh2YWx1ZTogRGF0YVJlbmRlck1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb2x1bW5SZW5kZXJpbmdNb2RlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCBtb2RlKCk6IERhdGFHcmlkU2Nyb2xsTW9kZSB8IFNjcm9sbE1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtb2RlJyk7XG4gICAgfVxuICAgIHNldCBtb2RlKHZhbHVlOiBEYXRhR3JpZFNjcm9sbE1vZGUgfCBTY3JvbGxNb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbW9kZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgcHJlbG9hZEVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ByZWxvYWRFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBwcmVsb2FkRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3ByZWxvYWRFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCByZW5kZXJBc3luYygpOiBib29sZWFuIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVuZGVyQXN5bmMnKTtcbiAgICB9XG4gICAgc2V0IHJlbmRlckFzeW5jKHZhbHVlOiBib29sZWFuIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncmVuZGVyQXN5bmMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IHJvd1JlbmRlcmluZ01vZGUoKTogRGF0YVJlbmRlck1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyb3dSZW5kZXJpbmdNb2RlJyk7XG4gICAgfVxuICAgIHNldCByb3dSZW5kZXJpbmdNb2RlKHZhbHVlOiBEYXRhUmVuZGVyTW9kZSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Jvd1JlbmRlcmluZ01vZGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IHNjcm9sbEJ5Q29udGVudCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2Nyb2xsQnlDb250ZW50Jyk7XG4gICAgfVxuICAgIHNldCBzY3JvbGxCeUNvbnRlbnQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzY3JvbGxCeUNvbnRlbnQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgZ2V0IHNjcm9sbEJ5VGh1bWIoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Njcm9sbEJ5VGh1bWInKTtcbiAgICB9XG4gICAgc2V0IHNjcm9sbEJ5VGh1bWIodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzY3JvbGxCeVRodW1iJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGdldCBzaG93U2Nyb2xsYmFyKCk6IFNjcm9sbGJhck1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaG93U2Nyb2xsYmFyJyk7XG4gICAgfVxuICAgIHNldCBzaG93U2Nyb2xsYmFyKHZhbHVlOiBTY3JvbGxiYXJNb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd1Njcm9sbGJhcicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgdXNlTmF0aXZlKCk6IE1vZGUgfCBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndXNlTmF0aXZlJyk7XG4gICAgfVxuICAgIHNldCB1c2VOYXRpdmUodmFsdWU6IE1vZGUgfCBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndXNlTmF0aXZlJywgdmFsdWUpO1xuICAgIH1cbn1cbiJdfQ==