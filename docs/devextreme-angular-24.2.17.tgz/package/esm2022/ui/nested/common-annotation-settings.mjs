/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoChartCommonAnnotationConfig } from './base/chart-common-annotation-config';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoCommonAnnotationSettingsComponent extends DxoChartCommonAnnotationConfig {
    get _optionPath() {
        return 'commonAnnotationSettings';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonAnnotationSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoCommonAnnotationSettingsComponent, selector: "dxo-common-annotation-settings", inputs: { allowDragging: "allowDragging", argument: "argument", arrowLength: "arrowLength", arrowWidth: "arrowWidth", axis: "axis", border: "border", color: "color", customizeTooltip: "customizeTooltip", data: "data", description: "description", font: "font", height: "height", image: "image", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", series: "series", shadow: "shadow", template: "template", text: "text", textOverflow: "textOverflow", tooltipEnabled: "tooltipEnabled", tooltipTemplate: "tooltipTemplate", type: "type", value: "value", width: "width", wordWrap: "wordWrap", x: "x", y: "y", location: "location", angle: "angle", radius: "radius", coordinates: "coordinates" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonAnnotationSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-common-annotation-settings', template: '', providers: [NestedOptionHost], inputs: [
                        'allowDragging',
                        'argument',
                        'arrowLength',
                        'arrowWidth',
                        'axis',
                        'border',
                        'color',
                        'customizeTooltip',
                        'data',
                        'description',
                        'font',
                        'height',
                        'image',
                        'offsetX',
                        'offsetY',
                        'opacity',
                        'paddingLeftRight',
                        'paddingTopBottom',
                        'series',
                        'shadow',
                        'template',
                        'text',
                        'textOverflow',
                        'tooltipEnabled',
                        'tooltipTemplate',
                        'type',
                        'value',
                        'width',
                        'wordWrap',
                        'x',
                        'y',
                        'location',
                        'angle',
                        'radius',
                        'coordinates'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoCommonAnnotationSettingsModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonAnnotationSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonAnnotationSettingsModule, declarations: [DxoCommonAnnotationSettingsComponent], exports: [DxoCommonAnnotationSettingsComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonAnnotationSettingsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonAnnotationSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoCommonAnnotationSettingsComponent
                    ],
                    exports: [
                        DxoCommonAnnotationSettingsComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLWFubm90YXRpb24tc2V0dGluZ3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9jb21tb24tYW5ub3RhdGlvbi1zZXR0aW5ncy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFHVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFFBQVEsRUFDWCxNQUFNLGVBQWUsQ0FBQztBQU12QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLDhCQUE4QixFQUFFLE1BQU0sdUNBQXVDLENBQUM7OztBQThDdkYsTUFBTSxPQUFPLG9DQUFxQyxTQUFRLDhCQUE4QjtJQUVwRixJQUFjLFdBQVc7UUFDckIsT0FBTywwQkFBMEIsQ0FBQztJQUN0QyxDQUFDO0lBR0QsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBQ1IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUdELFFBQVE7UUFDSixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDOzJIQXJCUSxvQ0FBb0M7K0dBQXBDLG9DQUFvQyw2ekJBdkNsQyxDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkF5Q0gsb0NBQW9DO2tCQTNDaEQsU0FBUzsrQkFDSSxnQ0FBZ0MsWUFDaEMsRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUMsVUFDckI7d0JBQ0osZUFBZTt3QkFDZixVQUFVO3dCQUNWLGFBQWE7d0JBQ2IsWUFBWTt3QkFDWixNQUFNO3dCQUNOLFFBQVE7d0JBQ1IsT0FBTzt3QkFDUCxrQkFBa0I7d0JBQ2xCLE1BQU07d0JBQ04sYUFBYTt3QkFDYixNQUFNO3dCQUNOLFFBQVE7d0JBQ1IsT0FBTzt3QkFDUCxTQUFTO3dCQUNULFNBQVM7d0JBQ1QsU0FBUzt3QkFDVCxrQkFBa0I7d0JBQ2xCLGtCQUFrQjt3QkFDbEIsUUFBUTt3QkFDUixRQUFRO3dCQUNSLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsaUJBQWlCO3dCQUNqQixNQUFNO3dCQUNOLE9BQU87d0JBQ1AsT0FBTzt3QkFDUCxVQUFVO3dCQUNWLEdBQUc7d0JBQ0gsR0FBRzt3QkFDSCxVQUFVO3dCQUNWLE9BQU87d0JBQ1AsUUFBUTt3QkFDUixhQUFhO3FCQUNoQjs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBMEJqQixNQUFNLE9BQU8saUNBQWlDOzJIQUFqQyxpQ0FBaUM7NEhBQWpDLGlDQUFpQyxpQkFsQ2pDLG9DQUFvQyxhQUFwQyxvQ0FBb0M7NEhBa0NwQyxpQ0FBaUM7OzRGQUFqQyxpQ0FBaUM7a0JBUjdDLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLG9DQUFvQztxQkFDckM7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLG9DQUFvQztxQkFDckM7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgT25Jbml0LFxuICAgIE9uRGVzdHJveSxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIFNraXBTZWxmXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cblxuXG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhvQ2hhcnRDb21tb25Bbm5vdGF0aW9uQ29uZmlnIH0gZnJvbSAnLi9iYXNlL2NoYXJ0LWNvbW1vbi1hbm5vdGF0aW9uLWNvbmZpZyc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeG8tY29tbW9uLWFubm90YXRpb24tc2V0dGluZ3MnLFxuICAgIHRlbXBsYXRlOiAnJyxcbiAgICBzdHlsZXM6IFsnJ10sXG4gICAgcHJvdmlkZXJzOiBbTmVzdGVkT3B0aW9uSG9zdF0sXG4gICAgaW5wdXRzOiBbXG4gICAgICAgICdhbGxvd0RyYWdnaW5nJyxcbiAgICAgICAgJ2FyZ3VtZW50JyxcbiAgICAgICAgJ2Fycm93TGVuZ3RoJyxcbiAgICAgICAgJ2Fycm93V2lkdGgnLFxuICAgICAgICAnYXhpcycsXG4gICAgICAgICdib3JkZXInLFxuICAgICAgICAnY29sb3InLFxuICAgICAgICAnY3VzdG9taXplVG9vbHRpcCcsXG4gICAgICAgICdkYXRhJyxcbiAgICAgICAgJ2Rlc2NyaXB0aW9uJyxcbiAgICAgICAgJ2ZvbnQnLFxuICAgICAgICAnaGVpZ2h0JyxcbiAgICAgICAgJ2ltYWdlJyxcbiAgICAgICAgJ29mZnNldFgnLFxuICAgICAgICAnb2Zmc2V0WScsXG4gICAgICAgICdvcGFjaXR5JyxcbiAgICAgICAgJ3BhZGRpbmdMZWZ0UmlnaHQnLFxuICAgICAgICAncGFkZGluZ1RvcEJvdHRvbScsXG4gICAgICAgICdzZXJpZXMnLFxuICAgICAgICAnc2hhZG93JyxcbiAgICAgICAgJ3RlbXBsYXRlJyxcbiAgICAgICAgJ3RleHQnLFxuICAgICAgICAndGV4dE92ZXJmbG93JyxcbiAgICAgICAgJ3Rvb2x0aXBFbmFibGVkJyxcbiAgICAgICAgJ3Rvb2x0aXBUZW1wbGF0ZScsXG4gICAgICAgICd0eXBlJyxcbiAgICAgICAgJ3ZhbHVlJyxcbiAgICAgICAgJ3dpZHRoJyxcbiAgICAgICAgJ3dvcmRXcmFwJyxcbiAgICAgICAgJ3gnLFxuICAgICAgICAneScsXG4gICAgICAgICdsb2NhdGlvbicsXG4gICAgICAgICdhbmdsZScsXG4gICAgICAgICdyYWRpdXMnLFxuICAgICAgICAnY29vcmRpbmF0ZXMnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeG9Db21tb25Bbm5vdGF0aW9uU2V0dGluZ3NDb21wb25lbnQgZXh0ZW5kcyBEeG9DaGFydENvbW1vbkFubm90YXRpb25Db25maWcgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uSW5pdCAge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdjb21tb25Bbm5vdGF0aW9uU2V0dGluZ3MnO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9Db21tb25Bbm5vdGF0aW9uU2V0dGluZ3NDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4b0NvbW1vbkFubm90YXRpb25TZXR0aW5nc0NvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9Db21tb25Bbm5vdGF0aW9uU2V0dGluZ3NNb2R1bGUgeyB9XG4iXX0=