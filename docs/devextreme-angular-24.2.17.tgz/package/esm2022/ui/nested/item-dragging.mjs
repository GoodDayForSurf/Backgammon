/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoSortableOptions } from './base/sortable-options';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoItemDraggingComponent extends DxoSortableOptions {
    get _optionPath() {
        return 'itemDragging';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoItemDraggingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoItemDraggingComponent, selector: "dxo-item-dragging", inputs: { allowDropInsideItem: "allowDropInsideItem", allowReordering: "allowReordering", autoScroll: "autoScroll", boundary: "boundary", container: "container", cursorOffset: "cursorOffset", data: "data", dragDirection: "dragDirection", dragTemplate: "dragTemplate", dropFeedbackMode: "dropFeedbackMode", elementAttr: "elementAttr", filter: "filter", group: "group", handle: "handle", height: "height", itemOrientation: "itemOrientation", moveItemOnDrop: "moveItemOnDrop", onAdd: "onAdd", onDisposing: "onDisposing", onDragChange: "onDragChange", onDragEnd: "onDragEnd", onDragMove: "onDragMove", onDragStart: "onDragStart", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onRemove: "onRemove", onReorder: "onReorder", rtlEnabled: "rtlEnabled", scrollSensitivity: "scrollSensitivity", scrollSpeed: "scrollSpeed", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoItemDraggingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-item-dragging', template: '', providers: [NestedOptionHost], inputs: [
                        'allowDropInsideItem',
                        'allowReordering',
                        'autoScroll',
                        'boundary',
                        'container',
                        'cursorOffset',
                        'data',
                        'dragDirection',
                        'dragTemplate',
                        'dropFeedbackMode',
                        'elementAttr',
                        'filter',
                        'group',
                        'handle',
                        'height',
                        'itemOrientation',
                        'moveItemOnDrop',
                        'onAdd',
                        'onDisposing',
                        'onDragChange',
                        'onDragEnd',
                        'onDragMove',
                        'onDragStart',
                        'onInitialized',
                        'onOptionChanged',
                        'onRemove',
                        'onReorder',
                        'rtlEnabled',
                        'scrollSensitivity',
                        'scrollSpeed',
                        'width'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoItemDraggingModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoItemDraggingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoItemDraggingModule, declarations: [DxoItemDraggingComponent], exports: [DxoItemDraggingComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoItemDraggingModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoItemDraggingModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoItemDraggingComponent
                    ],
                    exports: [
                        DxoItemDraggingComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS1kcmFnZ2luZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2l0ZW0tZHJhZ2dpbmcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsaURBQWlEO0FBRWpELE9BQU8sRUFDSCxTQUFTLEVBR1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1gsTUFBTSxlQUFlLENBQUM7QUFNdkIsT0FBTyxFQUNILGdCQUFnQixHQUNuQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLHlCQUF5QixDQUFDOzs7QUEwQzdELE1BQU0sT0FBTyx3QkFBeUIsU0FBUSxrQkFBa0I7SUFFNUQsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFHRCxZQUFnQyxnQkFBa0MsRUFDbEQsVUFBNEI7UUFDeEMsS0FBSyxFQUFFLENBQUM7UUFDUixnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBR0QsUUFBUTtRQUNKLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7MkhBckJRLHdCQUF3QjsrR0FBeEIsd0JBQXdCLGc0QkFuQ3RCLENBQUMsZ0JBQWdCLENBQUMsaURBRm5CLEVBQUU7OzRGQXFDSCx3QkFBd0I7a0JBdkNwQyxTQUFTOytCQUNJLG1CQUFtQixZQUNuQixFQUFFLGFBRUQsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUNyQjt3QkFDSixxQkFBcUI7d0JBQ3JCLGlCQUFpQjt3QkFDakIsWUFBWTt3QkFDWixVQUFVO3dCQUNWLFdBQVc7d0JBQ1gsY0FBYzt3QkFDZCxNQUFNO3dCQUNOLGVBQWU7d0JBQ2YsY0FBYzt3QkFDZCxrQkFBa0I7d0JBQ2xCLGFBQWE7d0JBQ2IsUUFBUTt3QkFDUixPQUFPO3dCQUNQLFFBQVE7d0JBQ1IsUUFBUTt3QkFDUixpQkFBaUI7d0JBQ2pCLGdCQUFnQjt3QkFDaEIsT0FBTzt3QkFDUCxhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsV0FBVzt3QkFDWCxZQUFZO3dCQUNaLGFBQWE7d0JBQ2IsZUFBZTt3QkFDZixpQkFBaUI7d0JBQ2pCLFVBQVU7d0JBQ1YsV0FBVzt3QkFDWCxZQUFZO3dCQUNaLG1CQUFtQjt3QkFDbkIsYUFBYTt3QkFDYixPQUFPO3FCQUNWOzswQkFTWSxRQUFROzswQkFBSSxJQUFJOzswQkFDcEIsSUFBSTs7QUEwQmpCLE1BQU0sT0FBTyxxQkFBcUI7MkhBQXJCLHFCQUFxQjs0SEFBckIscUJBQXFCLGlCQWxDckIsd0JBQXdCLGFBQXhCLHdCQUF3Qjs0SEFrQ3hCLHFCQUFxQjs7NEZBQXJCLHFCQUFxQjtrQkFSakMsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osd0JBQXdCO3FCQUN6QjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1Asd0JBQXdCO3FCQUN6QjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuLyogdHNsaW50OmRpc2FibGU6dXNlLWlucHV0LXByb3BlcnR5LWRlY29yYXRvciAqL1xuXG5pbXBvcnQge1xuICAgIENvbXBvbmVudCxcbiAgICBPbkluaXQsXG4gICAgT25EZXN0cm95LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeG9Tb3J0YWJsZU9wdGlvbnMgfSBmcm9tICcuL2Jhc2Uvc29ydGFibGUtb3B0aW9ucyc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeG8taXRlbS1kcmFnZ2luZycsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHN0eWxlczogWycnXSxcbiAgICBwcm92aWRlcnM6IFtOZXN0ZWRPcHRpb25Ib3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2FsbG93RHJvcEluc2lkZUl0ZW0nLFxuICAgICAgICAnYWxsb3dSZW9yZGVyaW5nJyxcbiAgICAgICAgJ2F1dG9TY3JvbGwnLFxuICAgICAgICAnYm91bmRhcnknLFxuICAgICAgICAnY29udGFpbmVyJyxcbiAgICAgICAgJ2N1cnNvck9mZnNldCcsXG4gICAgICAgICdkYXRhJyxcbiAgICAgICAgJ2RyYWdEaXJlY3Rpb24nLFxuICAgICAgICAnZHJhZ1RlbXBsYXRlJyxcbiAgICAgICAgJ2Ryb3BGZWVkYmFja01vZGUnLFxuICAgICAgICAnZWxlbWVudEF0dHInLFxuICAgICAgICAnZmlsdGVyJyxcbiAgICAgICAgJ2dyb3VwJyxcbiAgICAgICAgJ2hhbmRsZScsXG4gICAgICAgICdoZWlnaHQnLFxuICAgICAgICAnaXRlbU9yaWVudGF0aW9uJyxcbiAgICAgICAgJ21vdmVJdGVtT25Ecm9wJyxcbiAgICAgICAgJ29uQWRkJyxcbiAgICAgICAgJ29uRGlzcG9zaW5nJyxcbiAgICAgICAgJ29uRHJhZ0NoYW5nZScsXG4gICAgICAgICdvbkRyYWdFbmQnLFxuICAgICAgICAnb25EcmFnTW92ZScsXG4gICAgICAgICdvbkRyYWdTdGFydCcsXG4gICAgICAgICdvbkluaXRpYWxpemVkJyxcbiAgICAgICAgJ29uT3B0aW9uQ2hhbmdlZCcsXG4gICAgICAgICdvblJlbW92ZScsXG4gICAgICAgICdvblJlb3JkZXInLFxuICAgICAgICAncnRsRW5hYmxlZCcsXG4gICAgICAgICdzY3JvbGxTZW5zaXRpdml0eScsXG4gICAgICAgICdzY3JvbGxTcGVlZCcsXG4gICAgICAgICd3aWR0aCdcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4b0l0ZW1EcmFnZ2luZ0NvbXBvbmVudCBleHRlbmRzIER4b1NvcnRhYmxlT3B0aW9ucyBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25Jbml0ICB7XG5cbiAgICBwcm90ZWN0ZWQgZ2V0IF9vcHRpb25QYXRoKCkge1xuICAgICAgICByZXR1cm4gJ2l0ZW1EcmFnZ2luZyc7XG4gICAgfVxuXG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLl9hZGRSZWNyZWF0ZWRDb21wb25lbnQoKTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVtb3ZlZE9wdGlvbih0aGlzLl9nZXRPcHRpb25QYXRoKCkpO1xuICAgIH1cblxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4b0l0ZW1EcmFnZ2luZ0NvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhvSXRlbURyYWdnaW5nQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4b0l0ZW1EcmFnZ2luZ01vZHVsZSB7IH1cbiJdfQ==