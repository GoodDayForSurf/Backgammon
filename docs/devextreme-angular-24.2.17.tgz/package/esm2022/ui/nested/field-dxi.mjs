/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiFilterBuilderField } from './base/filter-builder-field-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiFieldComponent extends DxiFilterBuilderField {
    get _optionPath() {
        return 'fields';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFieldComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiFieldComponent, selector: "dxi-field", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editorOptions: "editorOptions", editorTemplate: "editorTemplate", falseText: "falseText", filterOperations: "filterOperations", format: "format", lookup: "lookup", name: "name", trueText: "trueText", allowCrossGroupCalculation: "allowCrossGroupCalculation", allowExpandAll: "allowExpandAll", allowFiltering: "allowFiltering", allowSorting: "allowSorting", allowSortingBySummary: "allowSortingBySummary", area: "area", areaIndex: "areaIndex", calculateCustomSummary: "calculateCustomSummary", calculateSummaryValue: "calculateSummaryValue", displayFolder: "displayFolder", expanded: "expanded", filterType: "filterType", filterValues: "filterValues", groupIndex: "groupIndex", groupInterval: "groupInterval", groupName: "groupName", headerFilter: "headerFilter", isMeasure: "isMeasure", precision: "precision", runningTotal: "runningTotal", selector: "selector", showGrandTotals: "showGrandTotals", showTotals: "showTotals", showValues: "showValues", sortBy: "sortBy", sortBySummaryField: "sortBySummaryField", sortBySummaryPath: "sortBySummaryPath", sortingMethod: "sortingMethod", sortOrder: "sortOrder", summaryDisplayMode: "summaryDisplayMode", summaryType: "summaryType", visible: "visible", width: "width", wordWrapEnabled: "wordWrapEnabled" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-field', template: '', providers: [NestedOptionHost], inputs: [
                        'calculateFilterExpression',
                        'caption',
                        'customizeText',
                        'dataField',
                        'dataType',
                        'editorOptions',
                        'editorTemplate',
                        'falseText',
                        'filterOperations',
                        'format',
                        'lookup',
                        'name',
                        'trueText',
                        'allowCrossGroupCalculation',
                        'allowExpandAll',
                        'allowFiltering',
                        'allowSorting',
                        'allowSortingBySummary',
                        'area',
                        'areaIndex',
                        'calculateCustomSummary',
                        'calculateSummaryValue',
                        'displayFolder',
                        'expanded',
                        'filterType',
                        'filterValues',
                        'groupIndex',
                        'groupInterval',
                        'groupName',
                        'headerFilter',
                        'isMeasure',
                        'precision',
                        'runningTotal',
                        'selector',
                        'showGrandTotals',
                        'showTotals',
                        'showValues',
                        'sortBy',
                        'sortBySummaryField',
                        'sortBySummaryPath',
                        'sortingMethod',
                        'sortOrder',
                        'summaryDisplayMode',
                        'summaryType',
                        'visible',
                        'width',
                        'wordWrapEnabled'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxiFieldModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiFieldModule, declarations: [DxiFieldComponent], exports: [DxiFieldComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFieldModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiFieldComponent
                    ],
                    exports: [
                        DxiFieldComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmllbGQtZHhpLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvZmllbGQtZHhpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUNULFFBQVEsRUFDUixJQUFJLEVBQ0osUUFBUSxFQUNYLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQzs7O0FBMER4RSxNQUFNLE9BQU8saUJBQWtCLFNBQVEscUJBQXFCO0lBRXhELElBQWMsV0FBVztRQUNyQixPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBR0QsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBQ1IsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUlELFdBQVc7UUFDUCxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7SUFDdkQsQ0FBQzsySEFsQlEsaUJBQWlCOytHQUFqQixpQkFBaUIsMDZDQW5EZixDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkFxREgsaUJBQWlCO2tCQXZEN0IsU0FBUzsrQkFDSSxXQUFXLFlBQ1gsRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUMsVUFDckI7d0JBQ0osMkJBQTJCO3dCQUMzQixTQUFTO3dCQUNULGVBQWU7d0JBQ2YsV0FBVzt3QkFDWCxVQUFVO3dCQUNWLGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQixXQUFXO3dCQUNYLGtCQUFrQjt3QkFDbEIsUUFBUTt3QkFDUixRQUFRO3dCQUNSLE1BQU07d0JBQ04sVUFBVTt3QkFDViw0QkFBNEI7d0JBQzVCLGdCQUFnQjt3QkFDaEIsZ0JBQWdCO3dCQUNoQixjQUFjO3dCQUNkLHVCQUF1Qjt3QkFDdkIsTUFBTTt3QkFDTixXQUFXO3dCQUNYLHdCQUF3Qjt3QkFDeEIsdUJBQXVCO3dCQUN2QixlQUFlO3dCQUNmLFVBQVU7d0JBQ1YsWUFBWTt3QkFDWixjQUFjO3dCQUNkLFlBQVk7d0JBQ1osZUFBZTt3QkFDZixXQUFXO3dCQUNYLGNBQWM7d0JBQ2QsV0FBVzt3QkFDWCxXQUFXO3dCQUNYLGNBQWM7d0JBQ2QsVUFBVTt3QkFDVixpQkFBaUI7d0JBQ2pCLFlBQVk7d0JBQ1osWUFBWTt3QkFDWixRQUFRO3dCQUNSLG9CQUFvQjt3QkFDcEIsbUJBQW1CO3dCQUNuQixlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsb0JBQW9CO3dCQUNwQixhQUFhO3dCQUNiLFNBQVM7d0JBQ1QsT0FBTzt3QkFDUCxpQkFBaUI7cUJBQ3BCOzswQkFTWSxRQUFROzswQkFBSSxJQUFJOzswQkFDcEIsSUFBSTs7QUFzQmpCLE1BQU0sT0FBTyxjQUFjOzJIQUFkLGNBQWM7NEhBQWQsY0FBYyxpQkE5QmQsaUJBQWlCLGFBQWpCLGlCQUFpQjs0SEE4QmpCLGNBQWM7OzRGQUFkLGNBQWM7a0JBUjFCLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLGlCQUFpQjtxQkFDbEI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLGlCQUFpQjtxQkFDbEI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBTa2lwU2VsZlxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG5cblxuXG5pbXBvcnQge1xuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IER4aUZpbHRlckJ1aWxkZXJGaWVsZCB9IGZyb20gJy4vYmFzZS9maWx0ZXItYnVpbGRlci1maWVsZC1keGknO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhpLWZpZWxkJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnY2FsY3VsYXRlRmlsdGVyRXhwcmVzc2lvbicsXG4gICAgICAgICdjYXB0aW9uJyxcbiAgICAgICAgJ2N1c3RvbWl6ZVRleHQnLFxuICAgICAgICAnZGF0YUZpZWxkJyxcbiAgICAgICAgJ2RhdGFUeXBlJyxcbiAgICAgICAgJ2VkaXRvck9wdGlvbnMnLFxuICAgICAgICAnZWRpdG9yVGVtcGxhdGUnLFxuICAgICAgICAnZmFsc2VUZXh0JyxcbiAgICAgICAgJ2ZpbHRlck9wZXJhdGlvbnMnLFxuICAgICAgICAnZm9ybWF0JyxcbiAgICAgICAgJ2xvb2t1cCcsXG4gICAgICAgICduYW1lJyxcbiAgICAgICAgJ3RydWVUZXh0JyxcbiAgICAgICAgJ2FsbG93Q3Jvc3NHcm91cENhbGN1bGF0aW9uJyxcbiAgICAgICAgJ2FsbG93RXhwYW5kQWxsJyxcbiAgICAgICAgJ2FsbG93RmlsdGVyaW5nJyxcbiAgICAgICAgJ2FsbG93U29ydGluZycsXG4gICAgICAgICdhbGxvd1NvcnRpbmdCeVN1bW1hcnknLFxuICAgICAgICAnYXJlYScsXG4gICAgICAgICdhcmVhSW5kZXgnLFxuICAgICAgICAnY2FsY3VsYXRlQ3VzdG9tU3VtbWFyeScsXG4gICAgICAgICdjYWxjdWxhdGVTdW1tYXJ5VmFsdWUnLFxuICAgICAgICAnZGlzcGxheUZvbGRlcicsXG4gICAgICAgICdleHBhbmRlZCcsXG4gICAgICAgICdmaWx0ZXJUeXBlJyxcbiAgICAgICAgJ2ZpbHRlclZhbHVlcycsXG4gICAgICAgICdncm91cEluZGV4JyxcbiAgICAgICAgJ2dyb3VwSW50ZXJ2YWwnLFxuICAgICAgICAnZ3JvdXBOYW1lJyxcbiAgICAgICAgJ2hlYWRlckZpbHRlcicsXG4gICAgICAgICdpc01lYXN1cmUnLFxuICAgICAgICAncHJlY2lzaW9uJyxcbiAgICAgICAgJ3J1bm5pbmdUb3RhbCcsXG4gICAgICAgICdzZWxlY3RvcicsXG4gICAgICAgICdzaG93R3JhbmRUb3RhbHMnLFxuICAgICAgICAnc2hvd1RvdGFscycsXG4gICAgICAgICdzaG93VmFsdWVzJyxcbiAgICAgICAgJ3NvcnRCeScsXG4gICAgICAgICdzb3J0QnlTdW1tYXJ5RmllbGQnLFxuICAgICAgICAnc29ydEJ5U3VtbWFyeVBhdGgnLFxuICAgICAgICAnc29ydGluZ01ldGhvZCcsXG4gICAgICAgICdzb3J0T3JkZXInLFxuICAgICAgICAnc3VtbWFyeURpc3BsYXlNb2RlJyxcbiAgICAgICAgJ3N1bW1hcnlUeXBlJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAnd2lkdGgnLFxuICAgICAgICAnd29yZFdyYXBFbmFibGVkJ1xuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhpRmllbGRDb21wb25lbnQgZXh0ZW5kcyBEeGlGaWx0ZXJCdWlsZGVyRmllbGQge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdmaWVsZHMnO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZWxldGVSZW1vdmVkT3B0aW9ucyh0aGlzLl9mdWxsT3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cbn1cblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhpRmllbGRDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4aUZpZWxkQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4aUZpZWxkTW9kdWxlIHsgfVxuIl19