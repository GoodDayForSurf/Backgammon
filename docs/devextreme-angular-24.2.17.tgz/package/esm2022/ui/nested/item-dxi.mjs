/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, ElementRef, Renderer2, Inject, SkipSelf, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { NestedOptionHost, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { DxiButtonGroupItem } from './base/button-group-item-dxi';
import { DxiValidationRuleComponent } from './validation-rule-dxi';
import { DxiTabComponent } from './tab-dxi';
import { DxiLocationComponent } from './location-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiItemComponent extends DxiButtonGroupItem {
    renderer;
    document;
    element;
    get _optionPath() {
        return 'items';
    }
    get itemsChildren() {
        return this._getOption('items');
    }
    set itemsChildren(value) {
        this.setChildren('items', value);
    }
    get validationRulesChildren() {
        return this._getOption('validationRules');
    }
    set validationRulesChildren(value) {
        this.setChildren('validationRules', value);
    }
    get tabsChildren() {
        return this._getOption('tabs');
    }
    set tabsChildren(value) {
        this.setChildren('tabs', value);
    }
    get locationChildren() {
        return this._getOption('location');
    }
    set locationChildren(value) {
        this.setChildren('location', value);
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiItemComponent, selector: "dxi-item", inputs: { disabled: "disabled", html: "html", icon: "icon", template: "template", text: "text", title: "title", titleTemplate: "titleTemplate", visible: "visible", onClick: "onClick", stylingMode: "stylingMode", type: "type", baseSize: "baseSize", box: "box", ratio: "ratio", shrink: "shrink", elementAttr: "elementAttr", hint: "hint", author: "author", timestamp: "timestamp", typing: "typing", beginGroup: "beginGroup", closeMenuOnClick: "closeMenuOnClick", items: "items", selectable: "selectable", selected: "selected", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", validationRules: "validationRules", visibleIndex: "visibleIndex", alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", tabPanelOptions: "tabPanelOptions", tabs: "tabs", badge: "badge", tabTemplate: "tabTemplate", buttonOptions: "buttonOptions", horizontalAlignment: "horizontalAlignment", verticalAlignment: "verticalAlignment", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", widget: "widget", height: "height", width: "width", imageAlt: "imageAlt", imageSrc: "imageSrc", acceptedValues: "acceptedValues", formatName: "formatName", formatValues: "formatValues", key: "key", showChevron: "showChevron", linkAttr: "linkAttr", url: "url", collapsed: "collapsed", collapsedSize: "collapsedSize", collapsible: "collapsible", maxSize: "maxSize", minSize: "minSize", resizable: "resizable", size: "size", splitter: "splitter", heightRatio: "heightRatio", widthRatio: "widthRatio", expanded: "expanded", hasItems: "hasItems", id: "id", parentId: "parentId" }, providers: [NestedOptionHost, DxTemplateHost], queries: [{ propertyName: "itemsChildren", predicate: i0.forwardRef(function () { return DxiItemComponent; }) }, { propertyName: "validationRulesChildren", predicate: i0.forwardRef(function () { return DxiValidationRuleComponent; }) }, { propertyName: "tabsChildren", predicate: i0.forwardRef(function () { return DxiTabComponent; }) }, { propertyName: "locationChildren", predicate: i0.forwardRef(function () { return DxiLocationComponent; }) }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-item', template: '<ng-content></ng-content>', providers: [NestedOptionHost, DxTemplateHost], inputs: [
                        'disabled',
                        'html',
                        'icon',
                        'template',
                        'text',
                        'title',
                        'titleTemplate',
                        'visible',
                        'onClick',
                        'stylingMode',
                        'type',
                        'baseSize',
                        'box',
                        'ratio',
                        'shrink',
                        'elementAttr',
                        'hint',
                        'author',
                        'timestamp',
                        'typing',
                        'beginGroup',
                        'closeMenuOnClick',
                        'items',
                        'selectable',
                        'selected',
                        'colSpan',
                        'cssClass',
                        'dataField',
                        'editorOptions',
                        'editorType',
                        'helpText',
                        'isRequired',
                        'itemType',
                        'label',
                        'name',
                        'validationRules',
                        'visibleIndex',
                        'alignItemLabels',
                        'caption',
                        'captionTemplate',
                        'colCount',
                        'colCountByScreen',
                        'tabPanelOptions',
                        'tabs',
                        'badge',
                        'tabTemplate',
                        'buttonOptions',
                        'horizontalAlignment',
                        'verticalAlignment',
                        'locateInMenu',
                        'location',
                        'menuItemTemplate',
                        'options',
                        'showText',
                        'widget',
                        'height',
                        'width',
                        'imageAlt',
                        'imageSrc',
                        'acceptedValues',
                        'formatName',
                        'formatValues',
                        'key',
                        'showChevron',
                        'linkAttr',
                        'url',
                        'collapsed',
                        'collapsedSize',
                        'collapsible',
                        'maxSize',
                        'minSize',
                        'resizable',
                        'size',
                        'splitter',
                        'heightRatio',
                        'widthRatio',
                        'expanded',
                        'hasItems',
                        'id',
                        'parentId'
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }]; }, propDecorators: { itemsChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiItemComponent)]
            }], validationRulesChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiValidationRuleComponent)]
            }], tabsChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiTabComponent)]
            }], locationChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiLocationComponent)]
            }] } });
export class DxiItemModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiItemModule, declarations: [DxiItemComponent], exports: [DxiItemComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiItemModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiItemModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiItemComponent
                    ],
                    exports: [
                        DxiItemComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS1keGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9pdGVtLWR4aS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFDVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFVBQVUsRUFDVixTQUFTLEVBQ1QsTUFBTSxFQUVOLFFBQVEsRUFDUixlQUFlLEVBQ2YsVUFBVSxFQUNWLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFJM0MsT0FBTyxFQUNILGdCQUFnQixFQUNoQixlQUFlLEVBR2YsY0FBYyxFQUNqQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSwwQkFBMEIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDNUMsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7OztBQTJGdEQsTUFBTSxPQUFPLGdCQUFpQixTQUFRLGtCQUFrQjtJQTBDcEM7SUFDa0I7SUFFbEI7SUExQ2hCLElBQWMsV0FBVztRQUNyQixPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBR0QsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFLO1FBQ25CLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxJQUNJLHVCQUF1QjtRQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSx1QkFBdUIsQ0FBQyxLQUFLO1FBQzdCLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBSztRQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQUs7UUFDdEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QixFQUM1QixRQUFtQixFQUNELFFBQWEsRUFDL0IsWUFBNEIsRUFDNUIsT0FBbUI7UUFDL0IsS0FBSyxFQUFFLENBQUM7UUFKSSxhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ0QsYUFBUSxHQUFSLFFBQVEsQ0FBSztRQUUvQixZQUFPLEdBQVAsT0FBTyxDQUFZO1FBRS9CLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzFELFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELFdBQVcsQ0FBQyxRQUE2QjtRQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUM3QixDQUFDO0lBQ0QsZUFBZTtRQUNYLGVBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBSUQsV0FBVztRQUNQLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDOzJIQS9EUSxnQkFBZ0IsbUpBMkNULFFBQVE7K0dBM0NmLGdCQUFnQiwrM0RBcEZkLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLDJGQTRGWCxnQkFBZ0IsaUdBUWhCLDBCQUEwQixzRkFRMUIsZUFBZSwwRkFRZixvQkFBb0Isd0RBdEg1QywyQkFBMkI7OzRGQXNGNUIsZ0JBQWdCO2tCQXhGNUIsU0FBUzsrQkFDSSxVQUFVLFlBQ1YsMkJBQTJCLGFBRTFCLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLFVBQ3JDO3dCQUNKLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixNQUFNO3dCQUNOLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixPQUFPO3dCQUNQLGVBQWU7d0JBQ2YsU0FBUzt3QkFDVCxTQUFTO3dCQUNULGFBQWE7d0JBQ2IsTUFBTTt3QkFDTixVQUFVO3dCQUNWLEtBQUs7d0JBQ0wsT0FBTzt3QkFDUCxRQUFRO3dCQUNSLGFBQWE7d0JBQ2IsTUFBTTt3QkFDTixRQUFRO3dCQUNSLFdBQVc7d0JBQ1gsUUFBUTt3QkFDUixZQUFZO3dCQUNaLGtCQUFrQjt3QkFDbEIsT0FBTzt3QkFDUCxZQUFZO3dCQUNaLFVBQVU7d0JBQ1YsU0FBUzt3QkFDVCxVQUFVO3dCQUNWLFdBQVc7d0JBQ1gsZUFBZTt3QkFDZixZQUFZO3dCQUNaLFVBQVU7d0JBQ1YsWUFBWTt3QkFDWixVQUFVO3dCQUNWLE9BQU87d0JBQ1AsTUFBTTt3QkFDTixpQkFBaUI7d0JBQ2pCLGNBQWM7d0JBQ2QsaUJBQWlCO3dCQUNqQixTQUFTO3dCQUNULGlCQUFpQjt3QkFDakIsVUFBVTt3QkFDVixrQkFBa0I7d0JBQ2xCLGlCQUFpQjt3QkFDakIsTUFBTTt3QkFDTixPQUFPO3dCQUNQLGFBQWE7d0JBQ2IsZUFBZTt3QkFDZixxQkFBcUI7d0JBQ3JCLG1CQUFtQjt3QkFDbkIsY0FBYzt3QkFDZCxVQUFVO3dCQUNWLGtCQUFrQjt3QkFDbEIsU0FBUzt3QkFDVCxVQUFVO3dCQUNWLFFBQVE7d0JBQ1IsUUFBUTt3QkFDUixPQUFPO3dCQUNQLFVBQVU7d0JBQ1YsVUFBVTt3QkFDVixnQkFBZ0I7d0JBQ2hCLFlBQVk7d0JBQ1osY0FBYzt3QkFDZCxLQUFLO3dCQUNMLGFBQWE7d0JBQ2IsVUFBVTt3QkFDVixLQUFLO3dCQUNMLFdBQVc7d0JBQ1gsZUFBZTt3QkFDZixhQUFhO3dCQUNiLFNBQVM7d0JBQ1QsU0FBUzt3QkFDVCxXQUFXO3dCQUNYLE1BQU07d0JBQ04sVUFBVTt3QkFDVixhQUFhO3dCQUNiLFlBQVk7d0JBQ1osVUFBVTt3QkFDVixVQUFVO3dCQUNWLElBQUk7d0JBQ0osVUFBVTtxQkFDYjs7MEJBMENZLFFBQVE7OzBCQUFJLElBQUk7OzBCQUNwQixJQUFJOzswQkFFSixNQUFNOzJCQUFDLFFBQVE7OzBCQUNmLElBQUk7cUVBbkNULGFBQWE7c0JBRGhCLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLGdCQUFnQixDQUFDO2dCQVMvQyx1QkFBdUI7c0JBRDFCLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLDBCQUEwQixDQUFDO2dCQVN6RCxZQUFZO3NCQURmLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLGVBQWUsQ0FBQztnQkFTOUMsZ0JBQWdCO3NCQURuQixlQUFlO3VCQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQzs7QUEyQzNELE1BQU0sT0FBTyxhQUFhOzJIQUFiLGFBQWE7NEhBQWIsYUFBYSxpQkEzRWIsZ0JBQWdCLGFBQWhCLGdCQUFnQjs0SEEyRWhCLGFBQWE7OzRGQUFiLGFBQWE7a0JBUnpCLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLGdCQUFnQjtxQkFDakI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLGdCQUFnQjtxQkFDakI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBFbGVtZW50UmVmLFxuICAgIFJlbmRlcmVyMixcbiAgICBJbmplY3QsXG4gICAgQWZ0ZXJWaWV3SW5pdCxcbiAgICBTa2lwU2VsZixcbiAgICBDb250ZW50Q2hpbGRyZW4sXG4gICAgZm9yd2FyZFJlZixcbiAgICBRdWVyeUxpc3Rcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuXG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICBleHRyYWN0VGVtcGxhdGUsXG4gICAgRHhUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJRHhUZW1wbGF0ZUhvc3QsXG4gICAgRHhUZW1wbGF0ZUhvc3Rcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhpQnV0dG9uR3JvdXBJdGVtIH0gZnJvbSAnLi9iYXNlL2J1dHRvbi1ncm91cC1pdGVtLWR4aSc7XG5pbXBvcnQgeyBEeGlWYWxpZGF0aW9uUnVsZUNvbXBvbmVudCB9IGZyb20gJy4vdmFsaWRhdGlvbi1ydWxlLWR4aSc7XG5pbXBvcnQgeyBEeGlUYWJDb21wb25lbnQgfSBmcm9tICcuL3RhYi1keGknO1xuaW1wb3J0IHsgRHhpTG9jYXRpb25Db21wb25lbnQgfSBmcm9tICcuL2xvY2F0aW9uLWR4aSc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeGktaXRlbScsXG4gICAgdGVtcGxhdGU6ICc8bmctY29udGVudD48L25nLWNvbnRlbnQ+JyxcbiAgICBzdHlsZXM6IFsnOmhvc3QgeyBkaXNwbGF5OiBibG9jazsgfSddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3QsIER4VGVtcGxhdGVIb3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2Rpc2FibGVkJyxcbiAgICAgICAgJ2h0bWwnLFxuICAgICAgICAnaWNvbicsXG4gICAgICAgICd0ZW1wbGF0ZScsXG4gICAgICAgICd0ZXh0JyxcbiAgICAgICAgJ3RpdGxlJyxcbiAgICAgICAgJ3RpdGxlVGVtcGxhdGUnLFxuICAgICAgICAndmlzaWJsZScsXG4gICAgICAgICdvbkNsaWNrJyxcbiAgICAgICAgJ3N0eWxpbmdNb2RlJyxcbiAgICAgICAgJ3R5cGUnLFxuICAgICAgICAnYmFzZVNpemUnLFxuICAgICAgICAnYm94JyxcbiAgICAgICAgJ3JhdGlvJyxcbiAgICAgICAgJ3NocmluaycsXG4gICAgICAgICdlbGVtZW50QXR0cicsXG4gICAgICAgICdoaW50JyxcbiAgICAgICAgJ2F1dGhvcicsXG4gICAgICAgICd0aW1lc3RhbXAnLFxuICAgICAgICAndHlwaW5nJyxcbiAgICAgICAgJ2JlZ2luR3JvdXAnLFxuICAgICAgICAnY2xvc2VNZW51T25DbGljaycsXG4gICAgICAgICdpdGVtcycsXG4gICAgICAgICdzZWxlY3RhYmxlJyxcbiAgICAgICAgJ3NlbGVjdGVkJyxcbiAgICAgICAgJ2NvbFNwYW4nLFxuICAgICAgICAnY3NzQ2xhc3MnLFxuICAgICAgICAnZGF0YUZpZWxkJyxcbiAgICAgICAgJ2VkaXRvck9wdGlvbnMnLFxuICAgICAgICAnZWRpdG9yVHlwZScsXG4gICAgICAgICdoZWxwVGV4dCcsXG4gICAgICAgICdpc1JlcXVpcmVkJyxcbiAgICAgICAgJ2l0ZW1UeXBlJyxcbiAgICAgICAgJ2xhYmVsJyxcbiAgICAgICAgJ25hbWUnLFxuICAgICAgICAndmFsaWRhdGlvblJ1bGVzJyxcbiAgICAgICAgJ3Zpc2libGVJbmRleCcsXG4gICAgICAgICdhbGlnbkl0ZW1MYWJlbHMnLFxuICAgICAgICAnY2FwdGlvbicsXG4gICAgICAgICdjYXB0aW9uVGVtcGxhdGUnLFxuICAgICAgICAnY29sQ291bnQnLFxuICAgICAgICAnY29sQ291bnRCeVNjcmVlbicsXG4gICAgICAgICd0YWJQYW5lbE9wdGlvbnMnLFxuICAgICAgICAndGFicycsXG4gICAgICAgICdiYWRnZScsXG4gICAgICAgICd0YWJUZW1wbGF0ZScsXG4gICAgICAgICdidXR0b25PcHRpb25zJyxcbiAgICAgICAgJ2hvcml6b250YWxBbGlnbm1lbnQnLFxuICAgICAgICAndmVydGljYWxBbGlnbm1lbnQnLFxuICAgICAgICAnbG9jYXRlSW5NZW51JyxcbiAgICAgICAgJ2xvY2F0aW9uJyxcbiAgICAgICAgJ21lbnVJdGVtVGVtcGxhdGUnLFxuICAgICAgICAnb3B0aW9ucycsXG4gICAgICAgICdzaG93VGV4dCcsXG4gICAgICAgICd3aWRnZXQnLFxuICAgICAgICAnaGVpZ2h0JyxcbiAgICAgICAgJ3dpZHRoJyxcbiAgICAgICAgJ2ltYWdlQWx0JyxcbiAgICAgICAgJ2ltYWdlU3JjJyxcbiAgICAgICAgJ2FjY2VwdGVkVmFsdWVzJyxcbiAgICAgICAgJ2Zvcm1hdE5hbWUnLFxuICAgICAgICAnZm9ybWF0VmFsdWVzJyxcbiAgICAgICAgJ2tleScsXG4gICAgICAgICdzaG93Q2hldnJvbicsXG4gICAgICAgICdsaW5rQXR0cicsXG4gICAgICAgICd1cmwnLFxuICAgICAgICAnY29sbGFwc2VkJyxcbiAgICAgICAgJ2NvbGxhcHNlZFNpemUnLFxuICAgICAgICAnY29sbGFwc2libGUnLFxuICAgICAgICAnbWF4U2l6ZScsXG4gICAgICAgICdtaW5TaXplJyxcbiAgICAgICAgJ3Jlc2l6YWJsZScsXG4gICAgICAgICdzaXplJyxcbiAgICAgICAgJ3NwbGl0dGVyJyxcbiAgICAgICAgJ2hlaWdodFJhdGlvJyxcbiAgICAgICAgJ3dpZHRoUmF0aW8nLFxuICAgICAgICAnZXhwYW5kZWQnLFxuICAgICAgICAnaGFzSXRlbXMnLFxuICAgICAgICAnaWQnLFxuICAgICAgICAncGFyZW50SWQnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeGlJdGVtQ29tcG9uZW50IGV4dGVuZHMgRHhpQnV0dG9uR3JvdXBJdGVtIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCxcbiAgICBJRHhUZW1wbGF0ZUhvc3Qge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdpdGVtcyc7XG4gICAgfVxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKGZvcndhcmRSZWYoKCkgPT4gRHhpSXRlbUNvbXBvbmVudCkpXG4gICAgZ2V0IGl0ZW1zQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aUl0ZW1Db21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaXRlbXMnKTtcbiAgICB9XG4gICAgc2V0IGl0ZW1zQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignaXRlbXMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihmb3J3YXJkUmVmKCgpID0+IER4aVZhbGlkYXRpb25SdWxlQ29tcG9uZW50KSlcbiAgICBnZXQgdmFsaWRhdGlvblJ1bGVzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aVZhbGlkYXRpb25SdWxlQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbGlkYXRpb25SdWxlcycpO1xuICAgIH1cbiAgICBzZXQgdmFsaWRhdGlvblJ1bGVzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbigndmFsaWRhdGlvblJ1bGVzJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oZm9yd2FyZFJlZigoKSA9PiBEeGlUYWJDb21wb25lbnQpKVxuICAgIGdldCB0YWJzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aVRhYkNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0YWJzJyk7XG4gICAgfVxuICAgIHNldCB0YWJzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbigndGFicycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBAQ29udGVudENoaWxkcmVuKGZvcndhcmRSZWYoKCkgPT4gRHhpTG9jYXRpb25Db21wb25lbnQpKVxuICAgIGdldCBsb2NhdGlvbkNoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlMb2NhdGlvbkNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdsb2NhdGlvbicpO1xuICAgIH1cbiAgICBzZXQgbG9jYXRpb25DaGlsZHJlbih2YWx1ZSkge1xuICAgICAgICB0aGlzLnNldENoaWxkcmVuKCdsb2NhdGlvbicsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgICAgICAgICBASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBhbnksXG4gICAgICAgICAgICBASG9zdCgpIHRlbXBsYXRlSG9zdDogRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgICAgICBwcml2YXRlIGVsZW1lbnQ6IEVsZW1lbnRSZWYpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGVtcGxhdGVIb3N0LnNldEhvc3QodGhpcyk7XG4gICAgfVxuXG4gICAgc2V0VGVtcGxhdGUodGVtcGxhdGU6IER4VGVtcGxhdGVEaXJlY3RpdmUpIHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZSA9IHRlbXBsYXRlO1xuICAgIH1cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIGV4dHJhY3RUZW1wbGF0ZSh0aGlzLCB0aGlzLmVsZW1lbnQsIHRoaXMucmVuZGVyZXIsIHRoaXMuZG9jdW1lbnQpO1xuICAgIH1cblxuXG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fZGVsZXRlUmVtb3ZlZE9wdGlvbnModGhpcy5fZnVsbE9wdGlvblBhdGgoKSk7XG4gICAgfVxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4aUl0ZW1Db21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4aUl0ZW1Db21wb25lbnRcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRHhpSXRlbU1vZHVsZSB7IH1cbiJdfQ==