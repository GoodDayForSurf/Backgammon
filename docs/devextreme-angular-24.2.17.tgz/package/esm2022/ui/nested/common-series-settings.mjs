/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoChartCommonSeriesSettings } from './base/chart-common-series-settings';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoCommonSeriesSettingsComponent extends DxoChartCommonSeriesSettings {
    get _optionPath() {
        return 'commonSeriesSettings';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonSeriesSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoCommonSeriesSettingsComponent, selector: "dxo-common-series-settings", inputs: { aggregation: "aggregation", area: "area", argumentField: "argumentField", axis: "axis", bar: "bar", barOverlapGroup: "barOverlapGroup", barPadding: "barPadding", barWidth: "barWidth", border: "border", bubble: "bubble", candlestick: "candlestick", closeValueField: "closeValueField", color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", fullstackedarea: "fullstackedarea", fullstackedbar: "fullstackedbar", fullstackedline: "fullstackedline", fullstackedspline: "fullstackedspline", fullstackedsplinearea: "fullstackedsplinearea", highValueField: "highValueField", hoverMode: "hoverMode", hoverStyle: "hoverStyle", ignoreEmptyPoints: "ignoreEmptyPoints", innerColor: "innerColor", label: "label", line: "line", lowValueField: "lowValueField", maxLabelCount: "maxLabelCount", minBarSize: "minBarSize", opacity: "opacity", openValueField: "openValueField", pane: "pane", point: "point", rangearea: "rangearea", rangebar: "rangebar", rangeValue1Field: "rangeValue1Field", rangeValue2Field: "rangeValue2Field", reduction: "reduction", scatter: "scatter", selectionMode: "selectionMode", selectionStyle: "selectionStyle", showInLegend: "showInLegend", sizeField: "sizeField", spline: "spline", splinearea: "splinearea", stack: "stack", stackedarea: "stackedarea", stackedbar: "stackedbar", stackedline: "stackedline", stackedspline: "stackedspline", stackedsplinearea: "stackedsplinearea", steparea: "steparea", stepline: "stepline", stock: "stock", tagField: "tagField", type: "type", valueErrorBar: "valueErrorBar", valueField: "valueField", visible: "visible", width: "width", argumentType: "argumentType", minSegmentSize: "minSegmentSize", smallValuesGrouping: "smallValuesGrouping", closed: "closed" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonSeriesSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-common-series-settings', template: '', providers: [NestedOptionHost], inputs: [
                        'aggregation',
                        'area',
                        'argumentField',
                        'axis',
                        'bar',
                        'barOverlapGroup',
                        'barPadding',
                        'barWidth',
                        'border',
                        'bubble',
                        'candlestick',
                        'closeValueField',
                        'color',
                        'cornerRadius',
                        'dashStyle',
                        'fullstackedarea',
                        'fullstackedbar',
                        'fullstackedline',
                        'fullstackedspline',
                        'fullstackedsplinearea',
                        'highValueField',
                        'hoverMode',
                        'hoverStyle',
                        'ignoreEmptyPoints',
                        'innerColor',
                        'label',
                        'line',
                        'lowValueField',
                        'maxLabelCount',
                        'minBarSize',
                        'opacity',
                        'openValueField',
                        'pane',
                        'point',
                        'rangearea',
                        'rangebar',
                        'rangeValue1Field',
                        'rangeValue2Field',
                        'reduction',
                        'scatter',
                        'selectionMode',
                        'selectionStyle',
                        'showInLegend',
                        'sizeField',
                        'spline',
                        'splinearea',
                        'stack',
                        'stackedarea',
                        'stackedbar',
                        'stackedline',
                        'stackedspline',
                        'stackedsplinearea',
                        'steparea',
                        'stepline',
                        'stock',
                        'tagField',
                        'type',
                        'valueErrorBar',
                        'valueField',
                        'visible',
                        'width',
                        'argumentType',
                        'minSegmentSize',
                        'smallValuesGrouping',
                        'closed'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoCommonSeriesSettingsModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonSeriesSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonSeriesSettingsModule, declarations: [DxoCommonSeriesSettingsComponent], exports: [DxoCommonSeriesSettingsComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonSeriesSettingsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCommonSeriesSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoCommonSeriesSettingsComponent
                    ],
                    exports: [
                        DxoCommonSeriesSettingsComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLXNlcmllcy1zZXR0aW5ncy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2NvbW1vbi1zZXJpZXMtc2V0dGluZ3MudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsaURBQWlEO0FBRWpELE9BQU8sRUFDSCxTQUFTLEVBR1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1gsTUFBTSxlQUFlLENBQUM7QUFNdkIsT0FBTyxFQUNILGdCQUFnQixHQUNuQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSw0QkFBNEIsRUFBRSxNQUFNLHFDQUFxQyxDQUFDOzs7QUE0RW5GLE1BQU0sT0FBTyxnQ0FBaUMsU0FBUSw0QkFBNEI7SUFFOUUsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sc0JBQXNCLENBQUM7SUFDbEMsQ0FBQztJQUdELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUNSLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFHRCxRQUFRO1FBQ0osSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7SUFDbEQsQ0FBQzsySEFyQlEsZ0NBQWdDOytHQUFoQyxnQ0FBZ0MsdXZEQXJFOUIsQ0FBQyxnQkFBZ0IsQ0FBQyxpREFGbkIsRUFBRTs7NEZBdUVILGdDQUFnQztrQkF6RTVDLFNBQVM7K0JBQ0ksNEJBQTRCLFlBQzVCLEVBQUUsYUFFRCxDQUFDLGdCQUFnQixDQUFDLFVBQ3JCO3dCQUNKLGFBQWE7d0JBQ2IsTUFBTTt3QkFDTixlQUFlO3dCQUNmLE1BQU07d0JBQ04sS0FBSzt3QkFDTCxpQkFBaUI7d0JBQ2pCLFlBQVk7d0JBQ1osVUFBVTt3QkFDVixRQUFRO3dCQUNSLFFBQVE7d0JBQ1IsYUFBYTt3QkFDYixpQkFBaUI7d0JBQ2pCLE9BQU87d0JBQ1AsY0FBYzt3QkFDZCxXQUFXO3dCQUNYLGlCQUFpQjt3QkFDakIsZ0JBQWdCO3dCQUNoQixpQkFBaUI7d0JBQ2pCLG1CQUFtQjt3QkFDbkIsdUJBQXVCO3dCQUN2QixnQkFBZ0I7d0JBQ2hCLFdBQVc7d0JBQ1gsWUFBWTt3QkFDWixtQkFBbUI7d0JBQ25CLFlBQVk7d0JBQ1osT0FBTzt3QkFDUCxNQUFNO3dCQUNOLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixZQUFZO3dCQUNaLFNBQVM7d0JBQ1QsZ0JBQWdCO3dCQUNoQixNQUFNO3dCQUNOLE9BQU87d0JBQ1AsV0FBVzt3QkFDWCxVQUFVO3dCQUNWLGtCQUFrQjt3QkFDbEIsa0JBQWtCO3dCQUNsQixXQUFXO3dCQUNYLFNBQVM7d0JBQ1QsZUFBZTt3QkFDZixnQkFBZ0I7d0JBQ2hCLGNBQWM7d0JBQ2QsV0FBVzt3QkFDWCxRQUFRO3dCQUNSLFlBQVk7d0JBQ1osT0FBTzt3QkFDUCxhQUFhO3dCQUNiLFlBQVk7d0JBQ1osYUFBYTt3QkFDYixlQUFlO3dCQUNmLG1CQUFtQjt3QkFDbkIsVUFBVTt3QkFDVixVQUFVO3dCQUNWLE9BQU87d0JBQ1AsVUFBVTt3QkFDVixNQUFNO3dCQUNOLGVBQWU7d0JBQ2YsWUFBWTt3QkFDWixTQUFTO3dCQUNULE9BQU87d0JBQ1AsY0FBYzt3QkFDZCxnQkFBZ0I7d0JBQ2hCLHFCQUFxQjt3QkFDckIsUUFBUTtxQkFDWDs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBMEJqQixNQUFNLE9BQU8sNkJBQTZCOzJIQUE3Qiw2QkFBNkI7NEhBQTdCLDZCQUE2QixpQkFsQzdCLGdDQUFnQyxhQUFoQyxnQ0FBZ0M7NEhBa0NoQyw2QkFBNkI7OzRGQUE3Qiw2QkFBNkI7a0JBUnpDLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLGdDQUFnQztxQkFDakM7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLGdDQUFnQztxQkFDakM7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgT25Jbml0LFxuICAgIE9uRGVzdHJveSxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIFNraXBTZWxmXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cblxuXG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhvQ2hhcnRDb21tb25TZXJpZXNTZXR0aW5ncyB9IGZyb20gJy4vYmFzZS9jaGFydC1jb21tb24tc2VyaWVzLXNldHRpbmdzJztcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4by1jb21tb24tc2VyaWVzLXNldHRpbmdzJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnYWdncmVnYXRpb24nLFxuICAgICAgICAnYXJlYScsXG4gICAgICAgICdhcmd1bWVudEZpZWxkJyxcbiAgICAgICAgJ2F4aXMnLFxuICAgICAgICAnYmFyJyxcbiAgICAgICAgJ2Jhck92ZXJsYXBHcm91cCcsXG4gICAgICAgICdiYXJQYWRkaW5nJyxcbiAgICAgICAgJ2JhcldpZHRoJyxcbiAgICAgICAgJ2JvcmRlcicsXG4gICAgICAgICdidWJibGUnLFxuICAgICAgICAnY2FuZGxlc3RpY2snLFxuICAgICAgICAnY2xvc2VWYWx1ZUZpZWxkJyxcbiAgICAgICAgJ2NvbG9yJyxcbiAgICAgICAgJ2Nvcm5lclJhZGl1cycsXG4gICAgICAgICdkYXNoU3R5bGUnLFxuICAgICAgICAnZnVsbHN0YWNrZWRhcmVhJyxcbiAgICAgICAgJ2Z1bGxzdGFja2VkYmFyJyxcbiAgICAgICAgJ2Z1bGxzdGFja2VkbGluZScsXG4gICAgICAgICdmdWxsc3RhY2tlZHNwbGluZScsXG4gICAgICAgICdmdWxsc3RhY2tlZHNwbGluZWFyZWEnLFxuICAgICAgICAnaGlnaFZhbHVlRmllbGQnLFxuICAgICAgICAnaG92ZXJNb2RlJyxcbiAgICAgICAgJ2hvdmVyU3R5bGUnLFxuICAgICAgICAnaWdub3JlRW1wdHlQb2ludHMnLFxuICAgICAgICAnaW5uZXJDb2xvcicsXG4gICAgICAgICdsYWJlbCcsXG4gICAgICAgICdsaW5lJyxcbiAgICAgICAgJ2xvd1ZhbHVlRmllbGQnLFxuICAgICAgICAnbWF4TGFiZWxDb3VudCcsXG4gICAgICAgICdtaW5CYXJTaXplJyxcbiAgICAgICAgJ29wYWNpdHknLFxuICAgICAgICAnb3BlblZhbHVlRmllbGQnLFxuICAgICAgICAncGFuZScsXG4gICAgICAgICdwb2ludCcsXG4gICAgICAgICdyYW5nZWFyZWEnLFxuICAgICAgICAncmFuZ2ViYXInLFxuICAgICAgICAncmFuZ2VWYWx1ZTFGaWVsZCcsXG4gICAgICAgICdyYW5nZVZhbHVlMkZpZWxkJyxcbiAgICAgICAgJ3JlZHVjdGlvbicsXG4gICAgICAgICdzY2F0dGVyJyxcbiAgICAgICAgJ3NlbGVjdGlvbk1vZGUnLFxuICAgICAgICAnc2VsZWN0aW9uU3R5bGUnLFxuICAgICAgICAnc2hvd0luTGVnZW5kJyxcbiAgICAgICAgJ3NpemVGaWVsZCcsXG4gICAgICAgICdzcGxpbmUnLFxuICAgICAgICAnc3BsaW5lYXJlYScsXG4gICAgICAgICdzdGFjaycsXG4gICAgICAgICdzdGFja2VkYXJlYScsXG4gICAgICAgICdzdGFja2VkYmFyJyxcbiAgICAgICAgJ3N0YWNrZWRsaW5lJyxcbiAgICAgICAgJ3N0YWNrZWRzcGxpbmUnLFxuICAgICAgICAnc3RhY2tlZHNwbGluZWFyZWEnLFxuICAgICAgICAnc3RlcGFyZWEnLFxuICAgICAgICAnc3RlcGxpbmUnLFxuICAgICAgICAnc3RvY2snLFxuICAgICAgICAndGFnRmllbGQnLFxuICAgICAgICAndHlwZScsXG4gICAgICAgICd2YWx1ZUVycm9yQmFyJyxcbiAgICAgICAgJ3ZhbHVlRmllbGQnLFxuICAgICAgICAndmlzaWJsZScsXG4gICAgICAgICd3aWR0aCcsXG4gICAgICAgICdhcmd1bWVudFR5cGUnLFxuICAgICAgICAnbWluU2VnbWVudFNpemUnLFxuICAgICAgICAnc21hbGxWYWx1ZXNHcm91cGluZycsXG4gICAgICAgICdjbG9zZWQnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeG9Db21tb25TZXJpZXNTZXR0aW5nc0NvbXBvbmVudCBleHRlbmRzIER4b0NoYXJ0Q29tbW9uU2VyaWVzU2V0dGluZ3MgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uSW5pdCAge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdjb21tb25TZXJpZXNTZXR0aW5ncyc7XG4gICAgfVxuXG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLl9hZGRSZWNyZWF0ZWRDb21wb25lbnQoKTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVtb3ZlZE9wdGlvbih0aGlzLl9nZXRPcHRpb25QYXRoKCkpO1xuICAgIH1cblxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4b0NvbW1vblNlcmllc1NldHRpbmdzQ29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeG9Db21tb25TZXJpZXNTZXR0aW5nc0NvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9Db21tb25TZXJpZXNTZXR0aW5nc01vZHVsZSB7IH1cbiJdfQ==