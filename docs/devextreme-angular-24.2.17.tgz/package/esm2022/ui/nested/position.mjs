/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoPositionConfig } from './base/position-config';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoPositionComponent extends DxoPositionConfig {
    get _optionPath() {
        return 'position';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoPositionComponent, selector: "dxo-position", inputs: { at: "at", boundary: "boundary", boundaryOffset: "boundaryOffset", collision: "collision", my: "my", of: "of", offset: "offset" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-position', template: '', providers: [NestedOptionHost], inputs: [
                        'at',
                        'boundary',
                        'boundaryOffset',
                        'collision',
                        'my',
                        'of',
                        'offset'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoPositionModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionModule, declarations: [DxoPositionComponent], exports: [DxoPositionComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoPositionComponent
                    ],
                    exports: [
                        DxoPositionComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9zaXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9wb3NpdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFHVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFFBQVEsRUFDWCxNQUFNLGVBQWUsQ0FBQztBQU12QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sd0JBQXdCLENBQUM7OztBQWtCM0QsTUFBTSxPQUFPLG9CQUFxQixTQUFRLGlCQUFpQjtJQUV2RCxJQUFjLFdBQVc7UUFDckIsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUdELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUNSLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFHRCxRQUFRO1FBQ0osSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7SUFDbEQsQ0FBQzsySEFyQlEsb0JBQW9COytHQUFwQixvQkFBb0IsbUxBWGxCLENBQUMsZ0JBQWdCLENBQUMsaURBRm5CLEVBQUU7OzRGQWFILG9CQUFvQjtrQkFmaEMsU0FBUzsrQkFDSSxjQUFjLFlBQ2QsRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUMsVUFDckI7d0JBQ0osSUFBSTt3QkFDSixVQUFVO3dCQUNWLGdCQUFnQjt3QkFDaEIsV0FBVzt3QkFDWCxJQUFJO3dCQUNKLElBQUk7d0JBQ0osUUFBUTtxQkFDWDs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBMEJqQixNQUFNLE9BQU8saUJBQWlCOzJIQUFqQixpQkFBaUI7NEhBQWpCLGlCQUFpQixpQkFsQ2pCLG9CQUFvQixhQUFwQixvQkFBb0I7NEhBa0NwQixpQkFBaUI7OzRGQUFqQixpQkFBaUI7a0JBUjdCLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLG9CQUFvQjtxQkFDckI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLG9CQUFvQjtxQkFDckI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgT25Jbml0LFxuICAgIE9uRGVzdHJveSxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIFNraXBTZWxmXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cblxuXG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhvUG9zaXRpb25Db25maWcgfSBmcm9tICcuL2Jhc2UvcG9zaXRpb24tY29uZmlnJztcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4by1wb3NpdGlvbicsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHN0eWxlczogWycnXSxcbiAgICBwcm92aWRlcnM6IFtOZXN0ZWRPcHRpb25Ib3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2F0JyxcbiAgICAgICAgJ2JvdW5kYXJ5JyxcbiAgICAgICAgJ2JvdW5kYXJ5T2Zmc2V0JyxcbiAgICAgICAgJ2NvbGxpc2lvbicsXG4gICAgICAgICdteScsXG4gICAgICAgICdvZicsXG4gICAgICAgICdvZmZzZXQnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeG9Qb3NpdGlvbkNvbXBvbmVudCBleHRlbmRzIER4b1Bvc2l0aW9uQ29uZmlnIGltcGxlbWVudHMgT25EZXN0cm95LCBPbkluaXQgIHtcblxuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAncG9zaXRpb24nO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9Qb3NpdGlvbkNvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhvUG9zaXRpb25Db21wb25lbnRcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRHhvUG9zaXRpb25Nb2R1bGUgeyB9XG4iXX0=