/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf, Output, EventEmitter, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoPopupOptions } from './base/popup-options';
import { DxiToolbarItemComponent } from './toolbar-item-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoFilterBuilderPopupComponent extends DxoPopupOptions {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    get _optionPath() {
        return 'filterBuilderPopup';
    }
    get toolbarItemsChildren() {
        return this._getOption('toolbarItems');
    }
    set toolbarItemsChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'heightChange' },
            { emit: 'positionChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFilterBuilderPopupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoFilterBuilderPopupComponent, selector: "dxo-filter-builder-popup", inputs: { accessKey: "accessKey", animation: "animation", closeOnOutsideClick: "closeOnOutsideClick", container: "container", contentTemplate: "contentTemplate", deferRendering: "deferRendering", disabled: "disabled", dragAndResizeArea: "dragAndResizeArea", dragEnabled: "dragEnabled", dragOutsideBoundary: "dragOutsideBoundary", enableBodyScroll: "enableBodyScroll", focusStateEnabled: "focusStateEnabled", fullScreen: "fullScreen", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResize: "onResize", onResizeEnd: "onResizeEnd", onResizeStart: "onResizeStart", onShowing: "onShowing", onShown: "onShown", onTitleRendered: "onTitleRendered", position: "position", resizeEnabled: "resizeEnabled", restorePosition: "restorePosition", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showCloseButton: "showCloseButton", showTitle: "showTitle", tabIndex: "tabIndex", title: "title", titleTemplate: "titleTemplate", toolbarItems: "toolbarItems", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { heightChange: "heightChange", positionChange: "positionChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "toolbarItemsChildren", predicate: i0.forwardRef(function () { return DxiToolbarItemComponent; }) }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFilterBuilderPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-filter-builder-popup', template: '', providers: [NestedOptionHost], inputs: [
                        'accessKey',
                        'animation',
                        'closeOnOutsideClick',
                        'container',
                        'contentTemplate',
                        'deferRendering',
                        'disabled',
                        'dragAndResizeArea',
                        'dragEnabled',
                        'dragOutsideBoundary',
                        'enableBodyScroll',
                        'focusStateEnabled',
                        'fullScreen',
                        'height',
                        'hideOnOutsideClick',
                        'hideOnParentScroll',
                        'hint',
                        'hoverStateEnabled',
                        'maxHeight',
                        'maxWidth',
                        'minHeight',
                        'minWidth',
                        'onContentReady',
                        'onDisposing',
                        'onHidden',
                        'onHiding',
                        'onInitialized',
                        'onOptionChanged',
                        'onResize',
                        'onResizeEnd',
                        'onResizeStart',
                        'onShowing',
                        'onShown',
                        'onTitleRendered',
                        'position',
                        'resizeEnabled',
                        'restorePosition',
                        'rtlEnabled',
                        'shading',
                        'shadingColor',
                        'showCloseButton',
                        'showTitle',
                        'tabIndex',
                        'title',
                        'titleTemplate',
                        'toolbarItems',
                        'visible',
                        'width',
                        'wrapperAttr'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { heightChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], toolbarItemsChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiToolbarItemComponent)]
            }] } });
export class DxoFilterBuilderPopupModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFilterBuilderPopupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoFilterBuilderPopupModule, declarations: [DxoFilterBuilderPopupComponent], exports: [DxoFilterBuilderPopupComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFilterBuilderPopupModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFilterBuilderPopupModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoFilterBuilderPopupComponent
                    ],
                    exports: [
                        DxoFilterBuilderPopupComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsdGVyLWJ1aWxkZXItcG9wdXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9maWx0ZXItYnVpbGRlci1wb3B1cC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFHVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFFBQVEsRUFDUixNQUFNLEVBQ04sWUFBWSxFQUNaLGVBQWUsRUFDZixVQUFVLEVBQ1YsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBUXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDdkQsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQTREN0QsTUFBTSxPQUFPLDhCQUErQixTQUFRLGVBQWU7SUFFL0Q7Ozs7T0FJRztJQUNPLFlBQVksQ0FBMkM7SUFFakU7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBOEQ7SUFFdEY7Ozs7T0FJRztJQUNPLGFBQWEsQ0FBd0I7SUFFL0M7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBMkM7SUFDaEUsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sb0JBQW9CLENBQUM7SUFDaEMsQ0FBQztJQUdELElBQ0ksb0JBQW9CO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxvQkFBb0IsQ0FBQyxLQUFLO1FBQzFCLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFRCxZQUFnQyxnQkFBa0MsRUFDbEQsVUFBNEI7UUFDeEMsS0FBSyxFQUFFLENBQUM7UUFFUixJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDdEIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7U0FDMUIsQ0FBQyxDQUFDO1FBRUgsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUdELFFBQVE7UUFDSixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDOzJIQWhFUSw4QkFBOEI7K0dBQTlCLDhCQUE4Qiw4akRBckQ1QixDQUFDLGdCQUFnQixDQUFDLGtHQXVGSyx1QkFBdUIsd0RBekYvQyxFQUFFOzs0RkF1REgsOEJBQThCO2tCQXpEMUMsU0FBUzsrQkFDSSwwQkFBMEIsWUFDMUIsRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUMsVUFDckI7d0JBQ0osV0FBVzt3QkFDWCxXQUFXO3dCQUNYLHFCQUFxQjt3QkFDckIsV0FBVzt3QkFDWCxpQkFBaUI7d0JBQ2pCLGdCQUFnQjt3QkFDaEIsVUFBVTt3QkFDVixtQkFBbUI7d0JBQ25CLGFBQWE7d0JBQ2IscUJBQXFCO3dCQUNyQixrQkFBa0I7d0JBQ2xCLG1CQUFtQjt3QkFDbkIsWUFBWTt3QkFDWixRQUFRO3dCQUNSLG9CQUFvQjt3QkFDcEIsb0JBQW9CO3dCQUNwQixNQUFNO3dCQUNOLG1CQUFtQjt3QkFDbkIsV0FBVzt3QkFDWCxVQUFVO3dCQUNWLFdBQVc7d0JBQ1gsVUFBVTt3QkFDVixnQkFBZ0I7d0JBQ2hCLGFBQWE7d0JBQ2IsVUFBVTt3QkFDVixVQUFVO3dCQUNWLGVBQWU7d0JBQ2YsaUJBQWlCO3dCQUNqQixVQUFVO3dCQUNWLGFBQWE7d0JBQ2IsZUFBZTt3QkFDZixXQUFXO3dCQUNYLFNBQVM7d0JBQ1QsaUJBQWlCO3dCQUNqQixVQUFVO3dCQUNWLGVBQWU7d0JBQ2YsaUJBQWlCO3dCQUNqQixZQUFZO3dCQUNaLFNBQVM7d0JBQ1QsY0FBYzt3QkFDZCxpQkFBaUI7d0JBQ2pCLFdBQVc7d0JBQ1gsVUFBVTt3QkFDVixPQUFPO3dCQUNQLGVBQWU7d0JBQ2YsY0FBYzt3QkFDZCxTQUFTO3dCQUNULE9BQU87d0JBQ1AsYUFBYTtxQkFDaEI7OzBCQTRDWSxRQUFROzswQkFBSSxJQUFJOzswQkFDcEIsSUFBSTs0Q0FwQ0gsWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPSCxvQkFBb0I7c0JBRHZCLGVBQWU7dUJBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHVCQUF1QixDQUFDOztBQTJDOUQsTUFBTSxPQUFPLDJCQUEyQjsySEFBM0IsMkJBQTJCOzRIQUEzQiwyQkFBMkIsaUJBN0UzQiw4QkFBOEIsYUFBOUIsOEJBQThCOzRIQTZFOUIsMkJBQTJCOzs0RkFBM0IsMkJBQTJCO2tCQVJ2QyxRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWiw4QkFBOEI7cUJBQy9CO29CQUNELE9BQU8sRUFBRTt3QkFDUCw4QkFBOEI7cUJBQy9CO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE9uSW5pdCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBTa2lwU2VsZixcbiAgICBPdXRwdXQsXG4gICAgRXZlbnRFbWl0dGVyLFxuICAgIENvbnRlbnRDaGlsZHJlbixcbiAgICBmb3J3YXJkUmVmLFxuICAgIFF1ZXJ5TGlzdFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG5cblxuaW1wb3J0IHsgUG9zaXRpb25Db25maWcgfSBmcm9tICdkZXZleHRyZW1lL2FuaW1hdGlvbi9wb3NpdGlvbic7XG5pbXBvcnQgeyBQb3NpdGlvbkFsaWdubWVudCB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uJztcblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeG9Qb3B1cE9wdGlvbnMgfSBmcm9tICcuL2Jhc2UvcG9wdXAtb3B0aW9ucyc7XG5pbXBvcnQgeyBEeGlUb29sYmFySXRlbUNvbXBvbmVudCB9IGZyb20gJy4vdG9vbGJhci1pdGVtLWR4aSc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeG8tZmlsdGVyLWJ1aWxkZXItcG9wdXAnLFxuICAgIHRlbXBsYXRlOiAnJyxcbiAgICBzdHlsZXM6IFsnJ10sXG4gICAgcHJvdmlkZXJzOiBbTmVzdGVkT3B0aW9uSG9zdF0sXG4gICAgaW5wdXRzOiBbXG4gICAgICAgICdhY2Nlc3NLZXknLFxuICAgICAgICAnYW5pbWF0aW9uJyxcbiAgICAgICAgJ2Nsb3NlT25PdXRzaWRlQ2xpY2snLFxuICAgICAgICAnY29udGFpbmVyJyxcbiAgICAgICAgJ2NvbnRlbnRUZW1wbGF0ZScsXG4gICAgICAgICdkZWZlclJlbmRlcmluZycsXG4gICAgICAgICdkaXNhYmxlZCcsXG4gICAgICAgICdkcmFnQW5kUmVzaXplQXJlYScsXG4gICAgICAgICdkcmFnRW5hYmxlZCcsXG4gICAgICAgICdkcmFnT3V0c2lkZUJvdW5kYXJ5JyxcbiAgICAgICAgJ2VuYWJsZUJvZHlTY3JvbGwnLFxuICAgICAgICAnZm9jdXNTdGF0ZUVuYWJsZWQnLFxuICAgICAgICAnZnVsbFNjcmVlbicsXG4gICAgICAgICdoZWlnaHQnLFxuICAgICAgICAnaGlkZU9uT3V0c2lkZUNsaWNrJyxcbiAgICAgICAgJ2hpZGVPblBhcmVudFNjcm9sbCcsXG4gICAgICAgICdoaW50JyxcbiAgICAgICAgJ2hvdmVyU3RhdGVFbmFibGVkJyxcbiAgICAgICAgJ21heEhlaWdodCcsXG4gICAgICAgICdtYXhXaWR0aCcsXG4gICAgICAgICdtaW5IZWlnaHQnLFxuICAgICAgICAnbWluV2lkdGgnLFxuICAgICAgICAnb25Db250ZW50UmVhZHknLFxuICAgICAgICAnb25EaXNwb3NpbmcnLFxuICAgICAgICAnb25IaWRkZW4nLFxuICAgICAgICAnb25IaWRpbmcnLFxuICAgICAgICAnb25Jbml0aWFsaXplZCcsXG4gICAgICAgICdvbk9wdGlvbkNoYW5nZWQnLFxuICAgICAgICAnb25SZXNpemUnLFxuICAgICAgICAnb25SZXNpemVFbmQnLFxuICAgICAgICAnb25SZXNpemVTdGFydCcsXG4gICAgICAgICdvblNob3dpbmcnLFxuICAgICAgICAnb25TaG93bicsXG4gICAgICAgICdvblRpdGxlUmVuZGVyZWQnLFxuICAgICAgICAncG9zaXRpb24nLFxuICAgICAgICAncmVzaXplRW5hYmxlZCcsXG4gICAgICAgICdyZXN0b3JlUG9zaXRpb24nLFxuICAgICAgICAncnRsRW5hYmxlZCcsXG4gICAgICAgICdzaGFkaW5nJyxcbiAgICAgICAgJ3NoYWRpbmdDb2xvcicsXG4gICAgICAgICdzaG93Q2xvc2VCdXR0b24nLFxuICAgICAgICAnc2hvd1RpdGxlJyxcbiAgICAgICAgJ3RhYkluZGV4JyxcbiAgICAgICAgJ3RpdGxlJyxcbiAgICAgICAgJ3RpdGxlVGVtcGxhdGUnLFxuICAgICAgICAndG9vbGJhckl0ZW1zJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAnd2lkdGgnLFxuICAgICAgICAnd3JhcHBlckF0dHInXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeG9GaWx0ZXJCdWlsZGVyUG9wdXBDb21wb25lbnQgZXh0ZW5kcyBEeG9Qb3B1cE9wdGlvbnMgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uSW5pdCAge1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcG9zaXRpb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxQb3NpdGlvbkFsaWdubWVudCB8IFBvc2l0aW9uQ29uZmlnIHwgRnVuY3Rpb24+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdmlzaWJsZUNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgd2lkdGhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZz47XG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdmaWx0ZXJCdWlsZGVyUG9wdXAnO1xuICAgIH1cblxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihmb3J3YXJkUmVmKCgpID0+IER4aVRvb2xiYXJJdGVtQ29tcG9uZW50KSlcbiAgICBnZXQgdG9vbGJhckl0ZW1zQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aVRvb2xiYXJJdGVtQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Rvb2xiYXJJdGVtcycpO1xuICAgIH1cbiAgICBzZXQgdG9vbGJhckl0ZW1zQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbigndG9vbGJhckl0ZW1zJywgdmFsdWUpO1xuICAgIH1cblxuICAgIGNvbnN0cnVjdG9yKEBTa2lwU2VsZigpIEBIb3N0KCkgcGFyZW50T3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgICAgIEBIb3N0KCkgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCkge1xuICAgICAgICBzdXBlcigpO1xuXG4gICAgICAgIHRoaXMuX2NyZWF0ZUV2ZW50RW1pdHRlcnMoW1xuICAgICAgICAgICAgeyBlbWl0OiAnaGVpZ2h0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncG9zaXRpb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2aXNpYmxlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnd2lkdGhDaGFuZ2UnIH1cbiAgICAgICAgXSk7XG5cbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLl9hZGRSZWNyZWF0ZWRDb21wb25lbnQoKTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVtb3ZlZE9wdGlvbih0aGlzLl9nZXRPcHRpb25QYXRoKCkpO1xuICAgIH1cblxuXG59XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4b0ZpbHRlckJ1aWxkZXJQb3B1cENvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhvRmlsdGVyQnVpbGRlclBvcHVwQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4b0ZpbHRlckJ1aWxkZXJQb3B1cE1vZHVsZSB7IH1cbiJdfQ==