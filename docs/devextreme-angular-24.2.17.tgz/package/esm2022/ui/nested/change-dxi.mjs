/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiDataChange } from './base/data-change-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiChangeComponent extends DxiDataChange {
    get _optionPath() {
        return 'changes';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiChangeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiChangeComponent, selector: "dxi-change", inputs: { data: "data", insertAfterKey: "insertAfterKey", insertBeforeKey: "insertBeforeKey", key: "key", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiChangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-change', template: '', providers: [NestedOptionHost], inputs: [
                        'data',
                        'insertAfterKey',
                        'insertBeforeKey',
                        'key',
                        'type'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxiChangeModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiChangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiChangeModule, declarations: [DxiChangeComponent], exports: [DxiChangeComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiChangeModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiChangeModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiChangeComponent
                    ],
                    exports: [
                        DxiChangeComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhbmdlLWR4aS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2NoYW5nZS1keGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsaURBQWlEO0FBRWpELE9BQU8sRUFDSCxTQUFTLEVBQ1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1gsTUFBTSxlQUFlLENBQUM7QUFNdkIsT0FBTyxFQUNILGdCQUFnQixHQUNuQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQzs7O0FBZ0J2RCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsYUFBYTtJQUVqRCxJQUFjLFdBQVc7UUFDckIsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUdELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUNSLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFJRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7MkhBbEJRLGtCQUFrQjsrR0FBbEIsa0JBQWtCLCtKQVRoQixDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkFXSCxrQkFBa0I7a0JBYjlCLFNBQVM7K0JBQ0ksWUFBWSxZQUNaLEVBQUUsYUFFRCxDQUFDLGdCQUFnQixDQUFDLFVBQ3JCO3dCQUNKLE1BQU07d0JBQ04sZ0JBQWdCO3dCQUNoQixpQkFBaUI7d0JBQ2pCLEtBQUs7d0JBQ0wsTUFBTTtxQkFDVDs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBc0JqQixNQUFNLE9BQU8sZUFBZTsySEFBZixlQUFlOzRIQUFmLGVBQWUsaUJBOUJmLGtCQUFrQixhQUFsQixrQkFBa0I7NEhBOEJsQixlQUFlOzs0RkFBZixlQUFlO2tCQVIzQixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWixrQkFBa0I7cUJBQ25CO29CQUNELE9BQU8sRUFBRTt3QkFDUCxrQkFBa0I7cUJBQ25CO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeGlEYXRhQ2hhbmdlIH0gZnJvbSAnLi9iYXNlL2RhdGEtY2hhbmdlLWR4aSc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeGktY2hhbmdlJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnZGF0YScsXG4gICAgICAgICdpbnNlcnRBZnRlcktleScsXG4gICAgICAgICdpbnNlcnRCZWZvcmVLZXknLFxuICAgICAgICAna2V5JyxcbiAgICAgICAgJ3R5cGUnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeGlDaGFuZ2VDb21wb25lbnQgZXh0ZW5kcyBEeGlEYXRhQ2hhbmdlIHtcblxuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnY2hhbmdlcyc7XG4gICAgfVxuXG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cblxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2RlbGV0ZVJlbW92ZWRPcHRpb25zKHRoaXMuX2Z1bGxPcHRpb25QYXRoKCkpO1xuICAgIH1cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeGlDaGFuZ2VDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4aUNoYW5nZUNvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeGlDaGFuZ2VNb2R1bGUgeyB9XG4iXX0=