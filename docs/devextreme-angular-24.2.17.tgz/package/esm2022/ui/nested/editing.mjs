/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { Component, NgModule, Host, SkipSelf, Input, Output, EventEmitter, ContentChildren, forwardRef, QueryList } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { NestedOption } from 'devextreme-angular/core';
import { DxiChangeComponent } from './change-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoEditingComponent extends NestedOption {
    get allowAdding() {
        return this._getOption('allowAdding');
    }
    set allowAdding(value) {
        this._setOption('allowAdding', value);
    }
    get allowDeleting() {
        return this._getOption('allowDeleting');
    }
    set allowDeleting(value) {
        this._setOption('allowDeleting', value);
    }
    get allowUpdating() {
        return this._getOption('allowUpdating');
    }
    set allowUpdating(value) {
        this._setOption('allowUpdating', value);
    }
    get changes() {
        return this._getOption('changes');
    }
    set changes(value) {
        this._setOption('changes', value);
    }
    get confirmDelete() {
        return this._getOption('confirmDelete');
    }
    set confirmDelete(value) {
        this._setOption('confirmDelete', value);
    }
    get editColumnName() {
        return this._getOption('editColumnName');
    }
    set editColumnName(value) {
        this._setOption('editColumnName', value);
    }
    get editRowKey() {
        return this._getOption('editRowKey');
    }
    set editRowKey(value) {
        this._setOption('editRowKey', value);
    }
    get form() {
        return this._getOption('form');
    }
    set form(value) {
        this._setOption('form', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get newRowPosition() {
        return this._getOption('newRowPosition');
    }
    set newRowPosition(value) {
        this._setOption('newRowPosition', value);
    }
    get popup() {
        return this._getOption('popup');
    }
    set popup(value) {
        this._setOption('popup', value);
    }
    get refreshMode() {
        return this._getOption('refreshMode');
    }
    set refreshMode(value) {
        this._setOption('refreshMode', value);
    }
    get selectTextOnEditStart() {
        return this._getOption('selectTextOnEditStart');
    }
    set selectTextOnEditStart(value) {
        this._setOption('selectTextOnEditStart', value);
    }
    get startEditAction() {
        return this._getOption('startEditAction');
    }
    set startEditAction(value) {
        this._setOption('startEditAction', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get useIcons() {
        return this._getOption('useIcons');
    }
    set useIcons(value) {
        this._setOption('useIcons', value);
    }
    get allowAddShape() {
        return this._getOption('allowAddShape');
    }
    set allowAddShape(value) {
        this._setOption('allowAddShape', value);
    }
    get allowChangeConnection() {
        return this._getOption('allowChangeConnection');
    }
    set allowChangeConnection(value) {
        this._setOption('allowChangeConnection', value);
    }
    get allowChangeConnectorPoints() {
        return this._getOption('allowChangeConnectorPoints');
    }
    set allowChangeConnectorPoints(value) {
        this._setOption('allowChangeConnectorPoints', value);
    }
    get allowChangeConnectorText() {
        return this._getOption('allowChangeConnectorText');
    }
    set allowChangeConnectorText(value) {
        this._setOption('allowChangeConnectorText', value);
    }
    get allowChangeShapeText() {
        return this._getOption('allowChangeShapeText');
    }
    set allowChangeShapeText(value) {
        this._setOption('allowChangeShapeText', value);
    }
    get allowDeleteConnector() {
        return this._getOption('allowDeleteConnector');
    }
    set allowDeleteConnector(value) {
        this._setOption('allowDeleteConnector', value);
    }
    get allowDeleteShape() {
        return this._getOption('allowDeleteShape');
    }
    set allowDeleteShape(value) {
        this._setOption('allowDeleteShape', value);
    }
    get allowMoveShape() {
        return this._getOption('allowMoveShape');
    }
    set allowMoveShape(value) {
        this._setOption('allowMoveShape', value);
    }
    get allowResizeShape() {
        return this._getOption('allowResizeShape');
    }
    set allowResizeShape(value) {
        this._setOption('allowResizeShape', value);
    }
    get allowDependencyAdding() {
        return this._getOption('allowDependencyAdding');
    }
    set allowDependencyAdding(value) {
        this._setOption('allowDependencyAdding', value);
    }
    get allowDependencyDeleting() {
        return this._getOption('allowDependencyDeleting');
    }
    set allowDependencyDeleting(value) {
        this._setOption('allowDependencyDeleting', value);
    }
    get allowResourceAdding() {
        return this._getOption('allowResourceAdding');
    }
    set allowResourceAdding(value) {
        this._setOption('allowResourceAdding', value);
    }
    get allowResourceDeleting() {
        return this._getOption('allowResourceDeleting');
    }
    set allowResourceDeleting(value) {
        this._setOption('allowResourceDeleting', value);
    }
    get allowResourceUpdating() {
        return this._getOption('allowResourceUpdating');
    }
    set allowResourceUpdating(value) {
        this._setOption('allowResourceUpdating', value);
    }
    get allowTaskAdding() {
        return this._getOption('allowTaskAdding');
    }
    set allowTaskAdding(value) {
        this._setOption('allowTaskAdding', value);
    }
    get allowTaskDeleting() {
        return this._getOption('allowTaskDeleting');
    }
    set allowTaskDeleting(value) {
        this._setOption('allowTaskDeleting', value);
    }
    get allowTaskResourceUpdating() {
        return this._getOption('allowTaskResourceUpdating');
    }
    set allowTaskResourceUpdating(value) {
        this._setOption('allowTaskResourceUpdating', value);
    }
    get allowTaskUpdating() {
        return this._getOption('allowTaskUpdating');
    }
    set allowTaskUpdating(value) {
        this._setOption('allowTaskUpdating', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get allowDragging() {
        return this._getOption('allowDragging');
    }
    set allowDragging(value) {
        this._setOption('allowDragging', value);
    }
    get allowResizing() {
        return this._getOption('allowResizing');
    }
    set allowResizing(value) {
        this._setOption('allowResizing', value);
    }
    get allowTimeZoneEditing() {
        return this._getOption('allowTimeZoneEditing');
    }
    set allowTimeZoneEditing(value) {
        this._setOption('allowTimeZoneEditing', value);
    }
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    changesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editColumnNameChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editRowKeyChange;
    get _optionPath() {
        return 'editing';
    }
    get changesChildren() {
        return this._getOption('changes');
    }
    set changesChildren(value) {
        this.setChildren('changes', value);
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'changesChange' },
            { emit: 'editColumnNameChange' },
            { emit: 'editRowKeyChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoEditingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoEditingComponent, selector: "dxo-editing", inputs: { allowAdding: "allowAdding", allowDeleting: "allowDeleting", allowUpdating: "allowUpdating", changes: "changes", confirmDelete: "confirmDelete", editColumnName: "editColumnName", editRowKey: "editRowKey", form: "form", mode: "mode", newRowPosition: "newRowPosition", popup: "popup", refreshMode: "refreshMode", selectTextOnEditStart: "selectTextOnEditStart", startEditAction: "startEditAction", texts: "texts", useIcons: "useIcons", allowAddShape: "allowAddShape", allowChangeConnection: "allowChangeConnection", allowChangeConnectorPoints: "allowChangeConnectorPoints", allowChangeConnectorText: "allowChangeConnectorText", allowChangeShapeText: "allowChangeShapeText", allowDeleteConnector: "allowDeleteConnector", allowDeleteShape: "allowDeleteShape", allowMoveShape: "allowMoveShape", allowResizeShape: "allowResizeShape", allowDependencyAdding: "allowDependencyAdding", allowDependencyDeleting: "allowDependencyDeleting", allowResourceAdding: "allowResourceAdding", allowResourceDeleting: "allowResourceDeleting", allowResourceUpdating: "allowResourceUpdating", allowTaskAdding: "allowTaskAdding", allowTaskDeleting: "allowTaskDeleting", allowTaskResourceUpdating: "allowTaskResourceUpdating", allowTaskUpdating: "allowTaskUpdating", enabled: "enabled", allowDragging: "allowDragging", allowResizing: "allowResizing", allowTimeZoneEditing: "allowTimeZoneEditing" }, outputs: { changesChange: "changesChange", editColumnNameChange: "editColumnNameChange", editRowKeyChange: "editRowKeyChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "changesChildren", predicate: i0.forwardRef(function () { return DxiChangeComponent; }) }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoEditingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-editing', template: '', providers: [NestedOptionHost] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { allowAdding: [{
                type: Input
            }], allowDeleting: [{
                type: Input
            }], allowUpdating: [{
                type: Input
            }], changes: [{
                type: Input
            }], confirmDelete: [{
                type: Input
            }], editColumnName: [{
                type: Input
            }], editRowKey: [{
                type: Input
            }], form: [{
                type: Input
            }], mode: [{
                type: Input
            }], newRowPosition: [{
                type: Input
            }], popup: [{
                type: Input
            }], refreshMode: [{
                type: Input
            }], selectTextOnEditStart: [{
                type: Input
            }], startEditAction: [{
                type: Input
            }], texts: [{
                type: Input
            }], useIcons: [{
                type: Input
            }], allowAddShape: [{
                type: Input
            }], allowChangeConnection: [{
                type: Input
            }], allowChangeConnectorPoints: [{
                type: Input
            }], allowChangeConnectorText: [{
                type: Input
            }], allowChangeShapeText: [{
                type: Input
            }], allowDeleteConnector: [{
                type: Input
            }], allowDeleteShape: [{
                type: Input
            }], allowMoveShape: [{
                type: Input
            }], allowResizeShape: [{
                type: Input
            }], allowDependencyAdding: [{
                type: Input
            }], allowDependencyDeleting: [{
                type: Input
            }], allowResourceAdding: [{
                type: Input
            }], allowResourceDeleting: [{
                type: Input
            }], allowResourceUpdating: [{
                type: Input
            }], allowTaskAdding: [{
                type: Input
            }], allowTaskDeleting: [{
                type: Input
            }], allowTaskResourceUpdating: [{
                type: Input
            }], allowTaskUpdating: [{
                type: Input
            }], enabled: [{
                type: Input
            }], allowDragging: [{
                type: Input
            }], allowResizing: [{
                type: Input
            }], allowTimeZoneEditing: [{
                type: Input
            }], changesChange: [{
                type: Output
            }], editColumnNameChange: [{
                type: Output
            }], editRowKeyChange: [{
                type: Output
            }], changesChildren: [{
                type: ContentChildren,
                args: [forwardRef(() => DxiChangeComponent)]
            }] } });
export class DxoEditingModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoEditingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoEditingModule, declarations: [DxoEditingComponent], exports: [DxoEditingComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoEditingModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoEditingModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoEditingComponent
                    ],
                    exports: [
                        DxoEditingComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWRpdGluZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2VkaXRpbmcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUNILFNBQVMsRUFHVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFFBQVEsRUFDUixLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixlQUFlLEVBQ2YsVUFBVSxFQUNWLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQVN2QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGNBQWMsQ0FBQzs7O0FBU2xELE1BQU0sT0FBTyxtQkFBb0IsU0FBUSxZQUFZO0lBQ2pELElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBeUI7UUFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBeUI7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBeUI7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBd0I7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQWE7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFVO1FBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQW9CO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQW9CO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBcUI7UUFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFxQjtRQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUEyQjtRQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQsSUFDSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBYztRQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBc0I7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUEya0I7UUFDamxCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFDSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBYztRQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxJQUNJLDBCQUEwQjtRQUMxQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBSSwwQkFBMEIsQ0FBQyxLQUFjO1FBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUVELElBQ0ksd0JBQXdCO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxJQUFJLHdCQUF3QixDQUFDLEtBQWM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQsSUFDSSxvQkFBb0I7UUFDcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQUksb0JBQW9CLENBQUMsS0FBYztRQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxJQUNJLG9CQUFvQjtRQUNwQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBQ0QsSUFBSSxvQkFBb0IsQ0FBQyxLQUFjO1FBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELElBQ0ksZ0JBQWdCO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQWM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQWM7UUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBYztRQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUNJLHFCQUFxQjtRQUNyQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBSSxxQkFBcUIsQ0FBQyxLQUFjO1FBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELElBQ0ksdUJBQXVCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFDRCxJQUFJLHVCQUF1QixDQUFDLEtBQWM7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsSUFDSSxtQkFBbUI7UUFDbkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELElBQUksbUJBQW1CLENBQUMsS0FBYztRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCxJQUNJLHFCQUFxQjtRQUNyQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBSSxxQkFBcUIsQ0FBQyxLQUFjO1FBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELElBQ0kscUJBQXFCO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFJLHFCQUFxQixDQUFDLEtBQWM7UUFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQWM7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQsSUFDSSxpQkFBaUI7UUFDakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQUksaUJBQWlCLENBQUMsS0FBYztRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRCxJQUNJLHlCQUF5QjtRQUN6QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBSSx5QkFBeUIsQ0FBQyxLQUFjO1FBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELElBQ0ksaUJBQWlCO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDRCxJQUFJLGlCQUFpQixDQUFDLEtBQWM7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUNJLGFBQWE7UUFDYixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksYUFBYSxDQUFDLEtBQWM7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFDSSxvQkFBb0I7UUFDcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQUksb0JBQW9CLENBQUMsS0FBYztRQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFHRDs7OztPQUlHO0lBQ08sYUFBYSxDQUFrQztJQUV6RDs7OztPQUlHO0lBQ08sb0JBQW9CLENBQXVCO0lBRXJEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBb0I7SUFDOUMsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFHRCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQUs7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUVSLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUN0QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7U0FDL0IsQ0FBQyxDQUFDO1FBRUgsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUdELFFBQVE7UUFDSixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDOzJIQXhXUSxtQkFBbUI7K0dBQW5CLG1CQUFtQiwyZ0RBRmpCLENBQUMsZ0JBQWdCLENBQUMsNkZBNlVLLGtCQUFrQix3REEvVTFDLEVBQUU7OzRGQUlILG1CQUFtQjtrQkFOL0IsU0FBUzsrQkFDSSxhQUFhLFlBQ2IsRUFBRSxhQUVELENBQUMsZ0JBQWdCLENBQUM7OzBCQXFWaEIsUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7NENBbFZULFdBQVc7c0JBRGQsS0FBSztnQkFTRixhQUFhO3NCQURoQixLQUFLO2dCQVNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBU0YsT0FBTztzQkFEVixLQUFLO2dCQVNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBU0YsY0FBYztzQkFEakIsS0FBSztnQkFTRixVQUFVO3NCQURiLEtBQUs7Z0JBU0YsSUFBSTtzQkFEUCxLQUFLO2dCQVNGLElBQUk7c0JBRFAsS0FBSztnQkFTRixjQUFjO3NCQURqQixLQUFLO2dCQVNGLEtBQUs7c0JBRFIsS0FBSztnQkFTRixXQUFXO3NCQURkLEtBQUs7Z0JBU0YscUJBQXFCO3NCQUR4QixLQUFLO2dCQVNGLGVBQWU7c0JBRGxCLEtBQUs7Z0JBU0YsS0FBSztzQkFEUixLQUFLO2dCQVNGLFFBQVE7c0JBRFgsS0FBSztnQkFTRixhQUFhO3NCQURoQixLQUFLO2dCQVNGLHFCQUFxQjtzQkFEeEIsS0FBSztnQkFTRiwwQkFBMEI7c0JBRDdCLEtBQUs7Z0JBU0Ysd0JBQXdCO3NCQUQzQixLQUFLO2dCQVNGLG9CQUFvQjtzQkFEdkIsS0FBSztnQkFTRixvQkFBb0I7c0JBRHZCLEtBQUs7Z0JBU0YsZ0JBQWdCO3NCQURuQixLQUFLO2dCQVNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBU0YsZ0JBQWdCO3NCQURuQixLQUFLO2dCQVNGLHFCQUFxQjtzQkFEeEIsS0FBSztnQkFTRix1QkFBdUI7c0JBRDFCLEtBQUs7Z0JBU0YsbUJBQW1CO3NCQUR0QixLQUFLO2dCQVNGLHFCQUFxQjtzQkFEeEIsS0FBSztnQkFTRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBU0YsZUFBZTtzQkFEbEIsS0FBSztnQkFTRixpQkFBaUI7c0JBRHBCLEtBQUs7Z0JBU0YseUJBQXlCO3NCQUQ1QixLQUFLO2dCQVNGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFTRixPQUFPO3NCQURWLEtBQUs7Z0JBU0YsYUFBYTtzQkFEaEIsS0FBSztnQkFTRixhQUFhO3NCQURoQixLQUFLO2dCQVNGLG9CQUFvQjtzQkFEdkIsS0FBSztnQkFjSSxhQUFhO3NCQUF0QixNQUFNO2dCQU9HLG9CQUFvQjtzQkFBN0IsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0gsZUFBZTtzQkFEbEIsZUFBZTt1QkFBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsa0JBQWtCLENBQUM7O0FBMEN6RCxNQUFNLE9BQU8sZ0JBQWdCOzJIQUFoQixnQkFBZ0I7NEhBQWhCLGdCQUFnQixpQkFyWGhCLG1CQUFtQixhQUFuQixtQkFBbUI7NEhBcVhuQixnQkFBZ0I7OzRGQUFoQixnQkFBZ0I7a0JBUjVCLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLG1CQUFtQjtxQkFDcEI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLG1CQUFtQjtxQkFDcEI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgT25Jbml0LFxuICAgIE9uRGVzdHJveSxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIFNraXBTZWxmLFxuICAgIElucHV0LFxuICAgIE91dHB1dCxcbiAgICBFdmVudEVtaXR0ZXIsXG4gICAgQ29udGVudENoaWxkcmVuLFxuICAgIGZvcndhcmRSZWYsXG4gICAgUXVlcnlMaXN0XG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5cblxuXG5pbXBvcnQgeyBEYXRhQ2hhbmdlLCBHcmlkc0VkaXRNb2RlLCBHcmlkc0VkaXRSZWZyZXNoTW9kZSwgTmV3Um93UG9zaXRpb24sIFN0YXJ0RWRpdEFjdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uL2dyaWRzJztcbmltcG9ydCB7IFByb3BlcnRpZXMgYXMgZHhGb3JtT3B0aW9ucyB9IGZyb20gJ2RldmV4dHJlbWUvdWkvZm9ybSc7XG5pbXBvcnQgeyBQcm9wZXJ0aWVzIGFzIGR4UG9wdXBPcHRpb25zIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9wb3B1cCc7XG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmVzdGVkT3B0aW9uIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhpQ2hhbmdlQ29tcG9uZW50IH0gZnJvbSAnLi9jaGFuZ2UtZHhpJztcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4by1lZGl0aW5nJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdXG59KVxuZXhwb3J0IGNsYXNzIER4b0VkaXRpbmdDb21wb25lbnQgZXh0ZW5kcyBOZXN0ZWRPcHRpb24gaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uSW5pdCAge1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93QWRkaW5nKCk6IGJvb2xlYW4gfCBGdW5jdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93QWRkaW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd0FkZGluZyh2YWx1ZTogYm9vbGVhbiB8IEZ1bmN0aW9uKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dBZGRpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dEZWxldGluZygpOiBib29sZWFuIHwgRnVuY3Rpb24ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd0RlbGV0aW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd0RlbGV0aW5nKHZhbHVlOiBib29sZWFuIHwgRnVuY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd0RlbGV0aW5nJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93VXBkYXRpbmcoKTogYm9vbGVhbiB8IEZ1bmN0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dVcGRhdGluZycpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dVcGRhdGluZyh2YWx1ZTogYm9vbGVhbiB8IEZ1bmN0aW9uKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dVcGRhdGluZycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBjaGFuZ2VzKCk6IEFycmF5PERhdGFDaGFuZ2U+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY2hhbmdlcycpO1xuICAgIH1cbiAgICBzZXQgY2hhbmdlcyh2YWx1ZTogQXJyYXk8RGF0YUNoYW5nZT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjaGFuZ2VzJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGNvbmZpcm1EZWxldGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbmZpcm1EZWxldGUnKTtcbiAgICB9XG4gICAgc2V0IGNvbmZpcm1EZWxldGUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb25maXJtRGVsZXRlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGVkaXRDb2x1bW5OYW1lKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VkaXRDb2x1bW5OYW1lJyk7XG4gICAgfVxuICAgIHNldCBlZGl0Q29sdW1uTmFtZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZWRpdENvbHVtbk5hbWUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgZWRpdFJvd0tleSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdlZGl0Um93S2V5Jyk7XG4gICAgfVxuICAgIHNldCBlZGl0Um93S2V5KHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlZGl0Um93S2V5JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGZvcm0oKTogZHhGb3JtT3B0aW9ucyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Zvcm0nKTtcbiAgICB9XG4gICAgc2V0IGZvcm0odmFsdWU6IGR4Rm9ybU9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdmb3JtJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG1vZGUoKTogR3JpZHNFZGl0TW9kZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21vZGUnKTtcbiAgICB9XG4gICAgc2V0IG1vZGUodmFsdWU6IEdyaWRzRWRpdE1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdtb2RlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG5ld1Jvd1Bvc2l0aW9uKCk6IE5ld1Jvd1Bvc2l0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbmV3Um93UG9zaXRpb24nKTtcbiAgICB9XG4gICAgc2V0IG5ld1Jvd1Bvc2l0aW9uKHZhbHVlOiBOZXdSb3dQb3NpdGlvbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ25ld1Jvd1Bvc2l0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBvcHVwKCk6IGR4UG9wdXBPcHRpb25zIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncG9wdXAnKTtcbiAgICB9XG4gICAgc2V0IHBvcHVwKHZhbHVlOiBkeFBvcHVwT3B0aW9ucykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BvcHVwJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJlZnJlc2hNb2RlKCk6IEdyaWRzRWRpdFJlZnJlc2hNb2RlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVmcmVzaE1vZGUnKTtcbiAgICB9XG4gICAgc2V0IHJlZnJlc2hNb2RlKHZhbHVlOiBHcmlkc0VkaXRSZWZyZXNoTW9kZSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3JlZnJlc2hNb2RlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNlbGVjdFRleHRPbkVkaXRTdGFydCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2VsZWN0VGV4dE9uRWRpdFN0YXJ0Jyk7XG4gICAgfVxuICAgIHNldCBzZWxlY3RUZXh0T25FZGl0U3RhcnQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzZWxlY3RUZXh0T25FZGl0U3RhcnQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgc3RhcnRFZGl0QWN0aW9uKCk6IFN0YXJ0RWRpdEFjdGlvbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3N0YXJ0RWRpdEFjdGlvbicpO1xuICAgIH1cbiAgICBzZXQgc3RhcnRFZGl0QWN0aW9uKHZhbHVlOiBTdGFydEVkaXRBY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzdGFydEVkaXRBY3Rpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgdGV4dHMoKTogeyBhZGRSb3c/OiBzdHJpbmcsIGNhbmNlbEFsbENoYW5nZXM/OiBzdHJpbmcsIGNhbmNlbFJvd0NoYW5nZXM/OiBzdHJpbmcsIGNvbmZpcm1EZWxldGVNZXNzYWdlPzogc3RyaW5nLCBjb25maXJtRGVsZXRlVGl0bGU/OiBzdHJpbmcsIGRlbGV0ZVJvdz86IHN0cmluZywgZWRpdFJvdz86IHN0cmluZywgc2F2ZUFsbENoYW5nZXM/OiBzdHJpbmcsIHNhdmVSb3dDaGFuZ2VzPzogc3RyaW5nLCB1bmRlbGV0ZVJvdz86IHN0cmluZywgdmFsaWRhdGlvbkNhbmNlbENoYW5nZXM/OiBzdHJpbmcgfSB8IHsgYWRkUm93Pzogc3RyaW5nLCBhZGRSb3dUb05vZGU/OiBzdHJpbmcsIGNhbmNlbEFsbENoYW5nZXM/OiBzdHJpbmcsIGNhbmNlbFJvd0NoYW5nZXM/OiBzdHJpbmcsIGNvbmZpcm1EZWxldGVNZXNzYWdlPzogc3RyaW5nLCBjb25maXJtRGVsZXRlVGl0bGU/OiBzdHJpbmcsIGRlbGV0ZVJvdz86IHN0cmluZywgZWRpdFJvdz86IHN0cmluZywgc2F2ZUFsbENoYW5nZXM/OiBzdHJpbmcsIHNhdmVSb3dDaGFuZ2VzPzogc3RyaW5nLCB1bmRlbGV0ZVJvdz86IHN0cmluZywgdmFsaWRhdGlvbkNhbmNlbENoYW5nZXM/OiBzdHJpbmcgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RleHRzJyk7XG4gICAgfVxuICAgIHNldCB0ZXh0cyh2YWx1ZTogeyBhZGRSb3c/OiBzdHJpbmcsIGNhbmNlbEFsbENoYW5nZXM/OiBzdHJpbmcsIGNhbmNlbFJvd0NoYW5nZXM/OiBzdHJpbmcsIGNvbmZpcm1EZWxldGVNZXNzYWdlPzogc3RyaW5nLCBjb25maXJtRGVsZXRlVGl0bGU/OiBzdHJpbmcsIGRlbGV0ZVJvdz86IHN0cmluZywgZWRpdFJvdz86IHN0cmluZywgc2F2ZUFsbENoYW5nZXM/OiBzdHJpbmcsIHNhdmVSb3dDaGFuZ2VzPzogc3RyaW5nLCB1bmRlbGV0ZVJvdz86IHN0cmluZywgdmFsaWRhdGlvbkNhbmNlbENoYW5nZXM/OiBzdHJpbmcgfSB8IHsgYWRkUm93Pzogc3RyaW5nLCBhZGRSb3dUb05vZGU/OiBzdHJpbmcsIGNhbmNlbEFsbENoYW5nZXM/OiBzdHJpbmcsIGNhbmNlbFJvd0NoYW5nZXM/OiBzdHJpbmcsIGNvbmZpcm1EZWxldGVNZXNzYWdlPzogc3RyaW5nLCBjb25maXJtRGVsZXRlVGl0bGU/OiBzdHJpbmcsIGRlbGV0ZVJvdz86IHN0cmluZywgZWRpdFJvdz86IHN0cmluZywgc2F2ZUFsbENoYW5nZXM/OiBzdHJpbmcsIHNhdmVSb3dDaGFuZ2VzPzogc3RyaW5nLCB1bmRlbGV0ZVJvdz86IHN0cmluZywgdmFsaWRhdGlvbkNhbmNlbENoYW5nZXM/OiBzdHJpbmcgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3RleHRzJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHVzZUljb25zKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd1c2VJY29ucycpO1xuICAgIH1cbiAgICBzZXQgdXNlSWNvbnModmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd1c2VJY29ucycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd0FkZFNoYXBlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd0FkZFNoYXBlJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd0FkZFNoYXBlKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dBZGRTaGFwZScsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd0NoYW5nZUNvbm5lY3Rpb24oKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93Q2hhbmdlQ29ubmVjdGlvbicpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dDaGFuZ2VDb25uZWN0aW9uKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dDaGFuZ2VDb25uZWN0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93Q2hhbmdlQ29ubmVjdG9yUG9pbnRzKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd0NoYW5nZUNvbm5lY3RvclBvaW50cycpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dDaGFuZ2VDb25uZWN0b3JQb2ludHModmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd0NoYW5nZUNvbm5lY3RvclBvaW50cycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd0NoYW5nZUNvbm5lY3RvclRleHQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93Q2hhbmdlQ29ubmVjdG9yVGV4dCcpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dDaGFuZ2VDb25uZWN0b3JUZXh0KHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dDaGFuZ2VDb25uZWN0b3JUZXh0JywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93Q2hhbmdlU2hhcGVUZXh0KCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd0NoYW5nZVNoYXBlVGV4dCcpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dDaGFuZ2VTaGFwZVRleHQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd0NoYW5nZVNoYXBlVGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd0RlbGV0ZUNvbm5lY3RvcigpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dEZWxldGVDb25uZWN0b3InKTtcbiAgICB9XG4gICAgc2V0IGFsbG93RGVsZXRlQ29ubmVjdG9yKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dEZWxldGVDb25uZWN0b3InLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dEZWxldGVTaGFwZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dEZWxldGVTaGFwZScpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dEZWxldGVTaGFwZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93RGVsZXRlU2hhcGUnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dNb3ZlU2hhcGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93TW92ZVNoYXBlJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd01vdmVTaGFwZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93TW92ZVNoYXBlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93UmVzaXplU2hhcGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93UmVzaXplU2hhcGUnKTtcbiAgICB9XG4gICAgc2V0IGFsbG93UmVzaXplU2hhcGUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd1Jlc2l6ZVNoYXBlJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93RGVwZW5kZW5jeUFkZGluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dEZXBlbmRlbmN5QWRkaW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd0RlcGVuZGVuY3lBZGRpbmcodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd0RlcGVuZGVuY3lBZGRpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dEZXBlbmRlbmN5RGVsZXRpbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93RGVwZW5kZW5jeURlbGV0aW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd0RlcGVuZGVuY3lEZWxldGluZyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93RGVwZW5kZW5jeURlbGV0aW5nJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93UmVzb3VyY2VBZGRpbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93UmVzb3VyY2VBZGRpbmcnKTtcbiAgICB9XG4gICAgc2V0IGFsbG93UmVzb3VyY2VBZGRpbmcodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd1Jlc291cmNlQWRkaW5nJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93UmVzb3VyY2VEZWxldGluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dSZXNvdXJjZURlbGV0aW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd1Jlc291cmNlRGVsZXRpbmcodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd1Jlc291cmNlRGVsZXRpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dSZXNvdXJjZVVwZGF0aW5nKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd1Jlc291cmNlVXBkYXRpbmcnKTtcbiAgICB9XG4gICAgc2V0IGFsbG93UmVzb3VyY2VVcGRhdGluZyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93UmVzb3VyY2VVcGRhdGluZycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd1Rhc2tBZGRpbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93VGFza0FkZGluZycpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dUYXNrQWRkaW5nKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dUYXNrQWRkaW5nJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFsbG93VGFza0RlbGV0aW5nKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd1Rhc2tEZWxldGluZycpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dUYXNrRGVsZXRpbmcodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhbGxvd1Rhc2tEZWxldGluZycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd1Rhc2tSZXNvdXJjZVVwZGF0aW5nKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhbGxvd1Rhc2tSZXNvdXJjZVVwZGF0aW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd1Rhc2tSZXNvdXJjZVVwZGF0aW5nKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dUYXNrUmVzb3VyY2VVcGRhdGluZycsIHZhbHVlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd1Rhc2tVcGRhdGluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dUYXNrVXBkYXRpbmcnKTtcbiAgICB9XG4gICAgc2V0IGFsbG93VGFza1VwZGF0aW5nKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dUYXNrVXBkYXRpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgZW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgZW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2VuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dEcmFnZ2luZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dEcmFnZ2luZycpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dEcmFnZ2luZyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93RHJhZ2dpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dSZXNpemluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dSZXNpemluZycpO1xuICAgIH1cbiAgICBzZXQgYWxsb3dSZXNpemluZyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93UmVzaXppbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBnZXQgYWxsb3dUaW1lWm9uZUVkaXRpbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FsbG93VGltZVpvbmVFZGl0aW5nJyk7XG4gICAgfVxuICAgIHNldCBhbGxvd1RpbWVab25lRWRpdGluZyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FsbG93VGltZVpvbmVFZGl0aW5nJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY2hhbmdlc0NoYW5nZTogRXZlbnRFbWl0dGVyPEFycmF5PERhdGFDaGFuZ2U+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGVkaXRDb2x1bW5OYW1lQ2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGVkaXRSb3dLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnZWRpdGluZyc7XG4gICAgfVxuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKGZvcndhcmRSZWYoKCkgPT4gRHhpQ2hhbmdlQ29tcG9uZW50KSlcbiAgICBnZXQgY2hhbmdlc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlDaGFuZ2VDb21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY2hhbmdlcycpO1xuICAgIH1cbiAgICBzZXQgY2hhbmdlc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2NoYW5nZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG5cbiAgICAgICAgdGhpcy5fY3JlYXRlRXZlbnRFbWl0dGVycyhbXG4gICAgICAgICAgICB7IGVtaXQ6ICdjaGFuZ2VzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZWRpdENvbHVtbk5hbWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdlZGl0Um93S2V5Q2hhbmdlJyB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9FZGl0aW5nQ29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeG9FZGl0aW5nQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER4b0VkaXRpbmdNb2R1bGUgeyB9XG4iXX0=