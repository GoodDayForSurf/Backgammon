/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoChartCommonSeriesSettings } from './base/chart-common-series-settings';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoFullstackedsplineareaComponent extends DxoChartCommonSeriesSettings {
    get _optionPath() {
        return 'fullstackedsplinearea';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFullstackedsplineareaComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoFullstackedsplineareaComponent, selector: "dxo-fullstackedsplinearea", inputs: { aggregation: "aggregation", area: "area", argumentField: "argumentField", axis: "axis", bar: "bar", barOverlapGroup: "barOverlapGroup", barPadding: "barPadding", barWidth: "barWidth", border: "border", bubble: "bubble", candlestick: "candlestick", closeValueField: "closeValueField", color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", fullstackedarea: "fullstackedarea", fullstackedbar: "fullstackedbar", fullstackedline: "fullstackedline", fullstackedspline: "fullstackedspline", fullstackedsplinearea: "fullstackedsplinearea", highValueField: "highValueField", hoverMode: "hoverMode", hoverStyle: "hoverStyle", ignoreEmptyPoints: "ignoreEmptyPoints", innerColor: "innerColor", label: "label", line: "line", lowValueField: "lowValueField", maxLabelCount: "maxLabelCount", minBarSize: "minBarSize", opacity: "opacity", openValueField: "openValueField", pane: "pane", point: "point", rangearea: "rangearea", rangebar: "rangebar", rangeValue1Field: "rangeValue1Field", rangeValue2Field: "rangeValue2Field", reduction: "reduction", scatter: "scatter", selectionMode: "selectionMode", selectionStyle: "selectionStyle", showInLegend: "showInLegend", sizeField: "sizeField", spline: "spline", splinearea: "splinearea", stack: "stack", stackedarea: "stackedarea", stackedbar: "stackedbar", stackedline: "stackedline", stackedspline: "stackedspline", stackedsplinearea: "stackedsplinearea", steparea: "steparea", stepline: "stepline", stock: "stock", tagField: "tagField", type: "type", valueErrorBar: "valueErrorBar", valueField: "valueField", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFullstackedsplineareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-fullstackedsplinearea', template: '', providers: [NestedOptionHost], inputs: [
                        'aggregation',
                        'area',
                        'argumentField',
                        'axis',
                        'bar',
                        'barOverlapGroup',
                        'barPadding',
                        'barWidth',
                        'border',
                        'bubble',
                        'candlestick',
                        'closeValueField',
                        'color',
                        'cornerRadius',
                        'dashStyle',
                        'fullstackedarea',
                        'fullstackedbar',
                        'fullstackedline',
                        'fullstackedspline',
                        'fullstackedsplinearea',
                        'highValueField',
                        'hoverMode',
                        'hoverStyle',
                        'ignoreEmptyPoints',
                        'innerColor',
                        'label',
                        'line',
                        'lowValueField',
                        'maxLabelCount',
                        'minBarSize',
                        'opacity',
                        'openValueField',
                        'pane',
                        'point',
                        'rangearea',
                        'rangebar',
                        'rangeValue1Field',
                        'rangeValue2Field',
                        'reduction',
                        'scatter',
                        'selectionMode',
                        'selectionStyle',
                        'showInLegend',
                        'sizeField',
                        'spline',
                        'splinearea',
                        'stack',
                        'stackedarea',
                        'stackedbar',
                        'stackedline',
                        'stackedspline',
                        'stackedsplinearea',
                        'steparea',
                        'stepline',
                        'stock',
                        'tagField',
                        'type',
                        'valueErrorBar',
                        'valueField',
                        'visible',
                        'width'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoFullstackedsplineareaModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFullstackedsplineareaModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoFullstackedsplineareaModule, declarations: [DxoFullstackedsplineareaComponent], exports: [DxoFullstackedsplineareaComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFullstackedsplineareaModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoFullstackedsplineareaModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoFullstackedsplineareaComponent
                    ],
                    exports: [
                        DxoFullstackedsplineareaComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVsbHN0YWNrZWRzcGxpbmVhcmVhLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvZnVsbHN0YWNrZWRzcGxpbmVhcmVhLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUdULFFBQVEsRUFDUixJQUFJLEVBQ0osUUFBUSxFQUNYLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsNEJBQTRCLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQzs7O0FBd0VuRixNQUFNLE9BQU8saUNBQWtDLFNBQVEsNEJBQTRCO0lBRS9FLElBQWMsV0FBVztRQUNyQixPQUFPLHVCQUF1QixDQUFDO0lBQ25DLENBQUM7SUFHRCxZQUFnQyxnQkFBa0MsRUFDbEQsVUFBNEI7UUFDeEMsS0FBSyxFQUFFLENBQUM7UUFDUixnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBR0QsUUFBUTtRQUNKLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7MkhBckJRLGlDQUFpQzsrR0FBakMsaUNBQWlDLHduREFqRS9CLENBQUMsZ0JBQWdCLENBQUMsaURBRm5CLEVBQUU7OzRGQW1FSCxpQ0FBaUM7a0JBckU3QyxTQUFTOytCQUNJLDJCQUEyQixZQUMzQixFQUFFLGFBRUQsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUNyQjt3QkFDSixhQUFhO3dCQUNiLE1BQU07d0JBQ04sZUFBZTt3QkFDZixNQUFNO3dCQUNOLEtBQUs7d0JBQ0wsaUJBQWlCO3dCQUNqQixZQUFZO3dCQUNaLFVBQVU7d0JBQ1YsUUFBUTt3QkFDUixRQUFRO3dCQUNSLGFBQWE7d0JBQ2IsaUJBQWlCO3dCQUNqQixPQUFPO3dCQUNQLGNBQWM7d0JBQ2QsV0FBVzt3QkFDWCxpQkFBaUI7d0JBQ2pCLGdCQUFnQjt3QkFDaEIsaUJBQWlCO3dCQUNqQixtQkFBbUI7d0JBQ25CLHVCQUF1Qjt3QkFDdkIsZ0JBQWdCO3dCQUNoQixXQUFXO3dCQUNYLFlBQVk7d0JBQ1osbUJBQW1CO3dCQUNuQixZQUFZO3dCQUNaLE9BQU87d0JBQ1AsTUFBTTt3QkFDTixlQUFlO3dCQUNmLGVBQWU7d0JBQ2YsWUFBWTt3QkFDWixTQUFTO3dCQUNULGdCQUFnQjt3QkFDaEIsTUFBTTt3QkFDTixPQUFPO3dCQUNQLFdBQVc7d0JBQ1gsVUFBVTt3QkFDVixrQkFBa0I7d0JBQ2xCLGtCQUFrQjt3QkFDbEIsV0FBVzt3QkFDWCxTQUFTO3dCQUNULGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQixjQUFjO3dCQUNkLFdBQVc7d0JBQ1gsUUFBUTt3QkFDUixZQUFZO3dCQUNaLE9BQU87d0JBQ1AsYUFBYTt3QkFDYixZQUFZO3dCQUNaLGFBQWE7d0JBQ2IsZUFBZTt3QkFDZixtQkFBbUI7d0JBQ25CLFVBQVU7d0JBQ1YsVUFBVTt3QkFDVixPQUFPO3dCQUNQLFVBQVU7d0JBQ1YsTUFBTTt3QkFDTixlQUFlO3dCQUNmLFlBQVk7d0JBQ1osU0FBUzt3QkFDVCxPQUFPO3FCQUNWOzswQkFTWSxRQUFROzswQkFBSSxJQUFJOzswQkFDcEIsSUFBSTs7QUEwQmpCLE1BQU0sT0FBTyw4QkFBOEI7MkhBQTlCLDhCQUE4Qjs0SEFBOUIsOEJBQThCLGlCQWxDOUIsaUNBQWlDLGFBQWpDLGlDQUFpQzs0SEFrQ2pDLDhCQUE4Qjs7NEZBQTlCLDhCQUE4QjtrQkFSMUMsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osaUNBQWlDO3FCQUNsQztvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsaUNBQWlDO3FCQUNsQztpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuLyogdHNsaW50OmRpc2FibGU6dXNlLWlucHV0LXByb3BlcnR5LWRlY29yYXRvciAqL1xuXG5pbXBvcnQge1xuICAgIENvbXBvbmVudCxcbiAgICBPbkluaXQsXG4gICAgT25EZXN0cm95LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeG9DaGFydENvbW1vblNlcmllc1NldHRpbmdzIH0gZnJvbSAnLi9iYXNlL2NoYXJ0LWNvbW1vbi1zZXJpZXMtc2V0dGluZ3MnO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhvLWZ1bGxzdGFja2Vkc3BsaW5lYXJlYScsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHN0eWxlczogWycnXSxcbiAgICBwcm92aWRlcnM6IFtOZXN0ZWRPcHRpb25Ib3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2FnZ3JlZ2F0aW9uJyxcbiAgICAgICAgJ2FyZWEnLFxuICAgICAgICAnYXJndW1lbnRGaWVsZCcsXG4gICAgICAgICdheGlzJyxcbiAgICAgICAgJ2JhcicsXG4gICAgICAgICdiYXJPdmVybGFwR3JvdXAnLFxuICAgICAgICAnYmFyUGFkZGluZycsXG4gICAgICAgICdiYXJXaWR0aCcsXG4gICAgICAgICdib3JkZXInLFxuICAgICAgICAnYnViYmxlJyxcbiAgICAgICAgJ2NhbmRsZXN0aWNrJyxcbiAgICAgICAgJ2Nsb3NlVmFsdWVGaWVsZCcsXG4gICAgICAgICdjb2xvcicsXG4gICAgICAgICdjb3JuZXJSYWRpdXMnLFxuICAgICAgICAnZGFzaFN0eWxlJyxcbiAgICAgICAgJ2Z1bGxzdGFja2VkYXJlYScsXG4gICAgICAgICdmdWxsc3RhY2tlZGJhcicsXG4gICAgICAgICdmdWxsc3RhY2tlZGxpbmUnLFxuICAgICAgICAnZnVsbHN0YWNrZWRzcGxpbmUnLFxuICAgICAgICAnZnVsbHN0YWNrZWRzcGxpbmVhcmVhJyxcbiAgICAgICAgJ2hpZ2hWYWx1ZUZpZWxkJyxcbiAgICAgICAgJ2hvdmVyTW9kZScsXG4gICAgICAgICdob3ZlclN0eWxlJyxcbiAgICAgICAgJ2lnbm9yZUVtcHR5UG9pbnRzJyxcbiAgICAgICAgJ2lubmVyQ29sb3InLFxuICAgICAgICAnbGFiZWwnLFxuICAgICAgICAnbGluZScsXG4gICAgICAgICdsb3dWYWx1ZUZpZWxkJyxcbiAgICAgICAgJ21heExhYmVsQ291bnQnLFxuICAgICAgICAnbWluQmFyU2l6ZScsXG4gICAgICAgICdvcGFjaXR5JyxcbiAgICAgICAgJ29wZW5WYWx1ZUZpZWxkJyxcbiAgICAgICAgJ3BhbmUnLFxuICAgICAgICAncG9pbnQnLFxuICAgICAgICAncmFuZ2VhcmVhJyxcbiAgICAgICAgJ3JhbmdlYmFyJyxcbiAgICAgICAgJ3JhbmdlVmFsdWUxRmllbGQnLFxuICAgICAgICAncmFuZ2VWYWx1ZTJGaWVsZCcsXG4gICAgICAgICdyZWR1Y3Rpb24nLFxuICAgICAgICAnc2NhdHRlcicsXG4gICAgICAgICdzZWxlY3Rpb25Nb2RlJyxcbiAgICAgICAgJ3NlbGVjdGlvblN0eWxlJyxcbiAgICAgICAgJ3Nob3dJbkxlZ2VuZCcsXG4gICAgICAgICdzaXplRmllbGQnLFxuICAgICAgICAnc3BsaW5lJyxcbiAgICAgICAgJ3NwbGluZWFyZWEnLFxuICAgICAgICAnc3RhY2snLFxuICAgICAgICAnc3RhY2tlZGFyZWEnLFxuICAgICAgICAnc3RhY2tlZGJhcicsXG4gICAgICAgICdzdGFja2VkbGluZScsXG4gICAgICAgICdzdGFja2Vkc3BsaW5lJyxcbiAgICAgICAgJ3N0YWNrZWRzcGxpbmVhcmVhJyxcbiAgICAgICAgJ3N0ZXBhcmVhJyxcbiAgICAgICAgJ3N0ZXBsaW5lJyxcbiAgICAgICAgJ3N0b2NrJyxcbiAgICAgICAgJ3RhZ0ZpZWxkJyxcbiAgICAgICAgJ3R5cGUnLFxuICAgICAgICAndmFsdWVFcnJvckJhcicsXG4gICAgICAgICd2YWx1ZUZpZWxkJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAnd2lkdGgnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeG9GdWxsc3RhY2tlZHNwbGluZWFyZWFDb21wb25lbnQgZXh0ZW5kcyBEeG9DaGFydENvbW1vblNlcmllc1NldHRpbmdzIGltcGxlbWVudHMgT25EZXN0cm95LCBPbkluaXQgIHtcblxuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnZnVsbHN0YWNrZWRzcGxpbmVhcmVhJztcbiAgICB9XG5cblxuICAgIGNvbnN0cnVjdG9yKEBTa2lwU2VsZigpIEBIb3N0KCkgcGFyZW50T3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgICAgIEBIb3N0KCkgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICBwYXJlbnRPcHRpb25Ib3N0LnNldE5lc3RlZE9wdGlvbih0aGlzKTtcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMsIHRoaXMuX2Z1bGxPcHRpb25QYXRoLmJpbmQodGhpcykpO1xuICAgIH1cblxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlY3JlYXRlZENvbXBvbmVudCgpO1xuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9hZGRSZW1vdmVkT3B0aW9uKHRoaXMuX2dldE9wdGlvblBhdGgoKSk7XG4gICAgfVxuXG5cbn1cblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhvRnVsbHN0YWNrZWRzcGxpbmVhcmVhQ29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeG9GdWxsc3RhY2tlZHNwbGluZWFyZWFDb21wb25lbnRcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRHhvRnVsbHN0YWNrZWRzcGxpbmVhcmVhTW9kdWxlIHsgfVxuIl19