/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf, Output, EventEmitter } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoCalendarOptions } from './base/calendar-options';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoCalendarOptionsComponent extends DxoCalendarOptions {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomLevelChange;
    get _optionPath() {
        return 'calendarOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' },
            { emit: 'zoomLevelChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCalendarOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoCalendarOptionsComponent, selector: "dxo-calendar-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", cellTemplate: "cellTemplate", dateSerializationFormat: "dateSerializationFormat", disabled: "disabled", disabledDates: "disabledDates", elementAttr: "elementAttr", firstDayOfWeek: "firstDayOfWeek", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", isDirty: "isDirty", isValid: "isValid", max: "max", maxZoomLevel: "maxZoomLevel", min: "min", minZoomLevel: "minZoomLevel", name: "name", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", readOnly: "readOnly", rtlEnabled: "rtlEnabled", selectionMode: "selectionMode", selectWeekOnClick: "selectWeekOnClick", showTodayButton: "showTodayButton", showWeekNumbers: "showWeekNumbers", tabIndex: "tabIndex", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", visible: "visible", weekNumberRule: "weekNumberRule", width: "width", zoomLevel: "zoomLevel" }, outputs: { valueChange: "valueChange", zoomLevelChange: "zoomLevelChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCalendarOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-calendar-options', template: '', providers: [NestedOptionHost], inputs: [
                        'accessKey',
                        'activeStateEnabled',
                        'cellTemplate',
                        'dateSerializationFormat',
                        'disabled',
                        'disabledDates',
                        'elementAttr',
                        'firstDayOfWeek',
                        'focusStateEnabled',
                        'height',
                        'hint',
                        'hoverStateEnabled',
                        'isDirty',
                        'isValid',
                        'max',
                        'maxZoomLevel',
                        'min',
                        'minZoomLevel',
                        'name',
                        'onDisposing',
                        'onInitialized',
                        'onOptionChanged',
                        'onValueChanged',
                        'readOnly',
                        'rtlEnabled',
                        'selectionMode',
                        'selectWeekOnClick',
                        'showTodayButton',
                        'showWeekNumbers',
                        'tabIndex',
                        'validationError',
                        'validationErrors',
                        'validationMessageMode',
                        'validationMessagePosition',
                        'validationStatus',
                        'value',
                        'visible',
                        'weekNumberRule',
                        'width',
                        'zoomLevel'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; }, propDecorators: { valueChange: [{
                type: Output
            }], zoomLevelChange: [{
                type: Output
            }] } });
export class DxoCalendarOptionsModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCalendarOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoCalendarOptionsModule, declarations: [DxoCalendarOptionsComponent], exports: [DxoCalendarOptionsComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCalendarOptionsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoCalendarOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoCalendarOptionsComponent
                    ],
                    exports: [
                        DxoCalendarOptionsComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXItb3B0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2NhbGVuZGFyLW9wdGlvbnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsaURBQWlEO0FBRWpELE9BQU8sRUFDSCxTQUFTLEVBR1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1IsTUFBTSxFQUNOLFlBQVksRUFDZixNQUFNLGVBQWUsQ0FBQztBQU92QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0seUJBQXlCLENBQUM7OztBQW1EN0QsTUFBTSxPQUFPLDJCQUE0QixTQUFRLGtCQUFrQjtJQUUvRDs7OztPQUlHO0lBQ08sV0FBVyxDQUF1RTtJQUU1Rjs7OztPQUlHO0lBQ08sZUFBZSxDQUFrQztJQUMzRCxJQUFjLFdBQVc7UUFDckIsT0FBTyxpQkFBaUIsQ0FBQztJQUM3QixDQUFDO0lBR0QsWUFBZ0MsZ0JBQWtDLEVBQ2xELFVBQTRCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBRVIsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtTQUM5QixDQUFDLENBQUM7UUFFSCxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBR0QsUUFBUTtRQUNKLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7MkhBeENRLDJCQUEyQjsrR0FBM0IsMkJBQTJCLHd5Q0E1Q3pCLENBQUMsZ0JBQWdCLENBQUMsaURBRm5CLEVBQUU7OzRGQThDSCwyQkFBMkI7a0JBaER2QyxTQUFTOytCQUNJLHNCQUFzQixZQUN0QixFQUFFLGFBRUQsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUNyQjt3QkFDSixXQUFXO3dCQUNYLG9CQUFvQjt3QkFDcEIsY0FBYzt3QkFDZCx5QkFBeUI7d0JBQ3pCLFVBQVU7d0JBQ1YsZUFBZTt3QkFDZixhQUFhO3dCQUNiLGdCQUFnQjt3QkFDaEIsbUJBQW1CO3dCQUNuQixRQUFRO3dCQUNSLE1BQU07d0JBQ04sbUJBQW1CO3dCQUNuQixTQUFTO3dCQUNULFNBQVM7d0JBQ1QsS0FBSzt3QkFDTCxjQUFjO3dCQUNkLEtBQUs7d0JBQ0wsY0FBYzt3QkFDZCxNQUFNO3dCQUNOLGFBQWE7d0JBQ2IsZUFBZTt3QkFDZixpQkFBaUI7d0JBQ2pCLGdCQUFnQjt3QkFDaEIsVUFBVTt3QkFDVixZQUFZO3dCQUNaLGVBQWU7d0JBQ2YsbUJBQW1CO3dCQUNuQixpQkFBaUI7d0JBQ2pCLGlCQUFpQjt3QkFDakIsVUFBVTt3QkFDVixpQkFBaUI7d0JBQ2pCLGtCQUFrQjt3QkFDbEIsdUJBQXVCO3dCQUN2QiwyQkFBMkI7d0JBQzNCLGtCQUFrQjt3QkFDbEIsT0FBTzt3QkFDUCxTQUFTO3dCQUNULGdCQUFnQjt3QkFDaEIsT0FBTzt3QkFDUCxXQUFXO3FCQUNkOzswQkFzQlksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7NENBZEgsV0FBVztzQkFBcEIsTUFBTTtnQkFPRyxlQUFlO3NCQUF4QixNQUFNOztBQXVDWCxNQUFNLE9BQU8sd0JBQXdCOzJIQUF4Qix3QkFBd0I7NEhBQXhCLHdCQUF3QixpQkFyRHhCLDJCQUEyQixhQUEzQiwyQkFBMkI7NEhBcUQzQix3QkFBd0I7OzRGQUF4Qix3QkFBd0I7a0JBUnBDLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFO3dCQUNaLDJCQUEyQjtxQkFDNUI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLDJCQUEyQjtxQkFDNUI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cbi8qIHRzbGludDpkaXNhYmxlOnVzZS1pbnB1dC1wcm9wZXJ0eS1kZWNvcmF0b3IgKi9cblxuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgT25Jbml0LFxuICAgIE9uRGVzdHJveSxcbiAgICBOZ01vZHVsZSxcbiAgICBIb3N0LFxuICAgIFNraXBTZWxmLFxuICAgIE91dHB1dCxcbiAgICBFdmVudEVtaXR0ZXJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cbmltcG9ydCB7IENhbGVuZGFyWm9vbUxldmVsIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9jYWxlbmRhcic7XG5cbmltcG9ydCB7XG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRHhvQ2FsZW5kYXJPcHRpb25zIH0gZnJvbSAnLi9iYXNlL2NhbGVuZGFyLW9wdGlvbnMnO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhvLWNhbGVuZGFyLW9wdGlvbnMnLFxuICAgIHRlbXBsYXRlOiAnJyxcbiAgICBzdHlsZXM6IFsnJ10sXG4gICAgcHJvdmlkZXJzOiBbTmVzdGVkT3B0aW9uSG9zdF0sXG4gICAgaW5wdXRzOiBbXG4gICAgICAgICdhY2Nlc3NLZXknLFxuICAgICAgICAnYWN0aXZlU3RhdGVFbmFibGVkJyxcbiAgICAgICAgJ2NlbGxUZW1wbGF0ZScsXG4gICAgICAgICdkYXRlU2VyaWFsaXphdGlvbkZvcm1hdCcsXG4gICAgICAgICdkaXNhYmxlZCcsXG4gICAgICAgICdkaXNhYmxlZERhdGVzJyxcbiAgICAgICAgJ2VsZW1lbnRBdHRyJyxcbiAgICAgICAgJ2ZpcnN0RGF5T2ZXZWVrJyxcbiAgICAgICAgJ2ZvY3VzU3RhdGVFbmFibGVkJyxcbiAgICAgICAgJ2hlaWdodCcsXG4gICAgICAgICdoaW50JyxcbiAgICAgICAgJ2hvdmVyU3RhdGVFbmFibGVkJyxcbiAgICAgICAgJ2lzRGlydHknLFxuICAgICAgICAnaXNWYWxpZCcsXG4gICAgICAgICdtYXgnLFxuICAgICAgICAnbWF4Wm9vbUxldmVsJyxcbiAgICAgICAgJ21pbicsXG4gICAgICAgICdtaW5ab29tTGV2ZWwnLFxuICAgICAgICAnbmFtZScsXG4gICAgICAgICdvbkRpc3Bvc2luZycsXG4gICAgICAgICdvbkluaXRpYWxpemVkJyxcbiAgICAgICAgJ29uT3B0aW9uQ2hhbmdlZCcsXG4gICAgICAgICdvblZhbHVlQ2hhbmdlZCcsXG4gICAgICAgICdyZWFkT25seScsXG4gICAgICAgICdydGxFbmFibGVkJyxcbiAgICAgICAgJ3NlbGVjdGlvbk1vZGUnLFxuICAgICAgICAnc2VsZWN0V2Vla09uQ2xpY2snLFxuICAgICAgICAnc2hvd1RvZGF5QnV0dG9uJyxcbiAgICAgICAgJ3Nob3dXZWVrTnVtYmVycycsXG4gICAgICAgICd0YWJJbmRleCcsXG4gICAgICAgICd2YWxpZGF0aW9uRXJyb3InLFxuICAgICAgICAndmFsaWRhdGlvbkVycm9ycycsXG4gICAgICAgICd2YWxpZGF0aW9uTWVzc2FnZU1vZGUnLFxuICAgICAgICAndmFsaWRhdGlvbk1lc3NhZ2VQb3NpdGlvbicsXG4gICAgICAgICd2YWxpZGF0aW9uU3RhdHVzJyxcbiAgICAgICAgJ3ZhbHVlJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAnd2Vla051bWJlclJ1bGUnLFxuICAgICAgICAnd2lkdGgnLFxuICAgICAgICAnem9vbUxldmVsJ1xuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhvQ2FsZW5kYXJPcHRpb25zQ29tcG9uZW50IGV4dGVuZHMgRHhvQ2FsZW5kYXJPcHRpb25zIGltcGxlbWVudHMgT25EZXN0cm95LCBPbkluaXQgIHtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZhbHVlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8RGF0ZSB8IG51bWJlciB8IHN0cmluZyB8IEFycmF5PERhdGUgfCBudW1iZXIgfCBzdHJpbmc+PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHpvb21MZXZlbENoYW5nZTogRXZlbnRFbWl0dGVyPENhbGVuZGFyWm9vbUxldmVsPjtcbiAgICBwcm90ZWN0ZWQgZ2V0IF9vcHRpb25QYXRoKCkge1xuICAgICAgICByZXR1cm4gJ2NhbGVuZGFyT3B0aW9ucyc7XG4gICAgfVxuXG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcblxuICAgICAgICB0aGlzLl9jcmVhdGVFdmVudEVtaXR0ZXJzKFtcbiAgICAgICAgICAgIHsgZW1pdDogJ3ZhbHVlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnem9vbUxldmVsQ2hhbmdlJyB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5fYWRkUmVjcmVhdGVkQ29tcG9uZW50KCk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlbW92ZWRPcHRpb24odGhpcy5fZ2V0T3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeG9DYWxlbmRhck9wdGlvbnNDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4b0NhbGVuZGFyT3B0aW9uc0NvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9DYWxlbmRhck9wdGlvbnNNb2R1bGUgeyB9XG4iXX0=