/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiVizScaleBreak } from './base/viz-scale-break-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiBreakComponent extends DxiVizScaleBreak {
    get _optionPath() {
        return 'breaks';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiBreakComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiBreakComponent, selector: "dxi-break", inputs: { endValue: "endValue", startValue: "startValue" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiBreakComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-break', template: '', providers: [NestedOptionHost], inputs: [
                        'endValue',
                        'startValue'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxiBreakModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiBreakModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiBreakModule, declarations: [DxiBreakComponent], exports: [DxiBreakComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiBreakModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiBreakModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiBreakComponent
                    ],
                    exports: [
                        DxiBreakComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnJlYWstZHhpLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vZGlzdC91aS9uZXN0ZWQvYnJlYWstZHhpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBRXBDLGlEQUFpRDtBQUVqRCxPQUFPLEVBQ0gsU0FBUyxFQUNULFFBQVEsRUFDUixJQUFJLEVBQ0osUUFBUSxFQUNYLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE9BQU8sRUFDSCxnQkFBZ0IsR0FDbkIsTUFBTSx5QkFBeUIsQ0FBQztBQUNqQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7O0FBYTlELE1BQU0sT0FBTyxpQkFBa0IsU0FBUSxnQkFBZ0I7SUFFbkQsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFHRCxZQUFnQyxnQkFBa0MsRUFDbEQsVUFBNEI7UUFDeEMsS0FBSyxFQUFFLENBQUM7UUFDUixnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBSUQsV0FBVztRQUNQLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDOzJIQWxCUSxpQkFBaUI7K0dBQWpCLGlCQUFpQixnR0FOZixDQUFDLGdCQUFnQixDQUFDLGlEQUZuQixFQUFFOzs0RkFRSCxpQkFBaUI7a0JBVjdCLFNBQVM7K0JBQ0ksV0FBVyxZQUNYLEVBQUUsYUFFRCxDQUFDLGdCQUFnQixDQUFDLFVBQ3JCO3dCQUNKLFVBQVU7d0JBQ1YsWUFBWTtxQkFDZjs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBc0JqQixNQUFNLE9BQU8sY0FBYzsySEFBZCxjQUFjOzRIQUFkLGNBQWMsaUJBOUJkLGlCQUFpQixhQUFqQixpQkFBaUI7NEhBOEJqQixjQUFjOzs0RkFBZCxjQUFjO2tCQVIxQixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWixpQkFBaUI7cUJBQ2xCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxpQkFBaUI7cUJBQ2xCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeGlWaXpTY2FsZUJyZWFrIH0gZnJvbSAnLi9iYXNlL3Zpei1zY2FsZS1icmVhay1keGknO1xuXG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHhpLWJyZWFrJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnZW5kVmFsdWUnLFxuICAgICAgICAnc3RhcnRWYWx1ZSdcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4aUJyZWFrQ29tcG9uZW50IGV4dGVuZHMgRHhpVml6U2NhbGVCcmVhayB7XG5cbiAgICBwcm90ZWN0ZWQgZ2V0IF9vcHRpb25QYXRoKCkge1xuICAgICAgICByZXR1cm4gJ2JyZWFrcyc7XG4gICAgfVxuXG5cbiAgICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBASG9zdCgpIHBhcmVudE9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgICAgICAgICBASG9zdCgpIG9wdGlvbkhvc3Q6IE5lc3RlZE9wdGlvbkhvc3QpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgcGFyZW50T3B0aW9uSG9zdC5zZXROZXN0ZWRPcHRpb24odGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzLCB0aGlzLl9mdWxsT3B0aW9uUGF0aC5iaW5kKHRoaXMpKTtcbiAgICB9XG5cblxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2RlbGV0ZVJlbW92ZWRPcHRpb25zKHRoaXMuX2Z1bGxPcHRpb25QYXRoKCkpO1xuICAgIH1cblxufVxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeGlCcmVha0NvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhpQnJlYWtDb21wb25lbnRcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRHhpQnJlYWtNb2R1bGUgeyB9XG4iXX0=