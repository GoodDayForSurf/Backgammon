/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxoChartCommonSeriesSettings } from './base/chart-common-series-settings';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxoAreaComponent extends DxoChartCommonSeriesSettings {
    get _optionPath() {
        return 'area';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoAreaComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxoAreaComponent, selector: "dxo-area", inputs: { aggregation: "aggregation", area: "area", argumentField: "argumentField", axis: "axis", bar: "bar", barOverlapGroup: "barOverlapGroup", barPadding: "barPadding", barWidth: "barWidth", border: "border", bubble: "bubble", candlestick: "candlestick", closeValueField: "closeValueField", color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", fullstackedarea: "fullstackedarea", fullstackedbar: "fullstackedbar", fullstackedline: "fullstackedline", fullstackedspline: "fullstackedspline", fullstackedsplinearea: "fullstackedsplinearea", highValueField: "highValueField", hoverMode: "hoverMode", hoverStyle: "hoverStyle", ignoreEmptyPoints: "ignoreEmptyPoints", innerColor: "innerColor", label: "label", line: "line", lowValueField: "lowValueField", maxLabelCount: "maxLabelCount", minBarSize: "minBarSize", opacity: "opacity", openValueField: "openValueField", pane: "pane", point: "point", rangearea: "rangearea", rangebar: "rangebar", rangeValue1Field: "rangeValue1Field", rangeValue2Field: "rangeValue2Field", reduction: "reduction", scatter: "scatter", selectionMode: "selectionMode", selectionStyle: "selectionStyle", showInLegend: "showInLegend", sizeField: "sizeField", spline: "spline", splinearea: "splinearea", stack: "stack", stackedarea: "stackedarea", stackedbar: "stackedbar", stackedline: "stackedline", stackedspline: "stackedspline", stackedsplinearea: "stackedsplinearea", steparea: "steparea", stepline: "stepline", stock: "stock", tagField: "tagField", type: "type", valueErrorBar: "valueErrorBar", valueField: "valueField", visible: "visible", width: "width", closed: "closed" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoAreaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-area', template: '', providers: [NestedOptionHost], inputs: [
                        'aggregation',
                        'area',
                        'argumentField',
                        'axis',
                        'bar',
                        'barOverlapGroup',
                        'barPadding',
                        'barWidth',
                        'border',
                        'bubble',
                        'candlestick',
                        'closeValueField',
                        'color',
                        'cornerRadius',
                        'dashStyle',
                        'fullstackedarea',
                        'fullstackedbar',
                        'fullstackedline',
                        'fullstackedspline',
                        'fullstackedsplinearea',
                        'highValueField',
                        'hoverMode',
                        'hoverStyle',
                        'ignoreEmptyPoints',
                        'innerColor',
                        'label',
                        'line',
                        'lowValueField',
                        'maxLabelCount',
                        'minBarSize',
                        'opacity',
                        'openValueField',
                        'pane',
                        'point',
                        'rangearea',
                        'rangebar',
                        'rangeValue1Field',
                        'rangeValue2Field',
                        'reduction',
                        'scatter',
                        'selectionMode',
                        'selectionStyle',
                        'showInLegend',
                        'sizeField',
                        'spline',
                        'splinearea',
                        'stack',
                        'stackedarea',
                        'stackedbar',
                        'stackedline',
                        'stackedspline',
                        'stackedsplinearea',
                        'steparea',
                        'stepline',
                        'stock',
                        'tagField',
                        'type',
                        'valueErrorBar',
                        'valueField',
                        'visible',
                        'width',
                        'closed'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxoAreaModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoAreaModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxoAreaModule, declarations: [DxoAreaComponent], exports: [DxoAreaComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoAreaModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxoAreaModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxoAreaComponent
                    ],
                    exports: [
                        DxoAreaComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXJlYS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvbmVzdGVkL2FyZWEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFFcEMsaURBQWlEO0FBRWpELE9BQU8sRUFDSCxTQUFTLEVBR1QsUUFBUSxFQUNSLElBQUksRUFDSixRQUFRLEVBQ1gsTUFBTSxlQUFlLENBQUM7QUFNdkIsT0FBTyxFQUNILGdCQUFnQixHQUNuQixNQUFNLHlCQUF5QixDQUFDO0FBQ2pDLE9BQU8sRUFBRSw0QkFBNEIsRUFBRSxNQUFNLHFDQUFxQyxDQUFDOzs7QUF5RW5GLE1BQU0sT0FBTyxnQkFBaUIsU0FBUSw0QkFBNEI7SUFFOUQsSUFBYyxXQUFXO1FBQ3JCLE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFHRCxZQUFnQyxnQkFBa0MsRUFDbEQsVUFBNEI7UUFDeEMsS0FBSyxFQUFFLENBQUM7UUFDUixnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBR0QsUUFBUTtRQUNKLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7MkhBckJRLGdCQUFnQjsrR0FBaEIsZ0JBQWdCLHluREFsRWQsQ0FBQyxnQkFBZ0IsQ0FBQyxpREFGbkIsRUFBRTs7NEZBb0VILGdCQUFnQjtrQkF0RTVCLFNBQVM7K0JBQ0ksVUFBVSxZQUNWLEVBQUUsYUFFRCxDQUFDLGdCQUFnQixDQUFDLFVBQ3JCO3dCQUNKLGFBQWE7d0JBQ2IsTUFBTTt3QkFDTixlQUFlO3dCQUNmLE1BQU07d0JBQ04sS0FBSzt3QkFDTCxpQkFBaUI7d0JBQ2pCLFlBQVk7d0JBQ1osVUFBVTt3QkFDVixRQUFRO3dCQUNSLFFBQVE7d0JBQ1IsYUFBYTt3QkFDYixpQkFBaUI7d0JBQ2pCLE9BQU87d0JBQ1AsY0FBYzt3QkFDZCxXQUFXO3dCQUNYLGlCQUFpQjt3QkFDakIsZ0JBQWdCO3dCQUNoQixpQkFBaUI7d0JBQ2pCLG1CQUFtQjt3QkFDbkIsdUJBQXVCO3dCQUN2QixnQkFBZ0I7d0JBQ2hCLFdBQVc7d0JBQ1gsWUFBWTt3QkFDWixtQkFBbUI7d0JBQ25CLFlBQVk7d0JBQ1osT0FBTzt3QkFDUCxNQUFNO3dCQUNOLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixZQUFZO3dCQUNaLFNBQVM7d0JBQ1QsZ0JBQWdCO3dCQUNoQixNQUFNO3dCQUNOLE9BQU87d0JBQ1AsV0FBVzt3QkFDWCxVQUFVO3dCQUNWLGtCQUFrQjt3QkFDbEIsa0JBQWtCO3dCQUNsQixXQUFXO3dCQUNYLFNBQVM7d0JBQ1QsZUFBZTt3QkFDZixnQkFBZ0I7d0JBQ2hCLGNBQWM7d0JBQ2QsV0FBVzt3QkFDWCxRQUFRO3dCQUNSLFlBQVk7d0JBQ1osT0FBTzt3QkFDUCxhQUFhO3dCQUNiLFlBQVk7d0JBQ1osYUFBYTt3QkFDYixlQUFlO3dCQUNmLG1CQUFtQjt3QkFDbkIsVUFBVTt3QkFDVixVQUFVO3dCQUNWLE9BQU87d0JBQ1AsVUFBVTt3QkFDVixNQUFNO3dCQUNOLGVBQWU7d0JBQ2YsWUFBWTt3QkFDWixTQUFTO3dCQUNULE9BQU87d0JBQ1AsUUFBUTtxQkFDWDs7MEJBU1ksUUFBUTs7MEJBQUksSUFBSTs7MEJBQ3BCLElBQUk7O0FBMEJqQixNQUFNLE9BQU8sYUFBYTsySEFBYixhQUFhOzRIQUFiLGFBQWEsaUJBbENiLGdCQUFnQixhQUFoQixnQkFBZ0I7NEhBa0NoQixhQUFhOzs0RkFBYixhQUFhO2tCQVJ6QixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWixnQkFBZ0I7cUJBQ2pCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxnQkFBZ0I7cUJBQ2pCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE9uSW5pdCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgTmdNb2R1bGUsXG4gICAgSG9zdCxcbiAgICBTa2lwU2VsZlxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG5cblxuXG5pbXBvcnQge1xuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IER4b0NoYXJ0Q29tbW9uU2VyaWVzU2V0dGluZ3MgfSBmcm9tICcuL2Jhc2UvY2hhcnQtY29tbW9uLXNlcmllcy1zZXR0aW5ncyc7XG5cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeG8tYXJlYScsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHN0eWxlczogWycnXSxcbiAgICBwcm92aWRlcnM6IFtOZXN0ZWRPcHRpb25Ib3N0XSxcbiAgICBpbnB1dHM6IFtcbiAgICAgICAgJ2FnZ3JlZ2F0aW9uJyxcbiAgICAgICAgJ2FyZWEnLFxuICAgICAgICAnYXJndW1lbnRGaWVsZCcsXG4gICAgICAgICdheGlzJyxcbiAgICAgICAgJ2JhcicsXG4gICAgICAgICdiYXJPdmVybGFwR3JvdXAnLFxuICAgICAgICAnYmFyUGFkZGluZycsXG4gICAgICAgICdiYXJXaWR0aCcsXG4gICAgICAgICdib3JkZXInLFxuICAgICAgICAnYnViYmxlJyxcbiAgICAgICAgJ2NhbmRsZXN0aWNrJyxcbiAgICAgICAgJ2Nsb3NlVmFsdWVGaWVsZCcsXG4gICAgICAgICdjb2xvcicsXG4gICAgICAgICdjb3JuZXJSYWRpdXMnLFxuICAgICAgICAnZGFzaFN0eWxlJyxcbiAgICAgICAgJ2Z1bGxzdGFja2VkYXJlYScsXG4gICAgICAgICdmdWxsc3RhY2tlZGJhcicsXG4gICAgICAgICdmdWxsc3RhY2tlZGxpbmUnLFxuICAgICAgICAnZnVsbHN0YWNrZWRzcGxpbmUnLFxuICAgICAgICAnZnVsbHN0YWNrZWRzcGxpbmVhcmVhJyxcbiAgICAgICAgJ2hpZ2hWYWx1ZUZpZWxkJyxcbiAgICAgICAgJ2hvdmVyTW9kZScsXG4gICAgICAgICdob3ZlclN0eWxlJyxcbiAgICAgICAgJ2lnbm9yZUVtcHR5UG9pbnRzJyxcbiAgICAgICAgJ2lubmVyQ29sb3InLFxuICAgICAgICAnbGFiZWwnLFxuICAgICAgICAnbGluZScsXG4gICAgICAgICdsb3dWYWx1ZUZpZWxkJyxcbiAgICAgICAgJ21heExhYmVsQ291bnQnLFxuICAgICAgICAnbWluQmFyU2l6ZScsXG4gICAgICAgICdvcGFjaXR5JyxcbiAgICAgICAgJ29wZW5WYWx1ZUZpZWxkJyxcbiAgICAgICAgJ3BhbmUnLFxuICAgICAgICAncG9pbnQnLFxuICAgICAgICAncmFuZ2VhcmVhJyxcbiAgICAgICAgJ3JhbmdlYmFyJyxcbiAgICAgICAgJ3JhbmdlVmFsdWUxRmllbGQnLFxuICAgICAgICAncmFuZ2VWYWx1ZTJGaWVsZCcsXG4gICAgICAgICdyZWR1Y3Rpb24nLFxuICAgICAgICAnc2NhdHRlcicsXG4gICAgICAgICdzZWxlY3Rpb25Nb2RlJyxcbiAgICAgICAgJ3NlbGVjdGlvblN0eWxlJyxcbiAgICAgICAgJ3Nob3dJbkxlZ2VuZCcsXG4gICAgICAgICdzaXplRmllbGQnLFxuICAgICAgICAnc3BsaW5lJyxcbiAgICAgICAgJ3NwbGluZWFyZWEnLFxuICAgICAgICAnc3RhY2snLFxuICAgICAgICAnc3RhY2tlZGFyZWEnLFxuICAgICAgICAnc3RhY2tlZGJhcicsXG4gICAgICAgICdzdGFja2VkbGluZScsXG4gICAgICAgICdzdGFja2Vkc3BsaW5lJyxcbiAgICAgICAgJ3N0YWNrZWRzcGxpbmVhcmVhJyxcbiAgICAgICAgJ3N0ZXBhcmVhJyxcbiAgICAgICAgJ3N0ZXBsaW5lJyxcbiAgICAgICAgJ3N0b2NrJyxcbiAgICAgICAgJ3RhZ0ZpZWxkJyxcbiAgICAgICAgJ3R5cGUnLFxuICAgICAgICAndmFsdWVFcnJvckJhcicsXG4gICAgICAgICd2YWx1ZUZpZWxkJyxcbiAgICAgICAgJ3Zpc2libGUnLFxuICAgICAgICAnd2lkdGgnLFxuICAgICAgICAnY2xvc2VkJ1xuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhvQXJlYUNvbXBvbmVudCBleHRlbmRzIER4b0NoYXJ0Q29tbW9uU2VyaWVzU2V0dGluZ3MgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIE9uSW5pdCAge1xuXG4gICAgcHJvdGVjdGVkIGdldCBfb3B0aW9uUGF0aCgpIHtcbiAgICAgICAgcmV0dXJuICdhcmVhJztcbiAgICB9XG5cblxuICAgIGNvbnN0cnVjdG9yKEBTa2lwU2VsZigpIEBIb3N0KCkgcGFyZW50T3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgICAgIEBIb3N0KCkgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICBwYXJlbnRPcHRpb25Ib3N0LnNldE5lc3RlZE9wdGlvbih0aGlzKTtcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMsIHRoaXMuX2Z1bGxPcHRpb25QYXRoLmJpbmQodGhpcykpO1xuICAgIH1cblxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMuX2FkZFJlY3JlYXRlZENvbXBvbmVudCgpO1xuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9hZGRSZW1vdmVkT3B0aW9uKHRoaXMuX2dldE9wdGlvblBhdGgoKSk7XG4gICAgfVxuXG5cbn1cblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhvQXJlYUNvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhvQXJlYUNvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeG9BcmVhTW9kdWxlIHsgfVxuIl19