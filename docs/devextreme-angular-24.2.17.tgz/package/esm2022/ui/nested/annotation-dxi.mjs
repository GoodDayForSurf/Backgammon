/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
/* tslint:disable:use-input-property-decorator */
import { Component, NgModule, Host, SkipSelf } from '@angular/core';
import { NestedOptionHost, } from 'devextreme-angular/core';
import { DxiChartAnnotationConfig } from './base/chart-annotation-config-dxi';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxiAnnotationComponent extends DxiChartAnnotationConfig {
    get _optionPath() {
        return 'annotations';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiAnnotationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxiAnnotationComponent, selector: "dxi-annotation", inputs: { allowDragging: "allowDragging", argument: "argument", arrowLength: "arrowLength", arrowWidth: "arrowWidth", axis: "axis", border: "border", color: "color", customizeTooltip: "customizeTooltip", data: "data", description: "description", font: "font", height: "height", image: "image", name: "name", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", series: "series", shadow: "shadow", template: "template", text: "text", textOverflow: "textOverflow", tooltipEnabled: "tooltipEnabled", tooltipTemplate: "tooltipTemplate", type: "type", value: "value", width: "width", wordWrap: "wordWrap", x: "x", y: "y", location: "location", angle: "angle", radius: "radius", coordinates: "coordinates" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiAnnotationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-annotation', template: '', providers: [NestedOptionHost], inputs: [
                        'allowDragging',
                        'argument',
                        'arrowLength',
                        'arrowWidth',
                        'axis',
                        'border',
                        'color',
                        'customizeTooltip',
                        'data',
                        'description',
                        'font',
                        'height',
                        'image',
                        'name',
                        'offsetX',
                        'offsetY',
                        'opacity',
                        'paddingLeftRight',
                        'paddingTopBottom',
                        'series',
                        'shadow',
                        'template',
                        'text',
                        'textOverflow',
                        'tooltipEnabled',
                        'tooltipTemplate',
                        'type',
                        'value',
                        'width',
                        'wordWrap',
                        'x',
                        'y',
                        'location',
                        'angle',
                        'radius',
                        'coordinates'
                    ] }]
        }], ctorParameters: function () { return [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }]; } });
export class DxiAnnotationModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiAnnotationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxiAnnotationModule, declarations: [DxiAnnotationComponent], exports: [DxiAnnotationComponent] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiAnnotationModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxiAnnotationModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DxiAnnotationComponent
                    ],
                    exports: [
                        DxiAnnotationComponent
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5ub3RhdGlvbi1keGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL25lc3RlZC9hbm5vdGF0aW9uLWR4aS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILG9DQUFvQztBQUVwQyxpREFBaUQ7QUFFakQsT0FBTyxFQUNILFNBQVMsRUFDVCxRQUFRLEVBQ1IsSUFBSSxFQUNKLFFBQVEsRUFDWCxNQUFNLGVBQWUsQ0FBQztBQU12QixPQUFPLEVBQ0gsZ0JBQWdCLEdBQ25CLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sb0NBQW9DLENBQUM7OztBQStDOUUsTUFBTSxPQUFPLHNCQUF1QixTQUFRLHdCQUF3QjtJQUVoRSxJQUFjLFdBQVc7UUFDckIsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUdELFlBQWdDLGdCQUFrQyxFQUNsRCxVQUE0QjtRQUN4QyxLQUFLLEVBQUUsQ0FBQztRQUNSLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFJRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7MkhBbEJRLHNCQUFzQjsrR0FBdEIsc0JBQXNCLDJ6QkF4Q3BCLENBQUMsZ0JBQWdCLENBQUMsaURBRm5CLEVBQUU7OzRGQTBDSCxzQkFBc0I7a0JBNUNsQyxTQUFTOytCQUNJLGdCQUFnQixZQUNoQixFQUFFLGFBRUQsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUNyQjt3QkFDSixlQUFlO3dCQUNmLFVBQVU7d0JBQ1YsYUFBYTt3QkFDYixZQUFZO3dCQUNaLE1BQU07d0JBQ04sUUFBUTt3QkFDUixPQUFPO3dCQUNQLGtCQUFrQjt3QkFDbEIsTUFBTTt3QkFDTixhQUFhO3dCQUNiLE1BQU07d0JBQ04sUUFBUTt3QkFDUixPQUFPO3dCQUNQLE1BQU07d0JBQ04sU0FBUzt3QkFDVCxTQUFTO3dCQUNULFNBQVM7d0JBQ1Qsa0JBQWtCO3dCQUNsQixrQkFBa0I7d0JBQ2xCLFFBQVE7d0JBQ1IsUUFBUTt3QkFDUixVQUFVO3dCQUNWLE1BQU07d0JBQ04sY0FBYzt3QkFDZCxnQkFBZ0I7d0JBQ2hCLGlCQUFpQjt3QkFDakIsTUFBTTt3QkFDTixPQUFPO3dCQUNQLE9BQU87d0JBQ1AsVUFBVTt3QkFDVixHQUFHO3dCQUNILEdBQUc7d0JBQ0gsVUFBVTt3QkFDVixPQUFPO3dCQUNQLFFBQVE7d0JBQ1IsYUFBYTtxQkFDaEI7OzBCQVNZLFFBQVE7OzBCQUFJLElBQUk7OzBCQUNwQixJQUFJOztBQXNCakIsTUFBTSxPQUFPLG1CQUFtQjsySEFBbkIsbUJBQW1COzRIQUFuQixtQkFBbUIsaUJBOUJuQixzQkFBc0IsYUFBdEIsc0JBQXNCOzRIQThCdEIsbUJBQW1COzs0RkFBbkIsbUJBQW1CO2tCQVIvQixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRTt3QkFDWixzQkFBc0I7cUJBQ3ZCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxzQkFBc0I7cUJBQ3ZCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbi8qIHRzbGludDpkaXNhYmxlOm1heC1saW5lLWxlbmd0aCAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTp1c2UtaW5wdXQtcHJvcGVydHktZGVjb3JhdG9yICovXG5cbmltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIE5nTW9kdWxlLFxuICAgIEhvc3QsXG4gICAgU2tpcFNlbGZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuXG5cblxuaW1wb3J0IHtcbiAgICBOZXN0ZWRPcHRpb25Ib3N0LFxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEeGlDaGFydEFubm90YXRpb25Db25maWcgfSBmcm9tICcuL2Jhc2UvY2hhcnQtYW5ub3RhdGlvbi1jb25maWctZHhpJztcblxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4aS1hbm5vdGF0aW9uJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJyddLFxuICAgIHByb3ZpZGVyczogW05lc3RlZE9wdGlvbkhvc3RdLFxuICAgIGlucHV0czogW1xuICAgICAgICAnYWxsb3dEcmFnZ2luZycsXG4gICAgICAgICdhcmd1bWVudCcsXG4gICAgICAgICdhcnJvd0xlbmd0aCcsXG4gICAgICAgICdhcnJvd1dpZHRoJyxcbiAgICAgICAgJ2F4aXMnLFxuICAgICAgICAnYm9yZGVyJyxcbiAgICAgICAgJ2NvbG9yJyxcbiAgICAgICAgJ2N1c3RvbWl6ZVRvb2x0aXAnLFxuICAgICAgICAnZGF0YScsXG4gICAgICAgICdkZXNjcmlwdGlvbicsXG4gICAgICAgICdmb250JyxcbiAgICAgICAgJ2hlaWdodCcsXG4gICAgICAgICdpbWFnZScsXG4gICAgICAgICduYW1lJyxcbiAgICAgICAgJ29mZnNldFgnLFxuICAgICAgICAnb2Zmc2V0WScsXG4gICAgICAgICdvcGFjaXR5JyxcbiAgICAgICAgJ3BhZGRpbmdMZWZ0UmlnaHQnLFxuICAgICAgICAncGFkZGluZ1RvcEJvdHRvbScsXG4gICAgICAgICdzZXJpZXMnLFxuICAgICAgICAnc2hhZG93JyxcbiAgICAgICAgJ3RlbXBsYXRlJyxcbiAgICAgICAgJ3RleHQnLFxuICAgICAgICAndGV4dE92ZXJmbG93JyxcbiAgICAgICAgJ3Rvb2x0aXBFbmFibGVkJyxcbiAgICAgICAgJ3Rvb2x0aXBUZW1wbGF0ZScsXG4gICAgICAgICd0eXBlJyxcbiAgICAgICAgJ3ZhbHVlJyxcbiAgICAgICAgJ3dpZHRoJyxcbiAgICAgICAgJ3dvcmRXcmFwJyxcbiAgICAgICAgJ3gnLFxuICAgICAgICAneScsXG4gICAgICAgICdsb2NhdGlvbicsXG4gICAgICAgICdhbmdsZScsXG4gICAgICAgICdyYWRpdXMnLFxuICAgICAgICAnY29vcmRpbmF0ZXMnXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeGlBbm5vdGF0aW9uQ29tcG9uZW50IGV4dGVuZHMgRHhpQ2hhcnRBbm5vdGF0aW9uQ29uZmlnIHtcblxuICAgIHByb3RlY3RlZCBnZXQgX29wdGlvblBhdGgoKSB7XG4gICAgICAgIHJldHVybiAnYW5ub3RhdGlvbnMnO1xuICAgIH1cblxuXG4gICAgY29uc3RydWN0b3IoQFNraXBTZWxmKCkgQEhvc3QoKSBwYXJlbnRPcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgQEhvc3QoKSBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHBhcmVudE9wdGlvbkhvc3Quc2V0TmVzdGVkT3B0aW9uKHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcywgdGhpcy5fZnVsbE9wdGlvblBhdGguYmluZCh0aGlzKSk7XG4gICAgfVxuXG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZWxldGVSZW1vdmVkT3B0aW9ucyh0aGlzLl9mdWxsT3B0aW9uUGF0aCgpKTtcbiAgICB9XG5cbn1cblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhpQW5ub3RhdGlvbkNvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhpQW5ub3RhdGlvbkNvbXBvbmVudFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBEeGlBbm5vdGF0aW9uTW9kdWxlIHsgfVxuIl19