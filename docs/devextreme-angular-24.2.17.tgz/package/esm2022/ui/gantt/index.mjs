/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import DxGantt from 'devextreme/ui/gantt';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxiColumnModule } from 'devextreme-angular/ui/nested';
import { DxoFormatModule } from 'devextreme-angular/ui/nested';
import { DxoHeaderFilterModule } from 'devextreme-angular/ui/nested';
import { DxoSearchModule } from 'devextreme-angular/ui/nested';
import { DxoContextMenuModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoDependenciesModule } from 'devextreme-angular/ui/nested';
import { DxoEditingModule } from 'devextreme-angular/ui/nested';
import { DxoFilterRowModule } from 'devextreme-angular/ui/nested';
import { DxoOperationDescriptionsModule } from 'devextreme-angular/ui/nested';
import { DxoTextsModule } from 'devextreme-angular/ui/nested';
import { DxoResourceAssignmentsModule } from 'devextreme-angular/ui/nested';
import { DxoResourcesModule } from 'devextreme-angular/ui/nested';
import { DxoScaleTypeRangeModule } from 'devextreme-angular/ui/nested';
import { DxoSortingModule } from 'devextreme-angular/ui/nested';
import { DxiStripLineModule } from 'devextreme-angular/ui/nested';
import { DxoTasksModule } from 'devextreme-angular/ui/nested';
import { DxoToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoValidationModule } from 'devextreme-angular/ui/nested';
import { DxiColumnComponent } from 'devextreme-angular/ui/nested';
import { DxiStripLineComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxGantt]

 */
export class DxGanttComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxGanttOptions.allowSelection]
    
     */
    get allowSelection() {
        return this._getOption('allowSelection');
    }
    set allowSelection(value) {
        this._setOption('allowSelection', value);
    }
    /**
     * [descr:dxGanttOptions.columns]
    
     */
    get columns() {
        return this._getOption('columns');
    }
    set columns(value) {
        this._setOption('columns', value);
    }
    /**
     * [descr:dxGanttOptions.contextMenu]
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * [descr:dxGanttOptions.dependencies]
    
     */
    get dependencies() {
        return this._getOption('dependencies');
    }
    set dependencies(value) {
        this._setOption('dependencies', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxGanttOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxGanttOptions.endDateRange]
    
     */
    get endDateRange() {
        return this._getOption('endDateRange');
    }
    set endDateRange(value) {
        this._setOption('endDateRange', value);
    }
    /**
     * [descr:dxGanttOptions.filterRow]
    
     */
    get filterRow() {
        return this._getOption('filterRow');
    }
    set filterRow(value) {
        this._setOption('filterRow', value);
    }
    /**
     * [descr:dxGanttOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxGanttOptions.headerFilter]
    
     */
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxGanttOptions.resourceAssignments]
    
     */
    get resourceAssignments() {
        return this._getOption('resourceAssignments');
    }
    set resourceAssignments(value) {
        this._setOption('resourceAssignments', value);
    }
    /**
     * [descr:dxGanttOptions.resources]
    
     */
    get resources() {
        return this._getOption('resources');
    }
    set resources(value) {
        this._setOption('resources', value);
    }
    /**
     * [descr:dxGanttOptions.rootValue]
    
     */
    get rootValue() {
        return this._getOption('rootValue');
    }
    set rootValue(value) {
        this._setOption('rootValue', value);
    }
    /**
     * [descr:dxGanttOptions.scaleType]
    
     */
    get scaleType() {
        return this._getOption('scaleType');
    }
    set scaleType(value) {
        this._setOption('scaleType', value);
    }
    /**
     * [descr:dxGanttOptions.scaleTypeRange]
    
     */
    get scaleTypeRange() {
        return this._getOption('scaleTypeRange');
    }
    set scaleTypeRange(value) {
        this._setOption('scaleTypeRange', value);
    }
    /**
     * [descr:dxGanttOptions.selectedRowKey]
    
     */
    get selectedRowKey() {
        return this._getOption('selectedRowKey');
    }
    set selectedRowKey(value) {
        this._setOption('selectedRowKey', value);
    }
    /**
     * [descr:dxGanttOptions.showDependencies]
    
     */
    get showDependencies() {
        return this._getOption('showDependencies');
    }
    set showDependencies(value) {
        this._setOption('showDependencies', value);
    }
    /**
     * [descr:dxGanttOptions.showResources]
    
     */
    get showResources() {
        return this._getOption('showResources');
    }
    set showResources(value) {
        this._setOption('showResources', value);
    }
    /**
     * [descr:dxGanttOptions.showRowLines]
    
     */
    get showRowLines() {
        return this._getOption('showRowLines');
    }
    set showRowLines(value) {
        this._setOption('showRowLines', value);
    }
    /**
     * [descr:dxGanttOptions.sorting]
    
     */
    get sorting() {
        return this._getOption('sorting');
    }
    set sorting(value) {
        this._setOption('sorting', value);
    }
    /**
     * [descr:dxGanttOptions.startDateRange]
    
     */
    get startDateRange() {
        return this._getOption('startDateRange');
    }
    set startDateRange(value) {
        this._setOption('startDateRange', value);
    }
    /**
     * [descr:dxGanttOptions.stripLines]
    
     */
    get stripLines() {
        return this._getOption('stripLines');
    }
    set stripLines(value) {
        this._setOption('stripLines', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxGanttOptions.taskContentTemplate]
    
     */
    get taskContentTemplate() {
        return this._getOption('taskContentTemplate');
    }
    set taskContentTemplate(value) {
        this._setOption('taskContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.taskListWidth]
    
     */
    get taskListWidth() {
        return this._getOption('taskListWidth');
    }
    set taskListWidth(value) {
        this._setOption('taskListWidth', value);
    }
    /**
     * [descr:dxGanttOptions.taskProgressTooltipContentTemplate]
    
     */
    get taskProgressTooltipContentTemplate() {
        return this._getOption('taskProgressTooltipContentTemplate');
    }
    set taskProgressTooltipContentTemplate(value) {
        this._setOption('taskProgressTooltipContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.tasks]
    
     */
    get tasks() {
        return this._getOption('tasks');
    }
    set tasks(value) {
        this._setOption('tasks', value);
    }
    /**
     * [descr:dxGanttOptions.taskTimeTooltipContentTemplate]
    
     */
    get taskTimeTooltipContentTemplate() {
        return this._getOption('taskTimeTooltipContentTemplate');
    }
    set taskTimeTooltipContentTemplate(value) {
        this._setOption('taskTimeTooltipContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.taskTitlePosition]
    
     */
    get taskTitlePosition() {
        return this._getOption('taskTitlePosition');
    }
    set taskTitlePosition(value) {
        this._setOption('taskTitlePosition', value);
    }
    /**
     * [descr:dxGanttOptions.taskTooltipContentTemplate]
    
     */
    get taskTooltipContentTemplate() {
        return this._getOption('taskTooltipContentTemplate');
    }
    set taskTooltipContentTemplate(value) {
        this._setOption('taskTooltipContentTemplate', value);
    }
    /**
     * [descr:dxGanttOptions.toolbar]
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * [descr:dxGanttOptions.validation]
    
     */
    get validation() {
        return this._getOption('validation');
    }
    set validation(value) {
        this._setOption('validation', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
    
     * [descr:dxGanttOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxGanttOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing;
    /**
    
     * [descr:dxGanttOptions.onCustomCommand]
    
    
     */
    onCustomCommand;
    /**
    
     * [descr:dxGanttOptions.onDependencyDeleted]
    
    
     */
    onDependencyDeleted;
    /**
    
     * [descr:dxGanttOptions.onDependencyDeleting]
    
    
     */
    onDependencyDeleting;
    /**
    
     * [descr:dxGanttOptions.onDependencyInserted]
    
    
     */
    onDependencyInserted;
    /**
    
     * [descr:dxGanttOptions.onDependencyInserting]
    
    
     */
    onDependencyInserting;
    /**
    
     * [descr:dxGanttOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxGanttOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxGanttOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxGanttOptions.onResourceAssigned]
    
    
     */
    onResourceAssigned;
    /**
    
     * [descr:dxGanttOptions.onResourceAssigning]
    
    
     */
    onResourceAssigning;
    /**
    
     * [descr:dxGanttOptions.onResourceDeleted]
    
    
     */
    onResourceDeleted;
    /**
    
     * [descr:dxGanttOptions.onResourceDeleting]
    
    
     */
    onResourceDeleting;
    /**
    
     * [descr:dxGanttOptions.onResourceInserted]
    
    
     */
    onResourceInserted;
    /**
    
     * [descr:dxGanttOptions.onResourceInserting]
    
    
     */
    onResourceInserting;
    /**
    
     * [descr:dxGanttOptions.onResourceManagerDialogShowing]
    
    
     */
    onResourceManagerDialogShowing;
    /**
    
     * [descr:dxGanttOptions.onResourceUnassigned]
    
    
     */
    onResourceUnassigned;
    /**
    
     * [descr:dxGanttOptions.onResourceUnassigning]
    
    
     */
    onResourceUnassigning;
    /**
    
     * [descr:dxGanttOptions.onScaleCellPrepared]
    
    
     */
    onScaleCellPrepared;
    /**
    
     * [descr:dxGanttOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * [descr:dxGanttOptions.onTaskClick]
    
    
     */
    onTaskClick;
    /**
    
     * [descr:dxGanttOptions.onTaskDblClick]
    
    
     */
    onTaskDblClick;
    /**
    
     * [descr:dxGanttOptions.onTaskDeleted]
    
    
     */
    onTaskDeleted;
    /**
    
     * [descr:dxGanttOptions.onTaskDeleting]
    
    
     */
    onTaskDeleting;
    /**
    
     * [descr:dxGanttOptions.onTaskEditDialogShowing]
    
    
     */
    onTaskEditDialogShowing;
    /**
    
     * [descr:dxGanttOptions.onTaskInserted]
    
    
     */
    onTaskInserted;
    /**
    
     * [descr:dxGanttOptions.onTaskInserting]
    
    
     */
    onTaskInserting;
    /**
    
     * [descr:dxGanttOptions.onTaskMoving]
    
    
     */
    onTaskMoving;
    /**
    
     * [descr:dxGanttOptions.onTaskUpdated]
    
    
     */
    onTaskUpdated;
    /**
    
     * [descr:dxGanttOptions.onTaskUpdating]
    
    
     */
    onTaskUpdating;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSelectionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextMenuChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dependenciesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateRangeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterRowChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstDayOfWeekChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourceAssignmentsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourcesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rootValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleTypeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleTypeRangeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRowKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDependenciesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showResourcesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowLinesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateRangeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stripLinesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskListWidthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskProgressTooltipContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tasksChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTimeTooltipContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTitlePositionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTooltipContentTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    get columnsChildren() {
        return this._getOption('columns');
    }
    set columnsChildren(value) {
        this.setChildren('columns', value);
    }
    get stripLinesChildren() {
        return this._getOption('stripLines');
    }
    set stripLinesChildren(value) {
        this.setChildren('stripLines', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'customCommand', emit: 'onCustomCommand' },
            { subscribe: 'dependencyDeleted', emit: 'onDependencyDeleted' },
            { subscribe: 'dependencyDeleting', emit: 'onDependencyDeleting' },
            { subscribe: 'dependencyInserted', emit: 'onDependencyInserted' },
            { subscribe: 'dependencyInserting', emit: 'onDependencyInserting' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'resourceAssigned', emit: 'onResourceAssigned' },
            { subscribe: 'resourceAssigning', emit: 'onResourceAssigning' },
            { subscribe: 'resourceDeleted', emit: 'onResourceDeleted' },
            { subscribe: 'resourceDeleting', emit: 'onResourceDeleting' },
            { subscribe: 'resourceInserted', emit: 'onResourceInserted' },
            { subscribe: 'resourceInserting', emit: 'onResourceInserting' },
            { subscribe: 'resourceManagerDialogShowing', emit: 'onResourceManagerDialogShowing' },
            { subscribe: 'resourceUnassigned', emit: 'onResourceUnassigned' },
            { subscribe: 'resourceUnassigning', emit: 'onResourceUnassigning' },
            { subscribe: 'scaleCellPrepared', emit: 'onScaleCellPrepared' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'taskClick', emit: 'onTaskClick' },
            { subscribe: 'taskDblClick', emit: 'onTaskDblClick' },
            { subscribe: 'taskDeleted', emit: 'onTaskDeleted' },
            { subscribe: 'taskDeleting', emit: 'onTaskDeleting' },
            { subscribe: 'taskEditDialogShowing', emit: 'onTaskEditDialogShowing' },
            { subscribe: 'taskInserted', emit: 'onTaskInserted' },
            { subscribe: 'taskInserting', emit: 'onTaskInserting' },
            { subscribe: 'taskMoving', emit: 'onTaskMoving' },
            { subscribe: 'taskUpdated', emit: 'onTaskUpdated' },
            { subscribe: 'taskUpdating', emit: 'onTaskUpdating' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowSelectionChange' },
            { emit: 'columnsChange' },
            { emit: 'contextMenuChange' },
            { emit: 'dependenciesChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'endDateRangeChange' },
            { emit: 'filterRowChange' },
            { emit: 'firstDayOfWeekChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'headerFilterChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'resourceAssignmentsChange' },
            { emit: 'resourcesChange' },
            { emit: 'rootValueChange' },
            { emit: 'scaleTypeChange' },
            { emit: 'scaleTypeRangeChange' },
            { emit: 'selectedRowKeyChange' },
            { emit: 'showDependenciesChange' },
            { emit: 'showResourcesChange' },
            { emit: 'showRowLinesChange' },
            { emit: 'sortingChange' },
            { emit: 'startDateRangeChange' },
            { emit: 'stripLinesChange' },
            { emit: 'tabIndexChange' },
            { emit: 'taskContentTemplateChange' },
            { emit: 'taskListWidthChange' },
            { emit: 'taskProgressTooltipContentTemplateChange' },
            { emit: 'tasksChange' },
            { emit: 'taskTimeTooltipContentTemplateChange' },
            { emit: 'taskTitlePositionChange' },
            { emit: 'taskTooltipContentTemplateChange' },
            { emit: 'toolbarChange' },
            { emit: 'validationChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxGantt(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('columns', changes);
        this.setupChanges('stripLines', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('columns');
        this._idh.doCheck('stripLines');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxGanttComponent, selector: "dx-gantt", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowSelection: "allowSelection", columns: "columns", contextMenu: "contextMenu", dependencies: "dependencies", disabled: "disabled", editing: "editing", elementAttr: "elementAttr", endDateRange: "endDateRange", filterRow: "filterRow", firstDayOfWeek: "firstDayOfWeek", focusStateEnabled: "focusStateEnabled", headerFilter: "headerFilter", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", resourceAssignments: "resourceAssignments", resources: "resources", rootValue: "rootValue", scaleType: "scaleType", scaleTypeRange: "scaleTypeRange", selectedRowKey: "selectedRowKey", showDependencies: "showDependencies", showResources: "showResources", showRowLines: "showRowLines", sorting: "sorting", startDateRange: "startDateRange", stripLines: "stripLines", tabIndex: "tabIndex", taskContentTemplate: "taskContentTemplate", taskListWidth: "taskListWidth", taskProgressTooltipContentTemplate: "taskProgressTooltipContentTemplate", tasks: "tasks", taskTimeTooltipContentTemplate: "taskTimeTooltipContentTemplate", taskTitlePosition: "taskTitlePosition", taskTooltipContentTemplate: "taskTooltipContentTemplate", toolbar: "toolbar", validation: "validation", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onContextMenuPreparing: "onContextMenuPreparing", onCustomCommand: "onCustomCommand", onDependencyDeleted: "onDependencyDeleted", onDependencyDeleting: "onDependencyDeleting", onDependencyInserted: "onDependencyInserted", onDependencyInserting: "onDependencyInserting", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResourceAssigned: "onResourceAssigned", onResourceAssigning: "onResourceAssigning", onResourceDeleted: "onResourceDeleted", onResourceDeleting: "onResourceDeleting", onResourceInserted: "onResourceInserted", onResourceInserting: "onResourceInserting", onResourceManagerDialogShowing: "onResourceManagerDialogShowing", onResourceUnassigned: "onResourceUnassigned", onResourceUnassigning: "onResourceUnassigning", onScaleCellPrepared: "onScaleCellPrepared", onSelectionChanged: "onSelectionChanged", onTaskClick: "onTaskClick", onTaskDblClick: "onTaskDblClick", onTaskDeleted: "onTaskDeleted", onTaskDeleting: "onTaskDeleting", onTaskEditDialogShowing: "onTaskEditDialogShowing", onTaskInserted: "onTaskInserted", onTaskInserting: "onTaskInserting", onTaskMoving: "onTaskMoving", onTaskUpdated: "onTaskUpdated", onTaskUpdating: "onTaskUpdating", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowSelectionChange: "allowSelectionChange", columnsChange: "columnsChange", contextMenuChange: "contextMenuChange", dependenciesChange: "dependenciesChange", disabledChange: "disabledChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", endDateRangeChange: "endDateRangeChange", filterRowChange: "filterRowChange", firstDayOfWeekChange: "firstDayOfWeekChange", focusStateEnabledChange: "focusStateEnabledChange", headerFilterChange: "headerFilterChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", resourceAssignmentsChange: "resourceAssignmentsChange", resourcesChange: "resourcesChange", rootValueChange: "rootValueChange", scaleTypeChange: "scaleTypeChange", scaleTypeRangeChange: "scaleTypeRangeChange", selectedRowKeyChange: "selectedRowKeyChange", showDependenciesChange: "showDependenciesChange", showResourcesChange: "showResourcesChange", showRowLinesChange: "showRowLinesChange", sortingChange: "sortingChange", startDateRangeChange: "startDateRangeChange", stripLinesChange: "stripLinesChange", tabIndexChange: "tabIndexChange", taskContentTemplateChange: "taskContentTemplateChange", taskListWidthChange: "taskListWidthChange", taskProgressTooltipContentTemplateChange: "taskProgressTooltipContentTemplateChange", tasksChange: "tasksChange", taskTimeTooltipContentTemplateChange: "taskTimeTooltipContentTemplateChange", taskTitlePositionChange: "taskTitlePositionChange", taskTooltipContentTemplateChange: "taskTooltipContentTemplateChange", toolbarChange: "toolbarChange", validationChange: "validationChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "columnsChildren", predicate: DxiColumnComponent }, { propertyName: "stripLinesChildren", predicate: DxiStripLineComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-gantt',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowSelection: [{
                type: Input
            }], columns: [{
                type: Input
            }], contextMenu: [{
                type: Input
            }], dependencies: [{
                type: Input
            }], disabled: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], endDateRange: [{
                type: Input
            }], filterRow: [{
                type: Input
            }], firstDayOfWeek: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], resourceAssignments: [{
                type: Input
            }], resources: [{
                type: Input
            }], rootValue: [{
                type: Input
            }], scaleType: [{
                type: Input
            }], scaleTypeRange: [{
                type: Input
            }], selectedRowKey: [{
                type: Input
            }], showDependencies: [{
                type: Input
            }], showResources: [{
                type: Input
            }], showRowLines: [{
                type: Input
            }], sorting: [{
                type: Input
            }], startDateRange: [{
                type: Input
            }], stripLines: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], taskContentTemplate: [{
                type: Input
            }], taskListWidth: [{
                type: Input
            }], taskProgressTooltipContentTemplate: [{
                type: Input
            }], tasks: [{
                type: Input
            }], taskTimeTooltipContentTemplate: [{
                type: Input
            }], taskTitlePosition: [{
                type: Input
            }], taskTooltipContentTemplate: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], validation: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onContextMenuPreparing: [{
                type: Output
            }], onCustomCommand: [{
                type: Output
            }], onDependencyDeleted: [{
                type: Output
            }], onDependencyDeleting: [{
                type: Output
            }], onDependencyInserted: [{
                type: Output
            }], onDependencyInserting: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onResourceAssigned: [{
                type: Output
            }], onResourceAssigning: [{
                type: Output
            }], onResourceDeleted: [{
                type: Output
            }], onResourceDeleting: [{
                type: Output
            }], onResourceInserted: [{
                type: Output
            }], onResourceInserting: [{
                type: Output
            }], onResourceManagerDialogShowing: [{
                type: Output
            }], onResourceUnassigned: [{
                type: Output
            }], onResourceUnassigning: [{
                type: Output
            }], onScaleCellPrepared: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onTaskClick: [{
                type: Output
            }], onTaskDblClick: [{
                type: Output
            }], onTaskDeleted: [{
                type: Output
            }], onTaskDeleting: [{
                type: Output
            }], onTaskEditDialogShowing: [{
                type: Output
            }], onTaskInserted: [{
                type: Output
            }], onTaskInserting: [{
                type: Output
            }], onTaskMoving: [{
                type: Output
            }], onTaskUpdated: [{
                type: Output
            }], onTaskUpdating: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowSelectionChange: [{
                type: Output
            }], columnsChange: [{
                type: Output
            }], contextMenuChange: [{
                type: Output
            }], dependenciesChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], endDateRangeChange: [{
                type: Output
            }], filterRowChange: [{
                type: Output
            }], firstDayOfWeekChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], headerFilterChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], resourceAssignmentsChange: [{
                type: Output
            }], resourcesChange: [{
                type: Output
            }], rootValueChange: [{
                type: Output
            }], scaleTypeChange: [{
                type: Output
            }], scaleTypeRangeChange: [{
                type: Output
            }], selectedRowKeyChange: [{
                type: Output
            }], showDependenciesChange: [{
                type: Output
            }], showResourcesChange: [{
                type: Output
            }], showRowLinesChange: [{
                type: Output
            }], sortingChange: [{
                type: Output
            }], startDateRangeChange: [{
                type: Output
            }], stripLinesChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], taskContentTemplateChange: [{
                type: Output
            }], taskListWidthChange: [{
                type: Output
            }], taskProgressTooltipContentTemplateChange: [{
                type: Output
            }], tasksChange: [{
                type: Output
            }], taskTimeTooltipContentTemplateChange: [{
                type: Output
            }], taskTitlePositionChange: [{
                type: Output
            }], taskTooltipContentTemplateChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], validationChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], columnsChildren: [{
                type: ContentChildren,
                args: [DxiColumnComponent]
            }], stripLinesChildren: [{
                type: ContentChildren,
                args: [DxiStripLineComponent]
            }] } });
export class DxGanttModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, declarations: [DxGanttComponent], imports: [DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxGanttComponent, DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, imports: [DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxIntegrationModule,
            DxTemplateModule, DxiColumnModule,
            DxoFormatModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoContextMenuModule,
            DxiItemModule,
            DxoDependenciesModule,
            DxoEditingModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoTextsModule,
            DxoResourceAssignmentsModule,
            DxoResourcesModule,
            DxoScaleTypeRangeModule,
            DxoSortingModule,
            DxiStripLineModule,
            DxoTasksModule,
            DxoToolbarModule,
            DxoValidationModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxGanttModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiColumnModule,
                        DxoFormatModule,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoContextMenuModule,
                        DxiItemModule,
                        DxoDependenciesModule,
                        DxoEditingModule,
                        DxoFilterRowModule,
                        DxoOperationDescriptionsModule,
                        DxoTextsModule,
                        DxoResourceAssignmentsModule,
                        DxoResourcesModule,
                        DxoScaleTypeRangeModule,
                        DxoSortingModule,
                        DxiStripLineModule,
                        DxoTasksModule,
                        DxoToolbarModule,
                        DxoValidationModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxGanttComponent
                    ],
                    exports: [
                        DxGanttComponent,
                        DxiColumnModule,
                        DxoFormatModule,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoContextMenuModule,
                        DxiItemModule,
                        DxoDependenciesModule,
                        DxoEditingModule,
                        DxoFilterRowModule,
                        DxoOperationDescriptionsModule,
                        DxoTextsModule,
                        DxoResourceAssignmentsModule,
                        DxoResourcesModule,
                        DxoScaleTypeRangeModule,
                        DxoSortingModule,
                        DxiStripLineModule,
                        DxoTasksModule,
                        DxoToolbarModule,
                        DxoValidationModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL2dhbnR0L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsb0NBQW9DO0FBR3BDLE9BQU8sRUFDSCxhQUFhLEVBQ2IsU0FBUyxFQUNULFFBQVEsRUFDUixVQUFVLEVBQ1YsTUFBTSxFQUNOLFdBQVcsRUFDWCxNQUFNLEVBRU4sS0FBSyxFQUNMLE1BQU0sRUFFTixZQUFZLEVBSVosZUFBZSxFQUNmLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQVF2QixPQUFPLE9BQU8sTUFBTSxxQkFBcUIsQ0FBQztBQUcxQyxPQUFPLEVBQ0gsV0FBVyxFQUNYLGNBQWMsRUFDZCxtQkFBbUIsRUFDbkIsZ0JBQWdCLEVBQ2hCLGdCQUFnQixFQUNoQixvQkFBb0IsRUFDcEIsYUFBYSxFQUNoQixNQUFNLHlCQUF5QixDQUFDO0FBRWpDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDckUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3BFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNyRSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsOEJBQThCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDOUQsT0FBTyxFQUFFLDRCQUE0QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDNUUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDdkUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzlELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBRW5FLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDOzs7QUFJckU7OztHQUdHO0FBV0gsTUFBTSxPQUFPLGdCQUFpQixTQUFRLFdBQVc7SUFxa0M3QjtJQUNBO0lBcmtDaEIsUUFBUSxHQUFZLElBQUksQ0FBQztJQUV6Qjs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQXlCO1FBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGtCQUFrQjtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsSUFBSSxrQkFBa0IsQ0FBQyxLQUFjO1FBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFjO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBb0M7UUFDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBeUI7UUFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBa087UUFDL08sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYztRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUEyVDtRQUNuVSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFVO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQVc7UUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBdUI7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFpQztRQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBMEI7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksTUFBTTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBNkM7UUFDcEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksSUFBSTtRQUNKLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBeUI7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksaUJBQWlCO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDRCxJQUFJLGlCQUFpQixDQUFDLEtBQWM7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxtQkFBbUI7UUFDbkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELElBQUksbUJBQW1CLENBQUMsS0FBNEw7UUFDaE4sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFxTDtRQUMvTCxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFVO1FBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQXFCO1FBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBcUQ7UUFDcEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQXNCO1FBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksZ0JBQWdCO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQWM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFjO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQWM7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBcUI7UUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFXO1FBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBOEI7UUFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxtQkFBbUI7UUFDbkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELElBQUksbUJBQW1CLENBQUMsS0FBVTtRQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGFBQWE7UUFDYixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksYUFBYSxDQUFDLEtBQWE7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0NBQWtDO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFDRCxJQUFJLGtDQUFrQyxDQUFDLEtBQVU7UUFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQ0FBb0MsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFzVDtRQUM1VCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSw4QkFBOEI7UUFDOUIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdDQUFnQyxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQUksOEJBQThCLENBQUMsS0FBVTtRQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUE2QjtRQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLDBCQUEwQjtRQUMxQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBSSwwQkFBMEIsQ0FBQyxLQUFVO1FBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBcUI7UUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBMEc7UUFDckgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBYztRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUE2QztRQUNuRCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7OztPQUtHO0lBQ08sc0JBQXNCLENBQTBDO0lBRTFFOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLG1CQUFtQixDQUF1QztJQUVwRTs7Ozs7T0FLRztJQUNPLG9CQUFvQixDQUF3QztJQUV0RTs7Ozs7T0FLRztJQUNPLG9CQUFvQixDQUF3QztJQUV0RTs7Ozs7T0FLRztJQUNPLHFCQUFxQixDQUF5QztJQUV4RTs7Ozs7T0FLRztJQUNPLFdBQVcsQ0FBK0I7SUFFcEQ7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7Ozs7T0FLRztJQUNPLG1CQUFtQixDQUF1QztJQUVwRTs7Ozs7T0FLRztJQUNPLGlCQUFpQixDQUFxQztJQUVoRTs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7Ozs7T0FLRztJQUNPLG1CQUFtQixDQUF1QztJQUVwRTs7Ozs7T0FLRztJQUNPLDhCQUE4QixDQUFrRDtJQUUxRjs7Ozs7T0FLRztJQUNPLG9CQUFvQixDQUF3QztJQUV0RTs7Ozs7T0FLRztJQUNPLHFCQUFxQixDQUF5QztJQUV4RTs7Ozs7T0FLRztJQUNPLG1CQUFtQixDQUF1QztJQUVwRTs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7Ozs7T0FLRztJQUNPLFdBQVcsQ0FBK0I7SUFFcEQ7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7OztPQUtHO0lBQ08sYUFBYSxDQUFpQztJQUV4RDs7Ozs7T0FLRztJQUNPLGNBQWMsQ0FBa0M7SUFFMUQ7Ozs7O09BS0c7SUFDTyx1QkFBdUIsQ0FBMkM7SUFFNUU7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLFlBQVksQ0FBZ0M7SUFFdEQ7Ozs7O09BS0c7SUFDTyxhQUFhLENBQWlDO0lBRXhEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFrQztJQUUxRDs7OztPQUlHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7OztPQUlHO0lBQ08sd0JBQXdCLENBQXdCO0lBRTFEOzs7O09BSUc7SUFDTyxvQkFBb0IsQ0FBd0I7SUFFdEQ7Ozs7T0FJRztJQUNPLGFBQWEsQ0FBOEM7SUFFckU7Ozs7T0FJRztJQUNPLGlCQUFpQixDQUFtQztJQUU5RDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQTRPO0lBRXhROzs7O09BSUc7SUFDTyxjQUFjLENBQXdCO0lBRWhEOzs7O09BSUc7SUFDTyxhQUFhLENBQXFVO0lBRTVWOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBb0I7SUFFL0M7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFxQjtJQUVqRDs7OztPQUlHO0lBQ08sZUFBZSxDQUFpQztJQUUxRDs7OztPQUlHO0lBQ08sb0JBQW9CLENBQTJDO0lBRXpFOzs7O09BSUc7SUFDTyx1QkFBdUIsQ0FBd0I7SUFFekQ7Ozs7T0FJRztJQUNPLGtCQUFrQixDQUFvQztJQUVoRTs7OztPQUlHO0lBQ08sWUFBWSxDQUF1RDtJQUU3RTs7OztPQUlHO0lBQ08sVUFBVSxDQUFtQztJQUV2RDs7OztPQUlHO0lBQ08sdUJBQXVCLENBQXdCO0lBRXpEOzs7O09BSUc7SUFDTyx5QkFBeUIsQ0FBc007SUFFek87Ozs7T0FJRztJQUNPLGVBQWUsQ0FBK0w7SUFFeE47Ozs7T0FJRztJQUNPLGVBQWUsQ0FBb0I7SUFFN0M7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBK0I7SUFFeEQ7Ozs7T0FJRztJQUNPLG9CQUFvQixDQUErRDtJQUU3Rjs7OztPQUlHO0lBQ08sb0JBQW9CLENBQWdDO0lBRTlEOzs7O09BSUc7SUFDTyxzQkFBc0IsQ0FBd0I7SUFFeEQ7Ozs7T0FJRztJQUNPLG1CQUFtQixDQUF3QjtJQUVyRDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXdCO0lBRXBEOzs7O09BSUc7SUFDTyxhQUFhLENBQStCO0lBRXREOzs7O09BSUc7SUFDTyxvQkFBb0IsQ0FBcUI7SUFFbkQ7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF3QztJQUVsRTs7OztPQUlHO0lBQ08sY0FBYyxDQUF1QjtJQUUvQzs7OztPQUlHO0lBQ08seUJBQXlCLENBQW9CO0lBRXZEOzs7O09BSUc7SUFDTyxtQkFBbUIsQ0FBdUI7SUFFcEQ7Ozs7T0FJRztJQUNPLHdDQUF3QyxDQUFvQjtJQUV0RTs7OztPQUlHO0lBQ08sV0FBVyxDQUFnVTtJQUVyVjs7OztPQUlHO0lBQ08sb0NBQW9DLENBQW9CO0lBRWxFOzs7O09BSUc7SUFDTyx1QkFBdUIsQ0FBdUM7SUFFeEU7Ozs7T0FJRztJQUNPLGdDQUFnQyxDQUFvQjtJQUU5RDs7OztPQUlHO0lBQ08sYUFBYSxDQUErQjtJQUV0RDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQW9IO0lBRTlJOzs7O09BSUc7SUFDTyxhQUFhLENBQXdCO0lBRS9DOzs7O09BSUc7SUFDTyxXQUFXLENBQXVEO0lBSzVFLElBQ0ksZUFBZTtRQUNmLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBSztRQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsSUFDSSxrQkFBa0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQUs7UUFDeEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUtELFlBQVksVUFBc0IsRUFBRSxNQUFjLEVBQUUsWUFBNEIsRUFDaEUsY0FBNkIsRUFDN0IsSUFBMEIsRUFDbEMsVUFBNEIsRUFDNUIsYUFBNEIsRUFDUCxVQUFlO1FBRXhDLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBTnZFLG1CQUFjLEdBQWQsY0FBYyxDQUFlO1FBQzdCLFNBQUksR0FBSixJQUFJLENBQXNCO1FBT3RDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUN0QixFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsU0FBUyxFQUFFLHNCQUFzQixFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRTtZQUNyRSxFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvRCxFQUFFLFNBQVMsRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDakUsRUFBRSxTQUFTLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2pFLEVBQUUsU0FBUyxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNuRSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNuRCxFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM3RCxFQUFFLFNBQVMsRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0QsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzNELEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM3RCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxTQUFTLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9ELEVBQUUsU0FBUyxFQUFFLDhCQUE4QixFQUFFLElBQUksRUFBRSxnQ0FBZ0MsRUFBRTtZQUNyRixFQUFFLFNBQVMsRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDakUsRUFBRSxTQUFTLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ25FLEVBQUUsU0FBUyxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvRCxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDN0QsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDL0MsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUNyRCxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNuRCxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsU0FBUyxFQUFFLHVCQUF1QixFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUN2RSxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ3JELEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDdkQsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDakQsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDbkQsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUNyRCxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSwwQkFBMEIsRUFBRTtZQUNwQyxFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRTtZQUNoQyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDMUIsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFO1lBQ25DLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUN4QixFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7WUFDdEIsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsMkJBQTJCLEVBQUU7WUFDckMsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDbEMsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDL0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDOUIsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLDJCQUEyQixFQUFFO1lBQ3JDLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9CLEVBQUUsSUFBSSxFQUFFLDBDQUEwQyxFQUFFO1lBQ3BELEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxzQ0FBc0MsRUFBRTtZQUNoRCxFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUNuQyxFQUFFLElBQUksRUFBRSxrQ0FBa0MsRUFBRTtZQUM1QyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtTQUMxQixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFUyxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU87UUFFdEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdELFdBQVc7UUFDUCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBWSxFQUFFLE9BQXNCO1FBQzdDLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDbEM7SUFDTCxDQUFDO0lBRUQsU0FBUztRQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDcEMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2xCLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxVQUFVLENBQUMsSUFBWSxFQUFFLEtBQVU7UUFDL0IsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUM7UUFFM0QsSUFBSSxPQUFPLElBQUksU0FBUyxFQUFFO1lBQ3RCLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQzsySEFqc0NRLGdCQUFnQiw4TkF5a0NULFdBQVc7K0dBemtDbEIsZ0JBQWdCLDh2SUFQZDtZQUNQLGNBQWM7WUFDZCxhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtTQUN2QiwwREFtakNnQixrQkFBa0IscURBUWxCLHFCQUFxQix5RUFqa0M1QixFQUFFOzs0RkFRSCxnQkFBZ0I7a0JBVjVCLFNBQVM7bUJBQUM7b0JBQ1AsUUFBUSxFQUFFLFVBQVU7b0JBQ3BCLFFBQVEsRUFBRSxFQUFFO29CQUNaLFNBQVMsRUFBRTt3QkFDUCxjQUFjO3dCQUNkLGFBQWE7d0JBQ2IsZ0JBQWdCO3dCQUNoQixvQkFBb0I7cUJBQ3ZCO2lCQUNKOzswQkEwa0NZLE1BQU07MkJBQUMsV0FBVzs0Q0Fqa0N2QixTQUFTO3NCQURaLEtBQUs7Z0JBY0Ysa0JBQWtCO3NCQURyQixLQUFLO2dCQWNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLFdBQVc7c0JBRGQsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLE9BQU87c0JBRFYsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixjQUFjO3NCQURqQixLQUFLO2dCQWNGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0YsTUFBTTtzQkFEVCxLQUFLO2dCQWNGLElBQUk7c0JBRFAsS0FBSztnQkFjRixpQkFBaUI7c0JBRHBCLEtBQUs7Z0JBY0YsbUJBQW1CO3NCQUR0QixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixTQUFTO3NCQURaLEtBQUs7Z0JBY0YsU0FBUztzQkFEWixLQUFLO2dCQWNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBY0YsY0FBYztzQkFEakIsS0FBSztnQkFjRixnQkFBZ0I7c0JBRG5CLEtBQUs7Z0JBY0YsYUFBYTtzQkFEaEIsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixtQkFBbUI7c0JBRHRCLEtBQUs7Z0JBY0YsYUFBYTtzQkFEaEIsS0FBSztnQkFjRixrQ0FBa0M7c0JBRHJDLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLDhCQUE4QjtzQkFEakMsS0FBSztnQkFjRixpQkFBaUI7c0JBRHBCLEtBQUs7Z0JBY0YsMEJBQTBCO3NCQUQ3QixLQUFLO2dCQWNGLE9BQU87c0JBRFYsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjSSxjQUFjO3NCQUF2QixNQUFNO2dCQVFHLHNCQUFzQjtzQkFBL0IsTUFBTTtnQkFRRyxlQUFlO3NCQUF4QixNQUFNO2dCQVFHLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFRRyxvQkFBb0I7c0JBQTdCLE1BQU07Z0JBUUcsb0JBQW9CO3NCQUE3QixNQUFNO2dCQVFHLHFCQUFxQjtzQkFBOUIsTUFBTTtnQkFRRyxXQUFXO3NCQUFwQixNQUFNO2dCQVFHLGFBQWE7c0JBQXRCLE1BQU07Z0JBUUcsZUFBZTtzQkFBeEIsTUFBTTtnQkFRRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBUUcsbUJBQW1CO3NCQUE1QixNQUFNO2dCQVFHLGlCQUFpQjtzQkFBMUIsTUFBTTtnQkFRRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBUUcsa0JBQWtCO3NCQUEzQixNQUFNO2dCQVFHLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFRRyw4QkFBOEI7c0JBQXZDLE1BQU07Z0JBUUcsb0JBQW9CO3NCQUE3QixNQUFNO2dCQVFHLHFCQUFxQjtzQkFBOUIsTUFBTTtnQkFRRyxtQkFBbUI7c0JBQTVCLE1BQU07Z0JBUUcsa0JBQWtCO3NCQUEzQixNQUFNO2dCQVFHLFdBQVc7c0JBQXBCLE1BQU07Z0JBUUcsY0FBYztzQkFBdkIsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBUUcsdUJBQXVCO3NCQUFoQyxNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBUUcsZUFBZTtzQkFBeEIsTUFBTTtnQkFRRyxZQUFZO3NCQUFyQixNQUFNO2dCQVFHLGFBQWE7c0JBQXRCLE1BQU07Z0JBUUcsY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxlQUFlO3NCQUF4QixNQUFNO2dCQU9HLHdCQUF3QjtzQkFBakMsTUFBTTtnQkFPRyxvQkFBb0I7c0JBQTdCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQU9HLHVCQUF1QjtzQkFBaEMsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU9HLHVCQUF1QjtzQkFBaEMsTUFBTTtnQkFPRyx5QkFBeUI7c0JBQWxDLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyxlQUFlO3NCQUF4QixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQU9HLG9CQUFvQjtzQkFBN0IsTUFBTTtnQkFPRyxzQkFBc0I7c0JBQS9CLE1BQU07Z0JBT0csbUJBQW1CO3NCQUE1QixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxhQUFhO3NCQUF0QixNQUFNO2dCQU9HLG9CQUFvQjtzQkFBN0IsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyx5QkFBeUI7c0JBQWxDLE1BQU07Z0JBT0csbUJBQW1CO3NCQUE1QixNQUFNO2dCQU9HLHdDQUF3QztzQkFBakQsTUFBTTtnQkFPRyxXQUFXO3NCQUFwQixNQUFNO2dCQU9HLG9DQUFvQztzQkFBN0MsTUFBTTtnQkFPRyx1QkFBdUI7c0JBQWhDLE1BQU07Z0JBT0csZ0NBQWdDO3NCQUF6QyxNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFNSCxlQUFlO3NCQURsQixlQUFlO3VCQUFDLGtCQUFrQjtnQkFTL0Isa0JBQWtCO3NCQURyQixlQUFlO3VCQUFDLHFCQUFxQjs7QUE4TDFDLE1BQU0sT0FBTyxhQUFhOzJIQUFiLGFBQWE7NEhBQWIsYUFBYSxpQkF2dkNiLGdCQUFnQixhQXNzQ3pCLGVBQWU7WUFDZixlQUFlO1lBQ2YscUJBQXFCO1lBQ3JCLGVBQWU7WUFDZixvQkFBb0I7WUFDcEIsYUFBYTtZQUNiLHFCQUFxQjtZQUNyQixnQkFBZ0I7WUFDaEIsa0JBQWtCO1lBQ2xCLDhCQUE4QjtZQUM5QixjQUFjO1lBQ2QsNEJBQTRCO1lBQzVCLGtCQUFrQjtZQUNsQix1QkFBdUI7WUFDdkIsZ0JBQWdCO1lBQ2hCLGtCQUFrQjtZQUNsQixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixtQkFBbUI7WUFDbkIsZ0JBQWdCLGFBMXRDUCxnQkFBZ0IsRUFpdUN6QixlQUFlO1lBQ2YsZUFBZTtZQUNmLHFCQUFxQjtZQUNyQixlQUFlO1lBQ2Ysb0JBQW9CO1lBQ3BCLGFBQWE7WUFDYixxQkFBcUI7WUFDckIsZ0JBQWdCO1lBQ2hCLGtCQUFrQjtZQUNsQiw4QkFBOEI7WUFDOUIsY0FBYztZQUNkLDRCQUE0QjtZQUM1QixrQkFBa0I7WUFDbEIsdUJBQXVCO1lBQ3ZCLGdCQUFnQjtZQUNoQixrQkFBa0I7WUFDbEIsY0FBYztZQUNkLGdCQUFnQjtZQUNoQixtQkFBbUI7WUFDbkIsZ0JBQWdCOzRIQUdQLGFBQWEsWUFqRHRCLGVBQWU7WUFDZixlQUFlO1lBQ2YscUJBQXFCO1lBQ3JCLGVBQWU7WUFDZixvQkFBb0I7WUFDcEIsYUFBYTtZQUNiLHFCQUFxQjtZQUNyQixnQkFBZ0I7WUFDaEIsa0JBQWtCO1lBQ2xCLDhCQUE4QjtZQUM5QixjQUFjO1lBQ2QsNEJBQTRCO1lBQzVCLGtCQUFrQjtZQUNsQix1QkFBdUI7WUFDdkIsZ0JBQWdCO1lBQ2hCLGtCQUFrQjtZQUNsQixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixtQkFBbUI7WUFDbkIsZ0JBQWdCLEVBT2hCLGVBQWU7WUFDZixlQUFlO1lBQ2YscUJBQXFCO1lBQ3JCLGVBQWU7WUFDZixvQkFBb0I7WUFDcEIsYUFBYTtZQUNiLHFCQUFxQjtZQUNyQixnQkFBZ0I7WUFDaEIsa0JBQWtCO1lBQ2xCLDhCQUE4QjtZQUM5QixjQUFjO1lBQ2QsNEJBQTRCO1lBQzVCLGtCQUFrQjtZQUNsQix1QkFBdUI7WUFDdkIsZ0JBQWdCO1lBQ2hCLGtCQUFrQjtZQUNsQixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixnQkFBZ0I7OzRGQUdQLGFBQWE7a0JBbkR6QixRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRTt3QkFDUCxlQUFlO3dCQUNmLGVBQWU7d0JBQ2YscUJBQXFCO3dCQUNyQixlQUFlO3dCQUNmLG9CQUFvQjt3QkFDcEIsYUFBYTt3QkFDYixxQkFBcUI7d0JBQ3JCLGdCQUFnQjt3QkFDaEIsa0JBQWtCO3dCQUNsQiw4QkFBOEI7d0JBQzlCLGNBQWM7d0JBQ2QsNEJBQTRCO3dCQUM1QixrQkFBa0I7d0JBQ2xCLHVCQUF1Qjt3QkFDdkIsZ0JBQWdCO3dCQUNoQixrQkFBa0I7d0JBQ2xCLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixtQkFBbUI7d0JBQ25CLG1CQUFtQjt3QkFDbkIsZ0JBQWdCO3FCQUNqQjtvQkFDRCxZQUFZLEVBQUU7d0JBQ1osZ0JBQWdCO3FCQUNqQjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsZ0JBQWdCO3dCQUNoQixlQUFlO3dCQUNmLGVBQWU7d0JBQ2YscUJBQXFCO3dCQUNyQixlQUFlO3dCQUNmLG9CQUFvQjt3QkFDcEIsYUFBYTt3QkFDYixxQkFBcUI7d0JBQ3JCLGdCQUFnQjt3QkFDaEIsa0JBQWtCO3dCQUNsQiw4QkFBOEI7d0JBQzlCLGNBQWM7d0JBQ2QsNEJBQTRCO3dCQUM1QixrQkFBa0I7d0JBQ2xCLHVCQUF1Qjt3QkFDdkIsZ0JBQWdCO3dCQUNoQixrQkFBa0I7d0JBQ2xCLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixtQkFBbUI7d0JBQ25CLGdCQUFnQjtxQkFDakI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cblxuaW1wb3J0IHtcbiAgICBUcmFuc2ZlclN0YXRlLFxuICAgIENvbXBvbmVudCxcbiAgICBOZ01vZHVsZSxcbiAgICBFbGVtZW50UmVmLFxuICAgIE5nWm9uZSxcbiAgICBQTEFURk9STV9JRCxcbiAgICBJbmplY3QsXG5cbiAgICBJbnB1dCxcbiAgICBPdXRwdXQsXG4gICAgT25EZXN0cm95LFxuICAgIEV2ZW50RW1pdHRlcixcbiAgICBPbkNoYW5nZXMsXG4gICAgRG9DaGVjayxcbiAgICBTaW1wbGVDaGFuZ2VzLFxuICAgIENvbnRlbnRDaGlsZHJlbixcbiAgICBRdWVyeUxpc3Rcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuaW1wb3J0IHsgRmlyc3REYXlPZldlZWsgfSBmcm9tICdkZXZleHRyZW1lL2NvbW1vbic7XG5pbXBvcnQgeyBTdG9yZSB9IGZyb20gJ2RldmV4dHJlbWUvZGF0YSc7XG5pbXBvcnQgRGF0YVNvdXJjZSwgeyBPcHRpb25zIGFzIERhdGFTb3VyY2VPcHRpb25zIH0gZnJvbSAnZGV2ZXh0cmVtZS9kYXRhL2RhdGFfc291cmNlJztcbmltcG9ydCB7IENvbnRlbnRSZWFkeUV2ZW50LCBDb250ZXh0TWVudVByZXBhcmluZ0V2ZW50LCBDdXN0b21Db21tYW5kRXZlbnQsIERlcGVuZGVuY3lEZWxldGVkRXZlbnQsIERlcGVuZGVuY3lEZWxldGluZ0V2ZW50LCBEZXBlbmRlbmN5SW5zZXJ0ZWRFdmVudCwgRGVwZW5kZW5jeUluc2VydGluZ0V2ZW50LCBEaXNwb3NpbmdFdmVudCwgZHhHYW50dENvbHVtbiwgZHhHYW50dENvbnRleHRNZW51LCBkeEdhbnR0RmlsdGVyUm93LCBkeEdhbnR0SGVhZGVyRmlsdGVyLCBkeEdhbnR0U29ydGluZywgZHhHYW50dFN0cmlwTGluZSwgZHhHYW50dFRvb2xiYXIsIEdhbnR0U2NhbGVUeXBlLCBHYW50dFRhc2tUaXRsZVBvc2l0aW9uLCBJbml0aWFsaXplZEV2ZW50LCBPcHRpb25DaGFuZ2VkRXZlbnQsIFJlc291cmNlQXNzaWduZWRFdmVudCwgUmVzb3VyY2VBc3NpZ25pbmdFdmVudCwgUmVzb3VyY2VEZWxldGVkRXZlbnQsIFJlc291cmNlRGVsZXRpbmdFdmVudCwgUmVzb3VyY2VJbnNlcnRlZEV2ZW50LCBSZXNvdXJjZUluc2VydGluZ0V2ZW50LCBSZXNvdXJjZU1hbmFnZXJEaWFsb2dTaG93aW5nRXZlbnQsIFJlc291cmNlVW5hc3NpZ25lZEV2ZW50LCBSZXNvdXJjZVVuYXNzaWduaW5nRXZlbnQsIFNjYWxlQ2VsbFByZXBhcmVkRXZlbnQsIFNlbGVjdGlvbkNoYW5nZWRFdmVudCwgVGFza0NsaWNrRXZlbnQsIFRhc2tEYmxDbGlja0V2ZW50LCBUYXNrRGVsZXRlZEV2ZW50LCBUYXNrRGVsZXRpbmdFdmVudCwgVGFza0VkaXREaWFsb2dTaG93aW5nRXZlbnQsIFRhc2tJbnNlcnRlZEV2ZW50LCBUYXNrSW5zZXJ0aW5nRXZlbnQsIFRhc2tNb3ZpbmdFdmVudCwgVGFza1VwZGF0ZWRFdmVudCwgVGFza1VwZGF0aW5nRXZlbnQgfSBmcm9tICdkZXZleHRyZW1lL3VpL2dhbnR0JztcblxuaW1wb3J0IER4R2FudHQgZnJvbSAnZGV2ZXh0cmVtZS91aS9nYW50dCc7XG5cblxuaW1wb3J0IHtcbiAgICBEeENvbXBvbmVudCxcbiAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGUsXG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICBJdGVyYWJsZURpZmZlckhlbHBlcixcbiAgICBXYXRjaGVySGVscGVyXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRHhpQ29sdW1uTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Gb3JtYXRNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0hlYWRlckZpbHRlck1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2VhcmNoTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Db250ZXh0TWVudU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpSXRlbU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvRGVwZW5kZW5jaWVzTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9FZGl0aW5nTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9GaWx0ZXJSb3dNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b09wZXJhdGlvbkRlc2NyaXB0aW9uc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVGV4dHNNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Jlc291cmNlQXNzaWdubWVudHNNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Jlc291cmNlc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2NhbGVUeXBlUmFuZ2VNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1NvcnRpbmdNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aVN0cmlwTGluZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVGFza3NNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Rvb2xiYXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1ZhbGlkYXRpb25Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcblxuaW1wb3J0IHsgRHhpQ29sdW1uQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlTdHJpcExpbmVDb21wb25lbnQgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcblxuXG5cbi8qKlxuICogW2Rlc2NyOmR4R2FudHRdXG5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdkeC1nYW50dCcsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgV2F0Y2hlckhlbHBlcixcbiAgICAgICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4R2FudHRDb21wb25lbnQgZXh0ZW5kcyBEeENvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveSwgT25DaGFuZ2VzLCBEb0NoZWNrIHtcbiAgICBpbnN0YW5jZTogRHhHYW50dCA9IG51bGw7XG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5hY2Nlc3NLZXldXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYWNjZXNzS2V5KCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2FjY2Vzc0tleScpO1xuICAgIH1cbiAgICBzZXQgYWNjZXNzS2V5KHZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhY2Nlc3NLZXknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5hY3RpdmVTdGF0ZUVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYWN0aXZlU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhY3RpdmVTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGFjdGl2ZVN0YXRlRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjdGl2ZVN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5hbGxvd1NlbGVjdGlvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBhbGxvd1NlbGVjdGlvbigpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWxsb3dTZWxlY3Rpb24nKTtcbiAgICB9XG4gICAgc2V0IGFsbG93U2VsZWN0aW9uKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYWxsb3dTZWxlY3Rpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuY29sdW1uc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBjb2x1bW5zKCk6IEFycmF5PGR4R2FudHRDb2x1bW4gfCBzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY29sdW1ucycpO1xuICAgIH1cbiAgICBzZXQgY29sdW1ucyh2YWx1ZTogQXJyYXk8ZHhHYW50dENvbHVtbiB8IHN0cmluZz4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjb2x1bW5zJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLmNvbnRleHRNZW51XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGNvbnRleHRNZW51KCk6IGR4R2FudHRDb250ZXh0TWVudSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbnRleHRNZW51Jyk7XG4gICAgfVxuICAgIHNldCBjb250ZXh0TWVudSh2YWx1ZTogZHhHYW50dENvbnRleHRNZW51KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignY29udGV4dE1lbnUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuZGVwZW5kZW5jaWVzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRlcGVuZGVuY2llcygpOiB7IGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHByZWRlY2Vzc29ySWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHN1Y2Nlc3NvcklkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0eXBlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkZXBlbmRlbmNpZXMnKTtcbiAgICB9XG4gICAgc2V0IGRlcGVuZGVuY2llcyh2YWx1ZTogeyBkYXRhU291cmNlPzogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8YW55Piwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwcmVkZWNlc3NvcklkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdWNjZXNzb3JJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGVwZW5kZW5jaWVzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMuZGlzYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Rpc2FibGVkJyk7XG4gICAgfVxuICAgIHNldCBkaXNhYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Rpc2FibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLmVkaXRpbmddXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZWRpdGluZygpOiB7IGFsbG93RGVwZW5kZW5jeUFkZGluZz86IGJvb2xlYW4sIGFsbG93RGVwZW5kZW5jeURlbGV0aW5nPzogYm9vbGVhbiwgYWxsb3dSZXNvdXJjZUFkZGluZz86IGJvb2xlYW4sIGFsbG93UmVzb3VyY2VEZWxldGluZz86IGJvb2xlYW4sIGFsbG93UmVzb3VyY2VVcGRhdGluZz86IGJvb2xlYW4sIGFsbG93VGFza0FkZGluZz86IGJvb2xlYW4sIGFsbG93VGFza0RlbGV0aW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrUmVzb3VyY2VVcGRhdGluZz86IGJvb2xlYW4sIGFsbG93VGFza1VwZGF0aW5nPzogYm9vbGVhbiwgZW5hYmxlZD86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VkaXRpbmcnKTtcbiAgICB9XG4gICAgc2V0IGVkaXRpbmcodmFsdWU6IHsgYWxsb3dEZXBlbmRlbmN5QWRkaW5nPzogYm9vbGVhbiwgYWxsb3dEZXBlbmRlbmN5RGVsZXRpbmc/OiBib29sZWFuLCBhbGxvd1Jlc291cmNlQWRkaW5nPzogYm9vbGVhbiwgYWxsb3dSZXNvdXJjZURlbGV0aW5nPzogYm9vbGVhbiwgYWxsb3dSZXNvdXJjZVVwZGF0aW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrQWRkaW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrRGVsZXRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tSZXNvdXJjZVVwZGF0aW5nPzogYm9vbGVhbiwgYWxsb3dUYXNrVXBkYXRpbmc/OiBib29sZWFuLCBlbmFibGVkPzogYm9vbGVhbiB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZWRpdGluZycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnRPcHRpb25zLmVsZW1lbnRBdHRyXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGVsZW1lbnRBdHRyKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VsZW1lbnRBdHRyJyk7XG4gICAgfVxuICAgIHNldCBlbGVtZW50QXR0cih2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZWxlbWVudEF0dHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuZW5kRGF0ZVJhbmdlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGVuZERhdGVSYW5nZSgpOiBEYXRlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZW5kRGF0ZVJhbmdlJyk7XG4gICAgfVxuICAgIHNldCBlbmREYXRlUmFuZ2UodmFsdWU6IERhdGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbmREYXRlUmFuZ2UnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuZmlsdGVyUm93XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGZpbHRlclJvdygpOiBkeEdhbnR0RmlsdGVyUm93IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZmlsdGVyUm93Jyk7XG4gICAgfVxuICAgIHNldCBmaWx0ZXJSb3codmFsdWU6IGR4R2FudHRGaWx0ZXJSb3cpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdmaWx0ZXJSb3cnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuZmlyc3REYXlPZldlZWtdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZmlyc3REYXlPZldlZWsoKTogRmlyc3REYXlPZldlZWsgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdmaXJzdERheU9mV2VlaycpO1xuICAgIH1cbiAgICBzZXQgZmlyc3REYXlPZldlZWsodmFsdWU6IEZpcnN0RGF5T2ZXZWVrIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZmlyc3REYXlPZldlZWsnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5mb2N1c1N0YXRlRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBmb2N1c1N0YXRlRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGZvY3VzU3RhdGVFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZm9jdXNTdGF0ZUVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuaGVhZGVyRmlsdGVyXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhlYWRlckZpbHRlcigpOiBkeEdhbnR0SGVhZGVyRmlsdGVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGVhZGVyRmlsdGVyJyk7XG4gICAgfVxuICAgIHNldCBoZWFkZXJGaWx0ZXIodmFsdWU6IGR4R2FudHRIZWFkZXJGaWx0ZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoZWFkZXJGaWx0ZXInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5oZWlnaHRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGVpZ2h0KCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCBoZWlnaHQodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMuaGludF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBoaW50KCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hpbnQnKTtcbiAgICB9XG4gICAgc2V0IGhpbnQodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hpbnQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5ob3ZlclN0YXRlRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBob3ZlclN0YXRlRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaG92ZXJTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGhvdmVyU3RhdGVFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaG92ZXJTdGF0ZUVuYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMucmVzb3VyY2VBc3NpZ25tZW50c11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCByZXNvdXJjZUFzc2lnbm1lbnRzKCk6IHsgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcmVzb3VyY2VJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGFza0lkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyZXNvdXJjZUFzc2lnbm1lbnRzJyk7XG4gICAgfVxuICAgIHNldCByZXNvdXJjZUFzc2lnbm1lbnRzKHZhbHVlOiB7IGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHJlc291cmNlSWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRhc2tJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncmVzb3VyY2VBc3NpZ25tZW50cycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5yZXNvdXJjZXNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcmVzb3VyY2VzKCk6IHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRleHRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Jlc291cmNlcycpO1xuICAgIH1cbiAgICBzZXQgcmVzb3VyY2VzKHZhbHVlOiB7IGNvbG9yRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBkYXRhU291cmNlPzogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8YW55Piwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdyZXNvdXJjZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMucm9vdFZhbHVlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJvb3RWYWx1ZSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdyb290VmFsdWUnKTtcbiAgICB9XG4gICAgc2V0IHJvb3RWYWx1ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncm9vdFZhbHVlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLnNjYWxlVHlwZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzY2FsZVR5cGUoKTogR2FudHRTY2FsZVR5cGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzY2FsZVR5cGUnKTtcbiAgICB9XG4gICAgc2V0IHNjYWxlVHlwZSh2YWx1ZTogR2FudHRTY2FsZVR5cGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzY2FsZVR5cGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuc2NhbGVUeXBlUmFuZ2VdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2NhbGVUeXBlUmFuZ2UoKTogeyBtYXg/OiBHYW50dFNjYWxlVHlwZSwgbWluPzogR2FudHRTY2FsZVR5cGUgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NjYWxlVHlwZVJhbmdlJyk7XG4gICAgfVxuICAgIHNldCBzY2FsZVR5cGVSYW5nZSh2YWx1ZTogeyBtYXg/OiBHYW50dFNjYWxlVHlwZSwgbWluPzogR2FudHRTY2FsZVR5cGUgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NjYWxlVHlwZVJhbmdlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLnNlbGVjdGVkUm93S2V5XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNlbGVjdGVkUm93S2V5KCk6IGFueSB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NlbGVjdGVkUm93S2V5Jyk7XG4gICAgfVxuICAgIHNldCBzZWxlY3RlZFJvd0tleSh2YWx1ZTogYW55IHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2VsZWN0ZWRSb3dLZXknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuc2hvd0RlcGVuZGVuY2llc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93RGVwZW5kZW5jaWVzKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaG93RGVwZW5kZW5jaWVzJyk7XG4gICAgfVxuICAgIHNldCBzaG93RGVwZW5kZW5jaWVzKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd0RlcGVuZGVuY2llcycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5zaG93UmVzb3VyY2VzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNob3dSZXNvdXJjZXMoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Nob3dSZXNvdXJjZXMnKTtcbiAgICB9XG4gICAgc2V0IHNob3dSZXNvdXJjZXModmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzaG93UmVzb3VyY2VzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLnNob3dSb3dMaW5lc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93Um93TGluZXMoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Nob3dSb3dMaW5lcycpO1xuICAgIH1cbiAgICBzZXQgc2hvd1Jvd0xpbmVzKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd1Jvd0xpbmVzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLnNvcnRpbmddXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc29ydGluZygpOiBkeEdhbnR0U29ydGluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NvcnRpbmcnKTtcbiAgICB9XG4gICAgc2V0IHNvcnRpbmcodmFsdWU6IGR4R2FudHRTb3J0aW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc29ydGluZycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5zdGFydERhdGVSYW5nZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzdGFydERhdGVSYW5nZSgpOiBEYXRlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc3RhcnREYXRlUmFuZ2UnKTtcbiAgICB9XG4gICAgc2V0IHN0YXJ0RGF0ZVJhbmdlKHZhbHVlOiBEYXRlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc3RhcnREYXRlUmFuZ2UnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMuc3RyaXBMaW5lc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzdHJpcExpbmVzKCk6IEFycmF5PGR4R2FudHRTdHJpcExpbmU+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc3RyaXBMaW5lcycpO1xuICAgIH1cbiAgICBzZXQgc3RyaXBMaW5lcyh2YWx1ZTogQXJyYXk8ZHhHYW50dFN0cmlwTGluZT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzdHJpcExpbmVzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMudGFiSW5kZXhdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdGFiSW5kZXgoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFiSW5kZXgnKTtcbiAgICB9XG4gICAgc2V0IHRhYkluZGV4KHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0YWJJbmRleCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy50YXNrQ29udGVudFRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRhc2tDb250ZW50VGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza0NvbnRlbnRUZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgdGFza0NvbnRlbnRUZW1wbGF0ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFza0NvbnRlbnRUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy50YXNrTGlzdFdpZHRoXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRhc2tMaXN0V2lkdGgoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza0xpc3RXaWR0aCcpO1xuICAgIH1cbiAgICBzZXQgdGFza0xpc3RXaWR0aCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFza0xpc3RXaWR0aCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy50YXNrUHJvZ3Jlc3NUb29sdGlwQ29udGVudFRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRhc2tQcm9ncmVzc1Rvb2x0aXBDb250ZW50VGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza1Byb2dyZXNzVG9vbHRpcENvbnRlbnRUZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgdGFza1Byb2dyZXNzVG9vbHRpcENvbnRlbnRUZW1wbGF0ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFza1Byb2dyZXNzVG9vbHRpcENvbnRlbnRUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy50YXNrc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0YXNrcygpOiB7IGNvbG9yRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBkYXRhU291cmNlPzogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8YW55PiwgZW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHBhcmVudElkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwcm9ncmVzc0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgc3RhcnRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRpdGxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0YXNrcycpO1xuICAgIH1cbiAgICBzZXQgdGFza3ModmFsdWU6IHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBlbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcGFyZW50SWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHByb2dyZXNzRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdGFydEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGl0bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rhc2tzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLnRhc2tUaW1lVG9vbHRpcENvbnRlbnRUZW1wbGF0ZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0YXNrVGltZVRvb2x0aXBDb250ZW50VGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza1RpbWVUb29sdGlwQ29udGVudFRlbXBsYXRlJyk7XG4gICAgfVxuICAgIHNldCB0YXNrVGltZVRvb2x0aXBDb250ZW50VGVtcGxhdGUodmFsdWU6IGFueSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rhc2tUaW1lVG9vbHRpcENvbnRlbnRUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy50YXNrVGl0bGVQb3NpdGlvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0YXNrVGl0bGVQb3NpdGlvbigpOiBHYW50dFRhc2tUaXRsZVBvc2l0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza1RpdGxlUG9zaXRpb24nKTtcbiAgICB9XG4gICAgc2V0IHRhc2tUaXRsZVBvc2l0aW9uKHZhbHVlOiBHYW50dFRhc2tUaXRsZVBvc2l0aW9uKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFza1RpdGxlUG9zaXRpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMudGFza1Rvb2x0aXBDb250ZW50VGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdGFza1Rvb2x0aXBDb250ZW50VGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGFza1Rvb2x0aXBDb250ZW50VGVtcGxhdGUnKTtcbiAgICB9XG4gICAgc2V0IHRhc2tUb29sdGlwQ29udGVudFRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd0YXNrVG9vbHRpcENvbnRlbnRUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy50b29sYmFyXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRvb2xiYXIoKTogZHhHYW50dFRvb2xiYXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0b29sYmFyJyk7XG4gICAgfVxuICAgIHNldCB0b29sYmFyKHZhbHVlOiBkeEdhbnR0VG9vbGJhcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Rvb2xiYXInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMudmFsaWRhdGlvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB2YWxpZGF0aW9uKCk6IHsgYXV0b1VwZGF0ZVBhcmVudFRhc2tzPzogYm9vbGVhbiwgZW5hYmxlUHJlZGVjZXNzb3JHYXA/OiBib29sZWFuLCB2YWxpZGF0ZURlcGVuZGVuY2llcz86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbGlkYXRpb24nKTtcbiAgICB9XG4gICAgc2V0IHZhbGlkYXRpb24odmFsdWU6IHsgYXV0b1VwZGF0ZVBhcmVudFRhc2tzPzogYm9vbGVhbiwgZW5hYmxlUHJlZGVjZXNzb3JHYXA/OiBib29sZWFuLCB2YWxpZGF0ZURlcGVuZGVuY2llcz86IGJvb2xlYW4gfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3ZhbGlkYXRpb24nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy52aXNpYmxlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHZpc2libGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Zpc2libGUnKTtcbiAgICB9XG4gICAgc2V0IHZpc2libGUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2aXNpYmxlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMud2lkdGhdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgd2lkdGgoKTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd3aWR0aCcpO1xuICAgIH1cbiAgICBzZXQgd2lkdGgodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignd2lkdGgnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uQ29udGVudFJlYWR5XVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkNvbnRlbnRSZWFkeTogRXZlbnRFbWl0dGVyPENvbnRlbnRSZWFkeUV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vbkNvbnRleHRNZW51UHJlcGFyaW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkNvbnRleHRNZW51UHJlcGFyaW5nOiBFdmVudEVtaXR0ZXI8Q29udGV4dE1lbnVQcmVwYXJpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25DdXN0b21Db21tYW5kXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkN1c3RvbUNvbW1hbmQ6IEV2ZW50RW1pdHRlcjxDdXN0b21Db21tYW5kRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uRGVwZW5kZW5jeURlbGV0ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRGVwZW5kZW5jeURlbGV0ZWQ6IEV2ZW50RW1pdHRlcjxEZXBlbmRlbmN5RGVsZXRlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vbkRlcGVuZGVuY3lEZWxldGluZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25EZXBlbmRlbmN5RGVsZXRpbmc6IEV2ZW50RW1pdHRlcjxEZXBlbmRlbmN5RGVsZXRpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25EZXBlbmRlbmN5SW5zZXJ0ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRGVwZW5kZW5jeUluc2VydGVkOiBFdmVudEVtaXR0ZXI8RGVwZW5kZW5jeUluc2VydGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uRGVwZW5kZW5jeUluc2VydGluZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25EZXBlbmRlbmN5SW5zZXJ0aW5nOiBFdmVudEVtaXR0ZXI8RGVwZW5kZW5jeUluc2VydGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vbkRpc3Bvc2luZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25EaXNwb3Npbmc6IEV2ZW50RW1pdHRlcjxEaXNwb3NpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25Jbml0aWFsaXplZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25Jbml0aWFsaXplZDogRXZlbnRFbWl0dGVyPEluaXRpYWxpemVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uT3B0aW9uQ2hhbmdlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25PcHRpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8T3B0aW9uQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblJlc291cmNlQXNzaWduZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VBc3NpZ25lZDogRXZlbnRFbWl0dGVyPFJlc291cmNlQXNzaWduZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25SZXNvdXJjZUFzc2lnbmluZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25SZXNvdXJjZUFzc2lnbmluZzogRXZlbnRFbWl0dGVyPFJlc291cmNlQXNzaWduaW5nRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uUmVzb3VyY2VEZWxldGVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblJlc291cmNlRGVsZXRlZDogRXZlbnRFbWl0dGVyPFJlc291cmNlRGVsZXRlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblJlc291cmNlRGVsZXRpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VEZWxldGluZzogRXZlbnRFbWl0dGVyPFJlc291cmNlRGVsZXRpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25SZXNvdXJjZUluc2VydGVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblJlc291cmNlSW5zZXJ0ZWQ6IEV2ZW50RW1pdHRlcjxSZXNvdXJjZUluc2VydGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uUmVzb3VyY2VJbnNlcnRpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VJbnNlcnRpbmc6IEV2ZW50RW1pdHRlcjxSZXNvdXJjZUluc2VydGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblJlc291cmNlTWFuYWdlckRpYWxvZ1Nob3dpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VNYW5hZ2VyRGlhbG9nU2hvd2luZzogRXZlbnRFbWl0dGVyPFJlc291cmNlTWFuYWdlckRpYWxvZ1Nob3dpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25SZXNvdXJjZVVuYXNzaWduZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVzb3VyY2VVbmFzc2lnbmVkOiBFdmVudEVtaXR0ZXI8UmVzb3VyY2VVbmFzc2lnbmVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uUmVzb3VyY2VVbmFzc2lnbmluZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25SZXNvdXJjZVVuYXNzaWduaW5nOiBFdmVudEVtaXR0ZXI8UmVzb3VyY2VVbmFzc2lnbmluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblNjYWxlQ2VsbFByZXBhcmVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblNjYWxlQ2VsbFByZXBhcmVkOiBFdmVudEVtaXR0ZXI8U2NhbGVDZWxsUHJlcGFyZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25TZWxlY3Rpb25DaGFuZ2VkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblNlbGVjdGlvbkNoYW5nZWQ6IEV2ZW50RW1pdHRlcjxTZWxlY3Rpb25DaGFuZ2VkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uVGFza0NsaWNrXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblRhc2tDbGljazogRXZlbnRFbWl0dGVyPFRhc2tDbGlja0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblRhc2tEYmxDbGlja11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25UYXNrRGJsQ2xpY2s6IEV2ZW50RW1pdHRlcjxUYXNrRGJsQ2xpY2tFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25UYXNrRGVsZXRlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25UYXNrRGVsZXRlZDogRXZlbnRFbWl0dGVyPFRhc2tEZWxldGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uVGFza0RlbGV0aW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblRhc2tEZWxldGluZzogRXZlbnRFbWl0dGVyPFRhc2tEZWxldGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblRhc2tFZGl0RGlhbG9nU2hvd2luZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25UYXNrRWRpdERpYWxvZ1Nob3dpbmc6IEV2ZW50RW1pdHRlcjxUYXNrRWRpdERpYWxvZ1Nob3dpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25UYXNrSW5zZXJ0ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uVGFza0luc2VydGVkOiBFdmVudEVtaXR0ZXI8VGFza0luc2VydGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uVGFza0luc2VydGluZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25UYXNrSW5zZXJ0aW5nOiBFdmVudEVtaXR0ZXI8VGFza0luc2VydGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeEdhbnR0T3B0aW9ucy5vblRhc2tNb3ZpbmddXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uVGFza01vdmluZzogRXZlbnRFbWl0dGVyPFRhc2tNb3ZpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhHYW50dE9wdGlvbnMub25UYXNrVXBkYXRlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25UYXNrVXBkYXRlZDogRXZlbnRFbWl0dGVyPFRhc2tVcGRhdGVkRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4R2FudHRPcHRpb25zLm9uVGFza1VwZGF0aW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblRhc2tVcGRhdGluZzogRXZlbnRFbWl0dGVyPFRhc2tVcGRhdGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGFjY2Vzc0tleUNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBhY3RpdmVTdGF0ZUVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGFsbG93U2VsZWN0aW9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBjb2x1bW5zQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8ZHhHYW50dENvbHVtbiB8IHN0cmluZz4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY29udGV4dE1lbnVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxkeEdhbnR0Q29udGV4dE1lbnU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZGVwZW5kZW5jaWVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBkYXRhU291cmNlPzogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8YW55Piwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBwcmVkZWNlc3NvcklkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdWNjZXNzb3JJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRpc2FibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBlZGl0aW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBhbGxvd0RlcGVuZGVuY3lBZGRpbmc/OiBib29sZWFuLCBhbGxvd0RlcGVuZGVuY3lEZWxldGluZz86IGJvb2xlYW4sIGFsbG93UmVzb3VyY2VBZGRpbmc/OiBib29sZWFuLCBhbGxvd1Jlc291cmNlRGVsZXRpbmc/OiBib29sZWFuLCBhbGxvd1Jlc291cmNlVXBkYXRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tBZGRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tEZWxldGluZz86IGJvb2xlYW4sIGFsbG93VGFza1Jlc291cmNlVXBkYXRpbmc/OiBib29sZWFuLCBhbGxvd1Rhc2tVcGRhdGluZz86IGJvb2xlYW4sIGVuYWJsZWQ/OiBib29sZWFuIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZWxlbWVudEF0dHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZW5kRGF0ZVJhbmdlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8RGF0ZT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBmaWx0ZXJSb3dDaGFuZ2U6IEV2ZW50RW1pdHRlcjxkeEdhbnR0RmlsdGVyUm93PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGZpcnN0RGF5T2ZXZWVrQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Rmlyc3REYXlPZldlZWsgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZm9jdXNTdGF0ZUVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGhlYWRlckZpbHRlckNoYW5nZTogRXZlbnRFbWl0dGVyPGR4R2FudHRIZWFkZXJGaWx0ZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGludENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBob3ZlclN0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcmVzb3VyY2VBc3NpZ25tZW50c0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcmVzb3VyY2VJZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGFza0lkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcmVzb3VyY2VzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjb2xvckV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJvb3RWYWx1ZUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzY2FsZVR5cGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxHYW50dFNjYWxlVHlwZT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzY2FsZVR5cGVSYW5nZUNoYW5nZTogRXZlbnRFbWl0dGVyPHsgbWF4PzogR2FudHRTY2FsZVR5cGUsIG1pbj86IEdhbnR0U2NhbGVUeXBlIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2VsZWN0ZWRSb3dLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnkgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd0RlcGVuZGVuY2llc0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd1Jlc291cmNlc0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd1Jvd0xpbmVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzb3J0aW5nQ2hhbmdlOiBFdmVudEVtaXR0ZXI8ZHhHYW50dFNvcnRpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc3RhcnREYXRlUmFuZ2VDaGFuZ2U6IEV2ZW50RW1pdHRlcjxEYXRlPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHN0cmlwTGluZXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxBcnJheTxkeEdhbnR0U3RyaXBMaW5lPj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0YWJJbmRleENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlcj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0YXNrQ29udGVudFRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRhc2tMaXN0V2lkdGhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGFza1Byb2dyZXNzVG9vbHRpcENvbnRlbnRUZW1wbGF0ZUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0YXNrc0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgY29sb3JFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBlbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgcGFyZW50SWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHByb2dyZXNzRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBzdGFydEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGl0bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB0YXNrVGltZVRvb2x0aXBDb250ZW50VGVtcGxhdGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGFza1RpdGxlUG9zaXRpb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxHYW50dFRhc2tUaXRsZVBvc2l0aW9uPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRhc2tUb29sdGlwQ29udGVudFRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHRvb2xiYXJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxkeEdhbnR0VG9vbGJhcj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWxpZGF0aW9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBhdXRvVXBkYXRlUGFyZW50VGFza3M/OiBib29sZWFuLCBlbmFibGVQcmVkZWNlc3NvckdhcD86IGJvb2xlYW4sIHZhbGlkYXRlRGVwZW5kZW5jaWVzPzogYm9vbGVhbiB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZpc2libGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHdpZHRoQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG5cblxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihEeGlDb2x1bW5Db21wb25lbnQpXG4gICAgZ2V0IGNvbHVtbnNDaGlsZHJlbigpOiBRdWVyeUxpc3Q8RHhpQ29sdW1uQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbHVtbnMnKTtcbiAgICB9XG4gICAgc2V0IGNvbHVtbnNDaGlsZHJlbih2YWx1ZSkge1xuICAgICAgICB0aGlzLnNldENoaWxkcmVuKCdjb2x1bW5zJywgdmFsdWUpO1xuICAgIH1cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oRHhpU3RyaXBMaW5lQ29tcG9uZW50KVxuICAgIGdldCBzdHJpcExpbmVzQ2hpbGRyZW4oKTogUXVlcnlMaXN0PER4aVN0cmlwTGluZUNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzdHJpcExpbmVzJyk7XG4gICAgfVxuICAgIHNldCBzdHJpcExpbmVzQ2hpbGRyZW4odmFsdWUpIHtcbiAgICAgICAgdGhpcy5zZXRDaGlsZHJlbignc3RyaXBMaW5lcycsIHZhbHVlKTtcbiAgICB9XG5cblxuXG5cbiAgICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmLCBuZ1pvbmU6IE5nWm9uZSwgdGVtcGxhdGVIb3N0OiBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgICAgIHByaXZhdGUgX3dhdGNoZXJIZWxwZXI6IFdhdGNoZXJIZWxwZXIsXG4gICAgICAgICAgICBwcml2YXRlIF9pZGg6IEl0ZXJhYmxlRGlmZmVySGVscGVyLFxuICAgICAgICAgICAgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgICAgIHRyYW5zZmVyU3RhdGU6IFRyYW5zZmVyU3RhdGUsXG4gICAgICAgICAgICBASW5qZWN0KFBMQVRGT1JNX0lEKSBwbGF0Zm9ybUlkOiBhbnkpIHtcblxuICAgICAgICBzdXBlcihlbGVtZW50UmVmLCBuZ1pvbmUsIHRlbXBsYXRlSG9zdCwgX3dhdGNoZXJIZWxwZXIsIHRyYW5zZmVyU3RhdGUsIHBsYXRmb3JtSWQpO1xuXG4gICAgICAgIHRoaXMuX2NyZWF0ZUV2ZW50RW1pdHRlcnMoW1xuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdjb250ZW50UmVhZHknLCBlbWl0OiAnb25Db250ZW50UmVhZHknIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2NvbnRleHRNZW51UHJlcGFyaW5nJywgZW1pdDogJ29uQ29udGV4dE1lbnVQcmVwYXJpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2N1c3RvbUNvbW1hbmQnLCBlbWl0OiAnb25DdXN0b21Db21tYW5kJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkZXBlbmRlbmN5RGVsZXRlZCcsIGVtaXQ6ICdvbkRlcGVuZGVuY3lEZWxldGVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkZXBlbmRlbmN5RGVsZXRpbmcnLCBlbWl0OiAnb25EZXBlbmRlbmN5RGVsZXRpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2RlcGVuZGVuY3lJbnNlcnRlZCcsIGVtaXQ6ICdvbkRlcGVuZGVuY3lJbnNlcnRlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZGVwZW5kZW5jeUluc2VydGluZycsIGVtaXQ6ICdvbkRlcGVuZGVuY3lJbnNlcnRpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2Rpc3Bvc2luZycsIGVtaXQ6ICdvbkRpc3Bvc2luZycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5pdGlhbGl6ZWQnLCBlbWl0OiAnb25Jbml0aWFsaXplZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnb3B0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvbk9wdGlvbkNoYW5nZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlQXNzaWduZWQnLCBlbWl0OiAnb25SZXNvdXJjZUFzc2lnbmVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdyZXNvdXJjZUFzc2lnbmluZycsIGVtaXQ6ICdvblJlc291cmNlQXNzaWduaW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdyZXNvdXJjZURlbGV0ZWQnLCBlbWl0OiAnb25SZXNvdXJjZURlbGV0ZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlRGVsZXRpbmcnLCBlbWl0OiAnb25SZXNvdXJjZURlbGV0aW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdyZXNvdXJjZUluc2VydGVkJywgZW1pdDogJ29uUmVzb3VyY2VJbnNlcnRlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVzb3VyY2VJbnNlcnRpbmcnLCBlbWl0OiAnb25SZXNvdXJjZUluc2VydGluZycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVzb3VyY2VNYW5hZ2VyRGlhbG9nU2hvd2luZycsIGVtaXQ6ICdvblJlc291cmNlTWFuYWdlckRpYWxvZ1Nob3dpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Jlc291cmNlVW5hc3NpZ25lZCcsIGVtaXQ6ICdvblJlc291cmNlVW5hc3NpZ25lZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVzb3VyY2VVbmFzc2lnbmluZycsIGVtaXQ6ICdvblJlc291cmNlVW5hc3NpZ25pbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3NjYWxlQ2VsbFByZXBhcmVkJywgZW1pdDogJ29uU2NhbGVDZWxsUHJlcGFyZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3NlbGVjdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25TZWxlY3Rpb25DaGFuZ2VkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrQ2xpY2snLCBlbWl0OiAnb25UYXNrQ2xpY2snIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rhc2tEYmxDbGljaycsIGVtaXQ6ICdvblRhc2tEYmxDbGljaycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAndGFza0RlbGV0ZWQnLCBlbWl0OiAnb25UYXNrRGVsZXRlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAndGFza0RlbGV0aW5nJywgZW1pdDogJ29uVGFza0RlbGV0aW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrRWRpdERpYWxvZ1Nob3dpbmcnLCBlbWl0OiAnb25UYXNrRWRpdERpYWxvZ1Nob3dpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rhc2tJbnNlcnRlZCcsIGVtaXQ6ICdvblRhc2tJbnNlcnRlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAndGFza0luc2VydGluZycsIGVtaXQ6ICdvblRhc2tJbnNlcnRpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3Rhc2tNb3ZpbmcnLCBlbWl0OiAnb25UYXNrTW92aW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrVXBkYXRlZCcsIGVtaXQ6ICdvblRhc2tVcGRhdGVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICd0YXNrVXBkYXRpbmcnLCBlbWl0OiAnb25UYXNrVXBkYXRpbmcnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdhY2Nlc3NLZXlDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdhY3RpdmVTdGF0ZUVuYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdhbGxvd1NlbGVjdGlvbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2NvbHVtbnNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdjb250ZXh0TWVudUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2RlcGVuZGVuY2llc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2Rpc2FibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZWRpdGluZ0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2VsZW1lbnRBdHRyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZW5kRGF0ZVJhbmdlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZmlsdGVyUm93Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZmlyc3REYXlPZldlZWtDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdmb2N1c1N0YXRlRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hlYWRlckZpbHRlckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hlaWdodENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hpbnRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdob3ZlclN0YXRlRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Jlc291cmNlQXNzaWdubWVudHNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdyZXNvdXJjZXNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdyb290VmFsdWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzY2FsZVR5cGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzY2FsZVR5cGVSYW5nZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NlbGVjdGVkUm93S2V5Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2hvd0RlcGVuZGVuY2llc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dSZXNvdXJjZXNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzaG93Um93TGluZXNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzb3J0aW5nQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc3RhcnREYXRlUmFuZ2VDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzdHJpcExpbmVzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGFiSW5kZXhDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0YXNrQ29udGVudFRlbXBsYXRlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGFza0xpc3RXaWR0aENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rhc2tQcm9ncmVzc1Rvb2x0aXBDb250ZW50VGVtcGxhdGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0YXNrc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rhc2tUaW1lVG9vbHRpcENvbnRlbnRUZW1wbGF0ZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Rhc2tUaXRsZVBvc2l0aW9uQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGFza1Rvb2x0aXBDb250ZW50VGVtcGxhdGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0b29sYmFyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmFsaWRhdGlvbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Zpc2libGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd3aWR0aENoYW5nZScgfVxuICAgICAgICBdKTtcblxuICAgICAgICB0aGlzLl9pZGguc2V0SG9zdCh0aGlzKTtcbiAgICAgICAgb3B0aW9uSG9zdC5zZXRIb3N0KHRoaXMpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBfY3JlYXRlSW5zdGFuY2UoZWxlbWVudCwgb3B0aW9ucykge1xuXG4gICAgICAgIHJldHVybiBuZXcgRHhHYW50dChlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2NvbHVtbnMnLCBjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ3N0cmlwTGluZXMnLCBjaGFuZ2VzKTtcbiAgICB9XG5cbiAgICBzZXR1cENoYW5nZXMocHJvcDogc3RyaW5nLCBjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgICAgIGlmICghKHByb3AgaW4gdGhpcy5fb3B0aW9uc1RvVXBkYXRlKSkge1xuICAgICAgICAgICAgdGhpcy5faWRoLnNldHVwKHByb3AsIGNoYW5nZXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdEb0NoZWNrKCkge1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnY29sdW1ucycpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnc3RyaXBMaW5lcycpO1xuICAgICAgICB0aGlzLl93YXRjaGVySGVscGVyLmNoZWNrV2F0Y2hlcnMoKTtcbiAgICAgICAgc3VwZXIubmdEb0NoZWNrKCk7XG4gICAgICAgIHN1cGVyLmNsZWFyQ2hhbmdlZE9wdGlvbnMoKTtcbiAgICB9XG5cbiAgICBfc2V0T3B0aW9uKG5hbWU6IHN0cmluZywgdmFsdWU6IGFueSkge1xuICAgICAgICBsZXQgaXNTZXR1cCA9IHRoaXMuX2lkaC5zZXR1cFNpbmdsZShuYW1lLCB2YWx1ZSk7XG4gICAgICAgIGxldCBpc0NoYW5nZWQgPSB0aGlzLl9pZGguZ2V0Q2hhbmdlcyhuYW1lLCB2YWx1ZSkgIT09IG51bGw7XG5cbiAgICAgICAgaWYgKGlzU2V0dXAgfHwgaXNDaGFuZ2VkKSB7XG4gICAgICAgICAgICBzdXBlci5fc2V0T3B0aW9uKG5hbWUsIHZhbHVlKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW1xuICAgIER4aUNvbHVtbk1vZHVsZSxcbiAgICBEeG9Gb3JtYXRNb2R1bGUsXG4gICAgRHhvSGVhZGVyRmlsdGVyTW9kdWxlLFxuICAgIER4b1NlYXJjaE1vZHVsZSxcbiAgICBEeG9Db250ZXh0TWVudU1vZHVsZSxcbiAgICBEeGlJdGVtTW9kdWxlLFxuICAgIER4b0RlcGVuZGVuY2llc01vZHVsZSxcbiAgICBEeG9FZGl0aW5nTW9kdWxlLFxuICAgIER4b0ZpbHRlclJvd01vZHVsZSxcbiAgICBEeG9PcGVyYXRpb25EZXNjcmlwdGlvbnNNb2R1bGUsXG4gICAgRHhvVGV4dHNNb2R1bGUsXG4gICAgRHhvUmVzb3VyY2VBc3NpZ25tZW50c01vZHVsZSxcbiAgICBEeG9SZXNvdXJjZXNNb2R1bGUsXG4gICAgRHhvU2NhbGVUeXBlUmFuZ2VNb2R1bGUsXG4gICAgRHhvU29ydGluZ01vZHVsZSxcbiAgICBEeGlTdHJpcExpbmVNb2R1bGUsXG4gICAgRHhvVGFza3NNb2R1bGUsXG4gICAgRHhvVG9vbGJhck1vZHVsZSxcbiAgICBEeG9WYWxpZGF0aW9uTW9kdWxlLFxuICAgIER4SW50ZWdyYXRpb25Nb2R1bGUsXG4gICAgRHhUZW1wbGF0ZU1vZHVsZVxuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBEeEdhbnR0Q29tcG9uZW50XG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBEeEdhbnR0Q29tcG9uZW50LFxuICAgIER4aUNvbHVtbk1vZHVsZSxcbiAgICBEeG9Gb3JtYXRNb2R1bGUsXG4gICAgRHhvSGVhZGVyRmlsdGVyTW9kdWxlLFxuICAgIER4b1NlYXJjaE1vZHVsZSxcbiAgICBEeG9Db250ZXh0TWVudU1vZHVsZSxcbiAgICBEeGlJdGVtTW9kdWxlLFxuICAgIER4b0RlcGVuZGVuY2llc01vZHVsZSxcbiAgICBEeG9FZGl0aW5nTW9kdWxlLFxuICAgIER4b0ZpbHRlclJvd01vZHVsZSxcbiAgICBEeG9PcGVyYXRpb25EZXNjcmlwdGlvbnNNb2R1bGUsXG4gICAgRHhvVGV4dHNNb2R1bGUsXG4gICAgRHhvUmVzb3VyY2VBc3NpZ25tZW50c01vZHVsZSxcbiAgICBEeG9SZXNvdXJjZXNNb2R1bGUsXG4gICAgRHhvU2NhbGVUeXBlUmFuZ2VNb2R1bGUsXG4gICAgRHhvU29ydGluZ01vZHVsZSxcbiAgICBEeGlTdHJpcExpbmVNb2R1bGUsXG4gICAgRHhvVGFza3NNb2R1bGUsXG4gICAgRHhvVG9vbGJhck1vZHVsZSxcbiAgICBEeG9WYWxpZGF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGVcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeEdhbnR0TW9kdWxlIHsgfVxuXG5pbXBvcnQgdHlwZSAqIGFzIER4R2FudHRUeXBlcyBmcm9tIFwiZGV2ZXh0cmVtZS91aS9nYW50dF90eXBlc1wiO1xuZXhwb3J0IHsgRHhHYW50dFR5cGVzIH07XG5cblxuIl19