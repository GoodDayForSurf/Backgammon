/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, forwardRef, HostListener, ContentChildren, QueryList } from '@angular/core';
import DxSelectBox from 'devextreme/ui/select_box';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxiButtonModule } from 'devextreme-angular/ui/nested';
import { DxoOptionsModule } from 'devextreme-angular/ui/nested';
import { DxoDropDownOptionsModule } from 'devextreme-angular/ui/nested';
import { DxoAnimationModule } from 'devextreme-angular/ui/nested';
import { DxoHideModule } from 'devextreme-angular/ui/nested';
import { DxoFromModule } from 'devextreme-angular/ui/nested';
import { DxoPositionModule } from 'devextreme-angular/ui/nested';
import { DxoAtModule } from 'devextreme-angular/ui/nested';
import { DxoBoundaryOffsetModule } from 'devextreme-angular/ui/nested';
import { DxoCollisionModule } from 'devextreme-angular/ui/nested';
import { DxoMyModule } from 'devextreme-angular/ui/nested';
import { DxoOffsetModule } from 'devextreme-angular/ui/nested';
import { DxoToModule } from 'devextreme-angular/ui/nested';
import { DxoShowModule } from 'devextreme-angular/ui/nested';
import { DxiToolbarItemModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxiButtonComponent } from 'devextreme-angular/ui/nested';
import { DxiItemComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
const CUSTOM_VALUE_ACCESSOR_PROVIDER = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DxSelectBoxComponent),
    multi: true
};
/**
 * [descr:dxSelectBox]

 */
export class DxSelectBoxComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:dxSelectBoxOptions.acceptCustomValue]
    
     */
    get acceptCustomValue() {
        return this._getOption('acceptCustomValue');
    }
    set acceptCustomValue(value) {
        this._setOption('acceptCustomValue', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.buttons]
    
     */
    get buttons() {
        return this._getOption('buttons');
    }
    set buttons(value) {
        this._setOption('buttons', value);
    }
    /**
     * [descr:dxSelectBoxOptions.customItemCreateEvent]
    
     */
    get customItemCreateEvent() {
        return this._getOption('customItemCreateEvent');
    }
    set customItemCreateEvent(value) {
        this._setOption('customItemCreateEvent', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.deferRendering]
    
     */
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:dxDropDownListOptions.displayValue]
    
     */
    get displayValue() {
        return this._getOption('displayValue');
    }
    set displayValue(value) {
        this._setOption('displayValue', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.dropDownButtonTemplate]
    
     */
    get dropDownButtonTemplate() {
        return this._getOption('dropDownButtonTemplate');
    }
    set dropDownButtonTemplate(value) {
        this._setOption('dropDownButtonTemplate', value);
    }
    /**
     * [descr:dxSelectBoxOptions.dropDownOptions]
    
     */
    get dropDownOptions() {
        return this._getOption('dropDownOptions');
    }
    set dropDownOptions(value) {
        this._setOption('dropDownOptions', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxSelectBoxOptions.fieldTemplate]
    
     */
    get fieldTemplate() {
        return this._getOption('fieldTemplate');
    }
    set fieldTemplate(value) {
        this._setOption('fieldTemplate', value);
    }
    /**
     * [descr:dxTextEditorOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxDropDownListOptions.grouped]
    
     */
    get grouped() {
        return this._getOption('grouped');
    }
    set grouped(value) {
        this._setOption('grouped', value);
    }
    /**
     * [descr:dxDropDownListOptions.groupTemplate]
    
     */
    get groupTemplate() {
        return this._getOption('groupTemplate');
    }
    set groupTemplate(value) {
        this._setOption('groupTemplate', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxTextEditorOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxTextEditorOptions.inputAttr]
    
     */
    get inputAttr() {
        return this._getOption('inputAttr');
    }
    set inputAttr(value) {
        this._setOption('inputAttr', value);
    }
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxTextEditorOptions.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxTextEditorOptions.labelMode]
    
     */
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    /**
     * [descr:dxTextBoxOptions.maxLength]
    
     */
    get maxLength() {
        return this._getOption('maxLength');
    }
    set maxLength(value) {
        this._setOption('maxLength', value);
    }
    /**
     * [descr:dxDropDownListOptions.minSearchLength]
    
     */
    get minSearchLength() {
        return this._getOption('minSearchLength');
    }
    set minSearchLength(value) {
        this._setOption('minSearchLength', value);
    }
    /**
     * [descr:dxTextEditorOptions.name]
    
     */
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    /**
     * [descr:dxDropDownListOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.opened]
    
     */
    get opened() {
        return this._getOption('opened');
    }
    set opened(value) {
        this._setOption('opened', value);
    }
    /**
     * [descr:dxSelectBoxOptions.openOnFieldClick]
    
     */
    get openOnFieldClick() {
        return this._getOption('openOnFieldClick');
    }
    set openOnFieldClick(value) {
        this._setOption('openOnFieldClick', value);
    }
    /**
     * [descr:dxSelectBoxOptions.placeholder]
    
     */
    get placeholder() {
        return this._getOption('placeholder');
    }
    set placeholder(value) {
        this._setOption('placeholder', value);
    }
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchEnabled]
    
     */
    get searchEnabled() {
        return this._getOption('searchEnabled');
    }
    set searchEnabled(value) {
        this._setOption('searchEnabled', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchExpr]
    
     */
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchMode]
    
     */
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchTimeout]
    
     */
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    /**
     * [descr:dxDropDownListOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:dxTextEditorOptions.showClearButton]
    
     */
    get showClearButton() {
        return this._getOption('showClearButton');
    }
    set showClearButton(value) {
        this._setOption('showClearButton', value);
    }
    /**
     * [descr:dxDropDownListOptions.showDataBeforeSearch]
    
     */
    get showDataBeforeSearch() {
        return this._getOption('showDataBeforeSearch');
    }
    set showDataBeforeSearch(value) {
        this._setOption('showDataBeforeSearch', value);
    }
    /**
     * [descr:dxSelectBoxOptions.showDropDownButton]
    
     */
    get showDropDownButton() {
        return this._getOption('showDropDownButton');
    }
    set showDropDownButton(value) {
        this._setOption('showDropDownButton', value);
    }
    /**
     * [descr:dxSelectBoxOptions.showSelectionControls]
    
     */
    get showSelectionControls() {
        return this._getOption('showSelectionControls');
    }
    set showSelectionControls(value) {
        this._setOption('showSelectionControls', value);
    }
    /**
     * [descr:dxTextEditorOptions.spellcheck]
    
     */
    get spellcheck() {
        return this._getOption('spellcheck');
    }
    set spellcheck(value) {
        this._setOption('spellcheck', value);
    }
    /**
     * [descr:dxTextEditorOptions.stylingMode]
    
     */
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxTextEditorOptions.text]
    
     */
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    /**
     * [descr:dxDropDownListOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle() {
        return this._getOption('useItemTextAsTitle');
    }
    set useItemTextAsTitle(value) {
        this._setOption('useItemTextAsTitle', value);
    }
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode() {
        return this._getOption('validationMessageMode');
    }
    set validationMessageMode(value) {
        this._setOption('validationMessageMode', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition() {
        return this._getOption('validationMessagePosition');
    }
    set validationMessagePosition(value) {
        this._setOption('validationMessagePosition', value);
    }
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    /**
     * [descr:dxDropDownListOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
     * [descr:dxSelectBoxOptions.valueChangeEvent]
    
     * @deprecated [depNote:dxSelectBoxOptions.valueChangeEvent]
    
     */
    get valueChangeEvent() {
        return this._getOption('valueChangeEvent');
    }
    set valueChangeEvent(value) {
        this._setOption('valueChangeEvent', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.valueExpr]
    
     */
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxDropDownListOptions.wrapItemText]
    
     */
    get wrapItemText() {
        return this._getOption('wrapItemText');
    }
    set wrapItemText(value) {
        this._setOption('wrapItemText', value);
    }
    /**
    
     * [descr:dxSelectBoxOptions.onChange]
    
    
     */
    onChange;
    /**
    
     * [descr:dxSelectBoxOptions.onClosed]
    
    
     */
    onClosed;
    /**
    
     * [descr:dxSelectBoxOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxSelectBoxOptions.onCopy]
    
    
     */
    onCopy;
    /**
    
     * [descr:dxSelectBoxOptions.onCustomItemCreating]
    
    
     */
    onCustomItemCreating;
    /**
    
     * [descr:dxSelectBoxOptions.onCut]
    
    
     */
    onCut;
    /**
    
     * [descr:dxSelectBoxOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxSelectBoxOptions.onEnterKey]
    
    
     */
    onEnterKey;
    /**
    
     * [descr:dxSelectBoxOptions.onFocusIn]
    
    
     */
    onFocusIn;
    /**
    
     * [descr:dxSelectBoxOptions.onFocusOut]
    
    
     */
    onFocusOut;
    /**
    
     * [descr:dxSelectBoxOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxSelectBoxOptions.onInput]
    
    
     */
    onInput;
    /**
    
     * [descr:dxSelectBoxOptions.onItemClick]
    
    
     */
    onItemClick;
    /**
    
     * [descr:dxSelectBoxOptions.onKeyDown]
    
    
     */
    onKeyDown;
    /**
    
     * [descr:dxSelectBoxOptions.onKeyUp]
    
    
     */
    onKeyUp;
    /**
    
     * [descr:dxSelectBoxOptions.onOpened]
    
    
     */
    onOpened;
    /**
    
     * [descr:dxSelectBoxOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxSelectBoxOptions.onPaste]
    
    
     */
    onPaste;
    /**
    
     * [descr:dxSelectBoxOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * [descr:dxSelectBoxOptions.onValueChanged]
    
    
     */
    onValueChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    acceptCustomValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    buttonsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customItemCreateEventChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayValueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownButtonTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownOptionsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    inputAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxLengthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minSearchLengthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openOnFieldClickChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    placeholderChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchTimeoutChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showClearButtonChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDataBeforeSearchChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDropDownButtonChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showSelectionControlsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    spellcheckChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useItemTextAsTitleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChangeEventChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueExprChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapItemTextChange;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur;
    change(_) { }
    touched = (_) => { };
    get buttonsChildren() {
        return this._getOption('buttons');
    }
    set buttonsChildren(value) {
        this.setChildren('buttons', value);
    }
    get itemsChildren() {
        return this._getOption('items');
    }
    set itemsChildren(value) {
        this.setChildren('items', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'change', emit: 'onChange' },
            { subscribe: 'closed', emit: 'onClosed' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'copy', emit: 'onCopy' },
            { subscribe: 'customItemCreating', emit: 'onCustomItemCreating' },
            { subscribe: 'cut', emit: 'onCut' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'enterKey', emit: 'onEnterKey' },
            { subscribe: 'focusIn', emit: 'onFocusIn' },
            { subscribe: 'focusOut', emit: 'onFocusOut' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'input', emit: 'onInput' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'keyDown', emit: 'onKeyDown' },
            { subscribe: 'keyUp', emit: 'onKeyUp' },
            { subscribe: 'opened', emit: 'onOpened' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'paste', emit: 'onPaste' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'valueChanged', emit: 'onValueChanged' },
            { emit: 'acceptCustomValueChange' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'buttonsChange' },
            { emit: 'customItemCreateEventChange' },
            { emit: 'dataSourceChange' },
            { emit: 'deferRenderingChange' },
            { emit: 'disabledChange' },
            { emit: 'displayExprChange' },
            { emit: 'displayValueChange' },
            { emit: 'dropDownButtonTemplateChange' },
            { emit: 'dropDownOptionsChange' },
            { emit: 'elementAttrChange' },
            { emit: 'fieldTemplateChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'groupedChange' },
            { emit: 'groupTemplateChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'inputAttrChange' },
            { emit: 'isDirtyChange' },
            { emit: 'isValidChange' },
            { emit: 'itemsChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'labelChange' },
            { emit: 'labelModeChange' },
            { emit: 'maxLengthChange' },
            { emit: 'minSearchLengthChange' },
            { emit: 'nameChange' },
            { emit: 'noDataTextChange' },
            { emit: 'openedChange' },
            { emit: 'openOnFieldClickChange' },
            { emit: 'placeholderChange' },
            { emit: 'readOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'searchEnabledChange' },
            { emit: 'searchExprChange' },
            { emit: 'searchModeChange' },
            { emit: 'searchTimeoutChange' },
            { emit: 'selectedItemChange' },
            { emit: 'showClearButtonChange' },
            { emit: 'showDataBeforeSearchChange' },
            { emit: 'showDropDownButtonChange' },
            { emit: 'showSelectionControlsChange' },
            { emit: 'spellcheckChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'textChange' },
            { emit: 'useItemTextAsTitleChange' },
            { emit: 'validationErrorChange' },
            { emit: 'validationErrorsChange' },
            { emit: 'validationMessageModeChange' },
            { emit: 'validationMessagePositionChange' },
            { emit: 'validationStatusChange' },
            { emit: 'valueChange' },
            { emit: 'valueChangeEventChange' },
            { emit: 'valueExprChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wrapItemTextChange' },
            { emit: 'onBlur' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxSelectBox(element, options);
    }
    writeValue(value) {
        this.eventHelper.lockedValueChangeEvent = true;
        this.value = value;
        this.eventHelper.lockedValueChangeEvent = false;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    registerOnChange(fn) { this.change = fn; }
    registerOnTouched(fn) { this.touched = fn; }
    _createWidget(element) {
        super._createWidget(element);
        this.instance.on('focusOut', (e) => {
            this.eventHelper.fireNgEvent('onBlur', [e]);
        });
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('buttons', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
        this.setupChanges('searchExpr', changes);
        this.setupChanges('validationErrors', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('buttons');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._idh.doCheck('searchExpr');
        this._idh.doCheck('validationErrors');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSelectBoxComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxSelectBoxComponent, selector: "dx-select-box", inputs: { acceptCustomValue: "acceptCustomValue", accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", buttons: "buttons", customItemCreateEvent: "customItemCreateEvent", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", displayExpr: "displayExpr", displayValue: "displayValue", dropDownButtonTemplate: "dropDownButtonTemplate", dropDownOptions: "dropDownOptions", elementAttr: "elementAttr", fieldTemplate: "fieldTemplate", focusStateEnabled: "focusStateEnabled", grouped: "grouped", groupTemplate: "groupTemplate", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", inputAttr: "inputAttr", isDirty: "isDirty", isValid: "isValid", items: "items", itemTemplate: "itemTemplate", label: "label", labelMode: "labelMode", maxLength: "maxLength", minSearchLength: "minSearchLength", name: "name", noDataText: "noDataText", opened: "opened", openOnFieldClick: "openOnFieldClick", placeholder: "placeholder", readOnly: "readOnly", rtlEnabled: "rtlEnabled", searchEnabled: "searchEnabled", searchExpr: "searchExpr", searchMode: "searchMode", searchTimeout: "searchTimeout", selectedItem: "selectedItem", showClearButton: "showClearButton", showDataBeforeSearch: "showDataBeforeSearch", showDropDownButton: "showDropDownButton", showSelectionControls: "showSelectionControls", spellcheck: "spellcheck", stylingMode: "stylingMode", tabIndex: "tabIndex", text: "text", useItemTextAsTitle: "useItemTextAsTitle", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", valueChangeEvent: "valueChangeEvent", valueExpr: "valueExpr", visible: "visible", width: "width", wrapItemText: "wrapItemText" }, outputs: { onChange: "onChange", onClosed: "onClosed", onContentReady: "onContentReady", onCopy: "onCopy", onCustomItemCreating: "onCustomItemCreating", onCut: "onCut", onDisposing: "onDisposing", onEnterKey: "onEnterKey", onFocusIn: "onFocusIn", onFocusOut: "onFocusOut", onInitialized: "onInitialized", onInput: "onInput", onItemClick: "onItemClick", onKeyDown: "onKeyDown", onKeyUp: "onKeyUp", onOpened: "onOpened", onOptionChanged: "onOptionChanged", onPaste: "onPaste", onSelectionChanged: "onSelectionChanged", onValueChanged: "onValueChanged", acceptCustomValueChange: "acceptCustomValueChange", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", buttonsChange: "buttonsChange", customItemCreateEventChange: "customItemCreateEventChange", dataSourceChange: "dataSourceChange", deferRenderingChange: "deferRenderingChange", disabledChange: "disabledChange", displayExprChange: "displayExprChange", displayValueChange: "displayValueChange", dropDownButtonTemplateChange: "dropDownButtonTemplateChange", dropDownOptionsChange: "dropDownOptionsChange", elementAttrChange: "elementAttrChange", fieldTemplateChange: "fieldTemplateChange", focusStateEnabledChange: "focusStateEnabledChange", groupedChange: "groupedChange", groupTemplateChange: "groupTemplateChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", inputAttrChange: "inputAttrChange", isDirtyChange: "isDirtyChange", isValidChange: "isValidChange", itemsChange: "itemsChange", itemTemplateChange: "itemTemplateChange", labelChange: "labelChange", labelModeChange: "labelModeChange", maxLengthChange: "maxLengthChange", minSearchLengthChange: "minSearchLengthChange", nameChange: "nameChange", noDataTextChange: "noDataTextChange", openedChange: "openedChange", openOnFieldClickChange: "openOnFieldClickChange", placeholderChange: "placeholderChange", readOnlyChange: "readOnlyChange", rtlEnabledChange: "rtlEnabledChange", searchEnabledChange: "searchEnabledChange", searchExprChange: "searchExprChange", searchModeChange: "searchModeChange", searchTimeoutChange: "searchTimeoutChange", selectedItemChange: "selectedItemChange", showClearButtonChange: "showClearButtonChange", showDataBeforeSearchChange: "showDataBeforeSearchChange", showDropDownButtonChange: "showDropDownButtonChange", showSelectionControlsChange: "showSelectionControlsChange", spellcheckChange: "spellcheckChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", textChange: "textChange", useItemTextAsTitleChange: "useItemTextAsTitleChange", validationErrorChange: "validationErrorChange", validationErrorsChange: "validationErrorsChange", validationMessageModeChange: "validationMessageModeChange", validationMessagePositionChange: "validationMessagePositionChange", validationStatusChange: "validationStatusChange", valueChange: "valueChange", valueChangeEventChange: "valueChangeEventChange", valueExprChange: "valueExprChange", visibleChange: "visibleChange", widthChange: "widthChange", wrapItemTextChange: "wrapItemTextChange", onBlur: "onBlur" }, host: { listeners: { "valueChange": "change($event)", "onBlur": "touched($event)" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            CUSTOM_VALUE_ACCESSOR_PROVIDER,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "buttonsChildren", predicate: DxiButtonComponent }, { propertyName: "itemsChildren", predicate: DxiItemComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSelectBoxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-select-box',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        CUSTOM_VALUE_ACCESSOR_PROVIDER,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { acceptCustomValue: [{
                type: Input
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], buttons: [{
                type: Input
            }], customItemCreateEvent: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], displayValue: [{
                type: Input
            }], dropDownButtonTemplate: [{
                type: Input
            }], dropDownOptions: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], fieldTemplate: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], grouped: [{
                type: Input
            }], groupTemplate: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], inputAttr: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], label: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], minSearchLength: [{
                type: Input
            }], name: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], opened: [{
                type: Input
            }], openOnFieldClick: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], searchEnabled: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], showClearButton: [{
                type: Input
            }], showDataBeforeSearch: [{
                type: Input
            }], showDropDownButton: [{
                type: Input
            }], showSelectionControls: [{
                type: Input
            }], spellcheck: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], text: [{
                type: Input
            }], useItemTextAsTitle: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationMessageMode: [{
                type: Input
            }], validationMessagePosition: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], valueChangeEvent: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapItemText: [{
                type: Input
            }], onChange: [{
                type: Output
            }], onClosed: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onCopy: [{
                type: Output
            }], onCustomItemCreating: [{
                type: Output
            }], onCut: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onEnterKey: [{
                type: Output
            }], onFocusIn: [{
                type: Output
            }], onFocusOut: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onInput: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onKeyDown: [{
                type: Output
            }], onKeyUp: [{
                type: Output
            }], onOpened: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onPaste: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onValueChanged: [{
                type: Output
            }], acceptCustomValueChange: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], buttonsChange: [{
                type: Output
            }], customItemCreateEventChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], deferRenderingChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], displayValueChange: [{
                type: Output
            }], dropDownButtonTemplateChange: [{
                type: Output
            }], dropDownOptionsChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], fieldTemplateChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], groupedChange: [{
                type: Output
            }], groupTemplateChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], inputAttrChange: [{
                type: Output
            }], isDirtyChange: [{
                type: Output
            }], isValidChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], labelModeChange: [{
                type: Output
            }], maxLengthChange: [{
                type: Output
            }], minSearchLengthChange: [{
                type: Output
            }], nameChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], openedChange: [{
                type: Output
            }], openOnFieldClickChange: [{
                type: Output
            }], placeholderChange: [{
                type: Output
            }], readOnlyChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], searchEnabledChange: [{
                type: Output
            }], searchExprChange: [{
                type: Output
            }], searchModeChange: [{
                type: Output
            }], searchTimeoutChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], showClearButtonChange: [{
                type: Output
            }], showDataBeforeSearchChange: [{
                type: Output
            }], showDropDownButtonChange: [{
                type: Output
            }], showSelectionControlsChange: [{
                type: Output
            }], spellcheckChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], textChange: [{
                type: Output
            }], useItemTextAsTitleChange: [{
                type: Output
            }], validationErrorChange: [{
                type: Output
            }], validationErrorsChange: [{
                type: Output
            }], validationMessageModeChange: [{
                type: Output
            }], validationMessagePositionChange: [{
                type: Output
            }], validationStatusChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], valueChangeEventChange: [{
                type: Output
            }], valueExprChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wrapItemTextChange: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], change: [{
                type: HostListener,
                args: ['valueChange', ['$event']]
            }], touched: [{
                type: HostListener,
                args: ['onBlur', ['$event']]
            }], buttonsChildren: [{
                type: ContentChildren,
                args: [DxiButtonComponent]
            }], itemsChildren: [{
                type: ContentChildren,
                args: [DxiItemComponent]
            }] } });
export class DxSelectBoxModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSelectBoxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxSelectBoxModule, declarations: [DxSelectBoxComponent], imports: [DxiButtonModule,
            DxoOptionsModule,
            DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxSelectBoxComponent, DxiButtonModule,
            DxoOptionsModule,
            DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSelectBoxModule, imports: [DxiButtonModule,
            DxoOptionsModule,
            DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxIntegrationModule,
            DxTemplateModule, DxiButtonModule,
            DxoOptionsModule,
            DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiToolbarItemModule,
            DxiItemModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxSelectBoxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiButtonModule,
                        DxoOptionsModule,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiToolbarItemModule,
                        DxiItemModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxSelectBoxComponent
                    ],
                    exports: [
                        DxSelectBoxComponent,
                        DxiButtonModule,
                        DxoOptionsModule,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiToolbarItemModule,
                        DxiItemModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL3NlbGVjdC1ib3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUNILGFBQWEsRUFDYixTQUFTLEVBQ1QsUUFBUSxFQUNSLFVBQVUsRUFDVixNQUFNLEVBQ04sV0FBVyxFQUNYLE1BQU0sRUFFTixLQUFLLEVBQ0wsTUFBTSxFQUVOLFlBQVksRUFDWixVQUFVLEVBQ1YsWUFBWSxFQUlaLGVBQWUsRUFDZixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFXdkIsT0FBTyxXQUFXLE1BQU0sMEJBQTBCLENBQUM7QUFFbkQsT0FBTyxFQUVILGlCQUFpQixFQUNwQixNQUFNLGdCQUFnQixDQUFDO0FBRXhCLE9BQU8sRUFDSCxXQUFXLEVBQ1gsY0FBYyxFQUNkLG1CQUFtQixFQUNuQixnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2hCLE1BQU0seUJBQXlCLENBQUM7QUFFakMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDakUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzNELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3ZFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzNELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNwRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFFN0QsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7OztBQUtoRSxNQUFNLDhCQUE4QixHQUFHO0lBQ25DLE9BQU8sRUFBRSxpQkFBaUI7SUFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQztJQUNuRCxLQUFLLEVBQUUsSUFBSTtDQUNkLENBQUM7QUFDRjs7O0dBR0c7QUFZSCxNQUFNLE9BQU8sb0JBQXFCLFNBQVEsV0FBVztJQXk0Q2pDO0lBQ0E7SUF6NENoQixRQUFRLEdBQWdCLElBQUksQ0FBQztJQUU3Qjs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBeUI7UUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQWM7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUF5RDtRQUNqRSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBYTtRQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWlHO1FBQzVHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGNBQWM7UUFDZCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBSSxjQUFjLENBQUMsS0FBYztRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBb0M7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBeUI7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksc0JBQXNCO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFJLHNCQUFzQixDQUFDLEtBQVU7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyx3QkFBd0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQXFCO1FBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBVTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFVO1FBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksT0FBTztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBQ0QsSUFBSSxPQUFPLENBQUMsS0FBYztRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFVO1FBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQTZDO1FBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQXlCO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGlCQUFpQjtRQUNqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsQ0FBQyxLQUFjO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBVTtRQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBMkc7UUFDakgsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBVTtRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFhO1FBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQWdCO1FBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFNBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUNELElBQUksU0FBUyxDQUFDLEtBQXNCO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBYTtRQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQWE7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYTtRQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUFjO1FBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGdCQUFnQjtRQUNoQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBQ0QsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFjO1FBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBYTtRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFjO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFtRDtRQUM5RCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUEyQjtRQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxhQUFhO1FBQ2IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFDRCxJQUFJLGFBQWEsQ0FBQyxLQUFhO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQVU7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksZUFBZTtRQUNmLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFDRCxJQUFJLGVBQWUsQ0FBQyxLQUFjO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksb0JBQW9CO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxJQUFJLG9CQUFvQixDQUFDLEtBQWM7UUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxrQkFBa0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDakQsQ0FBQztJQUNELElBQUksa0JBQWtCLENBQUMsS0FBYztRQUNqQyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLHFCQUFxQjtRQUNyQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBSSxxQkFBcUIsQ0FBQyxLQUFjO1FBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFrQjtRQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLElBQUk7UUFDSixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQWE7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQWM7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQVU7UUFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBaUI7UUFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxxQkFBcUI7UUFDckIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQUkscUJBQXFCLENBQUMsS0FBNEI7UUFDbEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSx5QkFBeUI7UUFDekIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUNELElBQUkseUJBQXlCLENBQUMsS0FBc0I7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxnQkFBZ0I7UUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQUksZ0JBQWdCLENBQUMsS0FBdUI7UUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxLQUFLO1FBQ0wsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxLQUFVO1FBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFHRDs7Ozs7T0FLRztJQUNILElBQ0ksZ0JBQWdCO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFJLGdCQUFnQixDQUFDLEtBQWE7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUF3QjtRQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFjO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQTZDO1FBQ25ELElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQWM7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sUUFBUSxDQUE0QjtJQUU5Qzs7Ozs7T0FLRztJQUNPLFFBQVEsQ0FBNEI7SUFFOUM7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7OztPQUtHO0lBQ08sTUFBTSxDQUEwQjtJQUUxQzs7Ozs7T0FLRztJQUNPLG9CQUFvQixDQUF3QztJQUV0RTs7Ozs7T0FLRztJQUNPLEtBQUssQ0FBeUI7SUFFeEM7Ozs7O09BS0c7SUFDTyxXQUFXLENBQStCO0lBRXBEOzs7OztPQUtHO0lBQ08sVUFBVSxDQUE4QjtJQUVsRDs7Ozs7T0FLRztJQUNPLFNBQVMsQ0FBNkI7SUFFaEQ7Ozs7O09BS0c7SUFDTyxVQUFVLENBQThCO0lBRWxEOzs7OztPQUtHO0lBQ08sYUFBYSxDQUFpQztJQUV4RDs7Ozs7T0FLRztJQUNPLE9BQU8sQ0FBMkI7SUFFNUM7Ozs7O09BS0c7SUFDTyxXQUFXLENBQStCO0lBRXBEOzs7OztPQUtHO0lBQ08sU0FBUyxDQUE2QjtJQUVoRDs7Ozs7T0FLRztJQUNPLE9BQU8sQ0FBMkI7SUFFNUM7Ozs7O09BS0c7SUFDTyxRQUFRLENBQTRCO0lBRTlDOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLE9BQU8sQ0FBMkI7SUFFNUM7Ozs7O09BS0c7SUFDTyxrQkFBa0IsQ0FBc0M7SUFFbEU7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7O09BSUc7SUFDTyx1QkFBdUIsQ0FBd0I7SUFFekQ7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7T0FJRztJQUNPLHdCQUF3QixDQUF3QjtJQUUxRDs7OztPQUlHO0lBQ08sYUFBYSxDQUFtRTtJQUUxRjs7OztPQUlHO0lBQ08sMkJBQTJCLENBQXVCO0lBRTVEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBMkc7SUFFckk7Ozs7T0FJRztJQUNPLG9CQUFvQixDQUF3QjtJQUV0RDs7OztPQUlHO0lBQ08sY0FBYyxDQUF3QjtJQUVoRDs7OztPQUlHO0lBQ08saUJBQWlCLENBQThDO0lBRXpFOzs7O09BSUc7SUFDTyxrQkFBa0IsQ0FBbUM7SUFFL0Q7Ozs7T0FJRztJQUNPLDRCQUE0QixDQUFvQjtJQUUxRDs7OztPQUlHO0lBQ08scUJBQXFCLENBQStCO0lBRTlEOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBb0I7SUFFL0M7Ozs7T0FJRztJQUNPLG1CQUFtQixDQUFvQjtJQUVqRDs7OztPQUlHO0lBQ08sdUJBQXVCLENBQXdCO0lBRXpEOzs7O09BSUc7SUFDTyxhQUFhLENBQXdCO0lBRS9DOzs7O09BSUc7SUFDTyxtQkFBbUIsQ0FBb0I7SUFFakQ7Ozs7T0FJRztJQUNPLFlBQVksQ0FBdUQ7SUFFN0U7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBbUM7SUFFdkQ7Ozs7T0FJRztJQUNPLHVCQUF1QixDQUF3QjtJQUV6RDs7OztPQUlHO0lBQ08sZUFBZSxDQUFvQjtJQUU3Qzs7OztPQUlHO0lBQ08sYUFBYSxDQUF3QjtJQUUvQzs7OztPQUlHO0lBQ08sYUFBYSxDQUF3QjtJQUUvQzs7OztPQUlHO0lBQ08sV0FBVyxDQUFxSDtJQUUxSTs7OztPQUlHO0lBQ08sa0JBQWtCLENBQW9CO0lBRWhEOzs7O09BSUc7SUFDTyxXQUFXLENBQXVCO0lBRTVDOzs7O09BSUc7SUFDTyxlQUFlLENBQTBCO0lBRW5EOzs7O09BSUc7SUFDTyxlQUFlLENBQWdDO0lBRXpEOzs7O09BSUc7SUFDTyxxQkFBcUIsQ0FBdUI7SUFFdEQ7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBdUI7SUFFM0M7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF1QjtJQUVqRDs7OztPQUlHO0lBQ08sWUFBWSxDQUF3QjtJQUU5Qzs7OztPQUlHO0lBQ08sc0JBQXNCLENBQXdCO0lBRXhEOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBdUI7SUFFbEQ7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBd0I7SUFFaEQ7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF3QjtJQUVsRDs7OztPQUlHO0lBQ08sbUJBQW1CLENBQXdCO0lBRXJEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBNkQ7SUFFdkY7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUFxQztJQUUvRDs7OztPQUlHO0lBQ08sbUJBQW1CLENBQXVCO0lBRXBEOzs7O09BSUc7SUFDTyxrQkFBa0IsQ0FBb0I7SUFFaEQ7Ozs7T0FJRztJQUNPLHFCQUFxQixDQUF3QjtJQUV2RDs7OztPQUlHO0lBQ08sMEJBQTBCLENBQXdCO0lBRTVEOzs7O09BSUc7SUFDTyx3QkFBd0IsQ0FBd0I7SUFFMUQ7Ozs7T0FJRztJQUNPLDJCQUEyQixDQUF3QjtJQUU3RDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQXdCO0lBRWxEOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBNEI7SUFFdkQ7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBdUI7SUFFL0M7Ozs7T0FJRztJQUNPLFVBQVUsQ0FBdUI7SUFFM0M7Ozs7T0FJRztJQUNPLHdCQUF3QixDQUF3QjtJQUUxRDs7OztPQUlHO0lBQ08scUJBQXFCLENBQW9CO0lBRW5EOzs7O09BSUc7SUFDTyxzQkFBc0IsQ0FBMkI7SUFFM0Q7Ozs7T0FJRztJQUNPLDJCQUEyQixDQUFzQztJQUUzRTs7OztPQUlHO0lBQ08sK0JBQStCLENBQWdDO0lBRXpFOzs7O09BSUc7SUFDTyxzQkFBc0IsQ0FBaUM7SUFFakU7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBb0I7SUFFekM7Ozs7T0FJRztJQUNPLHNCQUFzQixDQUF1QjtJQUV2RDs7OztPQUlHO0lBQ08sZUFBZSxDQUFrQztJQUUzRDs7OztPQUlHO0lBQ08sYUFBYSxDQUF3QjtJQUUvQzs7OztPQUlHO0lBQ08sV0FBVyxDQUF1RDtJQUU1RTs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXdCO0lBRXBEOzs7OztPQUtHO0lBQ08sTUFBTSxDQUFvQjtJQUdLLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztJQUNsQixPQUFPLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFFLENBQUMsQ0FBQztJQUd4RCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQUs7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELElBQ0ksYUFBYTtRQUNiLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxhQUFhLENBQUMsS0FBSztRQUNuQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBS0QsWUFBWSxVQUFzQixFQUFFLE1BQWMsRUFBRSxZQUE0QixFQUNoRSxjQUE2QixFQUM3QixJQUEwQixFQUNsQyxVQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFFeEMsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFOdkUsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFDN0IsU0FBSSxHQUFKLElBQUksQ0FBc0I7UUFPdEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3RCLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3pDLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3pDLEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7WUFDckMsRUFBRSxTQUFTLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2pFLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFO1lBQ25DLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQzdDLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO1lBQzNDLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQzdDLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ25ELEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3ZDLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO1lBQzNDLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3ZDLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3pDLEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDdkQsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7WUFDdkMsRUFBRSxTQUFTLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzdELEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDbkMsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUU7WUFDcEMsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLDZCQUE2QixFQUFFO1lBQ3ZDLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLDhCQUE4QixFQUFFO1lBQ3hDLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ2pDLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9CLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFO1lBQ25DLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtZQUMvQixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQ3RCLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFO1lBQ25DLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDekIsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMzQixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNqQyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7WUFDdEIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDNUIsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3hCLEVBQUUsSUFBSSxFQUFFLHdCQUF3QixFQUFFO1lBQ2xDLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQy9CLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzlCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ2pDLEVBQUUsSUFBSSxFQUFFLDRCQUE0QixFQUFFO1lBQ3RDLEVBQUUsSUFBSSxFQUFFLDBCQUEwQixFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLDZCQUE2QixFQUFFO1lBQ3ZDLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUN0QixFQUFFLElBQUksRUFBRSwwQkFBMEIsRUFBRTtZQUNwQyxFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNqQyxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRTtZQUNsQyxFQUFFLElBQUksRUFBRSw2QkFBNkIsRUFBRTtZQUN2QyxFQUFFLElBQUksRUFBRSxpQ0FBaUMsRUFBRTtZQUMzQyxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRTtZQUNsQyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDbEMsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7U0FDckIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRVMsZUFBZSxDQUFDLE9BQU8sRUFBRSxPQUFPO1FBRXRDLE9BQU8sSUFBSSxXQUFXLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRCxVQUFVLENBQUMsS0FBVTtRQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztRQUMvQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuQixJQUFJLENBQUMsV0FBVyxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQztJQUNwRCxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsVUFBbUI7UUFDaEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7SUFDL0IsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQW9CLElBQVUsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ2xFLGlCQUFpQixDQUFDLEVBQWMsSUFBVSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFOUQsYUFBYSxDQUFDLE9BQVk7UUFDdEIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3QixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUMvQixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxZQUFZLENBQUMsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELFlBQVksQ0FBQyxJQUFZLEVBQUUsT0FBc0I7UUFDN0MsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsQztJQUNMLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUN0QyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3BDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNsQixLQUFLLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRUQsVUFBVSxDQUFDLElBQVksRUFBRSxLQUFVO1FBQy9CLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNqRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDO1FBRTNELElBQUksT0FBTyxJQUFJLFNBQVMsRUFBRTtZQUN0QixLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7MkhBemlEUSxvQkFBb0IsOE5BNjRDYixXQUFXOytHQTc0Q2xCLG9CQUFvQixrOUpBUmxCO1lBQ1AsY0FBYztZQUNkLGFBQWE7WUFDYiw4QkFBOEI7WUFDOUIsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtTQUN2QiwwREF1M0NnQixrQkFBa0IsZ0RBUWxCLGdCQUFnQix5RUF0NEN2QixFQUFFOzs0RkFTSCxvQkFBb0I7a0JBWGhDLFNBQVM7bUJBQUM7b0JBQ1AsUUFBUSxFQUFFLGVBQWU7b0JBQ3pCLFFBQVEsRUFBRSxFQUFFO29CQUNaLFNBQVMsRUFBRTt3QkFDUCxjQUFjO3dCQUNkLGFBQWE7d0JBQ2IsOEJBQThCO3dCQUM5QixnQkFBZ0I7d0JBQ2hCLG9CQUFvQjtxQkFDdkI7aUJBQ0o7OzBCQTg0Q1ksTUFBTTsyQkFBQyxXQUFXOzRDQXI0Q3ZCLGlCQUFpQjtzQkFEcEIsS0FBSztnQkFjRixTQUFTO3NCQURaLEtBQUs7Z0JBY0Ysa0JBQWtCO3NCQURyQixLQUFLO2dCQWNGLE9BQU87c0JBRFYsS0FBSztnQkFjRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLGNBQWM7c0JBRGpCLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLFdBQVc7c0JBRGQsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0Ysc0JBQXNCO3NCQUR6QixLQUFLO2dCQWNGLGVBQWU7c0JBRGxCLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBY0YsaUJBQWlCO3NCQURwQixLQUFLO2dCQWNGLE9BQU87c0JBRFYsS0FBSztnQkFjRixhQUFhO3NCQURoQixLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsaUJBQWlCO3NCQURwQixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixPQUFPO3NCQURWLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixTQUFTO3NCQURaLEtBQUs7Z0JBY0YsZUFBZTtzQkFEbEIsS0FBSztnQkFjRixJQUFJO3NCQURQLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixnQkFBZ0I7c0JBRG5CLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsYUFBYTtzQkFEaEIsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBY0YsWUFBWTtzQkFEZixLQUFLO2dCQWNGLGVBQWU7c0JBRGxCLEtBQUs7Z0JBY0Ysb0JBQW9CO3NCQUR2QixLQUFLO2dCQWNGLGtCQUFrQjtzQkFEckIsS0FBSztnQkFjRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBY0YsVUFBVTtzQkFEYixLQUFLO2dCQWNGLFdBQVc7c0JBRGQsS0FBSztnQkFjRixRQUFRO3NCQURYLEtBQUs7Z0JBY0YsSUFBSTtzQkFEUCxLQUFLO2dCQWNGLGtCQUFrQjtzQkFEckIsS0FBSztnQkFjRixlQUFlO3NCQURsQixLQUFLO2dCQWNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFjRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBY0YseUJBQXlCO3NCQUQ1QixLQUFLO2dCQWNGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFjRixLQUFLO3NCQURSLEtBQUs7Z0JBZ0JGLGdCQUFnQjtzQkFEbkIsS0FBSztnQkFjRixTQUFTO3NCQURaLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0ksUUFBUTtzQkFBakIsTUFBTTtnQkFRRyxRQUFRO3NCQUFqQixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBUUcsTUFBTTtzQkFBZixNQUFNO2dCQVFHLG9CQUFvQjtzQkFBN0IsTUFBTTtnQkFRRyxLQUFLO3NCQUFkLE1BQU07Z0JBUUcsV0FBVztzQkFBcEIsTUFBTTtnQkFRRyxVQUFVO3NCQUFuQixNQUFNO2dCQVFHLFNBQVM7c0JBQWxCLE1BQU07Z0JBUUcsVUFBVTtzQkFBbkIsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLE9BQU87c0JBQWhCLE1BQU07Z0JBUUcsV0FBVztzQkFBcEIsTUFBTTtnQkFRRyxTQUFTO3NCQUFsQixNQUFNO2dCQVFHLE9BQU87c0JBQWhCLE1BQU07Z0JBUUcsUUFBUTtzQkFBakIsTUFBTTtnQkFRRyxlQUFlO3NCQUF4QixNQUFNO2dCQVFHLE9BQU87c0JBQWhCLE1BQU07Z0JBUUcsa0JBQWtCO3NCQUEzQixNQUFNO2dCQVFHLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csdUJBQXVCO3NCQUFoQyxNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csd0JBQXdCO3NCQUFqQyxNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csMkJBQTJCO3NCQUFwQyxNQUFNO2dCQU9HLGdCQUFnQjtzQkFBekIsTUFBTTtnQkFPRyxvQkFBb0I7c0JBQTdCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLDRCQUE0QjtzQkFBckMsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFPRyx1QkFBdUI7c0JBQWhDLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxtQkFBbUI7c0JBQTVCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU9HLHVCQUF1QjtzQkFBaEMsTUFBTTtnQkFPRyxlQUFlO3NCQUF4QixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxXQUFXO3NCQUFwQixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxXQUFXO3NCQUFwQixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csVUFBVTtzQkFBbkIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxzQkFBc0I7c0JBQS9CLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLGNBQWM7c0JBQXZCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLG1CQUFtQjtzQkFBNUIsTUFBTTtnQkFPRyxrQkFBa0I7c0JBQTNCLE1BQU07Z0JBT0cscUJBQXFCO3NCQUE5QixNQUFNO2dCQU9HLDBCQUEwQjtzQkFBbkMsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csMkJBQTJCO3NCQUFwQyxNQUFNO2dCQU9HLGdCQUFnQjtzQkFBekIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxVQUFVO3NCQUFuQixNQUFNO2dCQU9HLHdCQUF3QjtzQkFBakMsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csc0JBQXNCO3NCQUEvQixNQUFNO2dCQU9HLDJCQUEyQjtzQkFBcEMsTUFBTTtnQkFPRywrQkFBK0I7c0JBQXhDLE1BQU07Z0JBT0csc0JBQXNCO3NCQUEvQixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBT0csc0JBQXNCO3NCQUEvQixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxXQUFXO3NCQUFwQixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFRRyxNQUFNO3NCQUFmLE1BQU07Z0JBR2tDLE1BQU07c0JBQTlDLFlBQVk7dUJBQUMsYUFBYSxFQUFFLENBQUMsUUFBUSxDQUFDO2dCQUNILE9BQU87c0JBQTFDLFlBQVk7dUJBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxDQUFDO2dCQUk5QixlQUFlO3NCQURsQixlQUFlO3VCQUFDLGtCQUFrQjtnQkFTL0IsYUFBYTtzQkFEaEIsZUFBZTt1QkFBQyxnQkFBZ0I7O0FBNE5yQyxNQUFNLE9BQU8saUJBQWlCOzJIQUFqQixpQkFBaUI7NEhBQWpCLGlCQUFpQixpQkF6bERqQixvQkFBb0IsYUE4aUQ3QixlQUFlO1lBQ2YsZ0JBQWdCO1lBQ2hCLHdCQUF3QjtZQUN4QixrQkFBa0I7WUFDbEIsYUFBYTtZQUNiLGFBQWE7WUFDYixpQkFBaUI7WUFDakIsV0FBVztZQUNYLHVCQUF1QjtZQUN2QixrQkFBa0I7WUFDbEIsV0FBVztZQUNYLGVBQWU7WUFDZixXQUFXO1lBQ1gsYUFBYTtZQUNiLG9CQUFvQjtZQUNwQixhQUFhO1lBQ2IsbUJBQW1CO1lBQ25CLGdCQUFnQixhQS9qRFAsb0JBQW9CLEVBc2tEN0IsZUFBZTtZQUNmLGdCQUFnQjtZQUNoQix3QkFBd0I7WUFDeEIsa0JBQWtCO1lBQ2xCLGFBQWE7WUFDYixhQUFhO1lBQ2IsaUJBQWlCO1lBQ2pCLFdBQVc7WUFDWCx1QkFBdUI7WUFDdkIsa0JBQWtCO1lBQ2xCLFdBQVc7WUFDWCxlQUFlO1lBQ2YsV0FBVztZQUNYLGFBQWE7WUFDYixvQkFBb0I7WUFDcEIsYUFBYTtZQUNiLGdCQUFnQjs0SEFHUCxpQkFBaUIsWUEzQzFCLGVBQWU7WUFDZixnQkFBZ0I7WUFDaEIsd0JBQXdCO1lBQ3hCLGtCQUFrQjtZQUNsQixhQUFhO1lBQ2IsYUFBYTtZQUNiLGlCQUFpQjtZQUNqQixXQUFXO1lBQ1gsdUJBQXVCO1lBQ3ZCLGtCQUFrQjtZQUNsQixXQUFXO1lBQ1gsZUFBZTtZQUNmLFdBQVc7WUFDWCxhQUFhO1lBQ2Isb0JBQW9CO1lBQ3BCLGFBQWE7WUFDYixtQkFBbUI7WUFDbkIsZ0JBQWdCLEVBT2hCLGVBQWU7WUFDZixnQkFBZ0I7WUFDaEIsd0JBQXdCO1lBQ3hCLGtCQUFrQjtZQUNsQixhQUFhO1lBQ2IsYUFBYTtZQUNiLGlCQUFpQjtZQUNqQixXQUFXO1lBQ1gsdUJBQXVCO1lBQ3ZCLGtCQUFrQjtZQUNsQixXQUFXO1lBQ1gsZUFBZTtZQUNmLFdBQVc7WUFDWCxhQUFhO1lBQ2Isb0JBQW9CO1lBQ3BCLGFBQWE7WUFDYixnQkFBZ0I7OzRGQUdQLGlCQUFpQjtrQkE3QzdCLFFBQVE7bUJBQUM7b0JBQ1IsT0FBTyxFQUFFO3dCQUNQLGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQix3QkFBd0I7d0JBQ3hCLGtCQUFrQjt3QkFDbEIsYUFBYTt3QkFDYixhQUFhO3dCQUNiLGlCQUFpQjt3QkFDakIsV0FBVzt3QkFDWCx1QkFBdUI7d0JBQ3ZCLGtCQUFrQjt3QkFDbEIsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsYUFBYTt3QkFDYixvQkFBb0I7d0JBQ3BCLGFBQWE7d0JBQ2IsbUJBQW1CO3dCQUNuQixnQkFBZ0I7cUJBQ2pCO29CQUNELFlBQVksRUFBRTt3QkFDWixvQkFBb0I7cUJBQ3JCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxvQkFBb0I7d0JBQ3BCLGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQix3QkFBd0I7d0JBQ3hCLGtCQUFrQjt3QkFDbEIsYUFBYTt3QkFDYixhQUFhO3dCQUNiLGlCQUFpQjt3QkFDakIsV0FBVzt3QkFDWCx1QkFBdUI7d0JBQ3ZCLGtCQUFrQjt3QkFDbEIsV0FBVzt3QkFDWCxlQUFlO3dCQUNmLFdBQVc7d0JBQ1gsYUFBYTt3QkFDYixvQkFBb0I7d0JBQ3BCLGFBQWE7d0JBQ2IsZ0JBQWdCO3FCQUNqQjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cblxuXG5pbXBvcnQge1xuICAgIFRyYW5zZmVyU3RhdGUsXG4gICAgQ29tcG9uZW50LFxuICAgIE5nTW9kdWxlLFxuICAgIEVsZW1lbnRSZWYsXG4gICAgTmdab25lLFxuICAgIFBMQVRGT1JNX0lELFxuICAgIEluamVjdCxcblxuICAgIElucHV0LFxuICAgIE91dHB1dCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgRXZlbnRFbWl0dGVyLFxuICAgIGZvcndhcmRSZWYsXG4gICAgSG9zdExpc3RlbmVyLFxuICAgIE9uQ2hhbmdlcyxcbiAgICBEb0NoZWNrLFxuICAgIFNpbXBsZUNoYW5nZXMsXG4gICAgQ29udGVudENoaWxkcmVuLFxuICAgIFF1ZXJ5TGlzdFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG5pbXBvcnQgeyBFZGl0b3JTdHlsZSwgTGFiZWxNb2RlLCBNb2RlLCBQb3NpdGlvbiwgU2ltcGxpZmllZFNlYXJjaE1vZGUsIFRleHRFZGl0b3JCdXR0b24sIFZhbGlkYXRpb25NZXNzYWdlTW9kZSwgVmFsaWRhdGlvblN0YXR1cyB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uJztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSAnZGV2ZXh0cmVtZS9kYXRhJztcbmltcG9ydCBEYXRhU291cmNlLCB7IE9wdGlvbnMgYXMgRGF0YVNvdXJjZU9wdGlvbnMgfSBmcm9tICdkZXZleHRyZW1lL2RhdGEvZGF0YV9zb3VyY2UnO1xuaW1wb3J0IHsgQ29sbGVjdGlvbldpZGdldEl0ZW0gfSBmcm9tICdkZXZleHRyZW1lL3VpL2NvbGxlY3Rpb24vdWkuY29sbGVjdGlvbl93aWRnZXQuYmFzZSc7XG5pbXBvcnQgeyBEcm9wRG93blByZWRlZmluZWRCdXR0b24gfSBmcm9tICdkZXZleHRyZW1lL3VpL2Ryb3BfZG93bl9lZGl0b3IvdWkuZHJvcF9kb3duX2VkaXRvcic7XG5pbXBvcnQgeyBQcm9wZXJ0aWVzIGFzIGR4UG9wdXBPcHRpb25zIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9wb3B1cCc7XG5pbXBvcnQgeyBDaGFuZ2VFdmVudCwgQ2xvc2VkRXZlbnQsIENvbnRlbnRSZWFkeUV2ZW50LCBDb3B5RXZlbnQsIEN1c3RvbUl0ZW1DcmVhdGluZ0V2ZW50LCBDdXRFdmVudCwgRGlzcG9zaW5nRXZlbnQsIEVudGVyS2V5RXZlbnQsIEZvY3VzSW5FdmVudCwgRm9jdXNPdXRFdmVudCwgSW5pdGlhbGl6ZWRFdmVudCwgSW5wdXRFdmVudCwgSXRlbUNsaWNrRXZlbnQsIEtleURvd25FdmVudCwgS2V5VXBFdmVudCwgT3BlbmVkRXZlbnQsIE9wdGlvbkNoYW5nZWRFdmVudCwgUGFzdGVFdmVudCwgU2VsZWN0aW9uQ2hhbmdlZEV2ZW50LCBWYWx1ZUNoYW5nZWRFdmVudCB9IGZyb20gJ2RldmV4dHJlbWUvdWkvc2VsZWN0X2JveCc7XG5cbmltcG9ydCBEeFNlbGVjdEJveCBmcm9tICdkZXZleHRyZW1lL3VpL3NlbGVjdF9ib3gnO1xuXG5pbXBvcnQge1xuICAgIENvbnRyb2xWYWx1ZUFjY2Vzc29yLFxuICAgIE5HX1ZBTFVFX0FDQ0VTU09SXG59IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcblxuaW1wb3J0IHtcbiAgICBEeENvbXBvbmVudCxcbiAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGUsXG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICBJdGVyYWJsZURpZmZlckhlbHBlcixcbiAgICBXYXRjaGVySGVscGVyXG59IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgRHhpQnV0dG9uTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9PcHRpb25zTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Ecm9wRG93bk9wdGlvbnNNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0FuaW1hdGlvbk1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvSGlkZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvRnJvbU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvUG9zaXRpb25Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b0F0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Cb3VuZGFyeU9mZnNldE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvQ29sbGlzaW9uTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9NeU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvT2Zmc2V0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Ub01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvU2hvd01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpVG9vbGJhckl0ZW1Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aUl0ZW1Nb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcblxuaW1wb3J0IHsgRHhpQnV0dG9uQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlJdGVtQ29tcG9uZW50IH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5cblxuXG5cbmNvbnN0IENVU1RPTV9WQUxVRV9BQ0NFU1NPUl9QUk9WSURFUiA9IHtcbiAgICBwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcbiAgICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBEeFNlbGVjdEJveENvbXBvbmVudCksXG4gICAgbXVsdGk6IHRydWVcbn07XG4vKipcbiAqIFtkZXNjcjpkeFNlbGVjdEJveF1cblxuICovXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2R4LXNlbGVjdC1ib3gnLFxuICAgIHRlbXBsYXRlOiAnJyxcbiAgICBwcm92aWRlcnM6IFtcbiAgICAgICAgRHhUZW1wbGF0ZUhvc3QsXG4gICAgICAgIFdhdGNoZXJIZWxwZXIsXG4gICAgICAgIENVU1RPTV9WQUxVRV9BQ0NFU1NPUl9QUk9WSURFUixcbiAgICAgICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4U2VsZWN0Qm94Q29tcG9uZW50IGV4dGVuZHMgRHhDb21wb25lbnQgaW1wbGVtZW50cyBPbkRlc3Ryb3ksIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBPbkNoYW5nZXMsIERvQ2hlY2sge1xuICAgIGluc3RhbmNlOiBEeFNlbGVjdEJveCA9IG51bGw7XG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLmFjY2VwdEN1c3RvbVZhbHVlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGFjY2VwdEN1c3RvbVZhbHVlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhY2NlcHRDdXN0b21WYWx1ZScpO1xuICAgIH1cbiAgICBzZXQgYWNjZXB0Q3VzdG9tVmFsdWUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdhY2NlcHRDdXN0b21WYWx1ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLmFjY2Vzc0tleV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBhY2Nlc3NLZXkoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYWNjZXNzS2V5Jyk7XG4gICAgfVxuICAgIHNldCBhY2Nlc3NLZXkodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjY2Vzc0tleScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duRWRpdG9yT3B0aW9ucy5hY3RpdmVTdGF0ZUVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgYWN0aXZlU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhY3RpdmVTdGF0ZUVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGFjdGl2ZVN0YXRlRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2FjdGl2ZVN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duRWRpdG9yT3B0aW9ucy5idXR0b25zXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGJ1dHRvbnMoKTogQXJyYXk8RHJvcERvd25QcmVkZWZpbmVkQnV0dG9uIHwgVGV4dEVkaXRvckJ1dHRvbj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdidXR0b25zJyk7XG4gICAgfVxuICAgIHNldCBidXR0b25zKHZhbHVlOiBBcnJheTxEcm9wRG93blByZWRlZmluZWRCdXR0b24gfCBUZXh0RWRpdG9yQnV0dG9uPikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2J1dHRvbnMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLmN1c3RvbUl0ZW1DcmVhdGVFdmVudF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBjdXN0b21JdGVtQ3JlYXRlRXZlbnQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY3VzdG9tSXRlbUNyZWF0ZUV2ZW50Jyk7XG4gICAgfVxuICAgIHNldCBjdXN0b21JdGVtQ3JlYXRlRXZlbnQodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2N1c3RvbUl0ZW1DcmVhdGVFdmVudCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpEYXRhRXhwcmVzc2lvbk1peGluT3B0aW9ucy5kYXRhU291cmNlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRhdGFTb3VyY2UoKTogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8Q29sbGVjdGlvbldpZGdldEl0ZW0gfCBhbnk+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGF0YVNvdXJjZScpO1xuICAgIH1cbiAgICBzZXQgZGF0YVNvdXJjZSh2YWx1ZTogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8Q29sbGVjdGlvbldpZGdldEl0ZW0gfCBhbnk+KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGF0YVNvdXJjZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duRWRpdG9yT3B0aW9ucy5kZWZlclJlbmRlcmluZ11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkZWZlclJlbmRlcmluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGVmZXJSZW5kZXJpbmcnKTtcbiAgICB9XG4gICAgc2V0IGRlZmVyUmVuZGVyaW5nKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGVmZXJSZW5kZXJpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5kaXNhYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGRpc2FibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RGF0YUV4cHJlc3Npb25NaXhpbk9wdGlvbnMuZGlzcGxheUV4cHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZGlzcGxheUV4cHIoKTogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkaXNwbGF5RXhwcicpO1xuICAgIH1cbiAgICBzZXQgZGlzcGxheUV4cHIodmFsdWU6IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzcGxheUV4cHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkxpc3RPcHRpb25zLmRpc3BsYXlWYWx1ZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkaXNwbGF5VmFsdWUoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzcGxheVZhbHVlJyk7XG4gICAgfVxuICAgIHNldCBkaXNwbGF5VmFsdWUodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Rpc3BsYXlWYWx1ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duRWRpdG9yT3B0aW9ucy5kcm9wRG93bkJ1dHRvblRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRyb3BEb3duQnV0dG9uVGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZHJvcERvd25CdXR0b25UZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgZHJvcERvd25CdXR0b25UZW1wbGF0ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZHJvcERvd25CdXR0b25UZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMuZHJvcERvd25PcHRpb25zXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGRyb3BEb3duT3B0aW9ucygpOiBkeFBvcHVwT3B0aW9ucyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2Ryb3BEb3duT3B0aW9ucycpO1xuICAgIH1cbiAgICBzZXQgZHJvcERvd25PcHRpb25zKHZhbHVlOiBkeFBvcHVwT3B0aW9ucykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Ryb3BEb3duT3B0aW9ucycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnRPcHRpb25zLmVsZW1lbnRBdHRyXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGVsZW1lbnRBdHRyKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VsZW1lbnRBdHRyJyk7XG4gICAgfVxuICAgIHNldCBlbGVtZW50QXR0cih2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZWxlbWVudEF0dHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLmZpZWxkVGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZmllbGRUZW1wbGF0ZSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdmaWVsZFRlbXBsYXRlJyk7XG4gICAgfVxuICAgIHNldCBmaWVsZFRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdmaWVsZFRlbXBsYXRlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VGV4dEVkaXRvck9wdGlvbnMuZm9jdXNTdGF0ZUVuYWJsZWRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZm9jdXNTdGF0ZUVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2ZvY3VzU3RhdGVFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBmb2N1c1N0YXRlRW5hYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2ZvY3VzU3RhdGVFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25MaXN0T3B0aW9ucy5ncm91cGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGdyb3VwZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2dyb3VwZWQnKTtcbiAgICB9XG4gICAgc2V0IGdyb3VwZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdncm91cGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25MaXN0T3B0aW9ucy5ncm91cFRlbXBsYXRlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGdyb3VwVGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZ3JvdXBUZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgZ3JvdXBUZW1wbGF0ZSh2YWx1ZTogYW55KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZ3JvdXBUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnRPcHRpb25zLmhlaWdodF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBoZWlnaHQoKTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdoZWlnaHQnKTtcbiAgICB9XG4gICAgc2V0IGhlaWdodCh2YWx1ZTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdoZWlnaHQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5oaW50XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhpbnQoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGludCcpO1xuICAgIH1cbiAgICBzZXQgaGludCh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGludCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFRleHRFZGl0b3JPcHRpb25zLmhvdmVyU3RhdGVFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGhvdmVyU3RhdGVFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdob3ZlclN0YXRlRW5hYmxlZCcpO1xuICAgIH1cbiAgICBzZXQgaG92ZXJTdGF0ZUVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdob3ZlclN0YXRlRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFRleHRFZGl0b3JPcHRpb25zLmlucHV0QXR0cl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBpbnB1dEF0dHIoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaW5wdXRBdHRyJyk7XG4gICAgfVxuICAgIHNldCBpbnB1dEF0dHIodmFsdWU6IGFueSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2lucHV0QXR0cicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpFZGl0b3JPcHRpb25zLmlzRGlydHldXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaXNEaXJ0eSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaXNEaXJ0eScpO1xuICAgIH1cbiAgICBzZXQgaXNEaXJ0eSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2lzRGlydHknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RWRpdG9yT3B0aW9ucy5pc1ZhbGlkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGlzVmFsaWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2lzVmFsaWQnKTtcbiAgICB9XG4gICAgc2V0IGlzVmFsaWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpc1ZhbGlkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRhdGFFeHByZXNzaW9uTWl4aW5PcHRpb25zLml0ZW1zXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGl0ZW1zKCk6IEFycmF5PGFueSB8IHsgZGlzYWJsZWQ/OiBib29sZWFuLCBodG1sPzogc3RyaW5nLCB0ZW1wbGF0ZT86IGFueSwgdGV4dD86IHN0cmluZywgdmlzaWJsZT86IGJvb2xlYW4gfT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdpdGVtcycpO1xuICAgIH1cbiAgICBzZXQgaXRlbXModmFsdWU6IEFycmF5PGFueSB8IHsgZGlzYWJsZWQ/OiBib29sZWFuLCBodG1sPzogc3RyaW5nLCB0ZW1wbGF0ZT86IGFueSwgdGV4dD86IHN0cmluZywgdmlzaWJsZT86IGJvb2xlYW4gfT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtcycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpEYXRhRXhwcmVzc2lvbk1peGluT3B0aW9ucy5pdGVtVGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaXRlbVRlbXBsYXRlKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2l0ZW1UZW1wbGF0ZScpO1xuICAgIH1cbiAgICBzZXQgaXRlbVRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdpdGVtVGVtcGxhdGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhUZXh0RWRpdG9yT3B0aW9ucy5sYWJlbF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBsYWJlbCgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdsYWJlbCcpO1xuICAgIH1cbiAgICBzZXQgbGFiZWwodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2xhYmVsJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VGV4dEVkaXRvck9wdGlvbnMubGFiZWxNb2RlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGxhYmVsTW9kZSgpOiBMYWJlbE1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdsYWJlbE1vZGUnKTtcbiAgICB9XG4gICAgc2V0IGxhYmVsTW9kZSh2YWx1ZTogTGFiZWxNb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbGFiZWxNb2RlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4VGV4dEJveE9wdGlvbnMubWF4TGVuZ3RoXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG1heExlbmd0aCgpOiBudW1iZXIgfCBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdtYXhMZW5ndGgnKTtcbiAgICB9XG4gICAgc2V0IG1heExlbmd0aCh2YWx1ZTogbnVtYmVyIHwgc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbWF4TGVuZ3RoJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25MaXN0T3B0aW9ucy5taW5TZWFyY2hMZW5ndGhdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbWluU2VhcmNoTGVuZ3RoKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21pblNlYXJjaExlbmd0aCcpO1xuICAgIH1cbiAgICBzZXQgbWluU2VhcmNoTGVuZ3RoKHZhbHVlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdtaW5TZWFyY2hMZW5ndGgnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhUZXh0RWRpdG9yT3B0aW9ucy5uYW1lXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG5hbWUoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbmFtZScpO1xuICAgIH1cbiAgICBzZXQgbmFtZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignbmFtZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duTGlzdE9wdGlvbnMubm9EYXRhVGV4dF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBub0RhdGFUZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ25vRGF0YVRleHQnKTtcbiAgICB9XG4gICAgc2V0IG5vRGF0YVRleHQodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ25vRGF0YVRleHQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkVkaXRvck9wdGlvbnMub3BlbmVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IG9wZW5lZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb3BlbmVkJyk7XG4gICAgfVxuICAgIHNldCBvcGVuZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdvcGVuZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9wZW5PbkZpZWxkQ2xpY2tdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgb3Blbk9uRmllbGRDbGljaygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignb3Blbk9uRmllbGRDbGljaycpO1xuICAgIH1cbiAgICBzZXQgb3Blbk9uRmllbGRDbGljayh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ29wZW5PbkZpZWxkQ2xpY2snLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLnBsYWNlaG9sZGVyXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBsYWNlaG9sZGVyKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3BsYWNlaG9sZGVyJyk7XG4gICAgfVxuICAgIHNldCBwbGFjZWhvbGRlcih2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncGxhY2Vob2xkZXInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RWRpdG9yT3B0aW9ucy5yZWFkT25seV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCByZWFkT25seSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncmVhZE9ubHknKTtcbiAgICB9XG4gICAgc2V0IHJlYWRPbmx5KHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncmVhZE9ubHknLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5ydGxFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHJ0bEVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3J0bEVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHJ0bEVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdydGxFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25MaXN0T3B0aW9ucy5zZWFyY2hFbmFibGVkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNlYXJjaEVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NlYXJjaEVuYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IHNlYXJjaEVuYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzZWFyY2hFbmFibGVkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25MaXN0T3B0aW9ucy5zZWFyY2hFeHByXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNlYXJjaEV4cHIoKTogRnVuY3Rpb24gfCBzdHJpbmcgfCBBcnJheTxGdW5jdGlvbiB8IHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzZWFyY2hFeHByJyk7XG4gICAgfVxuICAgIHNldCBzZWFyY2hFeHByKHZhbHVlOiBGdW5jdGlvbiB8IHN0cmluZyB8IEFycmF5PEZ1bmN0aW9uIHwgc3RyaW5nPikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NlYXJjaEV4cHInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkxpc3RPcHRpb25zLnNlYXJjaE1vZGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2VhcmNoTW9kZSgpOiBTaW1wbGlmaWVkU2VhcmNoTW9kZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NlYXJjaE1vZGUnKTtcbiAgICB9XG4gICAgc2V0IHNlYXJjaE1vZGUodmFsdWU6IFNpbXBsaWZpZWRTZWFyY2hNb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2VhcmNoTW9kZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duTGlzdE9wdGlvbnMuc2VhcmNoVGltZW91dF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzZWFyY2hUaW1lb3V0KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NlYXJjaFRpbWVvdXQnKTtcbiAgICB9XG4gICAgc2V0IHNlYXJjaFRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NlYXJjaFRpbWVvdXQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEcm9wRG93bkxpc3RPcHRpb25zLnNlbGVjdGVkSXRlbV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzZWxlY3RlZEl0ZW0oKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2VsZWN0ZWRJdGVtJyk7XG4gICAgfVxuICAgIHNldCBzZWxlY3RlZEl0ZW0odmFsdWU6IGFueSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NlbGVjdGVkSXRlbScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFRleHRFZGl0b3JPcHRpb25zLnNob3dDbGVhckJ1dHRvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93Q2xlYXJCdXR0b24oKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Nob3dDbGVhckJ1dHRvbicpO1xuICAgIH1cbiAgICBzZXQgc2hvd0NsZWFyQnV0dG9uKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd0NsZWFyQnV0dG9uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25MaXN0T3B0aW9ucy5zaG93RGF0YUJlZm9yZVNlYXJjaF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93RGF0YUJlZm9yZVNlYXJjaCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2hvd0RhdGFCZWZvcmVTZWFyY2gnKTtcbiAgICB9XG4gICAgc2V0IHNob3dEYXRhQmVmb3JlU2VhcmNoKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd0RhdGFCZWZvcmVTZWFyY2gnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLnNob3dEcm9wRG93bkJ1dHRvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzaG93RHJvcERvd25CdXR0b24oKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3Nob3dEcm9wRG93bkJ1dHRvbicpO1xuICAgIH1cbiAgICBzZXQgc2hvd0Ryb3BEb3duQnV0dG9uKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignc2hvd0Ryb3BEb3duQnV0dG9uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5zaG93U2VsZWN0aW9uQ29udHJvbHNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2hvd1NlbGVjdGlvbkNvbnRyb2xzKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaG93U2VsZWN0aW9uQ29udHJvbHMnKTtcbiAgICB9XG4gICAgc2V0IHNob3dTZWxlY3Rpb25Db250cm9scyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Nob3dTZWxlY3Rpb25Db250cm9scycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFRleHRFZGl0b3JPcHRpb25zLnNwZWxsY2hlY2tdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc3BlbGxjaGVjaygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc3BlbGxjaGVjaycpO1xuICAgIH1cbiAgICBzZXQgc3BlbGxjaGVjayh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NwZWxsY2hlY2snLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhUZXh0RWRpdG9yT3B0aW9ucy5zdHlsaW5nTW9kZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBzdHlsaW5nTW9kZSgpOiBFZGl0b3JTdHlsZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3N0eWxpbmdNb2RlJyk7XG4gICAgfVxuICAgIHNldCBzdHlsaW5nTW9kZSh2YWx1ZTogRWRpdG9yU3R5bGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzdHlsaW5nTW9kZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLnRhYkluZGV4XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRhYkluZGV4KCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3RhYkluZGV4Jyk7XG4gICAgfVxuICAgIHNldCB0YWJJbmRleCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGFiSW5kZXgnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhUZXh0RWRpdG9yT3B0aW9ucy50ZXh0XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndGV4dCcpO1xuICAgIH1cbiAgICBzZXQgdGV4dCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndGV4dCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duTGlzdE9wdGlvbnMudXNlSXRlbVRleHRBc1RpdGxlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHVzZUl0ZW1UZXh0QXNUaXRsZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndXNlSXRlbVRleHRBc1RpdGxlJyk7XG4gICAgfVxuICAgIHNldCB1c2VJdGVtVGV4dEFzVGl0bGUodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd1c2VJdGVtVGV4dEFzVGl0bGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RWRpdG9yT3B0aW9ucy52YWxpZGF0aW9uRXJyb3JdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmFsaWRhdGlvbkVycm9yKCk6IGFueSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbGlkYXRpb25FcnJvcicpO1xuICAgIH1cbiAgICBzZXQgdmFsaWRhdGlvbkVycm9yKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2YWxpZGF0aW9uRXJyb3InLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RWRpdG9yT3B0aW9ucy52YWxpZGF0aW9uRXJyb3JzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHZhbGlkYXRpb25FcnJvcnMoKTogQXJyYXk8YW55PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbGlkYXRpb25FcnJvcnMnKTtcbiAgICB9XG4gICAgc2V0IHZhbGlkYXRpb25FcnJvcnModmFsdWU6IEFycmF5PGFueT4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2YWxpZGF0aW9uRXJyb3JzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkVkaXRvck9wdGlvbnMudmFsaWRhdGlvbk1lc3NhZ2VNb2RlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHZhbGlkYXRpb25NZXNzYWdlTW9kZSgpOiBWYWxpZGF0aW9uTWVzc2FnZU1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2YWxpZGF0aW9uTWVzc2FnZU1vZGUnKTtcbiAgICB9XG4gICAgc2V0IHZhbGlkYXRpb25NZXNzYWdlTW9kZSh2YWx1ZTogVmFsaWRhdGlvbk1lc3NhZ2VNb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmFsaWRhdGlvbk1lc3NhZ2VNb2RlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RHJvcERvd25FZGl0b3JPcHRpb25zLnZhbGlkYXRpb25NZXNzYWdlUG9zaXRpb25dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmFsaWRhdGlvbk1lc3NhZ2VQb3NpdGlvbigpOiBQb3NpdGlvbiB8IE1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2YWxpZGF0aW9uTWVzc2FnZVBvc2l0aW9uJyk7XG4gICAgfVxuICAgIHNldCB2YWxpZGF0aW9uTWVzc2FnZVBvc2l0aW9uKHZhbHVlOiBQb3NpdGlvbiB8IE1vZGUpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2YWxpZGF0aW9uTWVzc2FnZVBvc2l0aW9uJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkVkaXRvck9wdGlvbnMudmFsaWRhdGlvblN0YXR1c11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB2YWxpZGF0aW9uU3RhdHVzKCk6IFZhbGlkYXRpb25TdGF0dXMge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2YWxpZGF0aW9uU3RhdHVzJyk7XG4gICAgfVxuICAgIHNldCB2YWxpZGF0aW9uU3RhdHVzKHZhbHVlOiBWYWxpZGF0aW9uU3RhdHVzKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmFsaWRhdGlvblN0YXR1cycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duTGlzdE9wdGlvbnMudmFsdWVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmFsdWUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmFsdWUnKTtcbiAgICB9XG4gICAgc2V0IHZhbHVlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd2YWx1ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMudmFsdWVDaGFuZ2VFdmVudF1cbiAgICBcbiAgICAgKiBAZGVwcmVjYXRlZCBbZGVwTm90ZTpkeFNlbGVjdEJveE9wdGlvbnMudmFsdWVDaGFuZ2VFdmVudF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB2YWx1ZUNoYW5nZUV2ZW50KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbHVlQ2hhbmdlRXZlbnQnKTtcbiAgICB9XG4gICAgc2V0IHZhbHVlQ2hhbmdlRXZlbnQodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3ZhbHVlQ2hhbmdlRXZlbnQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RGF0YUV4cHJlc3Npb25NaXhpbk9wdGlvbnMudmFsdWVFeHByXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHZhbHVlRXhwcigpOiBGdW5jdGlvbiB8IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3ZhbHVlRXhwcicpO1xuICAgIH1cbiAgICBzZXQgdmFsdWVFeHByKHZhbHVlOiBGdW5jdGlvbiB8IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3ZhbHVlRXhwcicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpXaWRnZXRPcHRpb25zLnZpc2libGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmlzaWJsZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlzaWJsZScpO1xuICAgIH1cbiAgICBzZXQgdmlzaWJsZSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3Zpc2libGUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy53aWR0aF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB3aWR0aCgpOiBudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3dpZHRoJyk7XG4gICAgfVxuICAgIHNldCB3aWR0aCh2YWx1ZTogbnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd3aWR0aCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERyb3BEb3duTGlzdE9wdGlvbnMud3JhcEl0ZW1UZXh0XVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHdyYXBJdGVtVGV4dCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignd3JhcEl0ZW1UZXh0Jyk7XG4gICAgfVxuICAgIHNldCB3cmFwSXRlbVRleHQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd3cmFwSXRlbVRleHQnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vbkNoYW5nZV1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjxDaGFuZ2VFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uQ2xvc2VkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkNsb3NlZDogRXZlbnRFbWl0dGVyPENsb3NlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMub25Db250ZW50UmVhZHldXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ29udGVudFJlYWR5OiBFdmVudEVtaXR0ZXI8Q29udGVudFJlYWR5RXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vbkNvcHldXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ29weTogRXZlbnRFbWl0dGVyPENvcHlFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uQ3VzdG9tSXRlbUNyZWF0aW5nXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkN1c3RvbUl0ZW1DcmVhdGluZzogRXZlbnRFbWl0dGVyPEN1c3RvbUl0ZW1DcmVhdGluZ0V2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMub25DdXRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ3V0OiBFdmVudEVtaXR0ZXI8Q3V0RXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vbkRpc3Bvc2luZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25EaXNwb3Npbmc6IEV2ZW50RW1pdHRlcjxEaXNwb3NpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uRW50ZXJLZXldXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uRW50ZXJLZXk6IEV2ZW50RW1pdHRlcjxFbnRlcktleUV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMub25Gb2N1c0luXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkZvY3VzSW46IEV2ZW50RW1pdHRlcjxGb2N1c0luRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vbkZvY3VzT3V0XVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkZvY3VzT3V0OiBFdmVudEVtaXR0ZXI8Rm9jdXNPdXRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uSW5pdGlhbGl6ZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uSW5pdGlhbGl6ZWQ6IEV2ZW50RW1pdHRlcjxJbml0aWFsaXplZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMub25JbnB1dF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25JbnB1dDogRXZlbnRFbWl0dGVyPElucHV0RXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vbkl0ZW1DbGlja11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25JdGVtQ2xpY2s6IEV2ZW50RW1pdHRlcjxJdGVtQ2xpY2tFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uS2V5RG93bl1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25LZXlEb3duOiBFdmVudEVtaXR0ZXI8S2V5RG93bkV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMub25LZXlVcF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25LZXlVcDogRXZlbnRFbWl0dGVyPEtleVVwRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vbk9wZW5lZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25PcGVuZWQ6IEV2ZW50RW1pdHRlcjxPcGVuZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uT3B0aW9uQ2hhbmdlZF1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25PcHRpb25DaGFuZ2VkOiBFdmVudEVtaXR0ZXI8T3B0aW9uQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFtkZXNjcjpkeFNlbGVjdEJveE9wdGlvbnMub25QYXN0ZV1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25QYXN0ZTogRXZlbnRFbWl0dGVyPFBhc3RlRXZlbnQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogW2Rlc2NyOmR4U2VsZWN0Qm94T3B0aW9ucy5vblNlbGVjdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uU2VsZWN0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPFNlbGVjdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhTZWxlY3RCb3hPcHRpb25zLm9uVmFsdWVDaGFuZ2VkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblZhbHVlQ2hhbmdlZDogRXZlbnRFbWl0dGVyPFZhbHVlQ2hhbmdlZEV2ZW50PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGFjY2VwdEN1c3RvbVZhbHVlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBhY2Nlc3NLZXlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBidXR0b25zQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8RHJvcERvd25QcmVkZWZpbmVkQnV0dG9uIHwgVGV4dEVkaXRvckJ1dHRvbj4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY3VzdG9tSXRlbUNyZWF0ZUV2ZW50Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRhdGFTb3VyY2VDaGFuZ2U6IEV2ZW50RW1pdHRlcjxTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxDb2xsZWN0aW9uV2lkZ2V0SXRlbSB8IGFueT4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZGVmZXJSZW5kZXJpbmdDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRpc2FibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkaXNwbGF5RXhwckNoYW5nZTogRXZlbnRFbWl0dGVyPEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRpc3BsYXlWYWx1ZUNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBkcm9wRG93bkJ1dHRvblRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRyb3BEb3duT3B0aW9uc0NoYW5nZTogRXZlbnRFbWl0dGVyPGR4UG9wdXBPcHRpb25zPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGVsZW1lbnRBdHRyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGZpZWxkVGVtcGxhdGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZm9jdXNTdGF0ZUVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGdyb3VwZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGdyb3VwVGVtcGxhdGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGludENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBob3ZlclN0YXRlRW5hYmxlZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaW5wdXRBdHRyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGlzRGlydHlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGlzVmFsaWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGl0ZW1zQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8YW55IHwgeyBkaXNhYmxlZD86IGJvb2xlYW4sIGh0bWw/OiBzdHJpbmcsIHRlbXBsYXRlPzogYW55LCB0ZXh0Pzogc3RyaW5nLCB2aXNpYmxlPzogYm9vbGVhbiB9Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBpdGVtVGVtcGxhdGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbGFiZWxDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbGFiZWxNb2RlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8TGFiZWxNb2RlPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG1heExlbmd0aENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlciB8IHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBtaW5TZWFyY2hMZW5ndGhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgbmFtZUNoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBub0RhdGFUZXh0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9wZW5lZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb3Blbk9uRmllbGRDbGlja0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcGxhY2Vob2xkZXJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcmVhZE9ubHlDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJ0bEVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNlYXJjaEVuYWJsZWRDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNlYXJjaEV4cHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxGdW5jdGlvbiB8IHN0cmluZyB8IEFycmF5PEZ1bmN0aW9uIHwgc3RyaW5nPj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzZWFyY2hNb2RlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8U2ltcGxpZmllZFNlYXJjaE1vZGU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2VhcmNoVGltZW91dENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlcj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzZWxlY3RlZEl0ZW1DaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd0NsZWFyQnV0dG9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzaG93RGF0YUJlZm9yZVNlYXJjaENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2hvd0Ryb3BEb3duQnV0dG9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzaG93U2VsZWN0aW9uQ29udHJvbHNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHNwZWxsY2hlY2tDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHN0eWxpbmdNb2RlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8RWRpdG9yU3R5bGU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGFiSW5kZXhDaGFuZ2U6IEV2ZW50RW1pdHRlcjxudW1iZXI+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdGV4dENoYW5nZTogRXZlbnRFbWl0dGVyPHN0cmluZz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB1c2VJdGVtVGV4dEFzVGl0bGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZhbGlkYXRpb25FcnJvckNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWxpZGF0aW9uRXJyb3JzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8QXJyYXk8YW55Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWxpZGF0aW9uTWVzc2FnZU1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxWYWxpZGF0aW9uTWVzc2FnZU1vZGU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdmFsaWRhdGlvbk1lc3NhZ2VQb3NpdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPFBvc2l0aW9uIHwgTW9kZT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWxpZGF0aW9uU3RhdHVzQ2hhbmdlOiBFdmVudEVtaXR0ZXI8VmFsaWRhdGlvblN0YXR1cz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWx1ZUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2YWx1ZUNoYW5nZUV2ZW50Q2hhbmdlOiBFdmVudEVtaXR0ZXI8c3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZhbHVlRXhwckNoYW5nZTogRXZlbnRFbWl0dGVyPEZ1bmN0aW9uIHwgc3RyaW5nPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZpc2libGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHdpZHRoQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgd3JhcEl0ZW1UZXh0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6dW5kZWZpbmVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkJsdXI6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG5cbiAgICBASG9zdExpc3RlbmVyKCd2YWx1ZUNoYW5nZScsIFsnJGV2ZW50J10pIGNoYW5nZShfKSB7IH1cbiAgICBASG9zdExpc3RlbmVyKCdvbkJsdXInLCBbJyRldmVudCddKSB0b3VjaGVkID0gKF8pID0+IHt9O1xuXG5cbiAgICBAQ29udGVudENoaWxkcmVuKER4aUJ1dHRvbkNvbXBvbmVudClcbiAgICBnZXQgYnV0dG9uc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlCdXR0b25Db21wb25lbnQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignYnV0dG9ucycpO1xuICAgIH1cbiAgICBzZXQgYnV0dG9uc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2J1dHRvbnMnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgQENvbnRlbnRDaGlsZHJlbihEeGlJdGVtQ29tcG9uZW50KVxuICAgIGdldCBpdGVtc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlJdGVtQ29tcG9uZW50PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2l0ZW1zJyk7XG4gICAgfVxuICAgIHNldCBpdGVtc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2l0ZW1zJywgdmFsdWUpO1xuICAgIH1cblxuXG5cblxuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIG5nWm9uZTogTmdab25lLCB0ZW1wbGF0ZUhvc3Q6IER4VGVtcGxhdGVIb3N0LFxuICAgICAgICAgICAgcHJpdmF0ZSBfd2F0Y2hlckhlbHBlcjogV2F0Y2hlckhlbHBlcixcbiAgICAgICAgICAgIHByaXZhdGUgX2lkaDogSXRlcmFibGVEaWZmZXJIZWxwZXIsXG4gICAgICAgICAgICBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxuICAgICAgICAgICAgdHJhbnNmZXJTdGF0ZTogVHJhbnNmZXJTdGF0ZSxcbiAgICAgICAgICAgIEBJbmplY3QoUExBVEZPUk1fSUQpIHBsYXRmb3JtSWQ6IGFueSkge1xuXG4gICAgICAgIHN1cGVyKGVsZW1lbnRSZWYsIG5nWm9uZSwgdGVtcGxhdGVIb3N0LCBfd2F0Y2hlckhlbHBlciwgdHJhbnNmZXJTdGF0ZSwgcGxhdGZvcm1JZCk7XG5cbiAgICAgICAgdGhpcy5fY3JlYXRlRXZlbnRFbWl0dGVycyhbXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2NoYW5nZScsIGVtaXQ6ICdvbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnY2xvc2VkJywgZW1pdDogJ29uQ2xvc2VkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdjb250ZW50UmVhZHknLCBlbWl0OiAnb25Db250ZW50UmVhZHknIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2NvcHknLCBlbWl0OiAnb25Db3B5JyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdjdXN0b21JdGVtQ3JlYXRpbmcnLCBlbWl0OiAnb25DdXN0b21JdGVtQ3JlYXRpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2N1dCcsIGVtaXQ6ICdvbkN1dCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZGlzcG9zaW5nJywgZW1pdDogJ29uRGlzcG9zaW5nJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdlbnRlcktleScsIGVtaXQ6ICdvbkVudGVyS2V5JyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdmb2N1c0luJywgZW1pdDogJ29uRm9jdXNJbicgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnZm9jdXNPdXQnLCBlbWl0OiAnb25Gb2N1c091dCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5pdGlhbGl6ZWQnLCBlbWl0OiAnb25Jbml0aWFsaXplZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaW5wdXQnLCBlbWl0OiAnb25JbnB1dCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaXRlbUNsaWNrJywgZW1pdDogJ29uSXRlbUNsaWNrJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdrZXlEb3duJywgZW1pdDogJ29uS2V5RG93bicgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAna2V5VXAnLCBlbWl0OiAnb25LZXlVcCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnb3BlbmVkJywgZW1pdDogJ29uT3BlbmVkJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdvcHRpb25DaGFuZ2VkJywgZW1pdDogJ29uT3B0aW9uQ2hhbmdlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncGFzdGUnLCBlbWl0OiAnb25QYXN0ZScgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnc2VsZWN0aW9uQ2hhbmdlZCcsIGVtaXQ6ICdvblNlbGVjdGlvbkNoYW5nZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3ZhbHVlQ2hhbmdlZCcsIGVtaXQ6ICdvblZhbHVlQ2hhbmdlZCcgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2FjY2VwdEN1c3RvbVZhbHVlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWNjZXNzS2V5Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYWN0aXZlU3RhdGVFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYnV0dG9uc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2N1c3RvbUl0ZW1DcmVhdGVFdmVudENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2RhdGFTb3VyY2VDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdkZWZlclJlbmRlcmluZ0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2Rpc2FibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZGlzcGxheUV4cHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdkaXNwbGF5VmFsdWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdkcm9wRG93bkJ1dHRvblRlbXBsYXRlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZHJvcERvd25PcHRpb25zQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZWxlbWVudEF0dHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdmaWVsZFRlbXBsYXRlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZm9jdXNTdGF0ZUVuYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdncm91cGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZ3JvdXBUZW1wbGF0ZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hlaWdodENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2hpbnRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdob3ZlclN0YXRlRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2lucHV0QXR0ckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2lzRGlydHlDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdpc1ZhbGlkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaXRlbXNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdpdGVtVGVtcGxhdGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdsYWJlbENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2xhYmVsTW9kZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ21heExlbmd0aENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ21pblNlYXJjaExlbmd0aENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ25hbWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdub0RhdGFUZXh0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnb3BlbmVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnb3Blbk9uRmllbGRDbGlja0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3BsYWNlaG9sZGVyQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncmVhZE9ubHlDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdydGxFbmFibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2VhcmNoRW5hYmxlZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NlYXJjaEV4cHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzZWFyY2hNb2RlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2VhcmNoVGltZW91dENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NlbGVjdGVkSXRlbUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dDbGVhckJ1dHRvbkNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3Nob3dEYXRhQmVmb3JlU2VhcmNoQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2hvd0Ryb3BEb3duQnV0dG9uQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc2hvd1NlbGVjdGlvbkNvbnRyb2xzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnc3BlbGxjaGVja0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3N0eWxpbmdNb2RlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndGFiSW5kZXhDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd0ZXh0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndXNlSXRlbVRleHRBc1RpdGxlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmFsaWRhdGlvbkVycm9yQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmFsaWRhdGlvbkVycm9yc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3ZhbGlkYXRpb25NZXNzYWdlTW9kZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3ZhbGlkYXRpb25NZXNzYWdlUG9zaXRpb25DaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2YWxpZGF0aW9uU3RhdHVzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmFsdWVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2YWx1ZUNoYW5nZUV2ZW50Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmFsdWVFeHByQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmlzaWJsZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3dpZHRoQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnd3JhcEl0ZW1UZXh0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnb25CbHVyJyB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIHRoaXMuX2lkaC5zZXRIb3N0KHRoaXMpO1xuICAgICAgICBvcHRpb25Ib3N0LnNldEhvc3QodGhpcyk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9jcmVhdGVJbnN0YW5jZShlbGVtZW50LCBvcHRpb25zKSB7XG5cbiAgICAgICAgcmV0dXJuIG5ldyBEeFNlbGVjdEJveChlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgICAgICB0aGlzLmV2ZW50SGVscGVyLmxvY2tlZFZhbHVlQ2hhbmdlRXZlbnQgPSB0cnVlO1xuICAgICAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgICAgIHRoaXMuZXZlbnRIZWxwZXIubG9ja2VkVmFsdWVDaGFuZ2VFdmVudCA9IGZhbHNlO1xuICAgIH1cblxuICAgIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xuICAgICAgICB0aGlzLmRpc2FibGVkID0gaXNEaXNhYmxlZDtcbiAgICB9XG5cbiAgICByZWdpc3Rlck9uQ2hhbmdlKGZuOiAoXzogYW55KSA9PiB2b2lkKTogdm9pZCB7IHRoaXMuY2hhbmdlID0gZm47IH1cbiAgICByZWdpc3Rlck9uVG91Y2hlZChmbjogKCkgPT4gdm9pZCk6IHZvaWQgeyB0aGlzLnRvdWNoZWQgPSBmbjsgfVxuXG4gICAgX2NyZWF0ZVdpZGdldChlbGVtZW50OiBhbnkpIHtcbiAgICAgICAgc3VwZXIuX2NyZWF0ZVdpZGdldChlbGVtZW50KTtcbiAgICAgICAgdGhpcy5pbnN0YW5jZS5vbignZm9jdXNPdXQnLCAoZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5ldmVudEhlbHBlci5maXJlTmdFdmVudCgnb25CbHVyJywgW2VdKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3lXaWRnZXQoKTtcbiAgICB9XG5cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgICAgIHN1cGVyLm5nT25DaGFuZ2VzKGNoYW5nZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygnYnV0dG9ucycsIGNoYW5nZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygnZGF0YVNvdXJjZScsIGNoYW5nZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhbmdlcygnaXRlbXMnLCBjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ3NlYXJjaEV4cHInLCBjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ3ZhbGlkYXRpb25FcnJvcnMnLCBjaGFuZ2VzKTtcbiAgICB9XG5cbiAgICBzZXR1cENoYW5nZXMocHJvcDogc3RyaW5nLCBjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgICAgIGlmICghKHByb3AgaW4gdGhpcy5fb3B0aW9uc1RvVXBkYXRlKSkge1xuICAgICAgICAgICAgdGhpcy5faWRoLnNldHVwKHByb3AsIGNoYW5nZXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdEb0NoZWNrKCkge1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnYnV0dG9ucycpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnZGF0YVNvdXJjZScpO1xuICAgICAgICB0aGlzLl9pZGguZG9DaGVjaygnaXRlbXMnKTtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ3NlYXJjaEV4cHInKTtcbiAgICAgICAgdGhpcy5faWRoLmRvQ2hlY2soJ3ZhbGlkYXRpb25FcnJvcnMnKTtcbiAgICAgICAgdGhpcy5fd2F0Y2hlckhlbHBlci5jaGVja1dhdGNoZXJzKCk7XG4gICAgICAgIHN1cGVyLm5nRG9DaGVjaygpO1xuICAgICAgICBzdXBlci5jbGVhckNoYW5nZWRPcHRpb25zKCk7XG4gICAgfVxuXG4gICAgX3NldE9wdGlvbihuYW1lOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcbiAgICAgICAgbGV0IGlzU2V0dXAgPSB0aGlzLl9pZGguc2V0dXBTaW5nbGUobmFtZSwgdmFsdWUpO1xuICAgICAgICBsZXQgaXNDaGFuZ2VkID0gdGhpcy5faWRoLmdldENoYW5nZXMobmFtZSwgdmFsdWUpICE9PSBudWxsO1xuXG4gICAgICAgIGlmIChpc1NldHVwIHx8IGlzQ2hhbmdlZCkge1xuICAgICAgICAgICAgc3VwZXIuX3NldE9wdGlvbihuYW1lLCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgICBEeGlCdXR0b25Nb2R1bGUsXG4gICAgRHhvT3B0aW9uc01vZHVsZSxcbiAgICBEeG9Ecm9wRG93bk9wdGlvbnNNb2R1bGUsXG4gICAgRHhvQW5pbWF0aW9uTW9kdWxlLFxuICAgIER4b0hpZGVNb2R1bGUsXG4gICAgRHhvRnJvbU1vZHVsZSxcbiAgICBEeG9Qb3NpdGlvbk1vZHVsZSxcbiAgICBEeG9BdE1vZHVsZSxcbiAgICBEeG9Cb3VuZGFyeU9mZnNldE1vZHVsZSxcbiAgICBEeG9Db2xsaXNpb25Nb2R1bGUsXG4gICAgRHhvTXlNb2R1bGUsXG4gICAgRHhvT2Zmc2V0TW9kdWxlLFxuICAgIER4b1RvTW9kdWxlLFxuICAgIER4b1Nob3dNb2R1bGUsXG4gICAgRHhpVG9vbGJhckl0ZW1Nb2R1bGUsXG4gICAgRHhpSXRlbU1vZHVsZSxcbiAgICBEeEludGVncmF0aW9uTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGVcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgRHhTZWxlY3RCb3hDb21wb25lbnRcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIER4U2VsZWN0Qm94Q29tcG9uZW50LFxuICAgIER4aUJ1dHRvbk1vZHVsZSxcbiAgICBEeG9PcHRpb25zTW9kdWxlLFxuICAgIER4b0Ryb3BEb3duT3B0aW9uc01vZHVsZSxcbiAgICBEeG9BbmltYXRpb25Nb2R1bGUsXG4gICAgRHhvSGlkZU1vZHVsZSxcbiAgICBEeG9Gcm9tTW9kdWxlLFxuICAgIER4b1Bvc2l0aW9uTW9kdWxlLFxuICAgIER4b0F0TW9kdWxlLFxuICAgIER4b0JvdW5kYXJ5T2Zmc2V0TW9kdWxlLFxuICAgIER4b0NvbGxpc2lvbk1vZHVsZSxcbiAgICBEeG9NeU1vZHVsZSxcbiAgICBEeG9PZmZzZXRNb2R1bGUsXG4gICAgRHhvVG9Nb2R1bGUsXG4gICAgRHhvU2hvd01vZHVsZSxcbiAgICBEeGlUb29sYmFySXRlbU1vZHVsZSxcbiAgICBEeGlJdGVtTW9kdWxlLFxuICAgIER4VGVtcGxhdGVNb2R1bGVcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBEeFNlbGVjdEJveE1vZHVsZSB7IH1cblxuaW1wb3J0IHR5cGUgKiBhcyBEeFNlbGVjdEJveFR5cGVzIGZyb20gXCJkZXZleHRyZW1lL3VpL3NlbGVjdF9ib3hfdHlwZXNcIjtcbmV4cG9ydCB7IER4U2VsZWN0Qm94VHlwZXMgfTtcblxuXG4iXX0=