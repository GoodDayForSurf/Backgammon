/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { TransferState, Component, NgModule, ElementRef, NgZone, PLATFORM_ID, Inject, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import DxDiagram from 'devextreme/ui/diagram';
import { DxComponent, DxTemplateHost, DxIntegrationModule, DxTemplateModule, NestedOptionHost, IterableDifferHelper, WatcherHelper } from 'devextreme-angular/core';
import { DxoContextMenuModule } from 'devextreme-angular/ui/nested';
import { DxiCommandModule } from 'devextreme-angular/ui/nested';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoContextToolboxModule } from 'devextreme-angular/ui/nested';
import { DxiCustomShapeModule } from 'devextreme-angular/ui/nested';
import { DxiConnectionPointModule } from 'devextreme-angular/ui/nested';
import { DxoDefaultItemPropertiesModule } from 'devextreme-angular/ui/nested';
import { DxoEdgesModule } from 'devextreme-angular/ui/nested';
import { DxoEditingModule } from 'devextreme-angular/ui/nested';
import { DxoExportModule } from 'devextreme-angular/ui/nested';
import { DxoGridSizeModule } from 'devextreme-angular/ui/nested';
import { DxoHistoryToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoMainToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoNodesModule } from 'devextreme-angular/ui/nested';
import { DxoAutoLayoutModule } from 'devextreme-angular/ui/nested';
import { DxoPageSizeModule } from 'devextreme-angular/ui/nested';
import { DxoPropertiesPanelModule } from 'devextreme-angular/ui/nested';
import { DxiTabModule } from 'devextreme-angular/ui/nested';
import { DxiGroupModule } from 'devextreme-angular/ui/nested';
import { DxoToolboxModule } from 'devextreme-angular/ui/nested';
import { DxoViewToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoZoomLevelModule } from 'devextreme-angular/ui/nested';
import { DxiCustomShapeComponent } from 'devextreme-angular/ui/nested';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
/**
 * [descr:dxDiagram]

 */
export class DxDiagramComponent extends DxComponent {
    _watcherHelper;
    _idh;
    instance = null;
    /**
     * [descr:dxDiagramOptions.autoZoomMode]
    
     */
    get autoZoomMode() {
        return this._getOption('autoZoomMode');
    }
    set autoZoomMode(value) {
        this._setOption('autoZoomMode', value);
    }
    /**
     * [descr:dxDiagramOptions.contextMenu]
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * [descr:dxDiagramOptions.contextToolbox]
    
     */
    get contextToolbox() {
        return this._getOption('contextToolbox');
    }
    set contextToolbox(value) {
        this._setOption('contextToolbox', value);
    }
    /**
     * [descr:dxDiagramOptions.customShapes]
    
     */
    get customShapes() {
        return this._getOption('customShapes');
    }
    set customShapes(value) {
        this._setOption('customShapes', value);
    }
    /**
     * [descr:dxDiagramOptions.customShapeTemplate]
    
     */
    get customShapeTemplate() {
        return this._getOption('customShapeTemplate');
    }
    set customShapeTemplate(value) {
        this._setOption('customShapeTemplate', value);
    }
    /**
     * [descr:dxDiagramOptions.customShapeToolboxTemplate]
    
     */
    get customShapeToolboxTemplate() {
        return this._getOption('customShapeToolboxTemplate');
    }
    set customShapeToolboxTemplate(value) {
        this._setOption('customShapeToolboxTemplate', value);
    }
    /**
     * [descr:dxDiagramOptions.defaultItemProperties]
    
     */
    get defaultItemProperties() {
        return this._getOption('defaultItemProperties');
    }
    set defaultItemProperties(value) {
        this._setOption('defaultItemProperties', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxDiagramOptions.edges]
    
     */
    get edges() {
        return this._getOption('edges');
    }
    set edges(value) {
        this._setOption('edges', value);
    }
    /**
     * [descr:dxDiagramOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxDiagramOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxDiagramOptions.fullScreen]
    
     */
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    /**
     * [descr:dxDiagramOptions.gridSize]
    
     */
    get gridSize() {
        return this._getOption('gridSize');
    }
    set gridSize(value) {
        this._setOption('gridSize', value);
    }
    /**
     * [descr:dxDiagramOptions.hasChanges]
    
     */
    get hasChanges() {
        return this._getOption('hasChanges');
    }
    set hasChanges(value) {
        this._setOption('hasChanges', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxDiagramOptions.historyToolbar]
    
     */
    get historyToolbar() {
        return this._getOption('historyToolbar');
    }
    set historyToolbar(value) {
        this._setOption('historyToolbar', value);
    }
    /**
     * [descr:dxDiagramOptions.mainToolbar]
    
     */
    get mainToolbar() {
        return this._getOption('mainToolbar');
    }
    set mainToolbar(value) {
        this._setOption('mainToolbar', value);
    }
    /**
     * [descr:dxDiagramOptions.nodes]
    
     */
    get nodes() {
        return this._getOption('nodes');
    }
    set nodes(value) {
        this._setOption('nodes', value);
    }
    /**
     * [descr:dxDiagramOptions.pageColor]
    
     */
    get pageColor() {
        return this._getOption('pageColor');
    }
    set pageColor(value) {
        this._setOption('pageColor', value);
    }
    /**
     * [descr:dxDiagramOptions.pageOrientation]
    
     */
    get pageOrientation() {
        return this._getOption('pageOrientation');
    }
    set pageOrientation(value) {
        this._setOption('pageOrientation', value);
    }
    /**
     * [descr:dxDiagramOptions.pageSize]
    
     */
    get pageSize() {
        return this._getOption('pageSize');
    }
    set pageSize(value) {
        this._setOption('pageSize', value);
    }
    /**
     * [descr:dxDiagramOptions.propertiesPanel]
    
     */
    get propertiesPanel() {
        return this._getOption('propertiesPanel');
    }
    set propertiesPanel(value) {
        this._setOption('propertiesPanel', value);
    }
    /**
     * [descr:dxDiagramOptions.readOnly]
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDiagramOptions.showGrid]
    
     */
    get showGrid() {
        return this._getOption('showGrid');
    }
    set showGrid(value) {
        this._setOption('showGrid', value);
    }
    /**
     * [descr:dxDiagramOptions.simpleView]
    
     */
    get simpleView() {
        return this._getOption('simpleView');
    }
    set simpleView(value) {
        this._setOption('simpleView', value);
    }
    /**
     * [descr:dxDiagramOptions.snapToGrid]
    
     */
    get snapToGrid() {
        return this._getOption('snapToGrid');
    }
    set snapToGrid(value) {
        this._setOption('snapToGrid', value);
    }
    /**
     * [descr:dxDiagramOptions.toolbox]
    
     */
    get toolbox() {
        return this._getOption('toolbox');
    }
    set toolbox(value) {
        this._setOption('toolbox', value);
    }
    /**
     * [descr:dxDiagramOptions.units]
    
     */
    get units() {
        return this._getOption('units');
    }
    set units(value) {
        this._setOption('units', value);
    }
    /**
     * [descr:dxDiagramOptions.useNativeScrolling]
    
     */
    get useNativeScrolling() {
        return this._getOption('useNativeScrolling');
    }
    set useNativeScrolling(value) {
        this._setOption('useNativeScrolling', value);
    }
    /**
     * [descr:dxDiagramOptions.viewToolbar]
    
     */
    get viewToolbar() {
        return this._getOption('viewToolbar');
    }
    set viewToolbar(value) {
        this._setOption('viewToolbar', value);
    }
    /**
     * [descr:dxDiagramOptions.viewUnits]
    
     */
    get viewUnits() {
        return this._getOption('viewUnits');
    }
    set viewUnits(value) {
        this._setOption('viewUnits', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxDiagramOptions.zoomLevel]
    
     */
    get zoomLevel() {
        return this._getOption('zoomLevel');
    }
    set zoomLevel(value) {
        this._setOption('zoomLevel', value);
    }
    /**
    
     * [descr:dxDiagramOptions.onContentReady]
    
    
     */
    onContentReady;
    /**
    
     * [descr:dxDiagramOptions.onCustomCommand]
    
    
     */
    onCustomCommand;
    /**
    
     * [descr:dxDiagramOptions.onDisposing]
    
    
     */
    onDisposing;
    /**
    
     * [descr:dxDiagramOptions.onInitialized]
    
    
     */
    onInitialized;
    /**
    
     * [descr:dxDiagramOptions.onItemClick]
    
    
     */
    onItemClick;
    /**
    
     * [descr:dxDiagramOptions.onItemDblClick]
    
    
     */
    onItemDblClick;
    /**
    
     * [descr:dxDiagramOptions.onOptionChanged]
    
    
     */
    onOptionChanged;
    /**
    
     * [descr:dxDiagramOptions.onRequestEditOperation]
    
    
     */
    onRequestEditOperation;
    /**
    
     * [descr:dxDiagramOptions.onRequestLayoutUpdate]
    
    
     */
    onRequestLayoutUpdate;
    /**
    
     * [descr:dxDiagramOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoZoomModeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextMenuChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextToolboxChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customShapesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customShapeTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customShapeToolboxTemplateChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    defaultItemPropertiesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    edgesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fullScreenChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    gridSizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hasChangesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    historyToolbarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    mainToolbarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nodesChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageColorChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageOrientationChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    propertiesPanelChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showGridChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    simpleViewChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    snapToGridChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolboxChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    unitsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeScrollingChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    viewToolbarChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    viewUnitsChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomLevelChange;
    get customShapesChildren() {
        return this._getOption('customShapes');
    }
    set customShapesChildren(value) {
        this.setChildren('customShapes', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'customCommand', emit: 'onCustomCommand' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemDblClick', emit: 'onItemDblClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'requestEditOperation', emit: 'onRequestEditOperation' },
            { subscribe: 'requestLayoutUpdate', emit: 'onRequestLayoutUpdate' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'autoZoomModeChange' },
            { emit: 'contextMenuChange' },
            { emit: 'contextToolboxChange' },
            { emit: 'customShapesChange' },
            { emit: 'customShapeTemplateChange' },
            { emit: 'customShapeToolboxTemplateChange' },
            { emit: 'defaultItemPropertiesChange' },
            { emit: 'disabledChange' },
            { emit: 'edgesChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'exportChange' },
            { emit: 'fullScreenChange' },
            { emit: 'gridSizeChange' },
            { emit: 'hasChangesChange' },
            { emit: 'heightChange' },
            { emit: 'historyToolbarChange' },
            { emit: 'mainToolbarChange' },
            { emit: 'nodesChange' },
            { emit: 'pageColorChange' },
            { emit: 'pageOrientationChange' },
            { emit: 'pageSizeChange' },
            { emit: 'propertiesPanelChange' },
            { emit: 'readOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showGridChange' },
            { emit: 'simpleViewChange' },
            { emit: 'snapToGridChange' },
            { emit: 'toolboxChange' },
            { emit: 'unitsChange' },
            { emit: 'useNativeScrollingChange' },
            { emit: 'viewToolbarChange' },
            { emit: 'viewUnitsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'zoomLevelChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxDiagram(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('customShapes', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('customShapes');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDiagramComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxDiagramComponent, selector: "dx-diagram", inputs: { autoZoomMode: "autoZoomMode", contextMenu: "contextMenu", contextToolbox: "contextToolbox", customShapes: "customShapes", customShapeTemplate: "customShapeTemplate", customShapeToolboxTemplate: "customShapeToolboxTemplate", defaultItemProperties: "defaultItemProperties", disabled: "disabled", edges: "edges", editing: "editing", elementAttr: "elementAttr", export: "export", fullScreen: "fullScreen", gridSize: "gridSize", hasChanges: "hasChanges", height: "height", historyToolbar: "historyToolbar", mainToolbar: "mainToolbar", nodes: "nodes", pageColor: "pageColor", pageOrientation: "pageOrientation", pageSize: "pageSize", propertiesPanel: "propertiesPanel", readOnly: "readOnly", rtlEnabled: "rtlEnabled", showGrid: "showGrid", simpleView: "simpleView", snapToGrid: "snapToGrid", toolbox: "toolbox", units: "units", useNativeScrolling: "useNativeScrolling", viewToolbar: "viewToolbar", viewUnits: "viewUnits", visible: "visible", width: "width", zoomLevel: "zoomLevel" }, outputs: { onContentReady: "onContentReady", onCustomCommand: "onCustomCommand", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemDblClick: "onItemDblClick", onOptionChanged: "onOptionChanged", onRequestEditOperation: "onRequestEditOperation", onRequestLayoutUpdate: "onRequestLayoutUpdate", onSelectionChanged: "onSelectionChanged", autoZoomModeChange: "autoZoomModeChange", contextMenuChange: "contextMenuChange", contextToolboxChange: "contextToolboxChange", customShapesChange: "customShapesChange", customShapeTemplateChange: "customShapeTemplateChange", customShapeToolboxTemplateChange: "customShapeToolboxTemplateChange", defaultItemPropertiesChange: "defaultItemPropertiesChange", disabledChange: "disabledChange", edgesChange: "edgesChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", exportChange: "exportChange", fullScreenChange: "fullScreenChange", gridSizeChange: "gridSizeChange", hasChangesChange: "hasChangesChange", heightChange: "heightChange", historyToolbarChange: "historyToolbarChange", mainToolbarChange: "mainToolbarChange", nodesChange: "nodesChange", pageColorChange: "pageColorChange", pageOrientationChange: "pageOrientationChange", pageSizeChange: "pageSizeChange", propertiesPanelChange: "propertiesPanelChange", readOnlyChange: "readOnlyChange", rtlEnabledChange: "rtlEnabledChange", showGridChange: "showGridChange", simpleViewChange: "simpleViewChange", snapToGridChange: "snapToGridChange", toolboxChange: "toolboxChange", unitsChange: "unitsChange", useNativeScrollingChange: "useNativeScrollingChange", viewToolbarChange: "viewToolbarChange", viewUnitsChange: "viewUnitsChange", visibleChange: "visibleChange", widthChange: "widthChange", zoomLevelChange: "zoomLevelChange" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "customShapesChildren", predicate: DxiCustomShapeComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDiagramComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-diagram',
                    template: '',
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { autoZoomMode: [{
                type: Input
            }], contextMenu: [{
                type: Input
            }], contextToolbox: [{
                type: Input
            }], customShapes: [{
                type: Input
            }], customShapeTemplate: [{
                type: Input
            }], customShapeToolboxTemplate: [{
                type: Input
            }], defaultItemProperties: [{
                type: Input
            }], disabled: [{
                type: Input
            }], edges: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], export: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], gridSize: [{
                type: Input
            }], hasChanges: [{
                type: Input
            }], height: [{
                type: Input
            }], historyToolbar: [{
                type: Input
            }], mainToolbar: [{
                type: Input
            }], nodes: [{
                type: Input
            }], pageColor: [{
                type: Input
            }], pageOrientation: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], propertiesPanel: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showGrid: [{
                type: Input
            }], simpleView: [{
                type: Input
            }], snapToGrid: [{
                type: Input
            }], toolbox: [{
                type: Input
            }], units: [{
                type: Input
            }], useNativeScrolling: [{
                type: Input
            }], viewToolbar: [{
                type: Input
            }], viewUnits: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], zoomLevel: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onCustomCommand: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemDblClick: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onRequestEditOperation: [{
                type: Output
            }], onRequestLayoutUpdate: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], autoZoomModeChange: [{
                type: Output
            }], contextMenuChange: [{
                type: Output
            }], contextToolboxChange: [{
                type: Output
            }], customShapesChange: [{
                type: Output
            }], customShapeTemplateChange: [{
                type: Output
            }], customShapeToolboxTemplateChange: [{
                type: Output
            }], defaultItemPropertiesChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], edgesChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], fullScreenChange: [{
                type: Output
            }], gridSizeChange: [{
                type: Output
            }], hasChangesChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], historyToolbarChange: [{
                type: Output
            }], mainToolbarChange: [{
                type: Output
            }], nodesChange: [{
                type: Output
            }], pageColorChange: [{
                type: Output
            }], pageOrientationChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }], propertiesPanelChange: [{
                type: Output
            }], readOnlyChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], showGridChange: [{
                type: Output
            }], simpleViewChange: [{
                type: Output
            }], snapToGridChange: [{
                type: Output
            }], toolboxChange: [{
                type: Output
            }], unitsChange: [{
                type: Output
            }], useNativeScrollingChange: [{
                type: Output
            }], viewToolbarChange: [{
                type: Output
            }], viewUnitsChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], zoomLevelChange: [{
                type: Output
            }], customShapesChildren: [{
                type: ContentChildren,
                args: [DxiCustomShapeComponent]
            }] } });
export class DxDiagramModule {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDiagramModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxDiagramModule, declarations: [DxDiagramComponent], imports: [DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxDiagramComponent, DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxTemplateModule] });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDiagramModule, imports: [DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxIntegrationModule,
            DxTemplateModule, DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxTemplateModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxDiagramModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoContextMenuModule,
                        DxiCommandModule,
                        DxiItemModule,
                        DxoContextToolboxModule,
                        DxiCustomShapeModule,
                        DxiConnectionPointModule,
                        DxoDefaultItemPropertiesModule,
                        DxoEdgesModule,
                        DxoEditingModule,
                        DxoExportModule,
                        DxoGridSizeModule,
                        DxoHistoryToolbarModule,
                        DxoMainToolbarModule,
                        DxoNodesModule,
                        DxoAutoLayoutModule,
                        DxoPageSizeModule,
                        DxoPropertiesPanelModule,
                        DxiTabModule,
                        DxiGroupModule,
                        DxoToolboxModule,
                        DxoViewToolbarModule,
                        DxoZoomLevelModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    declarations: [
                        DxDiagramComponent
                    ],
                    exports: [
                        DxDiagramComponent,
                        DxoContextMenuModule,
                        DxiCommandModule,
                        DxiItemModule,
                        DxoContextToolboxModule,
                        DxiCustomShapeModule,
                        DxiConnectionPointModule,
                        DxoDefaultItemPropertiesModule,
                        DxoEdgesModule,
                        DxoEditingModule,
                        DxoExportModule,
                        DxoGridSizeModule,
                        DxoHistoryToolbarModule,
                        DxoMainToolbarModule,
                        DxoNodesModule,
                        DxoAutoLayoutModule,
                        DxoPageSizeModule,
                        DxoPropertiesPanelModule,
                        DxiTabModule,
                        DxiGroupModule,
                        DxoToolboxModule,
                        DxoViewToolbarModule,
                        DxoZoomLevelModule,
                        DxTemplateModule
                    ]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9kaXN0L3VpL2RpYWdyYW0vaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFHcEMsT0FBTyxFQUNILGFBQWEsRUFDYixTQUFTLEVBQ1QsUUFBUSxFQUNSLFVBQVUsRUFDVixNQUFNLEVBQ04sV0FBVyxFQUNYLE1BQU0sRUFFTixLQUFLLEVBQ0wsTUFBTSxFQUVOLFlBQVksRUFJWixlQUFlLEVBQ2YsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBUXZCLE9BQU8sU0FBUyxNQUFNLHVCQUF1QixDQUFDO0FBRzlDLE9BQU8sRUFDSCxXQUFXLEVBQ1gsY0FBYyxFQUNkLG1CQUFtQixFQUNuQixnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2hCLE1BQU0seUJBQXlCLENBQUM7QUFFakMsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3ZFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3BFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3hFLE9BQU8sRUFBRSw4QkFBOEIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzlFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDakUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDdkUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzlELE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDcEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFFbEUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sOEJBQThCLENBQUM7OztBQUl2RTs7O0dBR0c7QUFXSCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsV0FBVztJQWl6Qi9CO0lBQ0E7SUFqekJoQixRQUFRLEdBQWMsSUFBSSxDQUFDO0lBRTNCOzs7T0FHRztJQUNILElBQ0ksWUFBWTtRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsS0FBbUI7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBdUU7UUFDbkYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksY0FBYztRQUNkLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLGNBQWMsQ0FBQyxLQUFnTDtRQUMvTCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFlBQVk7UUFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLEtBQTY3QjtRQUMxOEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksbUJBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFJLG1CQUFtQixDQUFDLEtBQVU7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSwwQkFBMEI7UUFDMUIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNELElBQUksMEJBQTBCLENBQUMsS0FBVTtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLHFCQUFxQjtRQUNyQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBSSxxQkFBcUIsQ0FBQyxLQUE0UztRQUNsVSxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBOHRCO1FBQ3B1QixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxPQUFPO1FBQ1AsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUErUjtRQUN2UyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUFVO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE1BQU07UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLEtBQTRCO1FBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFVBQVU7UUFDVixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQUksVUFBVSxDQUFDLEtBQWM7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBeUQ7UUFDbEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxNQUFNO1FBQ04sT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUE2QztRQUNwRCxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxjQUFjO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQUksY0FBYyxDQUFDLEtBQXVFO1FBQ3RGLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsSUFBSSxXQUFXLENBQUMsS0FBdUU7UUFDbkYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBbzVCO1FBQzE1QixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFhO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLGVBQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQ0QsSUFBSSxlQUFlLENBQUMsS0FBc0I7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxRQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFtSDtRQUM1SCxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxlQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUNELElBQUksZUFBZSxDQUFDLEtBQStNO1FBQy9OLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksUUFBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBYztRQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFjO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLFFBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksVUFBVTtRQUNWLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0QsSUFBSSxVQUFVLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxVQUFVO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxJQUFJLFVBQVUsQ0FBQyxLQUFjO1FBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQTJTO1FBQ25ULElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLEtBQVk7UUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFJLGtCQUFrQixDQUFDLEtBQWM7UUFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxLQUF1RTtRQUNuRixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0gsSUFDSSxTQUFTO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFZO1FBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFHRDs7O09BR0c7SUFDSCxJQUNJLE9BQU87UUFDUCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUNELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksS0FBSztRQUNMLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBQ0QsSUFBSSxLQUFLLENBQUMsS0FBNkM7UUFDbkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUdEOzs7T0FHRztJQUNILElBQ0ksU0FBUztRQUNULE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0QsSUFBSSxTQUFTLENBQUMsS0FBcUU7UUFDL0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFrQztJQUUxRDs7Ozs7T0FLRztJQUNPLGVBQWUsQ0FBbUM7SUFFNUQ7Ozs7O09BS0c7SUFDTyxXQUFXLENBQStCO0lBRXBEOzs7OztPQUtHO0lBQ08sYUFBYSxDQUFpQztJQUV4RDs7Ozs7T0FLRztJQUNPLFdBQVcsQ0FBK0I7SUFFcEQ7Ozs7O09BS0c7SUFDTyxjQUFjLENBQWtDO0lBRTFEOzs7OztPQUtHO0lBQ08sZUFBZSxDQUFtQztJQUU1RDs7Ozs7T0FLRztJQUNPLHNCQUFzQixDQUEwQztJQUUxRTs7Ozs7T0FLRztJQUNPLHFCQUFxQixDQUF5QztJQUV4RTs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFzQztJQUVsRTs7OztPQUlHO0lBQ08sa0JBQWtCLENBQTZCO0lBRXpEOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBaUY7SUFFNUc7Ozs7T0FJRztJQUNPLG9CQUFvQixDQUEwTDtJQUV4Tjs7OztPQUlHO0lBQ08sa0JBQWtCLENBQXU4QjtJQUVuK0I7Ozs7T0FJRztJQUNPLHlCQUF5QixDQUFvQjtJQUV2RDs7OztPQUlHO0lBQ08sZ0NBQWdDLENBQW9CO0lBRTlEOzs7O09BSUc7SUFDTywyQkFBMkIsQ0FBc1Q7SUFFM1Y7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBd0I7SUFFaEQ7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBd3VCO0lBRTd2Qjs7OztPQUlHO0lBQ08sYUFBYSxDQUF5UztJQUVoVTs7OztPQUlHO0lBQ08saUJBQWlCLENBQW9CO0lBRS9DOzs7O09BSUc7SUFDTyxZQUFZLENBQXNDO0lBRTVEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBd0I7SUFFbEQ7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBbUU7SUFFM0Y7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF3QjtJQUVsRDs7OztPQUlHO0lBQ08sWUFBWSxDQUF1RDtJQUU3RTs7OztPQUlHO0lBQ08sb0JBQW9CLENBQWlGO0lBRS9HOzs7O09BSUc7SUFDTyxpQkFBaUIsQ0FBaUY7SUFFNUc7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBODVCO0lBRW43Qjs7OztPQUlHO0lBQ08sZUFBZSxDQUF1QjtJQUVoRDs7OztPQUlHO0lBQ08scUJBQXFCLENBQWdDO0lBRS9EOzs7O09BSUc7SUFDTyxjQUFjLENBQTZIO0lBRXJKOzs7O09BSUc7SUFDTyxxQkFBcUIsQ0FBeU47SUFFeFA7Ozs7T0FJRztJQUNPLGNBQWMsQ0FBd0I7SUFFaEQ7Ozs7T0FJRztJQUNPLGdCQUFnQixDQUF3QjtJQUVsRDs7OztPQUlHO0lBQ08sY0FBYyxDQUF3QjtJQUVoRDs7OztPQUlHO0lBQ08sZ0JBQWdCLENBQXdCO0lBRWxEOzs7O09BSUc7SUFDTyxnQkFBZ0IsQ0FBd0I7SUFFbEQ7Ozs7T0FJRztJQUNPLGFBQWEsQ0FBcVQ7SUFFNVU7Ozs7T0FJRztJQUNPLFdBQVcsQ0FBc0I7SUFFM0M7Ozs7T0FJRztJQUNPLHdCQUF3QixDQUF3QjtJQUUxRDs7OztPQUlHO0lBQ08saUJBQWlCLENBQWlGO0lBRTVHOzs7O09BSUc7SUFDTyxlQUFlLENBQXNCO0lBRS9DOzs7O09BSUc7SUFDTyxhQUFhLENBQXdCO0lBRS9DOzs7O09BSUc7SUFDTyxXQUFXLENBQXVEO0lBRTVFOzs7O09BSUc7SUFDTyxlQUFlLENBQStFO0lBS3hHLElBQ0ksb0JBQW9CO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBQ0QsSUFBSSxvQkFBb0IsQ0FBQyxLQUFLO1FBQzFCLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFLRCxZQUFZLFVBQXNCLEVBQUUsTUFBYyxFQUFFLFlBQTRCLEVBQ2hFLGNBQTZCLEVBQzdCLElBQTBCLEVBQ2xDLFVBQTRCLEVBQzVCLGFBQTRCLEVBQ1AsVUFBZTtRQUV4QyxLQUFLLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQztRQU52RSxtQkFBYyxHQUFkLGNBQWMsQ0FBZTtRQUM3QixTQUFJLEdBQUosSUFBSSxDQUFzQjtRQU90QyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDdEIsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUNyRCxFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3ZELEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ25ELEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9DLEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDckQsRUFBRSxTQUFTLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUN2RCxFQUFFLFNBQVMsRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDckUsRUFBRSxTQUFTLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ25FLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM3RCxFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRTtZQUM3QixFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRTtZQUNoQyxFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUM5QixFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRTtZQUNyQyxFQUFFLElBQUksRUFBRSxrQ0FBa0MsRUFBRTtZQUM1QyxFQUFFLElBQUksRUFBRSw2QkFBNkIsRUFBRTtZQUN2QyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQzdCLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUN4QixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUMxQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUM1QixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDeEIsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDaEMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3ZCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQzNCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ2pDLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1lBQ2pDLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQzFCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUN6QixFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDdkIsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUU7WUFDcEMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0IsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDM0IsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ3pCLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN2QixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtTQUM5QixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFUyxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU87UUFFdEMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUdELFdBQVc7UUFDUCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBWSxFQUFFLE9BQXNCO1FBQzdDLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDbEM7SUFDTCxDQUFDO0lBRUQsU0FBUztRQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDcEMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2xCLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxVQUFVLENBQUMsSUFBWSxFQUFFLEtBQVU7UUFDL0IsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUM7UUFFM0QsSUFBSSxPQUFPLElBQUksU0FBUyxFQUFFO1lBQ3RCLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQzsySEFqNUJRLGtCQUFrQiw4TkFxekJYLFdBQVc7K0dBcnpCbEIsa0JBQWtCLDh2RkFQaEI7WUFDUCxjQUFjO1lBQ2QsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQixvQkFBb0I7U0FDdkIsK0RBdXlCZ0IsdUJBQXVCLHlFQTd5QjlCLEVBQUU7OzRGQVFILGtCQUFrQjtrQkFWOUIsU0FBUzttQkFBQztvQkFDUCxRQUFRLEVBQUUsWUFBWTtvQkFDdEIsUUFBUSxFQUFFLEVBQUU7b0JBQ1osU0FBUyxFQUFFO3dCQUNQLGNBQWM7d0JBQ2QsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLG9CQUFvQjtxQkFDdkI7aUJBQ0o7OzBCQXN6QlksTUFBTTsyQkFBQyxXQUFXOzRDQTd5QnZCLFlBQVk7c0JBRGYsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsY0FBYztzQkFEakIsS0FBSztnQkFjRixZQUFZO3NCQURmLEtBQUs7Z0JBY0YsbUJBQW1CO3NCQUR0QixLQUFLO2dCQWNGLDBCQUEwQjtzQkFEN0IsS0FBSztnQkFjRixxQkFBcUI7c0JBRHhCLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixPQUFPO3NCQURWLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLE1BQU07c0JBRFQsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixNQUFNO3NCQURULEtBQUs7Z0JBY0YsY0FBYztzQkFEakIsS0FBSztnQkFjRixXQUFXO3NCQURkLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixlQUFlO3NCQURsQixLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixlQUFlO3NCQURsQixLQUFLO2dCQWNGLFFBQVE7c0JBRFgsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsUUFBUTtzQkFEWCxLQUFLO2dCQWNGLFVBQVU7c0JBRGIsS0FBSztnQkFjRixVQUFVO3NCQURiLEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQWNGLEtBQUs7c0JBRFIsS0FBSztnQkFjRixrQkFBa0I7c0JBRHJCLEtBQUs7Z0JBY0YsV0FBVztzQkFEZCxLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjRixPQUFPO3NCQURWLEtBQUs7Z0JBY0YsS0FBSztzQkFEUixLQUFLO2dCQWNGLFNBQVM7c0JBRFosS0FBSztnQkFjSSxjQUFjO3NCQUF2QixNQUFNO2dCQVFHLGVBQWU7c0JBQXhCLE1BQU07Z0JBUUcsV0FBVztzQkFBcEIsTUFBTTtnQkFRRyxhQUFhO3NCQUF0QixNQUFNO2dCQVFHLFdBQVc7c0JBQXBCLE1BQU07Z0JBUUcsY0FBYztzQkFBdkIsTUFBTTtnQkFRRyxlQUFlO3NCQUF4QixNQUFNO2dCQVFHLHNCQUFzQjtzQkFBL0IsTUFBTTtnQkFRRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBUUcsa0JBQWtCO3NCQUEzQixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQU9HLGtCQUFrQjtzQkFBM0IsTUFBTTtnQkFPRyx5QkFBeUI7c0JBQWxDLE1BQU07Z0JBT0csZ0NBQWdDO3NCQUF6QyxNQUFNO2dCQU9HLDJCQUEyQjtzQkFBcEMsTUFBTTtnQkFPRyxjQUFjO3NCQUF2QixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxpQkFBaUI7c0JBQTFCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csWUFBWTtzQkFBckIsTUFBTTtnQkFPRyxvQkFBb0I7c0JBQTdCLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLFdBQVc7c0JBQXBCLE1BQU07Z0JBT0csZUFBZTtzQkFBeEIsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxxQkFBcUI7c0JBQTlCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csY0FBYztzQkFBdkIsTUFBTTtnQkFPRyxnQkFBZ0I7c0JBQXpCLE1BQU07Z0JBT0csZ0JBQWdCO3NCQUF6QixNQUFNO2dCQU9HLGFBQWE7c0JBQXRCLE1BQU07Z0JBT0csV0FBVztzQkFBcEIsTUFBTTtnQkFPRyx3QkFBd0I7c0JBQWpDLE1BQU07Z0JBT0csaUJBQWlCO3NCQUExQixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBT0csYUFBYTtzQkFBdEIsTUFBTTtnQkFPRyxXQUFXO3NCQUFwQixNQUFNO2dCQU9HLGVBQWU7c0JBQXhCLE1BQU07Z0JBTUgsb0JBQW9CO3NCQUR2QixlQUFlO3VCQUFDLHVCQUF1Qjs7QUF3SzVDLE1BQU0sT0FBTyxlQUFlOzJIQUFmLGVBQWU7NEhBQWYsZUFBZSxpQkE3OEJmLGtCQUFrQixhQXM1QjNCLG9CQUFvQjtZQUNwQixnQkFBZ0I7WUFDaEIsYUFBYTtZQUNiLHVCQUF1QjtZQUN2QixvQkFBb0I7WUFDcEIsd0JBQXdCO1lBQ3hCLDhCQUE4QjtZQUM5QixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsdUJBQXVCO1lBQ3ZCLG9CQUFvQjtZQUNwQixjQUFjO1lBQ2QsbUJBQW1CO1lBQ25CLGlCQUFpQjtZQUNqQix3QkFBd0I7WUFDeEIsWUFBWTtZQUNaLGNBQWM7WUFDZCxnQkFBZ0I7WUFDaEIsb0JBQW9CO1lBQ3BCLGtCQUFrQjtZQUNsQixtQkFBbUI7WUFDbkIsZ0JBQWdCLGFBNzZCUCxrQkFBa0IsRUFvN0IzQixvQkFBb0I7WUFDcEIsZ0JBQWdCO1lBQ2hCLGFBQWE7WUFDYix1QkFBdUI7WUFDdkIsb0JBQW9CO1lBQ3BCLHdCQUF3QjtZQUN4Qiw4QkFBOEI7WUFDOUIsY0FBYztZQUNkLGdCQUFnQjtZQUNoQixlQUFlO1lBQ2YsaUJBQWlCO1lBQ2pCLHVCQUF1QjtZQUN2QixvQkFBb0I7WUFDcEIsY0FBYztZQUNkLG1CQUFtQjtZQUNuQixpQkFBaUI7WUFDakIsd0JBQXdCO1lBQ3hCLFlBQVk7WUFDWixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLG9CQUFvQjtZQUNwQixrQkFBa0I7WUFDbEIsZ0JBQWdCOzRIQUdQLGVBQWUsWUF2RHhCLG9CQUFvQjtZQUNwQixnQkFBZ0I7WUFDaEIsYUFBYTtZQUNiLHVCQUF1QjtZQUN2QixvQkFBb0I7WUFDcEIsd0JBQXdCO1lBQ3hCLDhCQUE4QjtZQUM5QixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsdUJBQXVCO1lBQ3ZCLG9CQUFvQjtZQUNwQixjQUFjO1lBQ2QsbUJBQW1CO1lBQ25CLGlCQUFpQjtZQUNqQix3QkFBd0I7WUFDeEIsWUFBWTtZQUNaLGNBQWM7WUFDZCxnQkFBZ0I7WUFDaEIsb0JBQW9CO1lBQ3BCLGtCQUFrQjtZQUNsQixtQkFBbUI7WUFDbkIsZ0JBQWdCLEVBT2hCLG9CQUFvQjtZQUNwQixnQkFBZ0I7WUFDaEIsYUFBYTtZQUNiLHVCQUF1QjtZQUN2QixvQkFBb0I7WUFDcEIsd0JBQXdCO1lBQ3hCLDhCQUE4QjtZQUM5QixjQUFjO1lBQ2QsZ0JBQWdCO1lBQ2hCLGVBQWU7WUFDZixpQkFBaUI7WUFDakIsdUJBQXVCO1lBQ3ZCLG9CQUFvQjtZQUNwQixjQUFjO1lBQ2QsbUJBQW1CO1lBQ25CLGlCQUFpQjtZQUNqQix3QkFBd0I7WUFDeEIsWUFBWTtZQUNaLGNBQWM7WUFDZCxnQkFBZ0I7WUFDaEIsb0JBQW9CO1lBQ3BCLGtCQUFrQjtZQUNsQixnQkFBZ0I7OzRGQUdQLGVBQWU7a0JBekQzQixRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRTt3QkFDUCxvQkFBb0I7d0JBQ3BCLGdCQUFnQjt3QkFDaEIsYUFBYTt3QkFDYix1QkFBdUI7d0JBQ3ZCLG9CQUFvQjt3QkFDcEIsd0JBQXdCO3dCQUN4Qiw4QkFBOEI7d0JBQzlCLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixlQUFlO3dCQUNmLGlCQUFpQjt3QkFDakIsdUJBQXVCO3dCQUN2QixvQkFBb0I7d0JBQ3BCLGNBQWM7d0JBQ2QsbUJBQW1CO3dCQUNuQixpQkFBaUI7d0JBQ2pCLHdCQUF3Qjt3QkFDeEIsWUFBWTt3QkFDWixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsb0JBQW9CO3dCQUNwQixrQkFBa0I7d0JBQ2xCLG1CQUFtQjt3QkFDbkIsZ0JBQWdCO3FCQUNqQjtvQkFDRCxZQUFZLEVBQUU7d0JBQ1osa0JBQWtCO3FCQUNuQjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1Asa0JBQWtCO3dCQUNsQixvQkFBb0I7d0JBQ3BCLGdCQUFnQjt3QkFDaEIsYUFBYTt3QkFDYix1QkFBdUI7d0JBQ3ZCLG9CQUFvQjt3QkFDcEIsd0JBQXdCO3dCQUN4Qiw4QkFBOEI7d0JBQzlCLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixlQUFlO3dCQUNmLGlCQUFpQjt3QkFDakIsdUJBQXVCO3dCQUN2QixvQkFBb0I7d0JBQ3BCLGNBQWM7d0JBQ2QsbUJBQW1CO3dCQUNuQixpQkFBaUI7d0JBQ2pCLHdCQUF3Qjt3QkFDeEIsWUFBWTt3QkFDWixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsb0JBQW9CO3dCQUNwQixrQkFBa0I7d0JBQ2xCLGdCQUFnQjtxQkFDakI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuLyogdHNsaW50OmRpc2FibGU6bWF4LWxpbmUtbGVuZ3RoICovXG5cblxuaW1wb3J0IHtcbiAgICBUcmFuc2ZlclN0YXRlLFxuICAgIENvbXBvbmVudCxcbiAgICBOZ01vZHVsZSxcbiAgICBFbGVtZW50UmVmLFxuICAgIE5nWm9uZSxcbiAgICBQTEFURk9STV9JRCxcbiAgICBJbmplY3QsXG5cbiAgICBJbnB1dCxcbiAgICBPdXRwdXQsXG4gICAgT25EZXN0cm95LFxuICAgIEV2ZW50RW1pdHRlcixcbiAgICBPbkNoYW5nZXMsXG4gICAgRG9DaGVjayxcbiAgICBTaW1wbGVDaGFuZ2VzLFxuICAgIENvbnRlbnRDaGlsZHJlbixcbiAgICBRdWVyeUxpc3Rcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cblxuaW1wb3J0IHsgT3JpZW50YXRpb24sIFBhZ2VPcmllbnRhdGlvbiB9IGZyb20gJ2RldmV4dHJlbWUvY29tbW9uJztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSAnZGV2ZXh0cmVtZS9kYXRhJztcbmltcG9ydCBEYXRhU291cmNlLCB7IE9wdGlvbnMgYXMgRGF0YVNvdXJjZU9wdGlvbnMgfSBmcm9tICdkZXZleHRyZW1lL2RhdGEvZGF0YV9zb3VyY2UnO1xuaW1wb3J0IHsgQXV0b1pvb21Nb2RlLCBDb21tYW5kLCBDb25uZWN0b3JMaW5lRW5kLCBDb25uZWN0b3JMaW5lVHlwZSwgQ29udGVudFJlYWR5RXZlbnQsIEN1c3RvbUNvbW1hbmQsIEN1c3RvbUNvbW1hbmRFdmVudCwgRGF0YUxheW91dFR5cGUsIERpc3Bvc2luZ0V2ZW50LCBJbml0aWFsaXplZEV2ZW50LCBJdGVtQ2xpY2tFdmVudCwgSXRlbURibENsaWNrRXZlbnQsIE9wdGlvbkNoYW5nZWRFdmVudCwgUGFuZWxWaXNpYmlsaXR5LCBSZXF1ZXN0RWRpdE9wZXJhdGlvbkV2ZW50LCBSZXF1ZXN0TGF5b3V0VXBkYXRlRXZlbnQsIFNlbGVjdGlvbkNoYW5nZWRFdmVudCwgU2hhcGVDYXRlZ29yeSwgU2hhcGVUeXBlLCBUb29sYm94RGlzcGxheU1vZGUsIFVuaXRzIH0gZnJvbSAnZGV2ZXh0cmVtZS91aS9kaWFncmFtJztcblxuaW1wb3J0IER4RGlhZ3JhbSBmcm9tICdkZXZleHRyZW1lL3VpL2RpYWdyYW0nO1xuXG5cbmltcG9ydCB7XG4gICAgRHhDb21wb25lbnQsXG4gICAgRHhUZW1wbGF0ZUhvc3QsXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlLFxuICAgIE5lc3RlZE9wdGlvbkhvc3QsXG4gICAgSXRlcmFibGVEaWZmZXJIZWxwZXIsXG4gICAgV2F0Y2hlckhlbHBlclxufSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IER4b0NvbnRleHRNZW51TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlDb21tYW5kTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlJdGVtTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Db250ZXh0VG9vbGJveE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpQ3VzdG9tU2hhcGVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4aUNvbm5lY3Rpb25Qb2ludE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvRGVmYXVsdEl0ZW1Qcm9wZXJ0aWVzTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9FZGdlc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvRWRpdGluZ01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvRXhwb3J0TW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9HcmlkU2l6ZU1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvSGlzdG9yeVRvb2xiYXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b01haW5Ub29sYmFyTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeG9Ob2Rlc01vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvQXV0b0xheW91dE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvUGFnZVNpemVNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1Byb3BlcnRpZXNQYW5lbE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhpVGFiTW9kdWxlIH0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL3VpL25lc3RlZCc7XG5pbXBvcnQgeyBEeGlHcm91cE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVG9vbGJveE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuaW1wb3J0IHsgRHhvVmlld1Rvb2xiYXJNb2R1bGUgfSBmcm9tICdkZXZleHRyZW1lLWFuZ3VsYXIvdWkvbmVzdGVkJztcbmltcG9ydCB7IER4b1pvb21MZXZlbE1vZHVsZSB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuXG5pbXBvcnQgeyBEeGlDdXN0b21TaGFwZUNvbXBvbmVudCB9IGZyb20gJ2RldmV4dHJlbWUtYW5ndWxhci91aS9uZXN0ZWQnO1xuXG5cblxuLyoqXG4gKiBbZGVzY3I6ZHhEaWFncmFtXVxuXG4gKi9cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnZHgtZGlhZ3JhbScsXG4gICAgdGVtcGxhdGU6ICcnLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgV2F0Y2hlckhlbHBlcixcbiAgICAgICAgTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgSXRlcmFibGVEaWZmZXJIZWxwZXJcbiAgICBdXG59KVxuZXhwb3J0IGNsYXNzIER4RGlhZ3JhbUNvbXBvbmVudCBleHRlbmRzIER4Q29tcG9uZW50IGltcGxlbWVudHMgT25EZXN0cm95LCBPbkNoYW5nZXMsIERvQ2hlY2sge1xuICAgIGluc3RhbmNlOiBEeERpYWdyYW0gPSBudWxsO1xuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuYXV0b1pvb21Nb2RlXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGF1dG9ab29tTW9kZSgpOiBBdXRvWm9vbU1vZGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdhdXRvWm9vbU1vZGUnKTtcbiAgICB9XG4gICAgc2V0IGF1dG9ab29tTW9kZSh2YWx1ZTogQXV0b1pvb21Nb2RlKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignYXV0b1pvb21Nb2RlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuY29udGV4dE1lbnVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY29udGV4dE1lbnUoKTogeyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgZW5hYmxlZD86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbnRleHRNZW51Jyk7XG4gICAgfVxuICAgIHNldCBjb250ZXh0TWVudSh2YWx1ZTogeyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgZW5hYmxlZD86IGJvb2xlYW4gfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbnRleHRNZW51JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuY29udGV4dFRvb2xib3hdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY29udGV4dFRvb2xib3goKTogeyBjYXRlZ29yeT86IFNoYXBlQ2F0ZWdvcnkgfCBzdHJpbmcsIGRpc3BsYXlNb2RlPzogVG9vbGJveERpc3BsYXlNb2RlLCBlbmFibGVkPzogYm9vbGVhbiwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hhcGVzPzogQXJyYXk8U2hhcGVUeXBlIHwgc3RyaW5nPiwgd2lkdGg/OiBudW1iZXIgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2NvbnRleHRUb29sYm94Jyk7XG4gICAgfVxuICAgIHNldCBjb250ZXh0VG9vbGJveCh2YWx1ZTogeyBjYXRlZ29yeT86IFNoYXBlQ2F0ZWdvcnkgfCBzdHJpbmcsIGRpc3BsYXlNb2RlPzogVG9vbGJveERpc3BsYXlNb2RlLCBlbmFibGVkPzogYm9vbGVhbiwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hhcGVzPzogQXJyYXk8U2hhcGVUeXBlIHwgc3RyaW5nPiwgd2lkdGg/OiBudW1iZXIgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2NvbnRleHRUb29sYm94JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuY3VzdG9tU2hhcGVzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGN1c3RvbVNoYXBlcygpOiBBcnJheTxhbnkgfCB7IGFsbG93RWRpdEltYWdlPzogYm9vbGVhbiwgYWxsb3dFZGl0VGV4dD86IGJvb2xlYW4sIGFsbG93UmVzaXplPzogYm9vbGVhbiwgYmFja2dyb3VuZEltYWdlSGVpZ2h0PzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VMZWZ0PzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VUb29sYm94VXJsPzogc3RyaW5nLCBiYWNrZ3JvdW5kSW1hZ2VUb3A/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZVVybD86IHN0cmluZywgYmFja2dyb3VuZEltYWdlV2lkdGg/OiBudW1iZXIsIGJhc2VUeXBlPzogU2hhcGVUeXBlIHwgc3RyaW5nLCBjYXRlZ29yeT86IHN0cmluZywgY29ubmVjdGlvblBvaW50cz86IEFycmF5PGFueSB8IHsgeD86IG51bWJlciwgeT86IG51bWJlciB9PiwgZGVmYXVsdEhlaWdodD86IG51bWJlciwgZGVmYXVsdEltYWdlVXJsPzogc3RyaW5nLCBkZWZhdWx0VGV4dD86IHN0cmluZywgZGVmYXVsdFdpZHRoPzogbnVtYmVyLCBpbWFnZUhlaWdodD86IG51bWJlciwgaW1hZ2VMZWZ0PzogbnVtYmVyLCBpbWFnZVRvcD86IG51bWJlciwgaW1hZ2VXaWR0aD86IG51bWJlciwga2VlcFJhdGlvT25BdXRvU2l6ZT86IGJvb2xlYW4sIG1heEhlaWdodD86IG51bWJlciwgbWF4V2lkdGg/OiBudW1iZXIsIG1pbkhlaWdodD86IG51bWJlciwgbWluV2lkdGg/OiBudW1iZXIsIHRlbXBsYXRlPzogYW55LCB0ZW1wbGF0ZUhlaWdodD86IG51bWJlciwgdGVtcGxhdGVMZWZ0PzogbnVtYmVyLCB0ZW1wbGF0ZVRvcD86IG51bWJlciwgdGVtcGxhdGVXaWR0aD86IG51bWJlciwgdGV4dEhlaWdodD86IG51bWJlciwgdGV4dExlZnQ/OiBudW1iZXIsIHRleHRUb3A/OiBudW1iZXIsIHRleHRXaWR0aD86IG51bWJlciwgdGl0bGU/OiBzdHJpbmcsIHRvb2xib3hUZW1wbGF0ZT86IGFueSwgdG9vbGJveFdpZHRoVG9IZWlnaHRSYXRpbz86IG51bWJlciwgdHlwZT86IHN0cmluZyB9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2N1c3RvbVNoYXBlcycpO1xuICAgIH1cbiAgICBzZXQgY3VzdG9tU2hhcGVzKHZhbHVlOiBBcnJheTxhbnkgfCB7IGFsbG93RWRpdEltYWdlPzogYm9vbGVhbiwgYWxsb3dFZGl0VGV4dD86IGJvb2xlYW4sIGFsbG93UmVzaXplPzogYm9vbGVhbiwgYmFja2dyb3VuZEltYWdlSGVpZ2h0PzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VMZWZ0PzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VUb29sYm94VXJsPzogc3RyaW5nLCBiYWNrZ3JvdW5kSW1hZ2VUb3A/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZVVybD86IHN0cmluZywgYmFja2dyb3VuZEltYWdlV2lkdGg/OiBudW1iZXIsIGJhc2VUeXBlPzogU2hhcGVUeXBlIHwgc3RyaW5nLCBjYXRlZ29yeT86IHN0cmluZywgY29ubmVjdGlvblBvaW50cz86IEFycmF5PGFueSB8IHsgeD86IG51bWJlciwgeT86IG51bWJlciB9PiwgZGVmYXVsdEhlaWdodD86IG51bWJlciwgZGVmYXVsdEltYWdlVXJsPzogc3RyaW5nLCBkZWZhdWx0VGV4dD86IHN0cmluZywgZGVmYXVsdFdpZHRoPzogbnVtYmVyLCBpbWFnZUhlaWdodD86IG51bWJlciwgaW1hZ2VMZWZ0PzogbnVtYmVyLCBpbWFnZVRvcD86IG51bWJlciwgaW1hZ2VXaWR0aD86IG51bWJlciwga2VlcFJhdGlvT25BdXRvU2l6ZT86IGJvb2xlYW4sIG1heEhlaWdodD86IG51bWJlciwgbWF4V2lkdGg/OiBudW1iZXIsIG1pbkhlaWdodD86IG51bWJlciwgbWluV2lkdGg/OiBudW1iZXIsIHRlbXBsYXRlPzogYW55LCB0ZW1wbGF0ZUhlaWdodD86IG51bWJlciwgdGVtcGxhdGVMZWZ0PzogbnVtYmVyLCB0ZW1wbGF0ZVRvcD86IG51bWJlciwgdGVtcGxhdGVXaWR0aD86IG51bWJlciwgdGV4dEhlaWdodD86IG51bWJlciwgdGV4dExlZnQ/OiBudW1iZXIsIHRleHRUb3A/OiBudW1iZXIsIHRleHRXaWR0aD86IG51bWJlciwgdGl0bGU/OiBzdHJpbmcsIHRvb2xib3hUZW1wbGF0ZT86IGFueSwgdG9vbGJveFdpZHRoVG9IZWlnaHRSYXRpbz86IG51bWJlciwgdHlwZT86IHN0cmluZyB9Pikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2N1c3RvbVNoYXBlcycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLmN1c3RvbVNoYXBlVGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY3VzdG9tU2hhcGVUZW1wbGF0ZSgpOiBhbnkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjdXN0b21TaGFwZVRlbXBsYXRlJyk7XG4gICAgfVxuICAgIHNldCBjdXN0b21TaGFwZVRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjdXN0b21TaGFwZVRlbXBsYXRlJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGVdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGUoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignY3VzdG9tU2hhcGVUb29sYm94VGVtcGxhdGUnKTtcbiAgICB9XG4gICAgc2V0IGN1c3RvbVNoYXBlVG9vbGJveFRlbXBsYXRlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdjdXN0b21TaGFwZVRvb2xib3hUZW1wbGF0ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLmRlZmF1bHRJdGVtUHJvcGVydGllc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkZWZhdWx0SXRlbVByb3BlcnRpZXMoKTogeyBjb25uZWN0b3JMaW5lRW5kPzogQ29ubmVjdG9yTGluZUVuZCwgY29ubmVjdG9yTGluZVN0YXJ0PzogQ29ubmVjdG9yTGluZUVuZCwgY29ubmVjdG9yTGluZVR5cGU/OiBDb25uZWN0b3JMaW5lVHlwZSwgc2hhcGVNYXhIZWlnaHQ/OiBudW1iZXIgfCB1bmRlZmluZWQsIHNoYXBlTWF4V2lkdGg/OiBudW1iZXIgfCB1bmRlZmluZWQsIHNoYXBlTWluSGVpZ2h0PzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzaGFwZU1pbldpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdHlsZT86IGFueSwgdGV4dFN0eWxlPzogYW55IH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdkZWZhdWx0SXRlbVByb3BlcnRpZXMnKTtcbiAgICB9XG4gICAgc2V0IGRlZmF1bHRJdGVtUHJvcGVydGllcyh2YWx1ZTogeyBjb25uZWN0b3JMaW5lRW5kPzogQ29ubmVjdG9yTGluZUVuZCwgY29ubmVjdG9yTGluZVN0YXJ0PzogQ29ubmVjdG9yTGluZUVuZCwgY29ubmVjdG9yTGluZVR5cGU/OiBDb25uZWN0b3JMaW5lVHlwZSwgc2hhcGVNYXhIZWlnaHQ/OiBudW1iZXIgfCB1bmRlZmluZWQsIHNoYXBlTWF4V2lkdGg/OiBudW1iZXIgfCB1bmRlZmluZWQsIHNoYXBlTWluSGVpZ2h0PzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzaGFwZU1pbldpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzdHlsZT86IGFueSwgdGV4dFN0eWxlPzogYW55IH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdkZWZhdWx0SXRlbVByb3BlcnRpZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6V2lkZ2V0T3B0aW9ucy5kaXNhYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZGlzYWJsZWQnKTtcbiAgICB9XG4gICAgc2V0IGRpc2FibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZGlzYWJsZWQnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5lZGdlc11cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBlZGdlcygpOiB7IGN1c3RvbURhdGFFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBmcm9tRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBmcm9tTGluZUVuZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgZnJvbVBvaW50SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbGluZVR5cGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGxvY2tlZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgcG9pbnRzRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBzdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdGV4dFN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0b0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdG9MaW5lRW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0b1BvaW50SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHpJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWRnZXMnKTtcbiAgICB9XG4gICAgc2V0IGVkZ2VzKHZhbHVlOiB7IGN1c3RvbURhdGFFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBmcm9tRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBmcm9tTGluZUVuZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgZnJvbVBvaW50SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbGluZVR5cGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGxvY2tlZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgcG9pbnRzRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBzdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdGV4dFN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0b0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdG9MaW5lRW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0b1BvaW50SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHpJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignZWRnZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5lZGl0aW5nXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGVkaXRpbmcoKTogeyBhbGxvd0FkZFNoYXBlPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0aW9uPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0b3JQb2ludHM/OiBib29sZWFuLCBhbGxvd0NoYW5nZUNvbm5lY3RvclRleHQ/OiBib29sZWFuLCBhbGxvd0NoYW5nZVNoYXBlVGV4dD86IGJvb2xlYW4sIGFsbG93RGVsZXRlQ29ubmVjdG9yPzogYm9vbGVhbiwgYWxsb3dEZWxldGVTaGFwZT86IGJvb2xlYW4sIGFsbG93TW92ZVNoYXBlPzogYm9vbGVhbiwgYWxsb3dSZXNpemVTaGFwZT86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2VkaXRpbmcnKTtcbiAgICB9XG4gICAgc2V0IGVkaXRpbmcodmFsdWU6IHsgYWxsb3dBZGRTaGFwZT86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdGlvbj86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdG9yUG9pbnRzPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0b3JUZXh0PzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VTaGFwZVRleHQ/OiBib29sZWFuLCBhbGxvd0RlbGV0ZUNvbm5lY3Rvcj86IGJvb2xlYW4sIGFsbG93RGVsZXRlU2hhcGU/OiBib29sZWFuLCBhbGxvd01vdmVTaGFwZT86IGJvb2xlYW4sIGFsbG93UmVzaXplU2hhcGU/OiBib29sZWFuIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlZGl0aW5nJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMuZWxlbWVudEF0dHJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZWxlbWVudEF0dHIoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZWxlbWVudEF0dHInKTtcbiAgICB9XG4gICAgc2V0IGVsZW1lbnRBdHRyKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdlbGVtZW50QXR0cicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLmV4cG9ydF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBleHBvcnQoKTogeyBmaWxlTmFtZT86IHN0cmluZyB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZXhwb3J0Jyk7XG4gICAgfVxuICAgIHNldCBleHBvcnQodmFsdWU6IHsgZmlsZU5hbWU/OiBzdHJpbmcgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2V4cG9ydCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLmZ1bGxTY3JlZW5dXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgZnVsbFNjcmVlbigpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignZnVsbFNjcmVlbicpO1xuICAgIH1cbiAgICBzZXQgZnVsbFNjcmVlbih2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2Z1bGxTY3JlZW4nLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5ncmlkU2l6ZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBncmlkU2l6ZSgpOiBudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2dyaWRTaXplJyk7XG4gICAgfVxuICAgIHNldCBncmlkU2l6ZSh2YWx1ZTogbnVtYmVyIHwgeyBpdGVtcz86IEFycmF5PG51bWJlcj4sIHZhbHVlPzogbnVtYmVyIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdncmlkU2l6ZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLmhhc0NoYW5nZXNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGFzQ2hhbmdlcygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGFzQ2hhbmdlcycpO1xuICAgIH1cbiAgICBzZXQgaGFzQ2hhbmdlcyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hhc0NoYW5nZXMnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6RE9NQ29tcG9uZW50T3B0aW9ucy5oZWlnaHRdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGVpZ2h0KCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignaGVpZ2h0Jyk7XG4gICAgfVxuICAgIHNldCBoZWlnaHQodmFsdWU6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbignaGVpZ2h0JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuaGlzdG9yeVRvb2xiYXJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgaGlzdG9yeVRvb2xiYXIoKTogeyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgdmlzaWJsZT86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ2hpc3RvcnlUb29sYmFyJyk7XG4gICAgfVxuICAgIHNldCBoaXN0b3J5VG9vbGJhcih2YWx1ZTogeyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgdmlzaWJsZT86IGJvb2xlYW4gfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ2hpc3RvcnlUb29sYmFyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMubWFpblRvb2xiYXJdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbWFpblRvb2xiYXIoKTogeyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgdmlzaWJsZT86IGJvb2xlYW4gfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ21haW5Ub29sYmFyJyk7XG4gICAgfVxuICAgIHNldCBtYWluVG9vbGJhcih2YWx1ZTogeyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgdmlzaWJsZT86IGJvb2xlYW4gfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ21haW5Ub29sYmFyJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMubm9kZXNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgbm9kZXMoKTogeyBhdXRvTGF5b3V0PzogRGF0YUxheW91dFR5cGUgfCB7IG9yaWVudGF0aW9uPzogT3JpZW50YXRpb24sIHR5cGU/OiBEYXRhTGF5b3V0VHlwZSB9LCBhdXRvU2l6ZUVuYWJsZWQ/OiBib29sZWFuLCBjb250YWluZXJDaGlsZHJlbkV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgY29udGFpbmVyS2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBjdXN0b21EYXRhRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBkYXRhU291cmNlPzogU3RvcmUgfCBEYXRhU291cmNlIHwgRGF0YVNvdXJjZU9wdGlvbnMgfCBudWxsIHwgc3RyaW5nIHwgQXJyYXk8YW55PiwgaGVpZ2h0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBpbWFnZVVybEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaXRlbXNFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgbGVmdEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgbG9ja2VkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBwYXJlbnRLZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0ZXh0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0ZXh0U3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHRvcEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgd2lkdGhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHpJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignbm9kZXMnKTtcbiAgICB9XG4gICAgc2V0IG5vZGVzKHZhbHVlOiB7IGF1dG9MYXlvdXQ/OiBEYXRhTGF5b3V0VHlwZSB8IHsgb3JpZW50YXRpb24/OiBPcmllbnRhdGlvbiwgdHlwZT86IERhdGFMYXlvdXRUeXBlIH0sIGF1dG9TaXplRW5hYmxlZD86IGJvb2xlYW4sIGNvbnRhaW5lckNoaWxkcmVuRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBjb250YWluZXJLZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGN1c3RvbURhdGFFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGRhdGFTb3VyY2U/OiBTdG9yZSB8IERhdGFTb3VyY2UgfCBEYXRhU291cmNlT3B0aW9ucyB8IG51bGwgfCBzdHJpbmcgfCBBcnJheTxhbnk+LCBoZWlnaHRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGltYWdlVXJsRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBpdGVtc0V4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsZWZ0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBsb2NrZWRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHBhcmVudEtleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgc3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHRleHRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHRleHRTdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdG9wRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0eXBlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB3aWR0aEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgekluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIH0pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdub2RlcycsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLnBhZ2VDb2xvcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBwYWdlQ29sb3IoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncGFnZUNvbG9yJyk7XG4gICAgfVxuICAgIHNldCBwYWdlQ29sb3IodmFsdWU6IHN0cmluZykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BhZ2VDb2xvcicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLnBhZ2VPcmllbnRhdGlvbl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBwYWdlT3JpZW50YXRpb24oKTogUGFnZU9yaWVudGF0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncGFnZU9yaWVudGF0aW9uJyk7XG4gICAgfVxuICAgIHNldCBwYWdlT3JpZW50YXRpb24odmFsdWU6IFBhZ2VPcmllbnRhdGlvbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3BhZ2VPcmllbnRhdGlvbicsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLnBhZ2VTaXplXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHBhZ2VTaXplKCk6IHsgaGVpZ2h0PzogbnVtYmVyLCBpdGVtcz86IEFycmF5PGFueSB8IHsgaGVpZ2h0PzogbnVtYmVyLCB0ZXh0Pzogc3RyaW5nLCB3aWR0aD86IG51bWJlciB9Piwgd2lkdGg/OiBudW1iZXIgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3BhZ2VTaXplJyk7XG4gICAgfVxuICAgIHNldCBwYWdlU2l6ZSh2YWx1ZTogeyBoZWlnaHQ/OiBudW1iZXIsIGl0ZW1zPzogQXJyYXk8YW55IHwgeyBoZWlnaHQ/OiBudW1iZXIsIHRleHQ/OiBzdHJpbmcsIHdpZHRoPzogbnVtYmVyIH0+LCB3aWR0aD86IG51bWJlciB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncGFnZVNpemUnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5wcm9wZXJ0aWVzUGFuZWxdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcHJvcGVydGllc1BhbmVsKCk6IHsgdGFicz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4sIGdyb3Vwcz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4sIHRpdGxlPzogc3RyaW5nIH0+LCB0aXRsZT86IHN0cmluZyB9PiwgdmlzaWJpbGl0eT86IFBhbmVsVmlzaWJpbGl0eSB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigncHJvcGVydGllc1BhbmVsJyk7XG4gICAgfVxuICAgIHNldCBwcm9wZXJ0aWVzUGFuZWwodmFsdWU6IHsgdGFicz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4sIGdyb3Vwcz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4sIHRpdGxlPzogc3RyaW5nIH0+LCB0aXRsZT86IHN0cmluZyB9PiwgdmlzaWJpbGl0eT86IFBhbmVsVmlzaWJpbGl0eSB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncHJvcGVydGllc1BhbmVsJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMucmVhZE9ubHldXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgcmVhZE9ubHkoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3JlYWRPbmx5Jyk7XG4gICAgfVxuICAgIHNldCByZWFkT25seSh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3JlYWRPbmx5JywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOkRPTUNvbXBvbmVudE9wdGlvbnMucnRsRW5hYmxlZF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCBydGxFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdydGxFbmFibGVkJyk7XG4gICAgfVxuICAgIHNldCBydGxFbmFibGVkKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigncnRsRW5hYmxlZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLnNob3dHcmlkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNob3dHcmlkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdzaG93R3JpZCcpO1xuICAgIH1cbiAgICBzZXQgc2hvd0dyaWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzaG93R3JpZCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLnNpbXBsZVZpZXddXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgc2ltcGxlVmlldygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignc2ltcGxlVmlldycpO1xuICAgIH1cbiAgICBzZXQgc2ltcGxlVmlldyh2YWx1ZTogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3NpbXBsZVZpZXcnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5zbmFwVG9HcmlkXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHNuYXBUb0dyaWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3NuYXBUb0dyaWQnKTtcbiAgICB9XG4gICAgc2V0IHNuYXBUb0dyaWQodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCdzbmFwVG9HcmlkJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMudG9vbGJveF1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0b29sYm94KCk6IHsgZ3JvdXBzPzogQXJyYXk8U2hhcGVDYXRlZ29yeSB8IGFueSB8IHsgY2F0ZWdvcnk/OiBTaGFwZUNhdGVnb3J5IHwgc3RyaW5nLCBkaXNwbGF5TW9kZT86IFRvb2xib3hEaXNwbGF5TW9kZSwgZXhwYW5kZWQ/OiBib29sZWFuLCBzaGFwZXM/OiBBcnJheTxTaGFwZVR5cGUgfCBzdHJpbmc+LCB0aXRsZT86IHN0cmluZyB9Piwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hvd1NlYXJjaD86IGJvb2xlYW4sIHZpc2liaWxpdHk/OiBQYW5lbFZpc2liaWxpdHksIHdpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkIH0ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd0b29sYm94Jyk7XG4gICAgfVxuICAgIHNldCB0b29sYm94KHZhbHVlOiB7IGdyb3Vwcz86IEFycmF5PFNoYXBlQ2F0ZWdvcnkgfCBhbnkgfCB7IGNhdGVnb3J5PzogU2hhcGVDYXRlZ29yeSB8IHN0cmluZywgZGlzcGxheU1vZGU/OiBUb29sYm94RGlzcGxheU1vZGUsIGV4cGFuZGVkPzogYm9vbGVhbiwgc2hhcGVzPzogQXJyYXk8U2hhcGVUeXBlIHwgc3RyaW5nPiwgdGl0bGU/OiBzdHJpbmcgfT4sIHNoYXBlSWNvbnNQZXJSb3c/OiBudW1iZXIsIHNob3dTZWFyY2g/OiBib29sZWFuLCB2aXNpYmlsaXR5PzogUGFuZWxWaXNpYmlsaXR5LCB3aWR0aD86IG51bWJlciB8IHVuZGVmaW5lZCB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndG9vbGJveCcsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpkeERpYWdyYW1PcHRpb25zLnVuaXRzXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHVuaXRzKCk6IFVuaXRzIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndW5pdHMnKTtcbiAgICB9XG4gICAgc2V0IHVuaXRzKHZhbHVlOiBVbml0cykge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3VuaXRzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMudXNlTmF0aXZlU2Nyb2xsaW5nXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHVzZU5hdGl2ZVNjcm9sbGluZygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndXNlTmF0aXZlU2Nyb2xsaW5nJyk7XG4gICAgfVxuICAgIHNldCB1c2VOYXRpdmVTY3JvbGxpbmcodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fc2V0T3B0aW9uKCd1c2VOYXRpdmVTY3JvbGxpbmcnLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy52aWV3VG9vbGJhcl1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB2aWV3VG9vbGJhcigpOiB7IGNvbW1hbmRzPzogQXJyYXk8Q3VzdG9tQ29tbWFuZCB8IENvbW1hbmQ+LCB2aXNpYmxlPzogYm9vbGVhbiB9IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlld1Rvb2xiYXInKTtcbiAgICB9XG4gICAgc2V0IHZpZXdUb29sYmFyKHZhbHVlOiB7IGNvbW1hbmRzPzogQXJyYXk8Q3VzdG9tQ29tbWFuZCB8IENvbW1hbmQ+LCB2aXNpYmxlPzogYm9vbGVhbiB9KSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlld1Rvb2xiYXInLCB2YWx1ZSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy52aWV3VW5pdHNdXG4gICAgXG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBnZXQgdmlld1VuaXRzKCk6IFVuaXRzIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbigndmlld1VuaXRzJyk7XG4gICAgfVxuICAgIHNldCB2aWV3VW5pdHModmFsdWU6IFVuaXRzKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlld1VuaXRzJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOldpZGdldE9wdGlvbnMudmlzaWJsZV1cbiAgICBcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB2aXNpYmxlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCd2aXNpYmxlJyk7XG4gICAgfVxuICAgIHNldCB2aXNpYmxlKHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3NldE9wdGlvbigndmlzaWJsZScsIHZhbHVlKTtcbiAgICB9XG5cblxuICAgIC8qKlxuICAgICAqIFtkZXNjcjpET01Db21wb25lbnRPcHRpb25zLndpZHRoXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHdpZHRoKCk6IG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldE9wdGlvbignd2lkdGgnKTtcbiAgICB9XG4gICAgc2V0IHdpZHRoKHZhbHVlOiBudW1iZXIgfCBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3dpZHRoJywgdmFsdWUpO1xuICAgIH1cblxuXG4gICAgLyoqXG4gICAgICogW2Rlc2NyOmR4RGlhZ3JhbU9wdGlvbnMuem9vbUxldmVsXVxuICAgIFxuICAgICAqL1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IHpvb21MZXZlbCgpOiBudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfCB1bmRlZmluZWQgfSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRPcHRpb24oJ3pvb21MZXZlbCcpO1xuICAgIH1cbiAgICBzZXQgem9vbUxldmVsKHZhbHVlOiBudW1iZXIgfCB7IGl0ZW1zPzogQXJyYXk8bnVtYmVyPiwgdmFsdWU/OiBudW1iZXIgfCB1bmRlZmluZWQgfSkge1xuICAgICAgICB0aGlzLl9zZXRPcHRpb24oJ3pvb21MZXZlbCcsIHZhbHVlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbkNvbnRlbnRSZWFkeV1cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25Db250ZW50UmVhZHk6IEV2ZW50RW1pdHRlcjxDb250ZW50UmVhZHlFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbkN1c3RvbUNvbW1hbmRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uQ3VzdG9tQ29tbWFuZDogRXZlbnRFbWl0dGVyPEN1c3RvbUNvbW1hbmRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbkRpc3Bvc2luZ11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25EaXNwb3Npbmc6IEV2ZW50RW1pdHRlcjxEaXNwb3NpbmdFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbkluaXRpYWxpemVkXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvbkluaXRpYWxpemVkOiBFdmVudEVtaXR0ZXI8SW5pdGlhbGl6ZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbkl0ZW1DbGlja11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25JdGVtQ2xpY2s6IEV2ZW50RW1pdHRlcjxJdGVtQ2xpY2tFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbkl0ZW1EYmxDbGlja11cbiAgICBcbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgb25JdGVtRGJsQ2xpY2s6IEV2ZW50RW1pdHRlcjxJdGVtRGJsQ2xpY2tFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vbk9wdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uT3B0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPE9wdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vblJlcXVlc3RFZGl0T3BlcmF0aW9uXVxuICAgIFxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBvblJlcXVlc3RFZGl0T3BlcmF0aW9uOiBFdmVudEVtaXR0ZXI8UmVxdWVzdEVkaXRPcGVyYXRpb25FdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vblJlcXVlc3RMYXlvdXRVcGRhdGVdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uUmVxdWVzdExheW91dFVwZGF0ZTogRXZlbnRFbWl0dGVyPFJlcXVlc3RMYXlvdXRVcGRhdGVFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBbZGVzY3I6ZHhEaWFncmFtT3B0aW9ucy5vblNlbGVjdGlvbkNoYW5nZWRdXG4gICAgXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG9uU2VsZWN0aW9uQ2hhbmdlZDogRXZlbnRFbWl0dGVyPFNlbGVjdGlvbkNoYW5nZWRFdmVudD47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBhdXRvWm9vbU1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxBdXRvWm9vbU1vZGU+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgY29udGV4dE1lbnVDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGNvbW1hbmRzPzogQXJyYXk8Q3VzdG9tQ29tbWFuZCB8IENvbW1hbmQ+LCBlbmFibGVkPzogYm9vbGVhbiB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGNvbnRleHRUb29sYm94Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjYXRlZ29yeT86IFNoYXBlQ2F0ZWdvcnkgfCBzdHJpbmcsIGRpc3BsYXlNb2RlPzogVG9vbGJveERpc3BsYXlNb2RlLCBlbmFibGVkPzogYm9vbGVhbiwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hhcGVzPzogQXJyYXk8U2hhcGVUeXBlIHwgc3RyaW5nPiwgd2lkdGg/OiBudW1iZXIgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBjdXN0b21TaGFwZXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxBcnJheTxhbnkgfCB7IGFsbG93RWRpdEltYWdlPzogYm9vbGVhbiwgYWxsb3dFZGl0VGV4dD86IGJvb2xlYW4sIGFsbG93UmVzaXplPzogYm9vbGVhbiwgYmFja2dyb3VuZEltYWdlSGVpZ2h0PzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VMZWZ0PzogbnVtYmVyLCBiYWNrZ3JvdW5kSW1hZ2VUb29sYm94VXJsPzogc3RyaW5nLCBiYWNrZ3JvdW5kSW1hZ2VUb3A/OiBudW1iZXIsIGJhY2tncm91bmRJbWFnZVVybD86IHN0cmluZywgYmFja2dyb3VuZEltYWdlV2lkdGg/OiBudW1iZXIsIGJhc2VUeXBlPzogU2hhcGVUeXBlIHwgc3RyaW5nLCBjYXRlZ29yeT86IHN0cmluZywgY29ubmVjdGlvblBvaW50cz86IEFycmF5PGFueSB8IHsgeD86IG51bWJlciwgeT86IG51bWJlciB9PiwgZGVmYXVsdEhlaWdodD86IG51bWJlciwgZGVmYXVsdEltYWdlVXJsPzogc3RyaW5nLCBkZWZhdWx0VGV4dD86IHN0cmluZywgZGVmYXVsdFdpZHRoPzogbnVtYmVyLCBpbWFnZUhlaWdodD86IG51bWJlciwgaW1hZ2VMZWZ0PzogbnVtYmVyLCBpbWFnZVRvcD86IG51bWJlciwgaW1hZ2VXaWR0aD86IG51bWJlciwga2VlcFJhdGlvT25BdXRvU2l6ZT86IGJvb2xlYW4sIG1heEhlaWdodD86IG51bWJlciwgbWF4V2lkdGg/OiBudW1iZXIsIG1pbkhlaWdodD86IG51bWJlciwgbWluV2lkdGg/OiBudW1iZXIsIHRlbXBsYXRlPzogYW55LCB0ZW1wbGF0ZUhlaWdodD86IG51bWJlciwgdGVtcGxhdGVMZWZ0PzogbnVtYmVyLCB0ZW1wbGF0ZVRvcD86IG51bWJlciwgdGVtcGxhdGVXaWR0aD86IG51bWJlciwgdGV4dEhlaWdodD86IG51bWJlciwgdGV4dExlZnQ/OiBudW1iZXIsIHRleHRUb3A/OiBudW1iZXIsIHRleHRXaWR0aD86IG51bWJlciwgdGl0bGU/OiBzdHJpbmcsIHRvb2xib3hUZW1wbGF0ZT86IGFueSwgdG9vbGJveFdpZHRoVG9IZWlnaHRSYXRpbz86IG51bWJlciwgdHlwZT86IHN0cmluZyB9Pj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBjdXN0b21TaGFwZVRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGN1c3RvbVNoYXBlVG9vbGJveFRlbXBsYXRlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRlZmF1bHRJdGVtUHJvcGVydGllc0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgY29ubmVjdG9yTGluZUVuZD86IENvbm5lY3RvckxpbmVFbmQsIGNvbm5lY3RvckxpbmVTdGFydD86IENvbm5lY3RvckxpbmVFbmQsIGNvbm5lY3RvckxpbmVUeXBlPzogQ29ubmVjdG9yTGluZVR5cGUsIHNoYXBlTWF4SGVpZ2h0PzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzaGFwZU1heFdpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkLCBzaGFwZU1pbkhlaWdodD86IG51bWJlciB8IHVuZGVmaW5lZCwgc2hhcGVNaW5XaWR0aD86IG51bWJlciB8IHVuZGVmaW5lZCwgc3R5bGU/OiBhbnksIHRleHRTdHlsZT86IGFueSB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGRpc2FibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBlZGdlc0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgY3VzdG9tRGF0YUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGZyb21FeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGZyb21MaW5lRW5kRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBmcm9tUG9pbnRJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwga2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCBsaW5lVHlwZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgbG9ja2VkRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBwb2ludHNFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0ZXh0RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0ZXh0U3R5bGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHRvRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nLCB0b0xpbmVFbmRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHRvUG9pbnRJbmRleEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgekluZGV4RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZWRpdGluZ0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgYWxsb3dBZGRTaGFwZT86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdGlvbj86IGJvb2xlYW4sIGFsbG93Q2hhbmdlQ29ubmVjdG9yUG9pbnRzPzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VDb25uZWN0b3JUZXh0PzogYm9vbGVhbiwgYWxsb3dDaGFuZ2VTaGFwZVRleHQ/OiBib29sZWFuLCBhbGxvd0RlbGV0ZUNvbm5lY3Rvcj86IGJvb2xlYW4sIGFsbG93RGVsZXRlU2hhcGU/OiBib29sZWFuLCBhbGxvd01vdmVTaGFwZT86IGJvb2xlYW4sIGFsbG93UmVzaXplU2hhcGU/OiBib29sZWFuIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZWxlbWVudEF0dHJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgZXhwb3J0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBmaWxlTmFtZT86IHN0cmluZyB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGZ1bGxTY3JlZW5DaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIGdyaWRTaXplQ2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgeyBpdGVtcz86IEFycmF5PG51bWJlcj4sIHZhbHVlPzogbnVtYmVyIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGFzQ2hhbmdlc0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGVpZ2h0Q2hhbmdlOiBFdmVudEVtaXR0ZXI8bnVtYmVyIHwgRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQ+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgaGlzdG9yeVRvb2xiYXJDaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGNvbW1hbmRzPzogQXJyYXk8Q3VzdG9tQ29tbWFuZCB8IENvbW1hbmQ+LCB2aXNpYmxlPzogYm9vbGVhbiB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIG1haW5Ub29sYmFyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgdmlzaWJsZT86IGJvb2xlYW4gfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBub2Rlc0NoYW5nZTogRXZlbnRFbWl0dGVyPHsgYXV0b0xheW91dD86IERhdGFMYXlvdXRUeXBlIHwgeyBvcmllbnRhdGlvbj86IE9yaWVudGF0aW9uLCB0eXBlPzogRGF0YUxheW91dFR5cGUgfSwgYXV0b1NpemVFbmFibGVkPzogYm9vbGVhbiwgY29udGFpbmVyQ2hpbGRyZW5FeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGNvbnRhaW5lcktleUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgY3VzdG9tRGF0YUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgZGF0YVNvdXJjZT86IFN0b3JlIHwgRGF0YVNvdXJjZSB8IERhdGFTb3VyY2VPcHRpb25zIHwgbnVsbCB8IHN0cmluZyB8IEFycmF5PGFueT4sIGhlaWdodEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgaW1hZ2VVcmxFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGl0ZW1zRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBrZXlFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIGxlZnRFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIGxvY2tlZEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgcGFyZW50S2V5RXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCBzdHlsZUV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZyB8IHVuZGVmaW5lZCwgdGV4dEV4cHI/OiBGdW5jdGlvbiB8IHN0cmluZywgdGV4dFN0eWxlRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB0b3BFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQsIHR5cGVFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcsIHdpZHRoRXhwcj86IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkLCB6SW5kZXhFeHByPzogRnVuY3Rpb24gfCBzdHJpbmcgfCB1bmRlZmluZWQgfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBwYWdlQ29sb3JDaGFuZ2U6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgcGFnZU9yaWVudGF0aW9uQ2hhbmdlOiBFdmVudEVtaXR0ZXI8UGFnZU9yaWVudGF0aW9uPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHBhZ2VTaXplQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBoZWlnaHQ/OiBudW1iZXIsIGl0ZW1zPzogQXJyYXk8YW55IHwgeyBoZWlnaHQ/OiBudW1iZXIsIHRleHQ/OiBzdHJpbmcsIHdpZHRoPzogbnVtYmVyIH0+LCB3aWR0aD86IG51bWJlciB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHByb3BlcnRpZXNQYW5lbENoYW5nZTogRXZlbnRFbWl0dGVyPHsgdGFicz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4sIGdyb3Vwcz86IEFycmF5PGFueSB8IHsgY29tbWFuZHM/OiBBcnJheTxDdXN0b21Db21tYW5kIHwgQ29tbWFuZD4sIHRpdGxlPzogc3RyaW5nIH0+LCB0aXRsZT86IHN0cmluZyB9PiwgdmlzaWJpbGl0eT86IFBhbmVsVmlzaWJpbGl0eSB9PjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHJlYWRPbmx5Q2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBydGxFbmFibGVkQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSBzaG93R3JpZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc2ltcGxlVmlld0NoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgc25hcFRvR3JpZENoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdG9vbGJveENoYW5nZTogRXZlbnRFbWl0dGVyPHsgZ3JvdXBzPzogQXJyYXk8U2hhcGVDYXRlZ29yeSB8IGFueSB8IHsgY2F0ZWdvcnk/OiBTaGFwZUNhdGVnb3J5IHwgc3RyaW5nLCBkaXNwbGF5TW9kZT86IFRvb2xib3hEaXNwbGF5TW9kZSwgZXhwYW5kZWQ/OiBib29sZWFuLCBzaGFwZXM/OiBBcnJheTxTaGFwZVR5cGUgfCBzdHJpbmc+LCB0aXRsZT86IHN0cmluZyB9Piwgc2hhcGVJY29uc1BlclJvdz86IG51bWJlciwgc2hvd1NlYXJjaD86IGJvb2xlYW4sIHZpc2liaWxpdHk/OiBQYW5lbFZpc2liaWxpdHksIHdpZHRoPzogbnVtYmVyIHwgdW5kZWZpbmVkIH0+O1xuXG4gICAgLyoqXG4gICAgXG4gICAgICogVGhpcyBtZW1iZXIgc3VwcG9ydHMgdGhlIGludGVybmFsIGluZnJhc3RydWN0dXJlIGFuZCBpcyBub3QgaW50ZW5kZWQgdG8gYmUgdXNlZCBkaXJlY3RseSBmcm9tIHlvdXIgY29kZS5cbiAgICBcbiAgICAgKi9cbiAgICBAT3V0cHV0KCkgdW5pdHNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxVbml0cz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB1c2VOYXRpdmVTY3JvbGxpbmdDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHZpZXdUb29sYmFyQ2hhbmdlOiBFdmVudEVtaXR0ZXI8eyBjb21tYW5kcz86IEFycmF5PEN1c3RvbUNvbW1hbmQgfCBDb21tYW5kPiwgdmlzaWJsZT86IGJvb2xlYW4gfT47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2aWV3VW5pdHNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxVbml0cz47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB2aXNpYmxlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG5cbiAgICAvKipcbiAgICBcbiAgICAgKiBUaGlzIG1lbWJlciBzdXBwb3J0cyB0aGUgaW50ZXJuYWwgaW5mcmFzdHJ1Y3R1cmUgYW5kIGlzIG5vdCBpbnRlbmRlZCB0byBiZSB1c2VkIGRpcmVjdGx5IGZyb20geW91ciBjb2RlLlxuICAgIFxuICAgICAqL1xuICAgIEBPdXRwdXQoKSB3aWR0aENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlciB8IEZ1bmN0aW9uIHwgc3RyaW5nIHwgdW5kZWZpbmVkPjtcblxuICAgIC8qKlxuICAgIFxuICAgICAqIFRoaXMgbWVtYmVyIHN1cHBvcnRzIHRoZSBpbnRlcm5hbCBpbmZyYXN0cnVjdHVyZSBhbmQgaXMgbm90IGludGVuZGVkIHRvIGJlIHVzZWQgZGlyZWN0bHkgZnJvbSB5b3VyIGNvZGUuXG4gICAgXG4gICAgICovXG4gICAgQE91dHB1dCgpIHpvb21MZXZlbENoYW5nZTogRXZlbnRFbWl0dGVyPG51bWJlciB8IHsgaXRlbXM/OiBBcnJheTxudW1iZXI+LCB2YWx1ZT86IG51bWJlciB8IHVuZGVmaW5lZCB9PjtcblxuXG5cblxuICAgIEBDb250ZW50Q2hpbGRyZW4oRHhpQ3VzdG9tU2hhcGVDb21wb25lbnQpXG4gICAgZ2V0IGN1c3RvbVNoYXBlc0NoaWxkcmVuKCk6IFF1ZXJ5TGlzdDxEeGlDdXN0b21TaGFwZUNvbXBvbmVudD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0T3B0aW9uKCdjdXN0b21TaGFwZXMnKTtcbiAgICB9XG4gICAgc2V0IGN1c3RvbVNoYXBlc0NoaWxkcmVuKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRyZW4oJ2N1c3RvbVNoYXBlcycsIHZhbHVlKTtcbiAgICB9XG5cblxuXG5cbiAgICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmLCBuZ1pvbmU6IE5nWm9uZSwgdGVtcGxhdGVIb3N0OiBEeFRlbXBsYXRlSG9zdCxcbiAgICAgICAgICAgIHByaXZhdGUgX3dhdGNoZXJIZWxwZXI6IFdhdGNoZXJIZWxwZXIsXG4gICAgICAgICAgICBwcml2YXRlIF9pZGg6IEl0ZXJhYmxlRGlmZmVySGVscGVyLFxuICAgICAgICAgICAgb3B0aW9uSG9zdDogTmVzdGVkT3B0aW9uSG9zdCxcbiAgICAgICAgICAgIHRyYW5zZmVyU3RhdGU6IFRyYW5zZmVyU3RhdGUsXG4gICAgICAgICAgICBASW5qZWN0KFBMQVRGT1JNX0lEKSBwbGF0Zm9ybUlkOiBhbnkpIHtcblxuICAgICAgICBzdXBlcihlbGVtZW50UmVmLCBuZ1pvbmUsIHRlbXBsYXRlSG9zdCwgX3dhdGNoZXJIZWxwZXIsIHRyYW5zZmVyU3RhdGUsIHBsYXRmb3JtSWQpO1xuXG4gICAgICAgIHRoaXMuX2NyZWF0ZUV2ZW50RW1pdHRlcnMoW1xuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdjb250ZW50UmVhZHknLCBlbWl0OiAnb25Db250ZW50UmVhZHknIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2N1c3RvbUNvbW1hbmQnLCBlbWl0OiAnb25DdXN0b21Db21tYW5kJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdkaXNwb3NpbmcnLCBlbWl0OiAnb25EaXNwb3NpbmcnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2luaXRpYWxpemVkJywgZW1pdDogJ29uSW5pdGlhbGl6ZWQnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ2l0ZW1DbGljaycsIGVtaXQ6ICdvbkl0ZW1DbGljaycgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAnaXRlbURibENsaWNrJywgZW1pdDogJ29uSXRlbURibENsaWNrJyB9LFxuICAgICAgICAgICAgeyBzdWJzY3JpYmU6ICdvcHRpb25DaGFuZ2VkJywgZW1pdDogJ29uT3B0aW9uQ2hhbmdlZCcgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVxdWVzdEVkaXRPcGVyYXRpb24nLCBlbWl0OiAnb25SZXF1ZXN0RWRpdE9wZXJhdGlvbicgfSxcbiAgICAgICAgICAgIHsgc3Vic2NyaWJlOiAncmVxdWVzdExheW91dFVwZGF0ZScsIGVtaXQ6ICdvblJlcXVlc3RMYXlvdXRVcGRhdGUnIH0sXG4gICAgICAgICAgICB7IHN1YnNjcmliZTogJ3NlbGVjdGlvbkNoYW5nZWQnLCBlbWl0OiAnb25TZWxlY3Rpb25DaGFuZ2VkJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnYXV0b1pvb21Nb2RlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnY29udGV4dE1lbnVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdjb250ZXh0VG9vbGJveENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2N1c3RvbVNoYXBlc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2N1c3RvbVNoYXBlVGVtcGxhdGVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdjdXN0b21TaGFwZVRvb2xib3hUZW1wbGF0ZUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2RlZmF1bHRJdGVtUHJvcGVydGllc0NoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ2Rpc2FibGVkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZWRnZXNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdlZGl0aW5nQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZWxlbWVudEF0dHJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdleHBvcnRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdmdWxsU2NyZWVuQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnZ3JpZFNpemVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdoYXNDaGFuZ2VzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGVpZ2h0Q2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnaGlzdG9yeVRvb2xiYXJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdtYWluVG9vbGJhckNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ25vZGVzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncGFnZUNvbG9yQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncGFnZU9yaWVudGF0aW9uQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAncGFnZVNpemVDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdwcm9wZXJ0aWVzUGFuZWxDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdyZWFkT25seUNoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3J0bEVuYWJsZWRDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzaG93R3JpZENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3NpbXBsZVZpZXdDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICdzbmFwVG9HcmlkQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndG9vbGJveENoYW5nZScgfSxcbiAgICAgICAgICAgIHsgZW1pdDogJ3VuaXRzQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndXNlTmF0aXZlU2Nyb2xsaW5nQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAndmlld1Rvb2xiYXJDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2aWV3VW5pdHNDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd2aXNpYmxlQ2hhbmdlJyB9LFxuICAgICAgICAgICAgeyBlbWl0OiAnd2lkdGhDaGFuZ2UnIH0sXG4gICAgICAgICAgICB7IGVtaXQ6ICd6b29tTGV2ZWxDaGFuZ2UnIH1cbiAgICAgICAgXSk7XG5cbiAgICAgICAgdGhpcy5faWRoLnNldEhvc3QodGhpcyk7XG4gICAgICAgIG9wdGlvbkhvc3Quc2V0SG9zdCh0aGlzKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgX2NyZWF0ZUluc3RhbmNlKGVsZW1lbnQsIG9wdGlvbnMpIHtcblxuICAgICAgICByZXR1cm4gbmV3IER4RGlhZ3JhbShlbGVtZW50LCBvcHRpb25zKTtcbiAgICB9XG5cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9kZXN0cm95V2lkZ2V0KCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBzdXBlci5uZ09uQ2hhbmdlcyhjaGFuZ2VzKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYW5nZXMoJ2N1c3RvbVNoYXBlcycsIGNoYW5nZXMpO1xuICAgIH1cblxuICAgIHNldHVwQ2hhbmdlcyhwcm9wOiBzdHJpbmcsIGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgaWYgKCEocHJvcCBpbiB0aGlzLl9vcHRpb25zVG9VcGRhdGUpKSB7XG4gICAgICAgICAgICB0aGlzLl9pZGguc2V0dXAocHJvcCwgY2hhbmdlcyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBuZ0RvQ2hlY2soKSB7XG4gICAgICAgIHRoaXMuX2lkaC5kb0NoZWNrKCdjdXN0b21TaGFwZXMnKTtcbiAgICAgICAgdGhpcy5fd2F0Y2hlckhlbHBlci5jaGVja1dhdGNoZXJzKCk7XG4gICAgICAgIHN1cGVyLm5nRG9DaGVjaygpO1xuICAgICAgICBzdXBlci5jbGVhckNoYW5nZWRPcHRpb25zKCk7XG4gICAgfVxuXG4gICAgX3NldE9wdGlvbihuYW1lOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcbiAgICAgICAgbGV0IGlzU2V0dXAgPSB0aGlzLl9pZGguc2V0dXBTaW5nbGUobmFtZSwgdmFsdWUpO1xuICAgICAgICBsZXQgaXNDaGFuZ2VkID0gdGhpcy5faWRoLmdldENoYW5nZXMobmFtZSwgdmFsdWUpICE9PSBudWxsO1xuXG4gICAgICAgIGlmIChpc1NldHVwIHx8IGlzQ2hhbmdlZCkge1xuICAgICAgICAgICAgc3VwZXIuX3NldE9wdGlvbihuYW1lLCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgICBEeG9Db250ZXh0TWVudU1vZHVsZSxcbiAgICBEeGlDb21tYW5kTW9kdWxlLFxuICAgIER4aUl0ZW1Nb2R1bGUsXG4gICAgRHhvQ29udGV4dFRvb2xib3hNb2R1bGUsXG4gICAgRHhpQ3VzdG9tU2hhcGVNb2R1bGUsXG4gICAgRHhpQ29ubmVjdGlvblBvaW50TW9kdWxlLFxuICAgIER4b0RlZmF1bHRJdGVtUHJvcGVydGllc01vZHVsZSxcbiAgICBEeG9FZGdlc01vZHVsZSxcbiAgICBEeG9FZGl0aW5nTW9kdWxlLFxuICAgIER4b0V4cG9ydE1vZHVsZSxcbiAgICBEeG9HcmlkU2l6ZU1vZHVsZSxcbiAgICBEeG9IaXN0b3J5VG9vbGJhck1vZHVsZSxcbiAgICBEeG9NYWluVG9vbGJhck1vZHVsZSxcbiAgICBEeG9Ob2Rlc01vZHVsZSxcbiAgICBEeG9BdXRvTGF5b3V0TW9kdWxlLFxuICAgIER4b1BhZ2VTaXplTW9kdWxlLFxuICAgIER4b1Byb3BlcnRpZXNQYW5lbE1vZHVsZSxcbiAgICBEeGlUYWJNb2R1bGUsXG4gICAgRHhpR3JvdXBNb2R1bGUsXG4gICAgRHhvVG9vbGJveE1vZHVsZSxcbiAgICBEeG9WaWV3VG9vbGJhck1vZHVsZSxcbiAgICBEeG9ab29tTGV2ZWxNb2R1bGUsXG4gICAgRHhJbnRlZ3JhdGlvbk1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlXG4gIF0sXG4gIGRlY2xhcmF0aW9uczogW1xuICAgIER4RGlhZ3JhbUNvbXBvbmVudFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRHhEaWFncmFtQ29tcG9uZW50LFxuICAgIER4b0NvbnRleHRNZW51TW9kdWxlLFxuICAgIER4aUNvbW1hbmRNb2R1bGUsXG4gICAgRHhpSXRlbU1vZHVsZSxcbiAgICBEeG9Db250ZXh0VG9vbGJveE1vZHVsZSxcbiAgICBEeGlDdXN0b21TaGFwZU1vZHVsZSxcbiAgICBEeGlDb25uZWN0aW9uUG9pbnRNb2R1bGUsXG4gICAgRHhvRGVmYXVsdEl0ZW1Qcm9wZXJ0aWVzTW9kdWxlLFxuICAgIER4b0VkZ2VzTW9kdWxlLFxuICAgIER4b0VkaXRpbmdNb2R1bGUsXG4gICAgRHhvRXhwb3J0TW9kdWxlLFxuICAgIER4b0dyaWRTaXplTW9kdWxlLFxuICAgIER4b0hpc3RvcnlUb29sYmFyTW9kdWxlLFxuICAgIER4b01haW5Ub29sYmFyTW9kdWxlLFxuICAgIER4b05vZGVzTW9kdWxlLFxuICAgIER4b0F1dG9MYXlvdXRNb2R1bGUsXG4gICAgRHhvUGFnZVNpemVNb2R1bGUsXG4gICAgRHhvUHJvcGVydGllc1BhbmVsTW9kdWxlLFxuICAgIER4aVRhYk1vZHVsZSxcbiAgICBEeGlHcm91cE1vZHVsZSxcbiAgICBEeG9Ub29sYm94TW9kdWxlLFxuICAgIER4b1ZpZXdUb29sYmFyTW9kdWxlLFxuICAgIER4b1pvb21MZXZlbE1vZHVsZSxcbiAgICBEeFRlbXBsYXRlTW9kdWxlXG4gIF1cbn0pXG5leHBvcnQgY2xhc3MgRHhEaWFncmFtTW9kdWxlIHsgfVxuXG5pbXBvcnQgdHlwZSAqIGFzIER4RGlhZ3JhbVR5cGVzIGZyb20gXCJkZXZleHRyZW1lL3VpL2RpYWdyYW1fdHlwZXNcIjtcbmV4cG9ydCB7IER4RGlhZ3JhbVR5cGVzIH07XG5cblxuIl19