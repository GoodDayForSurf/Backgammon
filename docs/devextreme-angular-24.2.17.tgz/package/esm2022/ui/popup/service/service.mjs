/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { Injectable, ApplicationRef, ComponentFactoryResolver, Injector, } from '@angular/core';
import { DxServicePopupComponent } from './service.component';
import * as i0 from "@angular/core";
export class DxPopupService {
    injector;
    applicationRef;
    componentFactoryResolver;
    constructor(injector, applicationRef, componentFactoryResolver) {
        this.injector = injector;
        this.applicationRef = applicationRef;
        this.componentFactoryResolver = componentFactoryResolver;
    }
    open(contentComponent, popupOptions) {
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(DxServicePopupComponent);
        const componentRef = componentFactory.create(this.injector);
        const cmpInstance = componentRef.instance;
        cmpInstance.onHidden.subscribe(() => {
            this.applicationRef.detachView(componentRef.hostView);
            componentRef.destroy();
        });
        cmpInstance.afterViewInit$.subscribe(() => {
            if (popupOptions) {
                cmpInstance.instance.option(popupOptions);
            }
            componentRef.instance.contentRef = cmpInstance.contentInsertion?.viewContainerRef.createComponent(contentComponent);
        });
        this.applicationRef.attachView(componentRef.hostView);
        const domElem = componentRef.hostView.rootNodes[0];
        document.body.appendChild(domElem);
        cmpInstance.visible = true;
        this.applicationRef.tick();
        return componentRef.instance;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxPopupService, deps: [{ token: i0.Injector }, { token: i0.ApplicationRef }, { token: i0.ComponentFactoryResolver }], target: i0.ɵɵFactoryTarget.Injectable });
    /** @nocollapse */ static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxPopupService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxPopupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i0.Injector }, { type: i0.ApplicationRef }, { type: i0.ComponentFactoryResolver }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2Rpc3QvdWkvcG9wdXAvc2VydmljZS9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsT0FBTyxFQUNMLFVBQVUsRUFDVixjQUFjLEVBQ2Qsd0JBQXdCLEVBQ3hCLFFBQVEsR0FHVCxNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQzs7QUFLOUQsTUFBTSxPQUFPLGNBQWM7SUFFTjtJQUNBO0lBQ0E7SUFIbkIsWUFDbUIsUUFBa0IsRUFDbEIsY0FBOEIsRUFDOUIsd0JBQWtEO1FBRmxELGFBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsbUJBQWMsR0FBZCxjQUFjLENBQWdCO1FBQzlCLDZCQUF3QixHQUF4Qix3QkFBd0IsQ0FBMEI7SUFDbEUsQ0FBQztJQUVKLElBQUksQ0FBSSxnQkFBeUIsRUFBRSxZQUFzQztRQUN2RSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyx1QkFBdUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBQ3hHLE1BQU0sWUFBWSxHQUEwQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ25HLE1BQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxRQUFRLENBQUM7UUFFMUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN0RCxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7UUFFSCxXQUFXLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDeEMsSUFBSSxZQUFZLEVBQUU7Z0JBQ2hCLFdBQVcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQzNDO1lBRUQsWUFBWSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3RILENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXRELE1BQU0sT0FBTyxHQUFJLFlBQVksQ0FBQyxRQUFpQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQWdCLENBQUM7UUFFNUYsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFbkMsV0FBVyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFM0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUUzQixPQUFPLFlBQVksQ0FBQyxRQUE0RSxDQUFDO0lBQ25HLENBQUM7MkhBcENVLGNBQWM7K0hBQWQsY0FBYyxjQUZiLE1BQU07OzRGQUVQLGNBQWM7a0JBSDFCLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25CIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbmltcG9ydCB7XHJcbiAgSW5qZWN0YWJsZSxcclxuICBBcHBsaWNhdGlvblJlZixcclxuICBDb21wb25lbnRGYWN0b3J5UmVzb2x2ZXIsXHJcbiAgSW5qZWN0b3IsXHJcbiAgRW1iZWRkZWRWaWV3UmVmLFxyXG4gIENvbXBvbmVudFJlZiwgVHlwZSxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRHhQb3B1cFR5cGVzIH0gZnJvbSAnLi4vY29tcG9uZW50JztcclxuaW1wb3J0IHsgRHhTZXJ2aWNlUG9wdXBDb21wb25lbnQgfSBmcm9tICcuL3NlcnZpY2UuY29tcG9uZW50JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCcsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEeFBvcHVwU2VydmljZSB7XHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IGluamVjdG9yOiBJbmplY3RvcixcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgYXBwbGljYXRpb25SZWY6IEFwcGxpY2F0aW9uUmVmLFxyXG4gICAgcHJpdmF0ZSByZWFkb25seSBjb21wb25lbnRGYWN0b3J5UmVzb2x2ZXI6IENvbXBvbmVudEZhY3RvcnlSZXNvbHZlcixcclxuICApIHt9XHJcblxyXG4gIG9wZW48VD4oY29udGVudENvbXBvbmVudDogVHlwZTxUPiwgcG9wdXBPcHRpb25zPzogRHhQb3B1cFR5cGVzLlByb3BlcnRpZXMpIHtcclxuICAgIGNvbnN0IGNvbXBvbmVudEZhY3RvcnkgPSB0aGlzLmNvbXBvbmVudEZhY3RvcnlSZXNvbHZlci5yZXNvbHZlQ29tcG9uZW50RmFjdG9yeShEeFNlcnZpY2VQb3B1cENvbXBvbmVudCk7XHJcbiAgICBjb25zdCBjb21wb25lbnRSZWY6IENvbXBvbmVudFJlZjxEeFNlcnZpY2VQb3B1cENvbXBvbmVudD4gPSBjb21wb25lbnRGYWN0b3J5LmNyZWF0ZSh0aGlzLmluamVjdG9yKTtcclxuICAgIGNvbnN0IGNtcEluc3RhbmNlID0gY29tcG9uZW50UmVmLmluc3RhbmNlO1xyXG5cclxuICAgIGNtcEluc3RhbmNlLm9uSGlkZGVuLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgIHRoaXMuYXBwbGljYXRpb25SZWYuZGV0YWNoVmlldyhjb21wb25lbnRSZWYuaG9zdFZpZXcpO1xyXG4gICAgICBjb21wb25lbnRSZWYuZGVzdHJveSgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgY21wSW5zdGFuY2UuYWZ0ZXJWaWV3SW5pdCQuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgaWYgKHBvcHVwT3B0aW9ucykge1xyXG4gICAgICAgIGNtcEluc3RhbmNlLmluc3RhbmNlLm9wdGlvbihwb3B1cE9wdGlvbnMpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb21wb25lbnRSZWYuaW5zdGFuY2UuY29udGVudFJlZiA9IGNtcEluc3RhbmNlLmNvbnRlbnRJbnNlcnRpb24/LnZpZXdDb250YWluZXJSZWYuY3JlYXRlQ29tcG9uZW50KGNvbnRlbnRDb21wb25lbnQpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5hcHBsaWNhdGlvblJlZi5hdHRhY2hWaWV3KGNvbXBvbmVudFJlZi5ob3N0Vmlldyk7XHJcblxyXG4gICAgY29uc3QgZG9tRWxlbSA9IChjb21wb25lbnRSZWYuaG9zdFZpZXcgYXMgRW1iZWRkZWRWaWV3UmVmPGFueT4pLnJvb3ROb2Rlc1swXSBhcyBIVE1MRWxlbWVudDtcclxuXHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGRvbUVsZW0pO1xyXG5cclxuICAgIGNtcEluc3RhbmNlLnZpc2libGUgPSB0cnVlO1xyXG5cclxuICAgIHRoaXMuYXBwbGljYXRpb25SZWYudGljaygpO1xyXG5cclxuICAgIHJldHVybiBjb21wb25lbnRSZWYuaW5zdGFuY2UgYXMgKHR5cGVvZiBjb21wb25lbnRSZWYuaW5zdGFuY2UgJiB7IGNvbnRlbnRSZWY6IENvbXBvbmVudFJlZjxUPiB9KTtcclxuICB9XHJcbn1cclxuIl19