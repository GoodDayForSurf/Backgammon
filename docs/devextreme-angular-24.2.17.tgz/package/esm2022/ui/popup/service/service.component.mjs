/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { Component, ElementRef, EventEmitter, Inject, NgZone, Output, PLATFORM_ID, TransferState, ViewChild, } from '@angular/core';
import { DxTemplateHost, IterableDifferHelper, NestedOptionHost, WatcherHelper, } from 'devextreme-angular/core';
import { DxPopupComponent } from '../component';
import { DxServicePopupInsertionDirective } from './insertion.directive';
import * as i0 from "@angular/core";
import * as i1 from "devextreme-angular/core";
export class DxServicePopupComponent extends DxPopupComponent {
    contentInsertion;
    afterViewInit$ = new EventEmitter();
    contentRef;
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId);
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.afterViewInit$.emit();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServicePopupComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxServicePopupComponent, isStandalone: true, selector: "ng-component", outputs: { afterViewInit$: "afterViewInit$" }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper,
        ], viewQueries: [{ propertyName: "contentInsertion", first: true, predicate: DxServicePopupInsertionDirective, descendants: true }], usesInheritance: true, ngImport: i0, template: '<ng-template popup-content-insertion></ng-template>', isInline: true, dependencies: [{ kind: "directive", type: DxServicePopupInsertionDirective, selector: "[popup-content-insertion]" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServicePopupComponent, decorators: [{
            type: Component,
            args: [{
                    standalone: true,
                    imports: [DxServicePopupInsertionDirective],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper,
                    ],
                    template: '<ng-template popup-content-insertion></ng-template>',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { contentInsertion: [{
                type: ViewChild,
                args: [DxServicePopupInsertionDirective]
            }], afterViewInit$: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9kaXN0L3VpL3BvcHVwL3NlcnZpY2Uvc2VydmljZS5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxPQUFPLEVBRUwsU0FBUyxFQUNULFVBQVUsRUFDVixZQUFZLEVBQUUsTUFBTSxFQUNwQixNQUFNLEVBQ04sTUFBTSxFQUFFLFdBQVcsRUFDbkIsYUFBYSxFQUNiLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQ0wsY0FBYyxFQUNkLG9CQUFvQixFQUNwQixnQkFBZ0IsRUFDaEIsYUFBYSxHQUNkLE1BQU0seUJBQXlCLENBQUM7QUFDakMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ2hELE9BQU8sRUFBRSxnQ0FBZ0MsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFhekUsTUFBTSxPQUFPLHVCQUF3QixTQUFRLGdCQUFnQjtJQUNkLGdCQUFnQixDQUFtQztJQUV0RixjQUFjLEdBQXVCLElBQUksWUFBWSxFQUFRLENBQUM7SUFFeEUsVUFBVSxDQUF3QjtJQUVsQyxZQUNFLFVBQXNCLEVBQ3RCLE1BQWMsRUFDZCxZQUE0QixFQUM1QixjQUE2QixFQUM3QixJQUEwQixFQUMxQixVQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFFcEMsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUN2RyxDQUFDO0lBRUQsZUFBZTtRQUNiLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzdCLENBQUM7MkhBdkJVLHVCQUF1Qiw4TkFleEIsV0FBVzsrR0FmVix1QkFBdUIsMEdBUnZCO1lBQ1QsY0FBYztZQUNkLGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsb0JBQW9CO1NBQ3JCLDRFQUlVLGdDQUFnQyx1RUFIakMscURBQXFELDREQVByRCxnQ0FBZ0M7OzRGQVMvQix1QkFBdUI7a0JBWG5DLFNBQVM7bUJBQUM7b0JBQ1QsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxDQUFDLGdDQUFnQyxDQUFDO29CQUMzQyxTQUFTLEVBQUU7d0JBQ1QsY0FBYzt3QkFDZCxhQUFhO3dCQUNiLGdCQUFnQjt3QkFDaEIsb0JBQW9CO3FCQUNyQjtvQkFDRCxRQUFRLEVBQUUscURBQXFEO2lCQUNoRTs7MEJBZ0JJLE1BQU07MkJBQUMsV0FBVzs0Q0Fkd0IsZ0JBQWdCO3NCQUE1RCxTQUFTO3VCQUFDLGdDQUFnQztnQkFFakMsY0FBYztzQkFBdkIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG5pbXBvcnQge1xyXG4gIEFmdGVyVmlld0luaXQsXHJcbiAgQ29tcG9uZW50LCBDb21wb25lbnRSZWYsXHJcbiAgRWxlbWVudFJlZixcclxuICBFdmVudEVtaXR0ZXIsIEluamVjdCxcclxuICBOZ1pvbmUsXHJcbiAgT3V0cHV0LCBQTEFURk9STV9JRCxcclxuICBUcmFuc2ZlclN0YXRlLFxyXG4gIFZpZXdDaGlsZCxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICBEeFRlbXBsYXRlSG9zdCxcclxuICBJdGVyYWJsZURpZmZlckhlbHBlcixcclxuICBOZXN0ZWRPcHRpb25Ib3N0LFxyXG4gIFdhdGNoZXJIZWxwZXIsXHJcbn0gZnJvbSAnZGV2ZXh0cmVtZS1hbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBEeFBvcHVwQ29tcG9uZW50IH0gZnJvbSAnLi4vY29tcG9uZW50JztcclxuaW1wb3J0IHsgRHhTZXJ2aWNlUG9wdXBJbnNlcnRpb25EaXJlY3RpdmUgfSBmcm9tICcuL2luc2VydGlvbi5kaXJlY3RpdmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcclxuICBpbXBvcnRzOiBbRHhTZXJ2aWNlUG9wdXBJbnNlcnRpb25EaXJlY3RpdmVdLFxyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgRHhUZW1wbGF0ZUhvc3QsXHJcbiAgICBXYXRjaGVySGVscGVyLFxyXG4gICAgTmVzdGVkT3B0aW9uSG9zdCxcclxuICAgIEl0ZXJhYmxlRGlmZmVySGVscGVyLFxyXG4gIF0sXHJcbiAgdGVtcGxhdGU6ICc8bmctdGVtcGxhdGUgcG9wdXAtY29udGVudC1pbnNlcnRpb24+PC9uZy10ZW1wbGF0ZT4nLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgRHhTZXJ2aWNlUG9wdXBDb21wb25lbnQgZXh0ZW5kcyBEeFBvcHVwQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgQFZpZXdDaGlsZChEeFNlcnZpY2VQb3B1cEluc2VydGlvbkRpcmVjdGl2ZSkgY29udGVudEluc2VydGlvbjogRHhTZXJ2aWNlUG9wdXBJbnNlcnRpb25EaXJlY3RpdmU7XHJcblxyXG4gIEBPdXRwdXQoKSBhZnRlclZpZXdJbml0JDogRXZlbnRFbWl0dGVyPHZvaWQ+ID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xyXG5cclxuICBjb250ZW50UmVmOiBDb21wb25lbnRSZWY8dW5rbm93bj47XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgIG5nWm9uZTogTmdab25lLFxyXG4gICAgdGVtcGxhdGVIb3N0OiBEeFRlbXBsYXRlSG9zdCxcclxuICAgIF93YXRjaGVySGVscGVyOiBXYXRjaGVySGVscGVyLFxyXG4gICAgX2lkaDogSXRlcmFibGVEaWZmZXJIZWxwZXIsXHJcbiAgICBvcHRpb25Ib3N0OiBOZXN0ZWRPcHRpb25Ib3N0LFxyXG4gICAgdHJhbnNmZXJTdGF0ZTogVHJhbnNmZXJTdGF0ZSxcclxuICAgIEBJbmplY3QoUExBVEZPUk1fSUQpIHBsYXRmb3JtSWQ6IGFueSxcclxuICApIHtcclxuICAgIHN1cGVyKGVsZW1lbnRSZWYsIG5nWm9uZSwgdGVtcGxhdGVIb3N0LCBfd2F0Y2hlckhlbHBlciwgX2lkaCwgb3B0aW9uSG9zdCwgdHJhbnNmZXJTdGF0ZSwgcGxhdGZvcm1JZCk7XHJcbiAgfVxyXG5cclxuICBuZ0FmdGVyVmlld0luaXQoKSB7XHJcbiAgICBzdXBlci5uZ0FmdGVyVmlld0luaXQoKTtcclxuICAgIHRoaXMuYWZ0ZXJWaWV3SW5pdCQuZW1pdCgpO1xyXG4gIH1cclxufVxyXG4iXX0=