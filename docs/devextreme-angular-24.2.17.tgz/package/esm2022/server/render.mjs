/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { NgModule, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformServer } from '@angular/common';
import infernoRenderer from 'devextreme/core/inferno_renderer';
import { renderToString } from 'inferno-server';
import * as i0 from "@angular/core";
export class DxServerModule {
    constructor(platformId) {
        if (isPlatformServer(platformId)) {
            infernoRenderer.inject({
                render: (component, props, container) => {
                    const el = infernoRenderer.createElement(component, props);
                    const document = container.ownerDocument;
                    const temp = document.createElement(container.tagName);
                    temp.innerHTML = renderToString(el);
                    const mainElement = temp.childNodes[0];
                    const childString = mainElement.innerHTML;
                    for (let i = 0; i < mainElement.attributes.length; i++) {
                        temp.setAttribute(mainElement.attributes[i].name, mainElement.attributes[i].value);
                    }
                    temp.innerHTML = childString;
                    container.outerHTML = temp.outerHTML;
                },
            });
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule, deps: [{ token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxServerModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [],
                    imports: [],
                    providers: [],
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVuZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vZGlzdC9zZXJ2ZXIvcmVuZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzlELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRW5ELE9BQU8sZUFBZSxNQUFNLGtDQUFrQyxDQUFDO0FBQy9ELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7QUFPaEQsTUFBTSxPQUFPLGNBQWM7SUFDekIsWUFBaUMsVUFBZTtRQUM5QyxJQUFJLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ2hDLGVBQWUsQ0FBQyxNQUFNLENBQUM7Z0JBQ3JCLE1BQU0sRUFBRSxDQUNOLFNBQVMsRUFDVCxLQUFLLEVBQ0wsU0FBUyxFQUNULEVBQUU7b0JBQ0YsTUFBTSxFQUFFLEdBQUcsZUFBZSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQzNELE1BQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUM7b0JBQ3pDLE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUN2RCxJQUFJLENBQUMsU0FBUyxHQUFHLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDcEMsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkMsTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQztvQkFFMUMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUN0RCxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3BGO29CQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDO29CQUM3QixTQUFTLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ3ZDLENBQUM7YUFDRixDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7MkhBeEJVLGNBQWMsa0JBQ0wsV0FBVzs0SEFEcEIsY0FBYzs0SEFBZCxjQUFjOzs0RkFBZCxjQUFjO2tCQUwxQixRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRSxFQUFFO29CQUNYLE9BQU8sRUFBRSxFQUFFO29CQUNYLFNBQVMsRUFBRSxFQUFFO2lCQUNkOzswQkFFYyxNQUFNOzJCQUFDLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAqIGRldmV4dHJlbWUtYW5ndWxhclxuICogVmVyc2lvbjogMjQuMi4wXG4gKiBCdWlsZCBkYXRlOiBGcmkgQXVnIDE2IDIwMjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDI0IERldmVsb3BlciBFeHByZXNzIEluYy4gQUxMIFJJR0hUUyBSRVNFUlZFRFxuICpcbiAqIFRoaXMgc29mdHdhcmUgbWF5IGJlIG1vZGlmaWVkIGFuZCBkaXN0cmlidXRlZCB1bmRlciB0aGUgdGVybXNcbiAqIG9mIHRoZSBNSVQgbGljZW5zZS4gU2VlIHRoZSBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3Qgb2YgdGhlIHByb2plY3QgZm9yIGRldGFpbHMuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RldkV4cHJlc3MvZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKi9cblxuaW1wb3J0IHsgTmdNb2R1bGUsIEluamVjdCwgUExBVEZPUk1fSUQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgaXNQbGF0Zm9ybVNlcnZlciB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcblxyXG5pbXBvcnQgaW5mZXJub1JlbmRlcmVyIGZyb20gJ2RldmV4dHJlbWUvY29yZS9pbmZlcm5vX3JlbmRlcmVyJztcclxuaW1wb3J0IHsgcmVuZGVyVG9TdHJpbmcgfSBmcm9tICdpbmZlcm5vLXNlcnZlcic7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGV4cG9ydHM6IFtdLFxyXG4gIGltcG9ydHM6IFtdLFxyXG4gIHByb3ZpZGVyczogW10sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEeFNlcnZlck1vZHVsZSB7XHJcbiAgY29uc3RydWN0b3IoQEluamVjdChQTEFURk9STV9JRCkgcGxhdGZvcm1JZDogYW55KSB7XHJcbiAgICBpZiAoaXNQbGF0Zm9ybVNlcnZlcihwbGF0Zm9ybUlkKSkge1xyXG4gICAgICBpbmZlcm5vUmVuZGVyZXIuaW5qZWN0KHtcclxuICAgICAgICByZW5kZXI6IChcclxuICAgICAgICAgIGNvbXBvbmVudCxcclxuICAgICAgICAgIHByb3BzLFxyXG4gICAgICAgICAgY29udGFpbmVyLFxyXG4gICAgICAgICkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZWwgPSBpbmZlcm5vUmVuZGVyZXIuY3JlYXRlRWxlbWVudChjb21wb25lbnQsIHByb3BzKTtcclxuICAgICAgICAgIGNvbnN0IGRvY3VtZW50ID0gY29udGFpbmVyLm93bmVyRG9jdW1lbnQ7XHJcbiAgICAgICAgICBjb25zdCB0ZW1wID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChjb250YWluZXIudGFnTmFtZSk7XHJcbiAgICAgICAgICB0ZW1wLmlubmVySFRNTCA9IHJlbmRlclRvU3RyaW5nKGVsKTtcclxuICAgICAgICAgIGNvbnN0IG1haW5FbGVtZW50ID0gdGVtcC5jaGlsZE5vZGVzWzBdO1xyXG4gICAgICAgICAgY29uc3QgY2hpbGRTdHJpbmcgPSBtYWluRWxlbWVudC5pbm5lckhUTUw7XHJcblxyXG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYWluRWxlbWVudC5hdHRyaWJ1dGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHRlbXAuc2V0QXR0cmlidXRlKG1haW5FbGVtZW50LmF0dHJpYnV0ZXNbaV0ubmFtZSwgbWFpbkVsZW1lbnQuYXR0cmlidXRlc1tpXS52YWx1ZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0ZW1wLmlubmVySFRNTCA9IGNoaWxkU3RyaW5nO1xyXG4gICAgICAgICAgY29udGFpbmVyLm91dGVySFRNTCA9IHRlbXAub3V0ZXJIVE1MO1xyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0=