/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { TransferState, makeStateKey, Component, ElementRef, NgZone, PLATFORM_ID, Inject, EventEmitter, } from '@angular/core';
import { isPlatformServer } from '@angular/common';
import domAdapter from 'devextreme/core/dom_adapter';
import { triggerHandler } from 'devextreme/events';
import config from 'devextreme/core/config';
import { DxTemplateHost } from './template-host';
import { EmitterHelper, NgEventsStrategy } from './events-strategy';
import { WatcherHelper } from './watcher-helper';
import { CollectionNestedOptionContainerImpl, } from './nested-option';
import * as i0 from "@angular/core";
import * as i1 from "./template-host";
import * as i2 from "./watcher-helper";
config({
    buyNowLink: 'https://go.devexpress.com/Licensing_Installer_Watermark_DevExtremeAngular.aspx',
});
let serverStateKey;
export const getServerStateKey = () => {
    if (!serverStateKey) {
        serverStateKey = makeStateKey('DX_isPlatformServer');
    }
    return serverStateKey;
};
export class DxComponent {
    element;
    ngZone;
    watcherHelper;
    transferState;
    platformId;
    _initialOptions = {};
    _optionsToUpdate = {};
    _collectionContainerImpl;
    eventHelper;
    optionChangedHandlers = new EventEmitter();
    templates;
    instance;
    isLinked = true;
    changedOptions = {};
    removedNestedComponents = [];
    recreatedNestedComponents;
    widgetUpdateLocked = false;
    templateUpdateRequired = false;
    _updateTemplates() {
        if (this.templates.length && this.templateUpdateRequired) {
            const updatedTemplates = {};
            this.templates.forEach((template) => {
                updatedTemplates[template.name] = template;
            });
            this.instance.option('integrationOptions.templates', updatedTemplates);
            this.templates = Object.values(updatedTemplates);
            this.templateUpdateRequired = false;
        }
    }
    _initEvents() {
        this.instance.on('optionChanged', (e) => {
            this.changedOptions[e.name] = e.value;
            const value = e.name === e.fullName ? e.value : e.component.option(e.name);
            this.eventHelper.fireNgEvent(`${e.name}Change`, [value]);
            this.optionChangedHandlers.emit(e);
        });
    }
    _initOptions() {
        this._initialOptions.integrationOptions.watchMethod = this.watcherHelper.getWatchMethod();
    }
    _initPlatform() {
        if (this.transferState.hasKey(getServerStateKey())) {
            this._initialOptions.integrationOptions.renderedOnServer = this.transferState.get(getServerStateKey(), null);
        }
        else if (isPlatformServer(this.platformId)) {
            this.transferState.set(getServerStateKey(), true);
        }
    }
    _createEventEmitters(events) {
        const zone = this.ngZone;
        this.eventHelper.createEmitters(events);
        this._initialOptions.eventsStrategy = (instance) => {
            const strategy = new NgEventsStrategy(instance, zone);
            events.filter((event) => event.subscribe).forEach((event) => {
                strategy.addEmitter(event.subscribe, this[event.emit]);
            });
            return strategy;
        };
        this._initialOptions.nestedComponentOptions = function (component) {
            return {
                eventsStrategy: (instance) => new NgEventsStrategy(instance, zone),
                nestedComponentOptions: component.option('nestedComponentOptions'),
            };
        };
    }
    _shouldOptionChange(name, value) {
        if (this.changedOptions.hasOwnProperty(name)) {
            const prevValue = this.changedOptions[name];
            delete this.changedOptions[name];
            return value !== prevValue;
        }
        return true;
    }
    clearChangedOptions() {
        this.changedOptions = {};
    }
    _getOption(name) {
        return this.instance
            ? this.instance.option(name)
            : this._initialOptions[name];
    }
    lockWidgetUpdate() {
        if (!this.widgetUpdateLocked && this.instance) {
            this.instance.beginUpdate();
            this.widgetUpdateLocked = true;
        }
    }
    unlockWidgetUpdate() {
        if (this.widgetUpdateLocked) {
            this.widgetUpdateLocked = false;
            this.instance.endUpdate();
        }
    }
    _setOption(name, value) {
        this.lockWidgetUpdate();
        if (!this._shouldOptionChange(name, value)) {
            return;
        }
        if (this.instance) {
            this.instance.option(name, value);
        }
        else {
            this._initialOptions[name] = value;
        }
    }
    _createWidget(element) {
        this._initialOptions.integrationOptions = {};
        this._initPlatform();
        this._initOptions();
        this._initialOptions.onInitializing = function () {
            this.beginUpdate();
        };
        this.instance = this._createInstance(element, this._initialOptions);
        this._initEvents();
        this._initialOptions = {};
    }
    _destroyWidget() {
        this.removedNestedComponents = [];
        if (this.instance) {
            const element = this.instance.element();
            triggerHandler(element, 'dxremove', { _angularIntegration: true });
            this.instance.dispose();
            domAdapter.removeElement(element);
        }
    }
    constructor(element, ngZone, templateHost, watcherHelper, transferState, platformId) {
        this.element = element;
        this.ngZone = ngZone;
        this.watcherHelper = watcherHelper;
        this.transferState = transferState;
        this.platformId = platformId;
        this.templates = [];
        templateHost.setHost(this);
        this._collectionContainerImpl = new CollectionNestedOptionContainerImpl(this._setOption.bind(this));
        this.eventHelper = new EmitterHelper(ngZone, this);
    }
    ngOnChanges(changes) {
        for (const key in changes) {
            const change = changes[key];
            if (change.currentValue !== this[key]) {
                this._optionsToUpdate[key] = changes[key].currentValue;
            }
        }
    }
    ngOnInit() {
        this._createWidget(this.element.nativeElement);
    }
    ngDoCheck() {
        this.applyOptions();
    }
    ngAfterContentChecked() {
        this.applyOptions();
        this.resetOptions();
        this.unlockWidgetUpdate();
    }
    ngAfterViewInit() {
        this._updateTemplates();
        this.instance.endUpdate();
        this.recreatedNestedComponents = [];
    }
    ngAfterViewChecked() {
        this._updateTemplates();
    }
    applyOptions() {
        if (Object.keys(this._optionsToUpdate).length) {
            if (this.instance) {
                this.instance.option(this._optionsToUpdate);
            }
            this._optionsToUpdate = {};
        }
    }
    resetOptions(collectionName) {
        if (this.instance) {
            this.removedNestedComponents.filter((option) => (option
                && !this.isRecreated(option)
                && collectionName ? option.startsWith(collectionName) : true))
                .forEach((option) => {
                this.instance.resetOption(option);
            });
            this.removedNestedComponents = [];
            this.recreatedNestedComponents = [];
        }
    }
    isRecreated(name) {
        return this.recreatedNestedComponents
            && this.recreatedNestedComponents.some((nestedComponent) => nestedComponent.getOptionPath() === name);
    }
    setTemplate(template) {
        this.templates.push(template);
        this.templateUpdateRequired = true;
    }
    setChildren(propertyName, items) {
        this.resetOptions(propertyName);
        return this._collectionContainerImpl.setChildren(propertyName, items);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i2.WatcherHelper }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxComponent, selector: "ng-component", usesOnChanges: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxComponent, decorators: [{
            type: Component,
            args: [{
                    template: '',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i2.WatcherHelper }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; } });
export class DxComponentExtension extends DxComponent {
    createInstance(element) {
        this._createWidget(element);
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this._createWidget(this.element.nativeElement);
        this.instance.endUpdate();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxComponentExtension, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DxComponentExtension, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxComponentExtension, decorators: [{
            type: Component,
            args: [{
                    template: '',
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vZGlzdC9jb3JlL2NvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILE9BQU8sRUFDTCxhQUFhLEVBQ2IsWUFBWSxFQUNaLFNBQVMsRUFDVCxVQUFVLEVBQ1YsTUFBTSxFQUdOLFdBQVcsRUFDWCxNQUFNLEVBQ04sWUFBWSxHQVFiLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRW5ELE9BQU8sVUFBVSxNQUFNLDZCQUE2QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUNuRCxPQUFPLE1BQU0sTUFBTSx3QkFBd0IsQ0FBQztBQUc1QyxPQUFPLEVBQW1CLGNBQWMsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxhQUFhLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUNwRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFFakQsT0FBTyxFQUlMLG1DQUFtQyxHQUNwQyxNQUFNLGlCQUFpQixDQUFDOzs7O0FBRXpCLE1BQU0sQ0FBQztJQUNMLFVBQVUsRUFBRSxnRkFBZ0Y7Q0FDN0YsQ0FBQyxDQUFDO0FBRUgsSUFBSSxjQUFjLENBQUM7QUFDbkIsTUFBTSxDQUFDLE1BQU0saUJBQWlCLEdBQUcsR0FBRyxFQUFFO0lBQ3BDLElBQUksQ0FBQyxjQUFjLEVBQUU7UUFDbkIsY0FBYyxHQUFHLFlBQVksQ0FBTSxxQkFBcUIsQ0FBQyxDQUFDO0tBQzNEO0lBRUQsT0FBTyxjQUFjLENBQUM7QUFDeEIsQ0FBQyxDQUFDO0FBS0YsTUFBTSxPQUFnQixXQUFXO0lBOEpuQjtJQUNPO0lBRUE7SUFDQTtJQUNxQjtJQWpLaEMsZUFBZSxHQUFRLEVBQUUsQ0FBQztJQUV4QixnQkFBZ0IsR0FBUSxFQUFFLENBQUM7SUFFcEIsd0JBQXdCLENBQW1DO0lBRTVFLFdBQVcsQ0FBZ0I7SUFFM0IscUJBQXFCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFFOUQsU0FBUyxDQUF3QjtJQUVqQyxRQUFRLENBQU07SUFFZCxRQUFRLEdBQUcsSUFBSSxDQUFDO0lBRWhCLGNBQWMsR0FBRyxFQUFFLENBQUM7SUFFcEIsdUJBQXVCLEdBQWEsRUFBRSxDQUFDO0lBRXZDLHlCQUF5QixDQUFRO0lBRWpDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUUzQixzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFFdkIsZ0JBQWdCO1FBQ3RCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO1lBQ3hELE1BQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO1lBQzVCLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7Z0JBQ2xDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyw4QkFBOEIsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3ZFLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7U0FDckM7SUFDSCxDQUFDO0lBRU8sV0FBVztRQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUN0QyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBRXRDLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNFLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUN6RCxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLFlBQVk7UUFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUM1RixDQUFDO0lBRU8sYUFBYTtRQUNuQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLENBQUMsRUFBRTtZQUNsRCxJQUFJLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDOUc7YUFBTSxJQUFJLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUM1QyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ25EO0lBQ0gsQ0FBQztJQUVTLG9CQUFvQixDQUFDLE1BQU07UUFDbkMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN6QixJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV4QyxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsR0FBRyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2pELE1BQU0sUUFBUSxHQUFHLElBQUksZ0JBQWdCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRXRELE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtnQkFDMUQsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN6RCxDQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sUUFBUSxDQUFDO1FBQ2xCLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxlQUFlLENBQUMsc0JBQXNCLEdBQUcsVUFBVSxTQUFTO1lBQy9ELE9BQU87Z0JBQ0wsY0FBYyxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUM7Z0JBQ2xFLHNCQUFzQixFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUM7YUFDbkUsQ0FBQztRQUNKLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxJQUFZLEVBQUUsS0FBVTtRQUMxQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzVDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRWpDLE9BQU8sS0FBSyxLQUFLLFNBQVMsQ0FBQztTQUM1QjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVELG1CQUFtQjtRQUNqQixJQUFJLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRVMsVUFBVSxDQUFDLElBQVk7UUFDL0IsT0FBTyxJQUFJLENBQUMsUUFBUTtZQUNsQixDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1lBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFFRCxnQkFBZ0I7UUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDN0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1NBQ2hDO0lBQ0gsQ0FBQztJQUVELGtCQUFrQjtRQUNoQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtZQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1lBQ2hDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7U0FDM0I7SUFDSCxDQUFDO0lBRVMsVUFBVSxDQUFDLElBQVksRUFBRSxLQUFVO1FBQzNDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBRXhCLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQzFDLE9BQU87U0FDUjtRQUVELElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDbkM7YUFBTTtZQUNMLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDO1NBQ3BDO0lBQ0gsQ0FBQztJQUlTLGFBQWEsQ0FBQyxPQUFZO1FBQ2xDLElBQUksQ0FBQyxlQUFlLENBQUMsa0JBQWtCLEdBQUcsRUFBRSxDQUFDO1FBQzdDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFcEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLEdBQUc7WUFDcEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JCLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRVMsY0FBYztRQUN0QixJQUFJLENBQUMsdUJBQXVCLEdBQUcsRUFBRSxDQUFDO1FBQ2xDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3hDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsVUFBVSxFQUFFLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUNuRSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3hCLFVBQVUsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDbkM7SUFDSCxDQUFDO0lBRUQsWUFDWSxPQUFtQixFQUNaLE1BQWMsRUFDL0IsWUFBNEIsRUFDWCxhQUE0QixFQUM1QixhQUE0QixFQUNQLFVBQWU7UUFMM0MsWUFBTyxHQUFQLE9BQU8sQ0FBWTtRQUNaLFdBQU0sR0FBTixNQUFNLENBQVE7UUFFZCxrQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQUM1QixrQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQUNQLGVBQVUsR0FBVixVQUFVLENBQUs7UUFFckQsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDcEIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxtQ0FBbUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3BHLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxhQUFhLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDaEMsS0FBSyxNQUFNLEdBQUcsSUFBSSxPQUFPLEVBQUU7WUFDekIsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDO2FBQ3hEO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsUUFBUTtRQUNOLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRUQsU0FBUztRQUNQLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQscUJBQXFCO1FBQ25CLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELGVBQWU7UUFDYixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQzFCLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxFQUFFLENBQUM7SUFDdEMsQ0FBQztJQUVELGtCQUFrQjtRQUNoQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsWUFBWTtRQUNWLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLEVBQUU7WUFDN0MsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzthQUM3QztZQUNELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7U0FDNUI7SUFDSCxDQUFDO0lBRUQsWUFBWSxDQUFDLGNBQXVCO1FBQ2xDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQixJQUFJLENBQUMsdUJBQXVCLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU07bUJBQzFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7bUJBQ3pCLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JFLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFO2dCQUNsQixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQyxDQUFDLENBQUMsQ0FBQztZQUVMLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEVBQUUsQ0FBQztTQUNyQztJQUNILENBQUM7SUFFRCxXQUFXLENBQUMsSUFBWTtRQUN0QixPQUFPLElBQUksQ0FBQyx5QkFBeUI7ZUFDMUIsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxDQUFDLGVBQWUsRUFBRSxFQUFFLENBQUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxLQUFLLElBQUksQ0FBQyxDQUFDO0lBQ2hILENBQUM7SUFFRCxXQUFXLENBQUMsUUFBNkI7UUFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztJQUNyQyxDQUFDO0lBRUQsV0FBVyxDQUFvQyxZQUFvQixFQUFFLEtBQW1CO1FBQ3RGLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4RSxDQUFDOzJIQWhQbUIsV0FBVywwSkFtS3JCLFdBQVc7K0dBbktELFdBQVcseUVBRnJCLEVBQUU7OzRGQUVRLFdBQVc7a0JBSGhDLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLEVBQUU7aUJBQ2I7OzBCQW9LSSxNQUFNOzJCQUFDLFdBQVc7O0FBbUZ2QixNQUFNLE9BQWdCLG9CQUFxQixTQUFRLFdBQVc7SUFDNUQsY0FBYyxDQUFDLE9BQVk7UUFDekIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRUQsUUFBUTtJQUNSLENBQUM7SUFFRCxlQUFlO1FBQ2IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDNUIsQ0FBQzsySEFYbUIsb0JBQW9COytHQUFwQixvQkFBb0IsMkVBRjlCLEVBQUU7OzRGQUVRLG9CQUFvQjtrQkFIekMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsRUFBRTtpQkFDYiIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG5pbXBvcnQge1xyXG4gIFRyYW5zZmVyU3RhdGUsXHJcbiAgbWFrZVN0YXRlS2V5LFxyXG4gIENvbXBvbmVudCxcclxuICBFbGVtZW50UmVmLFxyXG4gIE5nWm9uZSxcclxuICBRdWVyeUxpc3QsXHJcbiAgU2ltcGxlQ2hhbmdlcyxcclxuICBQTEFURk9STV9JRCxcclxuICBJbmplY3QsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG5cclxuICBPbkNoYW5nZXMsXHJcbiAgT25Jbml0LFxyXG4gIERvQ2hlY2ssXHJcbiAgQWZ0ZXJDb250ZW50Q2hlY2tlZCxcclxuICBBZnRlclZpZXdJbml0LFxyXG4gIEFmdGVyVmlld0NoZWNrZWQsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbXBvcnQgeyBpc1BsYXRmb3JtU2VydmVyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuXHJcbmltcG9ydCBkb21BZGFwdGVyIGZyb20gJ2RldmV4dHJlbWUvY29yZS9kb21fYWRhcHRlcic7XHJcbmltcG9ydCB7IHRyaWdnZXJIYW5kbGVyIH0gZnJvbSAnZGV2ZXh0cmVtZS9ldmVudHMnO1xyXG5pbXBvcnQgY29uZmlnIGZyb20gJ2RldmV4dHJlbWUvY29yZS9jb25maWcnO1xyXG5cclxuaW1wb3J0IHsgRHhUZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vdGVtcGxhdGUnO1xyXG5pbXBvcnQgeyBJRHhUZW1wbGF0ZUhvc3QsIER4VGVtcGxhdGVIb3N0IH0gZnJvbSAnLi90ZW1wbGF0ZS1ob3N0JztcclxuaW1wb3J0IHsgRW1pdHRlckhlbHBlciwgTmdFdmVudHNTdHJhdGVneSB9IGZyb20gJy4vZXZlbnRzLXN0cmF0ZWd5JztcclxuaW1wb3J0IHsgV2F0Y2hlckhlbHBlciB9IGZyb20gJy4vd2F0Y2hlci1oZWxwZXInO1xyXG5cclxuaW1wb3J0IHtcclxuICBJTmVzdGVkT3B0aW9uQ29udGFpbmVyLFxyXG4gIElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uLFxyXG4gIElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uQ29udGFpbmVyLFxyXG4gIENvbGxlY3Rpb25OZXN0ZWRPcHRpb25Db250YWluZXJJbXBsLFxyXG59IGZyb20gJy4vbmVzdGVkLW9wdGlvbic7XHJcblxyXG5jb25maWcoe1xyXG4gIGJ1eU5vd0xpbms6ICdodHRwczovL2dvLmRldmV4cHJlc3MuY29tL0xpY2Vuc2luZ19JbnN0YWxsZXJfV2F0ZXJtYXJrX0RldkV4dHJlbWVBbmd1bGFyLmFzcHgnLFxyXG59KTtcclxuXHJcbmxldCBzZXJ2ZXJTdGF0ZUtleTtcclxuZXhwb3J0IGNvbnN0IGdldFNlcnZlclN0YXRlS2V5ID0gKCkgPT4ge1xyXG4gIGlmICghc2VydmVyU3RhdGVLZXkpIHtcclxuICAgIHNlcnZlclN0YXRlS2V5ID0gbWFrZVN0YXRlS2V5PGFueT4oJ0RYX2lzUGxhdGZvcm1TZXJ2ZXInKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBzZXJ2ZXJTdGF0ZUtleTtcclxufTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHRlbXBsYXRlOiAnJyxcclxufSlcclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIER4Q29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzLCBPbkluaXQsIERvQ2hlY2ssIEFmdGVyQ29udGVudENoZWNrZWQsIEFmdGVyVmlld0luaXQsIEFmdGVyVmlld0NoZWNrZWQsXHJcbiAgICBJTmVzdGVkT3B0aW9uQ29udGFpbmVyLCBJQ29sbGVjdGlvbk5lc3RlZE9wdGlvbkNvbnRhaW5lciwgSUR4VGVtcGxhdGVIb3N0IHtcclxuICBwcml2YXRlIF9pbml0aWFsT3B0aW9uczogYW55ID0ge307XHJcblxyXG4gIHByb3RlY3RlZCBfb3B0aW9uc1RvVXBkYXRlOiBhbnkgPSB7fTtcclxuXHJcbiAgcHJpdmF0ZSByZWFkb25seSBfY29sbGVjdGlvbkNvbnRhaW5lckltcGw6IElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uQ29udGFpbmVyO1xyXG5cclxuICBldmVudEhlbHBlcjogRW1pdHRlckhlbHBlcjtcclxuXHJcbiAgb3B0aW9uQ2hhbmdlZEhhbmRsZXJzOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgdGVtcGxhdGVzOiBEeFRlbXBsYXRlRGlyZWN0aXZlW107XHJcblxyXG4gIGluc3RhbmNlOiBhbnk7XHJcblxyXG4gIGlzTGlua2VkID0gdHJ1ZTtcclxuXHJcbiAgY2hhbmdlZE9wdGlvbnMgPSB7fTtcclxuXHJcbiAgcmVtb3ZlZE5lc3RlZENvbXBvbmVudHM6IHN0cmluZ1tdID0gW107XHJcblxyXG4gIHJlY3JlYXRlZE5lc3RlZENvbXBvbmVudHM6IGFueVtdO1xyXG5cclxuICB3aWRnZXRVcGRhdGVMb2NrZWQgPSBmYWxzZTtcclxuXHJcbiAgdGVtcGxhdGVVcGRhdGVSZXF1aXJlZCA9IGZhbHNlO1xyXG5cclxuICBwcml2YXRlIF91cGRhdGVUZW1wbGF0ZXMoKSB7XHJcbiAgICBpZiAodGhpcy50ZW1wbGF0ZXMubGVuZ3RoICYmIHRoaXMudGVtcGxhdGVVcGRhdGVSZXF1aXJlZCkge1xyXG4gICAgICBjb25zdCB1cGRhdGVkVGVtcGxhdGVzID0ge307XHJcbiAgICAgIHRoaXMudGVtcGxhdGVzLmZvckVhY2goKHRlbXBsYXRlKSA9PiB7XHJcbiAgICAgICAgdXBkYXRlZFRlbXBsYXRlc1t0ZW1wbGF0ZS5uYW1lXSA9IHRlbXBsYXRlO1xyXG4gICAgICB9KTtcclxuICAgICAgdGhpcy5pbnN0YW5jZS5vcHRpb24oJ2ludGVncmF0aW9uT3B0aW9ucy50ZW1wbGF0ZXMnLCB1cGRhdGVkVGVtcGxhdGVzKTtcclxuICAgICAgdGhpcy50ZW1wbGF0ZXMgPSBPYmplY3QudmFsdWVzKHVwZGF0ZWRUZW1wbGF0ZXMpO1xyXG4gICAgICB0aGlzLnRlbXBsYXRlVXBkYXRlUmVxdWlyZWQgPSBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgX2luaXRFdmVudHMoKSB7XHJcbiAgICB0aGlzLmluc3RhbmNlLm9uKCdvcHRpb25DaGFuZ2VkJywgKGUpID0+IHtcclxuICAgICAgdGhpcy5jaGFuZ2VkT3B0aW9uc1tlLm5hbWVdID0gZS52YWx1ZTtcclxuXHJcbiAgICAgIGNvbnN0IHZhbHVlID0gZS5uYW1lID09PSBlLmZ1bGxOYW1lID8gZS52YWx1ZSA6IGUuY29tcG9uZW50Lm9wdGlvbihlLm5hbWUpO1xyXG4gICAgICB0aGlzLmV2ZW50SGVscGVyLmZpcmVOZ0V2ZW50KGAke2UubmFtZX1DaGFuZ2VgLCBbdmFsdWVdKTtcclxuICAgICAgdGhpcy5vcHRpb25DaGFuZ2VkSGFuZGxlcnMuZW1pdChlKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBfaW5pdE9wdGlvbnMoKSB7XHJcbiAgICB0aGlzLl9pbml0aWFsT3B0aW9ucy5pbnRlZ3JhdGlvbk9wdGlvbnMud2F0Y2hNZXRob2QgPSB0aGlzLndhdGNoZXJIZWxwZXIuZ2V0V2F0Y2hNZXRob2QoKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgX2luaXRQbGF0Zm9ybSgpIHtcclxuICAgIGlmICh0aGlzLnRyYW5zZmVyU3RhdGUuaGFzS2V5KGdldFNlcnZlclN0YXRlS2V5KCkpKSB7XHJcbiAgICAgIHRoaXMuX2luaXRpYWxPcHRpb25zLmludGVncmF0aW9uT3B0aW9ucy5yZW5kZXJlZE9uU2VydmVyID0gdGhpcy50cmFuc2ZlclN0YXRlLmdldChnZXRTZXJ2ZXJTdGF0ZUtleSgpLCBudWxsKTtcclxuICAgIH0gZWxzZSBpZiAoaXNQbGF0Zm9ybVNlcnZlcih0aGlzLnBsYXRmb3JtSWQpKSB7XHJcbiAgICAgIHRoaXMudHJhbnNmZXJTdGF0ZS5zZXQoZ2V0U2VydmVyU3RhdGVLZXkoKSwgdHJ1ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgX2NyZWF0ZUV2ZW50RW1pdHRlcnMoZXZlbnRzKSB7XHJcbiAgICBjb25zdCB6b25lID0gdGhpcy5uZ1pvbmU7XHJcbiAgICB0aGlzLmV2ZW50SGVscGVyLmNyZWF0ZUVtaXR0ZXJzKGV2ZW50cyk7XHJcblxyXG4gICAgdGhpcy5faW5pdGlhbE9wdGlvbnMuZXZlbnRzU3RyYXRlZ3kgPSAoaW5zdGFuY2UpID0+IHtcclxuICAgICAgY29uc3Qgc3RyYXRlZ3kgPSBuZXcgTmdFdmVudHNTdHJhdGVneShpbnN0YW5jZSwgem9uZSk7XHJcblxyXG4gICAgICBldmVudHMuZmlsdGVyKChldmVudCkgPT4gZXZlbnQuc3Vic2NyaWJlKS5mb3JFYWNoKChldmVudCkgPT4ge1xyXG4gICAgICAgIHN0cmF0ZWd5LmFkZEVtaXR0ZXIoZXZlbnQuc3Vic2NyaWJlLCB0aGlzW2V2ZW50LmVtaXRdKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICByZXR1cm4gc3RyYXRlZ3k7XHJcbiAgICB9O1xyXG5cclxuICAgIHRoaXMuX2luaXRpYWxPcHRpb25zLm5lc3RlZENvbXBvbmVudE9wdGlvbnMgPSBmdW5jdGlvbiAoY29tcG9uZW50KSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgZXZlbnRzU3RyYXRlZ3k6IChpbnN0YW5jZSkgPT4gbmV3IE5nRXZlbnRzU3RyYXRlZ3koaW5zdGFuY2UsIHpvbmUpLFxyXG4gICAgICAgIG5lc3RlZENvbXBvbmVudE9wdGlvbnM6IGNvbXBvbmVudC5vcHRpb24oJ25lc3RlZENvbXBvbmVudE9wdGlvbnMnKSxcclxuICAgICAgfTtcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBfc2hvdWxkT3B0aW9uQ2hhbmdlKG5hbWU6IHN0cmluZywgdmFsdWU6IGFueSkge1xyXG4gICAgaWYgKHRoaXMuY2hhbmdlZE9wdGlvbnMuaGFzT3duUHJvcGVydHkobmFtZSkpIHtcclxuICAgICAgY29uc3QgcHJldlZhbHVlID0gdGhpcy5jaGFuZ2VkT3B0aW9uc1tuYW1lXTtcclxuICAgICAgZGVsZXRlIHRoaXMuY2hhbmdlZE9wdGlvbnNbbmFtZV07XHJcblxyXG4gICAgICByZXR1cm4gdmFsdWUgIT09IHByZXZWYWx1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuXHJcbiAgY2xlYXJDaGFuZ2VkT3B0aW9ucygpIHtcclxuICAgIHRoaXMuY2hhbmdlZE9wdGlvbnMgPSB7fTtcclxuICB9XHJcblxyXG4gIHByb3RlY3RlZCBfZ2V0T3B0aW9uKG5hbWU6IHN0cmluZykge1xyXG4gICAgcmV0dXJuIHRoaXMuaW5zdGFuY2VcclxuICAgICAgPyB0aGlzLmluc3RhbmNlLm9wdGlvbihuYW1lKVxyXG4gICAgICA6IHRoaXMuX2luaXRpYWxPcHRpb25zW25hbWVdO1xyXG4gIH1cclxuXHJcbiAgbG9ja1dpZGdldFVwZGF0ZSgpIHtcclxuICAgIGlmICghdGhpcy53aWRnZXRVcGRhdGVMb2NrZWQgJiYgdGhpcy5pbnN0YW5jZSkge1xyXG4gICAgICB0aGlzLmluc3RhbmNlLmJlZ2luVXBkYXRlKCk7XHJcbiAgICAgIHRoaXMud2lkZ2V0VXBkYXRlTG9ja2VkID0gdHJ1ZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHVubG9ja1dpZGdldFVwZGF0ZSgpIHtcclxuICAgIGlmICh0aGlzLndpZGdldFVwZGF0ZUxvY2tlZCkge1xyXG4gICAgICB0aGlzLndpZGdldFVwZGF0ZUxvY2tlZCA9IGZhbHNlO1xyXG4gICAgICB0aGlzLmluc3RhbmNlLmVuZFVwZGF0ZSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XHJcbiAgICB0aGlzLmxvY2tXaWRnZXRVcGRhdGUoKTtcclxuXHJcbiAgICBpZiAoIXRoaXMuX3Nob3VsZE9wdGlvbkNoYW5nZShuYW1lLCB2YWx1ZSkpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aGlzLmluc3RhbmNlKSB7XHJcbiAgICAgIHRoaXMuaW5zdGFuY2Uub3B0aW9uKG5hbWUsIHZhbHVlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuX2luaXRpYWxPcHRpb25zW25hbWVdID0gdmFsdWU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgYWJzdHJhY3QgX2NyZWF0ZUluc3RhbmNlKGVsZW1lbnQsIG9wdGlvbnMpO1xyXG5cclxuICBwcm90ZWN0ZWQgX2NyZWF0ZVdpZGdldChlbGVtZW50OiBhbnkpIHtcclxuICAgIHRoaXMuX2luaXRpYWxPcHRpb25zLmludGVncmF0aW9uT3B0aW9ucyA9IHt9O1xyXG4gICAgdGhpcy5faW5pdFBsYXRmb3JtKCk7XHJcbiAgICB0aGlzLl9pbml0T3B0aW9ucygpO1xyXG5cclxuICAgIHRoaXMuX2luaXRpYWxPcHRpb25zLm9uSW5pdGlhbGl6aW5nID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICB0aGlzLmJlZ2luVXBkYXRlKCk7XHJcbiAgICB9O1xyXG4gICAgdGhpcy5pbnN0YW5jZSA9IHRoaXMuX2NyZWF0ZUluc3RhbmNlKGVsZW1lbnQsIHRoaXMuX2luaXRpYWxPcHRpb25zKTtcclxuICAgIHRoaXMuX2luaXRFdmVudHMoKTtcclxuICAgIHRoaXMuX2luaXRpYWxPcHRpb25zID0ge307XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgX2Rlc3Ryb3lXaWRnZXQoKSB7XHJcbiAgICB0aGlzLnJlbW92ZWROZXN0ZWRDb21wb25lbnRzID0gW107XHJcbiAgICBpZiAodGhpcy5pbnN0YW5jZSkge1xyXG4gICAgICBjb25zdCBlbGVtZW50ID0gdGhpcy5pbnN0YW5jZS5lbGVtZW50KCk7XHJcbiAgICAgIHRyaWdnZXJIYW5kbGVyKGVsZW1lbnQsICdkeHJlbW92ZScsIHsgX2FuZ3VsYXJJbnRlZ3JhdGlvbjogdHJ1ZSB9KTtcclxuICAgICAgdGhpcy5pbnN0YW5jZS5kaXNwb3NlKCk7XHJcbiAgICAgIGRvbUFkYXB0ZXIucmVtb3ZlRWxlbWVudChlbGVtZW50KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJvdGVjdGVkIGVsZW1lbnQ6IEVsZW1lbnRSZWYsXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IG5nWm9uZTogTmdab25lLFxyXG4gICAgdGVtcGxhdGVIb3N0OiBEeFRlbXBsYXRlSG9zdCxcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgd2F0Y2hlckhlbHBlcjogV2F0Y2hlckhlbHBlcixcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgdHJhbnNmZXJTdGF0ZTogVHJhbnNmZXJTdGF0ZSxcclxuICAgIEBJbmplY3QoUExBVEZPUk1fSUQpIHByaXZhdGUgcmVhZG9ubHkgcGxhdGZvcm1JZDogYW55LFxyXG4gICkge1xyXG4gICAgdGhpcy50ZW1wbGF0ZXMgPSBbXTtcclxuICAgIHRlbXBsYXRlSG9zdC5zZXRIb3N0KHRoaXMpO1xyXG4gICAgdGhpcy5fY29sbGVjdGlvbkNvbnRhaW5lckltcGwgPSBuZXcgQ29sbGVjdGlvbk5lc3RlZE9wdGlvbkNvbnRhaW5lckltcGwodGhpcy5fc2V0T3B0aW9uLmJpbmQodGhpcykpO1xyXG4gICAgdGhpcy5ldmVudEhlbHBlciA9IG5ldyBFbWl0dGVySGVscGVyKG5nWm9uZSwgdGhpcyk7XHJcbiAgfVxyXG5cclxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBjaGFuZ2VzKSB7XHJcbiAgICAgIGNvbnN0IGNoYW5nZSA9IGNoYW5nZXNba2V5XTtcclxuICAgICAgaWYgKGNoYW5nZS5jdXJyZW50VmFsdWUgIT09IHRoaXNba2V5XSkge1xyXG4gICAgICAgIHRoaXMuX29wdGlvbnNUb1VwZGF0ZVtrZXldID0gY2hhbmdlc1trZXldLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICB0aGlzLl9jcmVhdGVXaWRnZXQodGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQpO1xyXG4gIH1cclxuXHJcbiAgbmdEb0NoZWNrKCkge1xyXG4gICAgdGhpcy5hcHBseU9wdGlvbnMoKTtcclxuICB9XHJcblxyXG4gIG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpIHtcclxuICAgIHRoaXMuYXBwbHlPcHRpb25zKCk7XHJcbiAgICB0aGlzLnJlc2V0T3B0aW9ucygpO1xyXG4gICAgdGhpcy51bmxvY2tXaWRnZXRVcGRhdGUoKTtcclxuICB9XHJcblxyXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcclxuICAgIHRoaXMuX3VwZGF0ZVRlbXBsYXRlcygpO1xyXG4gICAgdGhpcy5pbnN0YW5jZS5lbmRVcGRhdGUoKTtcclxuICAgIHRoaXMucmVjcmVhdGVkTmVzdGVkQ29tcG9uZW50cyA9IFtdO1xyXG4gIH1cclxuXHJcbiAgbmdBZnRlclZpZXdDaGVja2VkKCk6IHZvaWQge1xyXG4gICAgdGhpcy5fdXBkYXRlVGVtcGxhdGVzKCk7XHJcbiAgfVxyXG5cclxuICBhcHBseU9wdGlvbnMoKSB7XHJcbiAgICBpZiAoT2JqZWN0LmtleXModGhpcy5fb3B0aW9uc1RvVXBkYXRlKS5sZW5ndGgpIHtcclxuICAgICAgaWYgKHRoaXMuaW5zdGFuY2UpIHtcclxuICAgICAgICB0aGlzLmluc3RhbmNlLm9wdGlvbih0aGlzLl9vcHRpb25zVG9VcGRhdGUpO1xyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuX29wdGlvbnNUb1VwZGF0ZSA9IHt9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmVzZXRPcHRpb25zKGNvbGxlY3Rpb25OYW1lPzogc3RyaW5nKSB7XHJcbiAgICBpZiAodGhpcy5pbnN0YW5jZSkge1xyXG4gICAgICB0aGlzLnJlbW92ZWROZXN0ZWRDb21wb25lbnRzLmZpbHRlcigob3B0aW9uKSA9PiAob3B0aW9uXHJcbiAgICAgICAgICAgICAgICAmJiAhdGhpcy5pc1JlY3JlYXRlZChvcHRpb24pXHJcbiAgICAgICAgICAgICAgICAmJiBjb2xsZWN0aW9uTmFtZSA/IG9wdGlvbi5zdGFydHNXaXRoKGNvbGxlY3Rpb25OYW1lKSA6IHRydWUpKVxyXG4gICAgICAgIC5mb3JFYWNoKChvcHRpb24pID0+IHtcclxuICAgICAgICAgIHRoaXMuaW5zdGFuY2UucmVzZXRPcHRpb24ob3B0aW9uKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgIHRoaXMucmVtb3ZlZE5lc3RlZENvbXBvbmVudHMgPSBbXTtcclxuICAgICAgdGhpcy5yZWNyZWF0ZWROZXN0ZWRDb21wb25lbnRzID0gW107XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpc1JlY3JlYXRlZChuYW1lOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgIHJldHVybiB0aGlzLnJlY3JlYXRlZE5lc3RlZENvbXBvbmVudHNcclxuICAgICAgICAgICAgJiYgdGhpcy5yZWNyZWF0ZWROZXN0ZWRDb21wb25lbnRzLnNvbWUoKG5lc3RlZENvbXBvbmVudCkgPT4gbmVzdGVkQ29tcG9uZW50LmdldE9wdGlvblBhdGgoKSA9PT0gbmFtZSk7XHJcbiAgfVxyXG5cclxuICBzZXRUZW1wbGF0ZSh0ZW1wbGF0ZTogRHhUZW1wbGF0ZURpcmVjdGl2ZSkge1xyXG4gICAgdGhpcy50ZW1wbGF0ZXMucHVzaCh0ZW1wbGF0ZSk7XHJcbiAgICB0aGlzLnRlbXBsYXRlVXBkYXRlUmVxdWlyZWQgPSB0cnVlO1xyXG4gIH1cclxuXHJcbiAgc2V0Q2hpbGRyZW48VCBleHRlbmRzIElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uPihwcm9wZXJ0eU5hbWU6IHN0cmluZywgaXRlbXM6IFF1ZXJ5TGlzdDxUPikge1xyXG4gICAgdGhpcy5yZXNldE9wdGlvbnMocHJvcGVydHlOYW1lKTtcclxuICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uQ29udGFpbmVySW1wbC5zZXRDaGlsZHJlbihwcm9wZXJ0eU5hbWUsIGl0ZW1zKTtcclxuICB9XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHRlbXBsYXRlOiAnJyxcclxufSlcclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIER4Q29tcG9uZW50RXh0ZW5zaW9uIGV4dGVuZHMgRHhDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQge1xyXG4gIGNyZWF0ZUluc3RhbmNlKGVsZW1lbnQ6IGFueSkge1xyXG4gICAgdGhpcy5fY3JlYXRlV2lkZ2V0KGVsZW1lbnQpO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICBuZ0FmdGVyVmlld0luaXQoKSB7XHJcbiAgICB0aGlzLl9jcmVhdGVXaWRnZXQodGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQpO1xyXG4gICAgdGhpcy5pbnN0YW5jZS5lbmRVcGRhdGUoKTtcclxuICB9XHJcbn1cclxuIl19