/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
export * from './component';
export * from './events-strategy';
export * from './integration';
export * from './iterable-differ-helper';
export * from './nested-option';
export * from './template-host';
export * from './template';
export * from './transfer-state';
export * from './utils';
export * from './watcher-helper';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9kaXN0L2NvcmUvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxjQUFjLGFBQWEsQ0FBQztBQUM1QixjQUFjLG1CQUFtQixDQUFDO0FBQ2xDLGNBQWMsZUFBZSxDQUFDO0FBQzlCLGNBQWMsMEJBQTBCLENBQUM7QUFDekMsY0FBYyxpQkFBaUIsQ0FBQztBQUNoQyxjQUFjLGlCQUFpQixDQUFDO0FBQ2hDLGNBQWMsWUFBWSxDQUFDO0FBQzNCLGNBQWMsa0JBQWtCLENBQUM7QUFDakMsY0FBYyxTQUFTLENBQUM7QUFDeEIsY0FBYyxrQkFBa0IsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2NvbXBvbmVudCc7XHJcbmV4cG9ydCAqIGZyb20gJy4vZXZlbnRzLXN0cmF0ZWd5JztcclxuZXhwb3J0ICogZnJvbSAnLi9pbnRlZ3JhdGlvbic7XHJcbmV4cG9ydCAqIGZyb20gJy4vaXRlcmFibGUtZGlmZmVyLWhlbHBlcic7XHJcbmV4cG9ydCAqIGZyb20gJy4vbmVzdGVkLW9wdGlvbic7XHJcbmV4cG9ydCAqIGZyb20gJy4vdGVtcGxhdGUtaG9zdCc7XHJcbmV4cG9ydCAqIGZyb20gJy4vdGVtcGxhdGUnO1xyXG5leHBvcnQgKiBmcm9tICcuL3RyYW5zZmVyLXN0YXRlJztcclxuZXhwb3J0ICogZnJvbSAnLi91dGlscyc7XHJcbmV4cG9ydCAqIGZyb20gJy4vd2F0Y2hlci1oZWxwZXInO1xyXG4iXX0=