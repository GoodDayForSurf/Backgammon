/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { EventEmitter } from '@angular/core';
export class NgEventsStrategy {
    instance;
    zone;
    subscriptions = {};
    events = {};
    constructor(instance, zone) {
        this.instance = instance;
        this.zone = zone;
    }
    hasEvent(name) {
        return this.getEmitter(name).observers.length !== 0;
    }
    fireEvent(name, args) {
        const emitter = this.getEmitter(name);
        if (emitter.observers.length) {
            const internalSubs = this.subscriptions[name] || [];
            if (internalSubs.length === emitter.observers.length) {
                emitter.next(args && args[0]);
            }
            else {
                this.zone.run(() => emitter.next(args && args[0]));
            }
        }
    }
    on(name, handler) {
        if (typeof name === 'string') {
            const eventSubscriptions = this.subscriptions[name] || [];
            const subcription = this.getEmitter(name).subscribe(handler?.bind(this.instance));
            const unsubscribe = subcription.unsubscribe.bind(subcription);
            eventSubscriptions.push({ handler, unsubscribe });
            this.subscriptions[name] = eventSubscriptions;
        }
        else {
            const handlersObj = name;
            Object.keys(handlersObj).forEach((event) => this.on(event, handlersObj[event]));
        }
    }
    off(name, handler) {
        const eventSubscriptions = this.subscriptions[name] || [];
        if (handler) {
            eventSubscriptions.some((subscription, i) => {
                if (subscription.handler === handler) {
                    subscription.unsubscribe();
                    eventSubscriptions.splice(i, 1);
                    return true;
                }
                return false;
            });
        }
        else {
            eventSubscriptions.forEach((subscription) => {
                subscription.unsubscribe();
            });
            eventSubscriptions.splice(0, eventSubscriptions.length);
        }
    }
    dispose() { }
    addEmitter(eventName, emitter) {
        this.events[eventName] = emitter;
    }
    getEmitter(eventName) {
        if (!this.events[eventName]) {
            this.events[eventName] = new EventEmitter();
        }
        return this.events[eventName];
    }
}
export class EmitterHelper {
    zone;
    component;
    lockedValueChangeEvent = false;
    constructor(zone, component) {
        this.zone = zone;
        this.component = component;
    }
    fireNgEvent(eventName, eventArgs) {
        if (this.lockedValueChangeEvent && eventName === 'valueChange') {
            return;
        }
        const emitter = this.component[eventName];
        if (emitter && emitter.observers.length) {
            this.zone.run(() => {
                emitter.next(eventArgs && eventArgs[0]);
            });
        }
    }
    createEmitters(events) {
        events.forEach((event) => {
            this.component[event.emit] = new EventEmitter();
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXZlbnRzLXN0cmF0ZWd5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vZGlzdC9jb3JlL2V2ZW50cy1zdHJhdGVneS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7R0FXRztBQUVILE9BQU8sRUFBRSxZQUFZLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFPckQsTUFBTSxPQUFPLGdCQUFnQjtJQUtFO0lBQWdDO0lBSnJELGFBQWEsR0FBNEMsRUFBRSxDQUFDO0lBRTVELE1BQU0sR0FBeUMsRUFBRSxDQUFDO0lBRTFELFlBQTZCLFFBQWEsRUFBbUIsSUFBWTtRQUE1QyxhQUFRLEdBQVIsUUFBUSxDQUFLO1FBQW1CLFNBQUksR0FBSixJQUFJLENBQVE7SUFBSSxDQUFDO0lBRTlFLFFBQVEsQ0FBQyxJQUFZO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsU0FBUyxDQUFDLElBQUksRUFBRSxJQUFJO1FBQ2xCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEMsSUFBSSxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRTtZQUM1QixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNwRCxJQUFJLFlBQVksQ0FBQyxNQUFNLEtBQUssT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUU7Z0JBQ3BELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQy9CO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEQ7U0FDRjtJQUNILENBQUM7SUFFRCxFQUFFLENBQUMsSUFBcUIsRUFBRSxPQUFrQjtRQUMxQyxJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUM1QixNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzFELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDbEYsTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFOUQsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxrQkFBa0IsQ0FBQztTQUMvQzthQUFNO1lBQ0wsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDO1lBRXpCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2pGO0lBQ0gsQ0FBQztJQUVELEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTztRQUNmLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFFMUQsSUFBSSxPQUFPLEVBQUU7WUFDWCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzFDLElBQUksWUFBWSxDQUFDLE9BQU8sS0FBSyxPQUFPLEVBQUU7b0JBQ3BDLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDM0Isa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDaEMsT0FBTyxJQUFJLENBQUM7aUJBQ2I7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU07WUFDTCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLEVBQUUsRUFBRTtnQkFDMUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzdCLENBQUMsQ0FBQyxDQUFDO1lBQ0gsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN6RDtJQUNILENBQUM7SUFFRCxPQUFPLEtBQUksQ0FBQztJQUVMLFVBQVUsQ0FBQyxTQUFpQixFQUFFLE9BQTBCO1FBQzdELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDO0lBQ25DLENBQUM7SUFFTyxVQUFVLENBQUMsU0FBaUI7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1NBQzdDO1FBQ0QsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7Q0FDRjtBQUVELE1BQU0sT0FBTyxhQUFhO0lBR0s7SUFBc0I7SUFGbkQsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBRS9CLFlBQTZCLElBQVksRUFBVSxTQUFzQjtRQUE1QyxTQUFJLEdBQUosSUFBSSxDQUFRO1FBQVUsY0FBUyxHQUFULFNBQVMsQ0FBYTtJQUFJLENBQUM7SUFFOUUsV0FBVyxDQUFDLFNBQWlCLEVBQUUsU0FBYztRQUMzQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsSUFBSSxTQUFTLEtBQUssYUFBYSxFQUFFO1lBQzlELE9BQU87U0FDUjtRQUNELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUMsSUFBSSxPQUFPLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUU7WUFDdkMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFO2dCQUNqQixPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxDQUFDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQztJQUVELGNBQWMsQ0FBQyxNQUFhO1FBQzFCLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUN2QixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbmltcG9ydCB7IEV2ZW50RW1pdHRlciwgTmdab25lIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IER4Q29tcG9uZW50IH0gZnJvbSAnLi9jb21wb25lbnQnO1xyXG5cclxuaW50ZXJmYWNlIElFdmVudFN1YnNjcmlwdGlvbiB7XHJcbiAgaGFuZGxlcjogYW55O1xyXG4gIHVuc3Vic2NyaWJlOiAoKSA9PiB2b2lkO1xyXG59XHJcbmV4cG9ydCBjbGFzcyBOZ0V2ZW50c1N0cmF0ZWd5IHtcclxuICBwcml2YXRlIHN1YnNjcmlwdGlvbnM6IHsgW2tleTogc3RyaW5nXTogSUV2ZW50U3Vic2NyaXB0aW9uW10gfSA9IHt9O1xyXG5cclxuICBwcml2YXRlIGV2ZW50czogeyBba2V5OiBzdHJpbmddOiBFdmVudEVtaXR0ZXI8YW55PiB9ID0ge307XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgaW5zdGFuY2U6IGFueSwgcHJpdmF0ZSByZWFkb25seSB6b25lOiBOZ1pvbmUpIHsgfVxyXG5cclxuICBoYXNFdmVudChuYW1lOiBzdHJpbmcpIHtcclxuICAgIHJldHVybiB0aGlzLmdldEVtaXR0ZXIobmFtZSkub2JzZXJ2ZXJzLmxlbmd0aCAhPT0gMDtcclxuICB9XHJcblxyXG4gIGZpcmVFdmVudChuYW1lLCBhcmdzKSB7XHJcbiAgICBjb25zdCBlbWl0dGVyID0gdGhpcy5nZXRFbWl0dGVyKG5hbWUpO1xyXG4gICAgaWYgKGVtaXR0ZXIub2JzZXJ2ZXJzLmxlbmd0aCkge1xyXG4gICAgICBjb25zdCBpbnRlcm5hbFN1YnMgPSB0aGlzLnN1YnNjcmlwdGlvbnNbbmFtZV0gfHwgW107XHJcbiAgICAgIGlmIChpbnRlcm5hbFN1YnMubGVuZ3RoID09PSBlbWl0dGVyLm9ic2VydmVycy5sZW5ndGgpIHtcclxuICAgICAgICBlbWl0dGVyLm5leHQoYXJncyAmJiBhcmdzWzBdKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLnpvbmUucnVuKCgpID0+IGVtaXR0ZXIubmV4dChhcmdzICYmIGFyZ3NbMF0pKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgb24obmFtZTogc3RyaW5nIHwgT2JqZWN0LCBoYW5kbGVyPzogRnVuY3Rpb24pIHtcclxuICAgIGlmICh0eXBlb2YgbmFtZSA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgZXZlbnRTdWJzY3JpcHRpb25zID0gdGhpcy5zdWJzY3JpcHRpb25zW25hbWVdIHx8IFtdO1xyXG4gICAgICBjb25zdCBzdWJjcmlwdGlvbiA9IHRoaXMuZ2V0RW1pdHRlcihuYW1lKS5zdWJzY3JpYmUoaGFuZGxlcj8uYmluZCh0aGlzLmluc3RhbmNlKSk7XHJcbiAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gc3ViY3JpcHRpb24udW5zdWJzY3JpYmUuYmluZChzdWJjcmlwdGlvbik7XHJcblxyXG4gICAgICBldmVudFN1YnNjcmlwdGlvbnMucHVzaCh7IGhhbmRsZXIsIHVuc3Vic2NyaWJlIH0pO1xyXG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbnNbbmFtZV0gPSBldmVudFN1YnNjcmlwdGlvbnM7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBoYW5kbGVyc09iaiA9IG5hbWU7XHJcblxyXG4gICAgICBPYmplY3Qua2V5cyhoYW5kbGVyc09iaikuZm9yRWFjaCgoZXZlbnQpID0+IHRoaXMub24oZXZlbnQsIGhhbmRsZXJzT2JqW2V2ZW50XSkpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgb2ZmKG5hbWUsIGhhbmRsZXIpIHtcclxuICAgIGNvbnN0IGV2ZW50U3Vic2NyaXB0aW9ucyA9IHRoaXMuc3Vic2NyaXB0aW9uc1tuYW1lXSB8fCBbXTtcclxuXHJcbiAgICBpZiAoaGFuZGxlcikge1xyXG4gICAgICBldmVudFN1YnNjcmlwdGlvbnMuc29tZSgoc3Vic2NyaXB0aW9uLCBpKSA9PiB7XHJcbiAgICAgICAgaWYgKHN1YnNjcmlwdGlvbi5oYW5kbGVyID09PSBoYW5kbGVyKSB7XHJcbiAgICAgICAgICBzdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgIGV2ZW50U3Vic2NyaXB0aW9ucy5zcGxpY2UoaSwgMSk7XHJcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGV2ZW50U3Vic2NyaXB0aW9ucy5mb3JFYWNoKChzdWJzY3JpcHRpb24pID0+IHtcclxuICAgICAgICBzdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgfSk7XHJcbiAgICAgIGV2ZW50U3Vic2NyaXB0aW9ucy5zcGxpY2UoMCwgZXZlbnRTdWJzY3JpcHRpb25zLmxlbmd0aCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBkaXNwb3NlKCkge31cclxuXHJcbiAgcHVibGljIGFkZEVtaXR0ZXIoZXZlbnROYW1lOiBzdHJpbmcsIGVtaXR0ZXI6IEV2ZW50RW1pdHRlcjxhbnk+KSB7XHJcbiAgICB0aGlzLmV2ZW50c1tldmVudE5hbWVdID0gZW1pdHRlcjtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0RW1pdHRlcihldmVudE5hbWU6IHN0cmluZyk6IEV2ZW50RW1pdHRlcjxhbnk+IHtcclxuICAgIGlmICghdGhpcy5ldmVudHNbZXZlbnROYW1lXSkge1xyXG4gICAgICB0aGlzLmV2ZW50c1tldmVudE5hbWVdID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMuZXZlbnRzW2V2ZW50TmFtZV07XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgRW1pdHRlckhlbHBlciB7XHJcbiAgbG9ja2VkVmFsdWVDaGFuZ2VFdmVudCA9IGZhbHNlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IHpvbmU6IE5nWm9uZSwgcHJpdmF0ZSBjb21wb25lbnQ6IER4Q29tcG9uZW50KSB7IH1cclxuXHJcbiAgZmlyZU5nRXZlbnQoZXZlbnROYW1lOiBzdHJpbmcsIGV2ZW50QXJnczogYW55KSB7XHJcbiAgICBpZiAodGhpcy5sb2NrZWRWYWx1ZUNoYW5nZUV2ZW50ICYmIGV2ZW50TmFtZSA9PT0gJ3ZhbHVlQ2hhbmdlJykge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBlbWl0dGVyID0gdGhpcy5jb21wb25lbnRbZXZlbnROYW1lXTtcclxuICAgIGlmIChlbWl0dGVyICYmIGVtaXR0ZXIub2JzZXJ2ZXJzLmxlbmd0aCkge1xyXG4gICAgICB0aGlzLnpvbmUucnVuKCgpID0+IHtcclxuICAgICAgICBlbWl0dGVyLm5leHQoZXZlbnRBcmdzICYmIGV2ZW50QXJnc1swXSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY3JlYXRlRW1pdHRlcnMoZXZlbnRzOiBhbnlbXSkge1xyXG4gICAgZXZlbnRzLmZvckVhY2goKGV2ZW50KSA9PiB7XHJcbiAgICAgIHRoaXMuY29tcG9uZW50W2V2ZW50LmVtaXRdID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcbiJdfQ==