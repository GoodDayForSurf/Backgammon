/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { Component, EventEmitter, } from '@angular/core';
import render from 'devextreme/core/renderer';
import { triggerHandler } from 'devextreme/events';
import domAdapter from 'devextreme/core/dom_adapter';
import { getElement } from './utils';
import { DX_TEMPLATE_WRAPPER_CLASS } from './template';
import * as i0 from "@angular/core";
const VISIBILITY_CHANGE_SELECTOR = 'dx-visibility-change-handler';
export class BaseNestedOption {
    _host;
    _hostOptionPath;
    _collectionContainerImpl;
    _initialOptions = {};
    constructor() {
        this._collectionContainerImpl = new CollectionNestedOptionContainerImpl(this._setOption.bind(this), this._filterItems.bind(this));
    }
    _optionChangedHandler(e) {
        const fullOptionPath = this._fullOptionPath();
        if (e.fullName.indexOf(fullOptionPath) === 0) {
            const optionName = e.fullName.slice(fullOptionPath.length);
            const emitter = this[`${optionName}Change`];
            if (emitter) {
                emitter.next(e.value);
            }
        }
    }
    _createEventEmitters(events) {
        events.forEach((event) => {
            this[event.emit] = new EventEmitter();
        });
    }
    _getOption(name) {
        if (this.isLinked) {
            return this.instance.option(this._fullOptionPath() + name);
        }
        return this._initialOptions[name];
    }
    _setOption(name, value) {
        if (this.isLinked) {
            const fullPath = this._fullOptionPath() + name;
            this.instance.option(fullPath, value);
        }
        else {
            this._initialOptions[name] = value;
        }
    }
    _addRemovedOption(name) {
        if (this.instance && this.removedNestedComponents) {
            this.removedNestedComponents.push(name);
        }
    }
    _deleteRemovedOptions(name) {
        if (this.instance && this.removedNestedComponents) {
            this.removedNestedComponents = this.removedNestedComponents.filter((x) => !x.startsWith(name));
        }
    }
    _addRecreatedComponent() {
        if (this.instance && this.recreatedNestedComponents) {
            this.recreatedNestedComponents.push({ getOptionPath: () => this._getOptionPath() });
        }
    }
    _getOptionPath() {
        return this._hostOptionPath() + this._optionPath;
    }
    setHost(host, optionPath) {
        this._host = host;
        this._hostOptionPath = optionPath;
        this.optionChangedHandlers.subscribe(this._optionChangedHandler.bind(this));
    }
    setChildren(propertyName, items) {
        this.resetOptions(propertyName);
        return this._collectionContainerImpl.setChildren(propertyName, items);
    }
    _filterItems(items) {
        return items.filter((item) => item !== this);
    }
    get instance() {
        return this._host && this._host.instance;
    }
    get resetOptions() {
        return this._host && this._host.resetOptions;
    }
    get isRecreated() {
        return this._host && this._host.isRecreated;
    }
    get removedNestedComponents() {
        return this._host && this._host.removedNestedComponents;
    }
    set removedNestedComponents(value) {
        this._host.removedNestedComponents = value;
    }
    get recreatedNestedComponents() {
        return this._host && this._host.recreatedNestedComponents;
    }
    set recreatedNestedComponents(value) {
        this._host.recreatedNestedComponents = value;
    }
    get isLinked() {
        return !!this.instance && this._host.isLinked;
    }
    get optionChangedHandlers() {
        return this._host && this._host.optionChangedHandlers;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BaseNestedOption, deps: [], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: BaseNestedOption, selector: "ng-component", ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BaseNestedOption, decorators: [{
            type: Component,
            args: [{
                    template: '',
                }]
        }], ctorParameters: function () { return []; } });
export class CollectionNestedOptionContainerImpl {
    _setOption;
    _filterItems;
    _activatedQueries = {};
    constructor(_setOption, _filterItems) {
        this._setOption = _setOption;
        this._filterItems = _filterItems;
    }
    setChildren(propertyName, items) {
        if (this._filterItems) {
            items = this._filterItems(items);
        }
        if (items.length) {
            this._activatedQueries[propertyName] = true;
        }
        if (this._activatedQueries[propertyName]) {
            const widgetItems = items.map((item, index) => {
                item._index = index;
                return item._value;
            });
            this._setOption(propertyName, widgetItems);
        }
    }
}
export class NestedOption extends BaseNestedOption {
    setHost(host, optionPath) {
        super.setHost(host, optionPath);
        this._host[this._optionPath] = this._initialOptions;
    }
    _fullOptionPath() {
        return `${this._getOptionPath()}.`;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NestedOption, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: NestedOption, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NestedOption, decorators: [{
            type: Component,
            args: [{
                    template: '',
                }]
        }] });
export class CollectionNestedOption extends BaseNestedOption {
    _index;
    _fullOptionPath() {
        return `${this._getOptionPath()}[${this._index}].`;
    }
    get _value() {
        return this._initialOptions;
    }
    get isLinked() {
        return this._index !== undefined && !!this.instance && this._host.isLinked;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CollectionNestedOption, deps: null, target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CollectionNestedOption, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CollectionNestedOption, decorators: [{
            type: Component,
            args: [{
                    template: '',
                }]
        }] });
const triggerShownEvent = function (element) {
    const changeHandlers = [];
    if (!render(element).hasClass(VISIBILITY_CHANGE_SELECTOR)) {
        changeHandlers.push(element);
    }
    changeHandlers.push.apply(changeHandlers, element.querySelectorAll(`.${VISIBILITY_CHANGE_SELECTOR}`));
    for (let i = 0; i < changeHandlers.length; i++) {
        triggerHandler(changeHandlers[i], 'dxshown');
    }
};
export function extractTemplate(option, element, renderer, document) {
    if (!option.template === undefined || !element.nativeElement.hasChildNodes()) {
        return;
    }
    const childNodes = [].slice.call(element.nativeElement.childNodes);
    const userContent = childNodes.filter((n) => {
        if (n.tagName) {
            const tagNamePrefix = n.tagName.toLowerCase().substr(0, 3);
            return !(tagNamePrefix === 'dxi' || tagNamePrefix === 'dxo');
        }
        return n.nodeName !== '#comment' && n.textContent.replace(/\s/g, '').length;
    });
    if (!userContent.length) {
        return;
    }
    option.template = {
        render: (renderData) => {
            const result = element.nativeElement;
            domAdapter.setClass(result, DX_TEMPLATE_WRAPPER_CLASS, true);
            if (renderData.container) {
                const container = getElement(renderData.container);
                const resultInContainer = container.contains(element.nativeElement);
                renderer.appendChild(container, element.nativeElement);
                if (!resultInContainer) {
                    const resultInBody = document.body.contains(container);
                    if (resultInBody) {
                        triggerShownEvent(result);
                    }
                }
            }
            return result;
        },
    };
}
export class NestedOptionHost {
    _host;
    _optionPath;
    getHost() {
        return this._host;
    }
    setHost(host, optionPath) {
        this._host = host;
        this._optionPath = optionPath || (() => '');
    }
    setNestedOption(nestedOption) {
        nestedOption.setHost(this._host, this._optionPath);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVzdGVkLW9wdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2Rpc3QvY29yZS9uZXN0ZWQtb3B0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsT0FBTyxFQUNMLFNBQVMsRUFBb0MsWUFBWSxHQUMxRCxNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLE1BQU0sTUFBTSwwQkFBMEIsQ0FBQztBQUM5QyxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDbkQsT0FBTyxVQUFVLE1BQU0sNkJBQTZCLENBQUM7QUFDckQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLFNBQVMsQ0FBQztBQUNyQyxPQUFPLEVBQUUseUJBQXlCLEVBQUUsTUFBTSxZQUFZLENBQUM7O0FBRXZELE1BQU0sMEJBQTBCLEdBQUcsOEJBQThCLENBQUM7QUFpQmxFLE1BQU0sT0FBZ0IsZ0JBQWdCO0lBQzFCLEtBQUssQ0FBeUI7SUFFOUIsZUFBZSxDQUFvQjtJQUU1Qix3QkFBd0IsQ0FBbUM7SUFFbEUsZUFBZSxHQUFHLEVBQUUsQ0FBQztJQUsvQjtRQUNFLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLG1DQUFtQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDcEksQ0FBQztJQUVTLHFCQUFxQixDQUFDLENBQU07UUFDcEMsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRTlDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzVDLE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMzRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxVQUFVLFFBQVEsQ0FBQyxDQUFDO1lBRTVDLElBQUksT0FBTyxFQUFFO2dCQUNYLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3ZCO1NBQ0Y7SUFDSCxDQUFDO0lBRVMsb0JBQW9CLENBQUMsTUFBTTtRQUNuQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVTLFVBQVUsQ0FBQyxJQUFZO1FBQy9CLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUM1RDtRQUNELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRVMsVUFBVSxDQUFDLElBQVksRUFBRSxLQUFVO1FBQzNDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQy9DLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUN2QzthQUFNO1lBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUM7U0FDcEM7SUFDSCxDQUFDO0lBRVMsaUJBQWlCLENBQUMsSUFBWTtRQUN0QyxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ2pELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDekM7SUFDSCxDQUFDO0lBRVMscUJBQXFCLENBQUMsSUFBWTtRQUMxQyxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ2pELElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUNoRztJQUNILENBQUM7SUFFUyxzQkFBc0I7UUFDOUIsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyx5QkFBeUIsRUFBRTtZQUNuRCxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLEVBQUUsYUFBYSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDckY7SUFDSCxDQUFDO0lBRVMsY0FBYztRQUN0QixPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQ25ELENBQUM7SUFFRCxPQUFPLENBQUMsSUFBNEIsRUFBRSxVQUE2QjtRQUNqRSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLENBQUMsZUFBZSxHQUFHLFVBQVUsQ0FBQztRQUNsQyxJQUFJLENBQUMscUJBQXFCLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM5RSxDQUFDO0lBRUQsV0FBVyxDQUFvQyxZQUFvQixFQUFFLEtBQW1CO1FBQ3RGLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQWtDO1FBQzdDLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDVixPQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7SUFDM0MsQ0FBQztJQUVELElBQUksWUFBWTtRQUNkLE9BQU8sSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztJQUMvQyxDQUFDO0lBRUQsSUFBSSxXQUFXO1FBQ2IsT0FBTyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO0lBQzlDLENBQUM7SUFFRCxJQUFJLHVCQUF1QjtRQUN6QixPQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQztJQUMxRCxDQUFDO0lBRUQsSUFBSSx1QkFBdUIsQ0FBQyxLQUFLO1FBQy9CLElBQUksQ0FBQyxLQUFLLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFFRCxJQUFJLHlCQUF5QjtRQUMzQixPQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQztJQUM1RCxDQUFDO0lBRUQsSUFBSSx5QkFBeUIsQ0FBQyxLQUFLO1FBQ2pDLElBQUksQ0FBQyxLQUFLLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDVixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0lBQ2hELENBQUM7SUFFRCxJQUFJLHFCQUFxQjtRQUN2QixPQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztJQUN4RCxDQUFDOzJIQTFIbUIsZ0JBQWdCOytHQUFoQixnQkFBZ0Isb0RBRjFCLEVBQUU7OzRGQUVRLGdCQUFnQjtrQkFIckMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsRUFBRTtpQkFDYjs7QUFrSUQsTUFBTSxPQUFPLG1DQUFtQztJQUdqQjtJQUF1QztJQUY1RCxpQkFBaUIsR0FBRyxFQUFFLENBQUM7SUFFL0IsWUFBNkIsVUFBb0IsRUFBbUIsWUFBdUI7UUFBOUQsZUFBVSxHQUFWLFVBQVUsQ0FBVTtRQUFtQixpQkFBWSxHQUFaLFlBQVksQ0FBVztJQUFJLENBQUM7SUFFaEcsV0FBVyxDQUFvQyxZQUFvQixFQUFFLEtBQW1CO1FBQ3RGLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNyQixLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNsQztRQUNELElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTtZQUNoQixJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDO1NBQzdDO1FBQ0QsSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDeEMsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDNUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7Z0JBQ3BCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUNyQixDQUFDLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQzVDO0lBQ0gsQ0FBQztDQUNGO0FBS0QsTUFBTSxPQUFnQixZQUFhLFNBQVEsZ0JBQWdCO0lBQ3pELE9BQU8sQ0FBQyxJQUE0QixFQUFFLFVBQTZCO1FBQ2pFLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRWhDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDdEQsQ0FBQztJQUVTLGVBQWU7UUFDdkIsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDO0lBQ3JDLENBQUM7MkhBVG1CLFlBQVk7K0dBQVosWUFBWSwyRUFGdEIsRUFBRTs7NEZBRVEsWUFBWTtrQkFIakMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsRUFBRTtpQkFDYjs7QUFxQkQsTUFBTSxPQUFnQixzQkFBdUIsU0FBUSxnQkFBZ0I7SUFDbkUsTUFBTSxDQUFTO0lBRUwsZUFBZTtRQUN2QixPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQztJQUNyRCxDQUFDO0lBRUQsSUFBSSxNQUFNO1FBQ1IsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDVixPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0lBQzdFLENBQUM7MkhBYm1CLHNCQUFzQjsrR0FBdEIsc0JBQXNCLDJFQUZoQyxFQUFFOzs0RkFFUSxzQkFBc0I7a0JBSDNDLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLEVBQUU7aUJBQ2I7O0FBcUJELE1BQU0saUJBQWlCLEdBQUcsVUFBVSxPQUFPO0lBQ3pDLE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQztJQUUxQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxFQUFFO1FBQ3pELGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDOUI7SUFFRCxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLGdCQUFnQixDQUFDLElBQUksMEJBQTBCLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFdEcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDOUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztLQUM5QztBQUNILENBQUMsQ0FBQztBQUVGLE1BQU0sVUFBVSxlQUFlLENBQUMsTUFBMkIsRUFBRSxPQUFtQixFQUFFLFFBQW1CLEVBQUUsUUFBYTtJQUNsSCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxFQUFFO1FBQzVFLE9BQU87S0FDUjtJQUVELE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbkUsTUFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQzFDLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRTtZQUNiLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUMzRCxPQUFPLENBQUMsQ0FBQyxhQUFhLEtBQUssS0FBSyxJQUFJLGFBQWEsS0FBSyxLQUFLLENBQUMsQ0FBQztTQUM5RDtRQUNELE9BQU8sQ0FBQyxDQUFDLFFBQVEsS0FBSyxVQUFVLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztJQUM5RSxDQUFDLENBQUMsQ0FBQztJQUNILElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFO1FBQ3ZCLE9BQU87S0FDUjtJQUVELE1BQU0sQ0FBQyxRQUFRLEdBQUc7UUFDaEIsTUFBTSxFQUFFLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDckIsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQztZQUVyQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSx5QkFBeUIsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUU3RCxJQUFJLFVBQVUsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3hCLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ25ELE1BQU0saUJBQWlCLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBRXBFLFFBQVEsQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFFdkQsSUFBSSxDQUFDLGlCQUFpQixFQUFFO29CQUN0QixNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFFdkQsSUFBSSxZQUFZLEVBQUU7d0JBQ2hCLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUMzQjtpQkFDRjthQUNGO1lBRUQsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQztLQUNGLENBQUM7QUFDSixDQUFDO0FBRUQsTUFBTSxPQUFPLGdCQUFnQjtJQUNuQixLQUFLLENBQXlCO0lBRTlCLFdBQVcsQ0FBb0I7SUFFdkMsT0FBTztRQUNMLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztJQUNwQixDQUFDO0lBRUQsT0FBTyxDQUFDLElBQTRCLEVBQUUsVUFBOEI7UUFDbEUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7UUFDbEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQsZUFBZSxDQUFDLFlBQThCO1FBQzVDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDckQsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbmltcG9ydCB7XHJcbiAgQ29tcG9uZW50LCBRdWVyeUxpc3QsIEVsZW1lbnRSZWYsIFJlbmRlcmVyMiwgRXZlbnRFbWl0dGVyLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHJlbmRlciBmcm9tICdkZXZleHRyZW1lL2NvcmUvcmVuZGVyZXInO1xyXG5pbXBvcnQgeyB0cmlnZ2VySGFuZGxlciB9IGZyb20gJ2RldmV4dHJlbWUvZXZlbnRzJztcclxuaW1wb3J0IGRvbUFkYXB0ZXIgZnJvbSAnZGV2ZXh0cmVtZS9jb3JlL2RvbV9hZGFwdGVyJztcclxuaW1wb3J0IHsgZ2V0RWxlbWVudCB9IGZyb20gJy4vdXRpbHMnO1xyXG5pbXBvcnQgeyBEWF9URU1QTEFURV9XUkFQUEVSX0NMQVNTIH0gZnJvbSAnLi90ZW1wbGF0ZSc7XHJcblxyXG5jb25zdCBWSVNJQklMSVRZX0NIQU5HRV9TRUxFQ1RPUiA9ICdkeC12aXNpYmlsaXR5LWNoYW5nZS1oYW5kbGVyJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU5lc3RlZE9wdGlvbkNvbnRhaW5lciB7XHJcbiAgaW5zdGFuY2U6IGFueTtcclxuICBpc0xpbmtlZDogYm9vbGVhbjtcclxuICByZW1vdmVkTmVzdGVkQ29tcG9uZW50czogc3RyaW5nW107XHJcbiAgb3B0aW9uQ2hhbmdlZEhhbmRsZXJzOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuICByZWNyZWF0ZWROZXN0ZWRDb21wb25lbnRzOiBhbnlbXTtcclxuICByZXNldE9wdGlvbnM6IChjb2xsZWN0aW9uTmFtZT86IHN0cmluZykgPT4gdm9pZDtcclxuICBpc1JlY3JlYXRlZDogKG5hbWU6IHN0cmluZykgPT4gYm9vbGVhbjtcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgSU9wdGlvblBhdGhHZXR0ZXIgPSAoKSA9PiBzdHJpbmc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICB0ZW1wbGF0ZTogJycsXHJcbn0pXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBCYXNlTmVzdGVkT3B0aW9uIGltcGxlbWVudHMgSU5lc3RlZE9wdGlvbkNvbnRhaW5lciwgSUNvbGxlY3Rpb25OZXN0ZWRPcHRpb25Db250YWluZXIge1xyXG4gIHByb3RlY3RlZCBfaG9zdDogSU5lc3RlZE9wdGlvbkNvbnRhaW5lcjtcclxuXHJcbiAgcHJvdGVjdGVkIF9ob3N0T3B0aW9uUGF0aDogSU9wdGlvblBhdGhHZXR0ZXI7XHJcblxyXG4gIHByaXZhdGUgcmVhZG9ubHkgX2NvbGxlY3Rpb25Db250YWluZXJJbXBsOiBJQ29sbGVjdGlvbk5lc3RlZE9wdGlvbkNvbnRhaW5lcjtcclxuXHJcbiAgcHJvdGVjdGVkIF9pbml0aWFsT3B0aW9ucyA9IHt9O1xyXG5cclxuICBwcm90ZWN0ZWQgYWJzdHJhY3QgZ2V0IF9vcHRpb25QYXRoKCk6IHN0cmluZztcclxuICBwcm90ZWN0ZWQgYWJzdHJhY3QgX2Z1bGxPcHRpb25QYXRoKCk6IHN0cmluZztcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLl9jb2xsZWN0aW9uQ29udGFpbmVySW1wbCA9IG5ldyBDb2xsZWN0aW9uTmVzdGVkT3B0aW9uQ29udGFpbmVySW1wbCh0aGlzLl9zZXRPcHRpb24uYmluZCh0aGlzKSwgdGhpcy5fZmlsdGVySXRlbXMuYmluZCh0aGlzKSk7XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgX29wdGlvbkNoYW5nZWRIYW5kbGVyKGU6IGFueSkge1xyXG4gICAgY29uc3QgZnVsbE9wdGlvblBhdGggPSB0aGlzLl9mdWxsT3B0aW9uUGF0aCgpO1xyXG5cclxuICAgIGlmIChlLmZ1bGxOYW1lLmluZGV4T2YoZnVsbE9wdGlvblBhdGgpID09PSAwKSB7XHJcbiAgICAgIGNvbnN0IG9wdGlvbk5hbWUgPSBlLmZ1bGxOYW1lLnNsaWNlKGZ1bGxPcHRpb25QYXRoLmxlbmd0aCk7XHJcbiAgICAgIGNvbnN0IGVtaXR0ZXIgPSB0aGlzW2Ake29wdGlvbk5hbWV9Q2hhbmdlYF07XHJcblxyXG4gICAgICBpZiAoZW1pdHRlcikge1xyXG4gICAgICAgIGVtaXR0ZXIubmV4dChlLnZhbHVlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF9jcmVhdGVFdmVudEVtaXR0ZXJzKGV2ZW50cykge1xyXG4gICAgZXZlbnRzLmZvckVhY2goKGV2ZW50KSA9PiB7XHJcbiAgICAgIHRoaXNbZXZlbnQuZW1pdF0gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHByb3RlY3RlZCBfZ2V0T3B0aW9uKG5hbWU6IHN0cmluZyk6IGFueSB7XHJcbiAgICBpZiAodGhpcy5pc0xpbmtlZCkge1xyXG4gICAgICByZXR1cm4gdGhpcy5pbnN0YW5jZS5vcHRpb24odGhpcy5fZnVsbE9wdGlvblBhdGgoKSArIG5hbWUpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMuX2luaXRpYWxPcHRpb25zW25hbWVdO1xyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF9zZXRPcHRpb24obmFtZTogc3RyaW5nLCB2YWx1ZTogYW55KSB7XHJcbiAgICBpZiAodGhpcy5pc0xpbmtlZCkge1xyXG4gICAgICBjb25zdCBmdWxsUGF0aCA9IHRoaXMuX2Z1bGxPcHRpb25QYXRoKCkgKyBuYW1lO1xyXG4gICAgICB0aGlzLmluc3RhbmNlLm9wdGlvbihmdWxsUGF0aCwgdmFsdWUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5faW5pdGlhbE9wdGlvbnNbbmFtZV0gPSB2YWx1ZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByb3RlY3RlZCBfYWRkUmVtb3ZlZE9wdGlvbihuYW1lOiBzdHJpbmcpIHtcclxuICAgIGlmICh0aGlzLmluc3RhbmNlICYmIHRoaXMucmVtb3ZlZE5lc3RlZENvbXBvbmVudHMpIHtcclxuICAgICAgdGhpcy5yZW1vdmVkTmVzdGVkQ29tcG9uZW50cy5wdXNoKG5hbWUpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF9kZWxldGVSZW1vdmVkT3B0aW9ucyhuYW1lOiBzdHJpbmcpIHtcclxuICAgIGlmICh0aGlzLmluc3RhbmNlICYmIHRoaXMucmVtb3ZlZE5lc3RlZENvbXBvbmVudHMpIHtcclxuICAgICAgdGhpcy5yZW1vdmVkTmVzdGVkQ29tcG9uZW50cyA9IHRoaXMucmVtb3ZlZE5lc3RlZENvbXBvbmVudHMuZmlsdGVyKCh4KSA9PiAheC5zdGFydHNXaXRoKG5hbWUpKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByb3RlY3RlZCBfYWRkUmVjcmVhdGVkQ29tcG9uZW50KCkge1xyXG4gICAgaWYgKHRoaXMuaW5zdGFuY2UgJiYgdGhpcy5yZWNyZWF0ZWROZXN0ZWRDb21wb25lbnRzKSB7XHJcbiAgICAgIHRoaXMucmVjcmVhdGVkTmVzdGVkQ29tcG9uZW50cy5wdXNoKHsgZ2V0T3B0aW9uUGF0aDogKCkgPT4gdGhpcy5fZ2V0T3B0aW9uUGF0aCgpIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF9nZXRPcHRpb25QYXRoKCkge1xyXG4gICAgcmV0dXJuIHRoaXMuX2hvc3RPcHRpb25QYXRoKCkgKyB0aGlzLl9vcHRpb25QYXRoO1xyXG4gIH1cclxuXHJcbiAgc2V0SG9zdChob3N0OiBJTmVzdGVkT3B0aW9uQ29udGFpbmVyLCBvcHRpb25QYXRoOiBJT3B0aW9uUGF0aEdldHRlcikge1xyXG4gICAgdGhpcy5faG9zdCA9IGhvc3Q7XHJcbiAgICB0aGlzLl9ob3N0T3B0aW9uUGF0aCA9IG9wdGlvblBhdGg7XHJcbiAgICB0aGlzLm9wdGlvbkNoYW5nZWRIYW5kbGVycy5zdWJzY3JpYmUodGhpcy5fb3B0aW9uQ2hhbmdlZEhhbmRsZXIuYmluZCh0aGlzKSk7XHJcbiAgfVxyXG5cclxuICBzZXRDaGlsZHJlbjxUIGV4dGVuZHMgSUNvbGxlY3Rpb25OZXN0ZWRPcHRpb24+KHByb3BlcnR5TmFtZTogc3RyaW5nLCBpdGVtczogUXVlcnlMaXN0PFQ+KSB7XHJcbiAgICB0aGlzLnJlc2V0T3B0aW9ucyhwcm9wZXJ0eU5hbWUpO1xyXG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb25Db250YWluZXJJbXBsLnNldENoaWxkcmVuKHByb3BlcnR5TmFtZSwgaXRlbXMpO1xyXG4gIH1cclxuXHJcbiAgX2ZpbHRlckl0ZW1zKGl0ZW1zOiBRdWVyeUxpc3Q8QmFzZU5lc3RlZE9wdGlvbj4pIHtcclxuICAgIHJldHVybiBpdGVtcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0gIT09IHRoaXMpO1xyXG4gIH1cclxuXHJcbiAgZ2V0IGluc3RhbmNlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMuX2hvc3QgJiYgdGhpcy5faG9zdC5pbnN0YW5jZTtcclxuICB9XHJcblxyXG4gIGdldCByZXNldE9wdGlvbnMoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5faG9zdCAmJiB0aGlzLl9ob3N0LnJlc2V0T3B0aW9ucztcclxuICB9XHJcblxyXG4gIGdldCBpc1JlY3JlYXRlZCgpIHtcclxuICAgIHJldHVybiB0aGlzLl9ob3N0ICYmIHRoaXMuX2hvc3QuaXNSZWNyZWF0ZWQ7XHJcbiAgfVxyXG5cclxuICBnZXQgcmVtb3ZlZE5lc3RlZENvbXBvbmVudHMoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5faG9zdCAmJiB0aGlzLl9ob3N0LnJlbW92ZWROZXN0ZWRDb21wb25lbnRzO1xyXG4gIH1cclxuXHJcbiAgc2V0IHJlbW92ZWROZXN0ZWRDb21wb25lbnRzKHZhbHVlKSB7XHJcbiAgICB0aGlzLl9ob3N0LnJlbW92ZWROZXN0ZWRDb21wb25lbnRzID0gdmFsdWU7XHJcbiAgfVxyXG5cclxuICBnZXQgcmVjcmVhdGVkTmVzdGVkQ29tcG9uZW50cygpIHtcclxuICAgIHJldHVybiB0aGlzLl9ob3N0ICYmIHRoaXMuX2hvc3QucmVjcmVhdGVkTmVzdGVkQ29tcG9uZW50cztcclxuICB9XHJcblxyXG4gIHNldCByZWNyZWF0ZWROZXN0ZWRDb21wb25lbnRzKHZhbHVlKSB7XHJcbiAgICB0aGlzLl9ob3N0LnJlY3JlYXRlZE5lc3RlZENvbXBvbmVudHMgPSB2YWx1ZTtcclxuICB9XHJcblxyXG4gIGdldCBpc0xpbmtlZCgpIHtcclxuICAgIHJldHVybiAhIXRoaXMuaW5zdGFuY2UgJiYgdGhpcy5faG9zdC5pc0xpbmtlZDtcclxuICB9XHJcblxyXG4gIGdldCBvcHRpb25DaGFuZ2VkSGFuZGxlcnMoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5faG9zdCAmJiB0aGlzLl9ob3N0Lm9wdGlvbkNoYW5nZWRIYW5kbGVycztcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUNvbGxlY3Rpb25OZXN0ZWRPcHRpb25Db250YWluZXIge1xyXG4gIHNldENoaWxkcmVuOiA8VCBleHRlbmRzIElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uPihwcm9wZXJ0eU5hbWU6IHN0cmluZywgaXRlbXM6IFF1ZXJ5TGlzdDxUPikgPT4gYW55O1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgQ29sbGVjdGlvbk5lc3RlZE9wdGlvbkNvbnRhaW5lckltcGwgaW1wbGVtZW50cyBJQ29sbGVjdGlvbk5lc3RlZE9wdGlvbkNvbnRhaW5lciB7XHJcbiAgcHJpdmF0ZSBfYWN0aXZhdGVkUXVlcmllcyA9IHt9O1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IF9zZXRPcHRpb246IEZ1bmN0aW9uLCBwcml2YXRlIHJlYWRvbmx5IF9maWx0ZXJJdGVtcz86IEZ1bmN0aW9uKSB7IH1cclxuXHJcbiAgc2V0Q2hpbGRyZW48VCBleHRlbmRzIElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uPihwcm9wZXJ0eU5hbWU6IHN0cmluZywgaXRlbXM6IFF1ZXJ5TGlzdDxUPikge1xyXG4gICAgaWYgKHRoaXMuX2ZpbHRlckl0ZW1zKSB7XHJcbiAgICAgIGl0ZW1zID0gdGhpcy5fZmlsdGVySXRlbXMoaXRlbXMpO1xyXG4gICAgfVxyXG4gICAgaWYgKGl0ZW1zLmxlbmd0aCkge1xyXG4gICAgICB0aGlzLl9hY3RpdmF0ZWRRdWVyaWVzW3Byb3BlcnR5TmFtZV0gPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuX2FjdGl2YXRlZFF1ZXJpZXNbcHJvcGVydHlOYW1lXSkge1xyXG4gICAgICBjb25zdCB3aWRnZXRJdGVtcyA9IGl0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICBpdGVtLl9pbmRleCA9IGluZGV4O1xyXG4gICAgICAgIHJldHVybiBpdGVtLl92YWx1ZTtcclxuICAgICAgfSk7XHJcbiAgICAgIHRoaXMuX3NldE9wdGlvbihwcm9wZXJ0eU5hbWUsIHdpZGdldEl0ZW1zKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHRlbXBsYXRlOiAnJyxcclxufSlcclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIE5lc3RlZE9wdGlvbiBleHRlbmRzIEJhc2VOZXN0ZWRPcHRpb24ge1xyXG4gIHNldEhvc3QoaG9zdDogSU5lc3RlZE9wdGlvbkNvbnRhaW5lciwgb3B0aW9uUGF0aDogSU9wdGlvblBhdGhHZXR0ZXIpIHtcclxuICAgIHN1cGVyLnNldEhvc3QoaG9zdCwgb3B0aW9uUGF0aCk7XHJcblxyXG4gICAgdGhpcy5faG9zdFt0aGlzLl9vcHRpb25QYXRoXSA9IHRoaXMuX2luaXRpYWxPcHRpb25zO1xyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIF9mdWxsT3B0aW9uUGF0aCgpIHtcclxuICAgIHJldHVybiBgJHt0aGlzLl9nZXRPcHRpb25QYXRoKCl9LmA7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElDb2xsZWN0aW9uTmVzdGVkT3B0aW9uIHtcclxuICBfaW5kZXg6IG51bWJlcjtcclxuICBfdmFsdWU6IE9iamVjdDtcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgdGVtcGxhdGU6ICcnLFxyXG59KVxyXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgQ29sbGVjdGlvbk5lc3RlZE9wdGlvbiBleHRlbmRzIEJhc2VOZXN0ZWRPcHRpb24gaW1wbGVtZW50cyBJQ29sbGVjdGlvbk5lc3RlZE9wdGlvbiB7XHJcbiAgX2luZGV4OiBudW1iZXI7XHJcblxyXG4gIHByb3RlY3RlZCBfZnVsbE9wdGlvblBhdGgoKSB7XHJcbiAgICByZXR1cm4gYCR7dGhpcy5fZ2V0T3B0aW9uUGF0aCgpfVske3RoaXMuX2luZGV4fV0uYDtcclxuICB9XHJcblxyXG4gIGdldCBfdmFsdWUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5faW5pdGlhbE9wdGlvbnM7XHJcbiAgfVxyXG5cclxuICBnZXQgaXNMaW5rZWQoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5faW5kZXggIT09IHVuZGVmaW5lZCAmJiAhIXRoaXMuaW5zdGFuY2UgJiYgdGhpcy5faG9zdC5pc0xpbmtlZDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU9wdGlvbldpdGhUZW1wbGF0ZSBleHRlbmRzIEJhc2VOZXN0ZWRPcHRpb24ge1xyXG4gIHRlbXBsYXRlOiBhbnk7XHJcbn1cclxuXHJcbmNvbnN0IHRyaWdnZXJTaG93bkV2ZW50ID0gZnVuY3Rpb24gKGVsZW1lbnQpIHtcclxuICBjb25zdCBjaGFuZ2VIYW5kbGVycyA9IFtdO1xyXG5cclxuICBpZiAoIXJlbmRlcihlbGVtZW50KS5oYXNDbGFzcyhWSVNJQklMSVRZX0NIQU5HRV9TRUxFQ1RPUikpIHtcclxuICAgIGNoYW5nZUhhbmRsZXJzLnB1c2goZWxlbWVudCk7XHJcbiAgfVxyXG5cclxuICBjaGFuZ2VIYW5kbGVycy5wdXNoLmFwcGx5KGNoYW5nZUhhbmRsZXJzLCBlbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYC4ke1ZJU0lCSUxJVFlfQ0hBTkdFX1NFTEVDVE9SfWApKTtcclxuXHJcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGFuZ2VIYW5kbGVycy5sZW5ndGg7IGkrKykge1xyXG4gICAgdHJpZ2dlckhhbmRsZXIoY2hhbmdlSGFuZGxlcnNbaV0sICdkeHNob3duJyk7XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RUZW1wbGF0ZShvcHRpb246IElPcHRpb25XaXRoVGVtcGxhdGUsIGVsZW1lbnQ6IEVsZW1lbnRSZWYsIHJlbmRlcmVyOiBSZW5kZXJlcjIsIGRvY3VtZW50OiBhbnkpIHtcclxuICBpZiAoIW9wdGlvbi50ZW1wbGF0ZSA9PT0gdW5kZWZpbmVkIHx8ICFlbGVtZW50Lm5hdGl2ZUVsZW1lbnQuaGFzQ2hpbGROb2RlcygpKSB7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjb25zdCBjaGlsZE5vZGVzID0gW10uc2xpY2UuY2FsbChlbGVtZW50Lm5hdGl2ZUVsZW1lbnQuY2hpbGROb2Rlcyk7XHJcbiAgY29uc3QgdXNlckNvbnRlbnQgPSBjaGlsZE5vZGVzLmZpbHRlcigobikgPT4ge1xyXG4gICAgaWYgKG4udGFnTmFtZSkge1xyXG4gICAgICBjb25zdCB0YWdOYW1lUHJlZml4ID0gbi50YWdOYW1lLnRvTG93ZXJDYXNlKCkuc3Vic3RyKDAsIDMpO1xyXG4gICAgICByZXR1cm4gISh0YWdOYW1lUHJlZml4ID09PSAnZHhpJyB8fCB0YWdOYW1lUHJlZml4ID09PSAnZHhvJyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbi5ub2RlTmFtZSAhPT0gJyNjb21tZW50JyAmJiBuLnRleHRDb250ZW50LnJlcGxhY2UoL1xccy9nLCAnJykubGVuZ3RoO1xyXG4gIH0pO1xyXG4gIGlmICghdXNlckNvbnRlbnQubGVuZ3RoKSB7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBvcHRpb24udGVtcGxhdGUgPSB7XHJcbiAgICByZW5kZXI6IChyZW5kZXJEYXRhKSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuXHJcbiAgICAgIGRvbUFkYXB0ZXIuc2V0Q2xhc3MocmVzdWx0LCBEWF9URU1QTEFURV9XUkFQUEVSX0NMQVNTLCB0cnVlKTtcclxuXHJcbiAgICAgIGlmIChyZW5kZXJEYXRhLmNvbnRhaW5lcikge1xyXG4gICAgICAgIGNvbnN0IGNvbnRhaW5lciA9IGdldEVsZW1lbnQocmVuZGVyRGF0YS5jb250YWluZXIpO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdEluQ29udGFpbmVyID0gY29udGFpbmVyLmNvbnRhaW5zKGVsZW1lbnQubmF0aXZlRWxlbWVudCk7XHJcblxyXG4gICAgICAgIHJlbmRlcmVyLmFwcGVuZENoaWxkKGNvbnRhaW5lciwgZWxlbWVudC5uYXRpdmVFbGVtZW50KTtcclxuXHJcbiAgICAgICAgaWYgKCFyZXN1bHRJbkNvbnRhaW5lcikge1xyXG4gICAgICAgICAgY29uc3QgcmVzdWx0SW5Cb2R5ID0gZG9jdW1lbnQuYm9keS5jb250YWlucyhjb250YWluZXIpO1xyXG5cclxuICAgICAgICAgIGlmIChyZXN1bHRJbkJvZHkpIHtcclxuICAgICAgICAgICAgdHJpZ2dlclNob3duRXZlbnQocmVzdWx0KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBOZXN0ZWRPcHRpb25Ib3N0IHtcclxuICBwcml2YXRlIF9ob3N0OiBJTmVzdGVkT3B0aW9uQ29udGFpbmVyO1xyXG5cclxuICBwcml2YXRlIF9vcHRpb25QYXRoOiBJT3B0aW9uUGF0aEdldHRlcjtcclxuXHJcbiAgZ2V0SG9zdCgpOiBJTmVzdGVkT3B0aW9uQ29udGFpbmVyIHtcclxuICAgIHJldHVybiB0aGlzLl9ob3N0O1xyXG4gIH1cclxuXHJcbiAgc2V0SG9zdChob3N0OiBJTmVzdGVkT3B0aW9uQ29udGFpbmVyLCBvcHRpb25QYXRoPzogSU9wdGlvblBhdGhHZXR0ZXIpIHtcclxuICAgIHRoaXMuX2hvc3QgPSBob3N0O1xyXG4gICAgdGhpcy5fb3B0aW9uUGF0aCA9IG9wdGlvblBhdGggfHwgKCgpID0+ICcnKTtcclxuICB9XHJcblxyXG4gIHNldE5lc3RlZE9wdGlvbihuZXN0ZWRPcHRpb246IEJhc2VOZXN0ZWRPcHRpb24pIHtcclxuICAgIG5lc3RlZE9wdGlvbi5zZXRIb3N0KHRoaXMuX2hvc3QsIHRoaXMuX29wdGlvblBhdGgpO1xyXG4gIH1cclxufVxyXG4iXX0=