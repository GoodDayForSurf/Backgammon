/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
/* tslint:disable:max-line-length */
import { NgModule, Inject, NgZone, Optional, VERSION, } from '@angular/core';
import { DOCUMENT, XhrFactory } from '@angular/common';
import httpRequest from 'devextreme/core/http_request';
import domAdapter from 'devextreme/core/dom_adapter';
import readyCallbacks from 'devextreme/core/utils/ready_callbacks';
import eventsEngine from 'devextreme/events/core/events_engine';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
const outsideZoneEvents = ['mousemove', 'mouseover', 'mouseout'];
const insideZoneEvents = ['mouseup', 'click', 'mousedown', 'transitionend', 'wheel'];
let originalAdd;
let callbacks = [];
let readyCallbackAdd = function (callback) {
    if (!originalAdd) {
        originalAdd = this.callBase.bind(this);
    }
    callbacks.push(callback);
};
readyCallbacks.inject({
    add(callback) {
        return readyCallbackAdd.call(this, callback);
    },
});
let doInjections = (document, ngZone, xhrFactory) => {
    if (Number(VERSION.major) < 12) {
        console.warn('Your version of Angular is not supported. Please update your project to version 12 or later.'
            + ' Please refer to the Angular Update Guide for more information: https://update.angular.io');
    }
    domAdapter.inject({
        _document: document,
        listen(...args) {
            const eventName = args[1];
            if (outsideZoneEvents.includes(eventName)) {
                return ngZone.runOutsideAngular(() => this.callBase.apply(this, args));
            }
            if (ngZone.isStable && insideZoneEvents.includes(eventName)) {
                return ngZone.run(() => this.callBase.apply(this, args));
            }
            return this.callBase.apply(this, args);
        },
        isElementNode(element) {
            return element && element.nodeType === 1;
        },
        isTextNode(element) {
            return element && element.nodeType === 3;
        },
        isDocument(element) {
            return element && element.nodeType === 9;
        },
    });
    httpRequest.inject({
        getXhr() {
            if (!xhrFactory) {
                return this.callBase.apply(this);
            }
            const _xhr = xhrFactory.build();
            if (!('withCredentials' in _xhr)) {
                _xhr.withCredentials = false;
            }
            return _xhr;
        },
    });
    const runReadyCallbacksInZone = () => {
        ngZone.run(() => {
            eventsEngine.set({});
            callbacks.forEach((callback) => originalAdd.call(null, callback));
            callbacks = [];
            readyCallbacks.fire();
        });
    };
    runReadyCallbacksInZone();
    readyCallbackAdd = (callback) => ngZone.run(() => callback());
    doInjections = runReadyCallbacksInZone;
};
export class DxIntegrationModule {
    constructor(document, ngZone, xhrFactory) {
        doInjections(document, ngZone, xhrFactory);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxIntegrationModule, deps: [{ token: DOCUMENT }, { token: i0.NgZone }, { token: i1.XhrFactory, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    /** @nocollapse */ static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DxIntegrationModule });
    /** @nocollapse */ static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxIntegrationModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DxIntegrationModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.NgZone }, { type: i1.XhrFactory, decorators: [{
                    type: Optional
                }] }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZWdyYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9kaXN0L2NvcmUvaW50ZWdyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCxvQ0FBb0M7QUFDcEMsT0FBTyxFQUNMLFFBQVEsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxPQUFPLEdBQzVDLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDdkQsT0FBTyxXQUFXLE1BQU0sOEJBQThCLENBQUM7QUFFdkQsT0FBTyxVQUFVLE1BQU0sNkJBQTZCLENBQUM7QUFDckQsT0FBTyxjQUFjLE1BQU0sdUNBQXVDLENBQUM7QUFDbkUsT0FBTyxZQUFZLE1BQU0sc0NBQXNDLENBQUM7OztBQUVoRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNqRSxNQUFNLGdCQUFnQixHQUFHLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBRXJGLElBQUksV0FBVyxDQUFDO0FBQ2hCLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztBQUNuQixJQUFJLGdCQUFnQixHQUFHLFVBQVUsUUFBUTtJQUN2QyxJQUFJLENBQUMsV0FBVyxFQUFFO1FBQ2hCLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN4QztJQUNELFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDO0FBRUYsY0FBYyxDQUFDLE1BQU0sQ0FBQztJQUNwQixHQUFHLENBQUMsUUFBUTtRQUNWLE9BQU8sZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztJQUMvQyxDQUFDO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsSUFBSSxZQUFZLEdBQUcsQ0FBQyxRQUFhLEVBQUUsTUFBYyxFQUFFLFVBQXNCLEVBQUUsRUFBRTtJQUMzRSxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQzlCLE9BQU8sQ0FBQyxJQUFJLENBQUMsOEZBQThGO2NBQ3JHLDJGQUEyRixDQUFDLENBQUM7S0FDcEc7SUFFRCxVQUFVLENBQUMsTUFBTSxDQUFDO1FBQ2hCLFNBQVMsRUFBRSxRQUFRO1FBRW5CLE1BQU0sQ0FBQyxHQUFHLElBQUk7WUFDWixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUIsSUFBSSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3pDLE9BQU8sTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3hFO1lBRUQsSUFBSSxNQUFNLENBQUMsUUFBUSxJQUFJLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDM0QsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQzFEO1lBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDekMsQ0FBQztRQUVELGFBQWEsQ0FBQyxPQUFPO1lBQ25CLE9BQU8sT0FBTyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFFRCxVQUFVLENBQUMsT0FBTztZQUNoQixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQztRQUMzQyxDQUFDO1FBRUQsVUFBVSxDQUFDLE9BQU87WUFDaEIsT0FBTyxPQUFPLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxDQUFDLENBQUM7UUFDM0MsQ0FBQztLQUNGLENBQUMsQ0FBQztJQUVILFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFDakIsTUFBTTtZQUNKLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ2YsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNsQztZQUNELE1BQU0sSUFBSSxHQUFHLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNoQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsRUFBRTtnQkFDL0IsSUFBWSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7YUFDdkM7WUFFRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7S0FDRixDQUFDLENBQUM7SUFFSCxNQUFNLHVCQUF1QixHQUFHLEdBQUcsRUFBRTtRQUNuQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRTtZQUNkLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDckIsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNsRSxTQUFTLEdBQUcsRUFBRSxDQUFDO1lBQ2YsY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDO0lBRUYsdUJBQXVCLEVBQUUsQ0FBQztJQUUxQixnQkFBZ0IsR0FBRyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQzlELFlBQVksR0FBRyx1QkFBdUIsQ0FBQztBQUN6QyxDQUFDLENBQUM7QUFHRixNQUFNLE9BQU8sbUJBQW1CO0lBQzlCLFlBQThCLFFBQWEsRUFBRSxNQUFjLEVBQWMsVUFBc0I7UUFDN0YsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDN0MsQ0FBQzsySEFIVSxtQkFBbUIsa0JBQ1YsUUFBUTs0SEFEakIsbUJBQW1COzRIQUFuQixtQkFBbUI7OzRGQUFuQixtQkFBbUI7a0JBRC9CLFFBQVE7bUJBQUMsRUFBRTs7MEJBRUcsTUFBTTsyQkFBQyxRQUFROzswQkFBa0MsUUFBUSIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICogZGV2ZXh0cmVtZS1hbmd1bGFyXG4gKiBWZXJzaW9uOiAyNC4yLjBcbiAqIEJ1aWxkIGRhdGU6IEZyaSBBdWcgMTYgMjAyNFxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxMiAtIDIwMjQgRGV2ZWxvcGVyIEV4cHJlc3MgSW5jLiBBTEwgUklHSFRTIFJFU0VSVkVEXG4gKlxuICogVGhpcyBzb2Z0d2FyZSBtYXkgYmUgbW9kaWZpZWQgYW5kIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSB0ZXJtc1xuICogb2YgdGhlIE1JVCBsaWNlbnNlLiBTZWUgdGhlIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBvZiB0aGUgcHJvamVjdCBmb3IgZGV0YWlscy5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vRGV2RXhwcmVzcy9kZXZleHRyZW1lLWFuZ3VsYXJcbiAqL1xuXG4vKiB0c2xpbnQ6ZGlzYWJsZTptYXgtbGluZS1sZW5ndGggKi9cclxuaW1wb3J0IHtcclxuICBOZ01vZHVsZSwgSW5qZWN0LCBOZ1pvbmUsIE9wdGlvbmFsLCBWRVJTSU9OLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBET0NVTUVOVCwgWGhyRmFjdG9yeSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCBodHRwUmVxdWVzdCBmcm9tICdkZXZleHRyZW1lL2NvcmUvaHR0cF9yZXF1ZXN0JztcclxuXHJcbmltcG9ydCBkb21BZGFwdGVyIGZyb20gJ2RldmV4dHJlbWUvY29yZS9kb21fYWRhcHRlcic7XHJcbmltcG9ydCByZWFkeUNhbGxiYWNrcyBmcm9tICdkZXZleHRyZW1lL2NvcmUvdXRpbHMvcmVhZHlfY2FsbGJhY2tzJztcclxuaW1wb3J0IGV2ZW50c0VuZ2luZSBmcm9tICdkZXZleHRyZW1lL2V2ZW50cy9jb3JlL2V2ZW50c19lbmdpbmUnO1xyXG5cclxuY29uc3Qgb3V0c2lkZVpvbmVFdmVudHMgPSBbJ21vdXNlbW92ZScsICdtb3VzZW92ZXInLCAnbW91c2VvdXQnXTtcclxuY29uc3QgaW5zaWRlWm9uZUV2ZW50cyA9IFsnbW91c2V1cCcsICdjbGljaycsICdtb3VzZWRvd24nLCAndHJhbnNpdGlvbmVuZCcsICd3aGVlbCddO1xyXG5cclxubGV0IG9yaWdpbmFsQWRkO1xyXG5sZXQgY2FsbGJhY2tzID0gW107XHJcbmxldCByZWFkeUNhbGxiYWNrQWRkID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XHJcbiAgaWYgKCFvcmlnaW5hbEFkZCkge1xyXG4gICAgb3JpZ2luYWxBZGQgPSB0aGlzLmNhbGxCYXNlLmJpbmQodGhpcyk7XHJcbiAgfVxyXG4gIGNhbGxiYWNrcy5wdXNoKGNhbGxiYWNrKTtcclxufTtcclxuXHJcbnJlYWR5Q2FsbGJhY2tzLmluamVjdCh7XHJcbiAgYWRkKGNhbGxiYWNrKSB7XHJcbiAgICByZXR1cm4gcmVhZHlDYWxsYmFja0FkZC5jYWxsKHRoaXMsIGNhbGxiYWNrKTtcclxuICB9LFxyXG59KTtcclxuXHJcbmxldCBkb0luamVjdGlvbnMgPSAoZG9jdW1lbnQ6IGFueSwgbmdab25lOiBOZ1pvbmUsIHhockZhY3Rvcnk6IFhockZhY3RvcnkpID0+IHtcclxuICBpZiAoTnVtYmVyKFZFUlNJT04ubWFqb3IpIDwgMTIpIHtcclxuICAgIGNvbnNvbGUud2FybignWW91ciB2ZXJzaW9uIG9mIEFuZ3VsYXIgaXMgbm90IHN1cHBvcnRlZC4gUGxlYXNlIHVwZGF0ZSB5b3VyIHByb2plY3QgdG8gdmVyc2lvbiAxMiBvciBsYXRlci4nXHJcbiAgICAgICAgKyAnIFBsZWFzZSByZWZlciB0byB0aGUgQW5ndWxhciBVcGRhdGUgR3VpZGUgZm9yIG1vcmUgaW5mb3JtYXRpb246IGh0dHBzOi8vdXBkYXRlLmFuZ3VsYXIuaW8nKTtcclxuICB9XHJcblxyXG4gIGRvbUFkYXB0ZXIuaW5qZWN0KHtcclxuICAgIF9kb2N1bWVudDogZG9jdW1lbnQsXHJcblxyXG4gICAgbGlzdGVuKC4uLmFyZ3MpIHtcclxuICAgICAgY29uc3QgZXZlbnROYW1lID0gYXJnc1sxXTtcclxuICAgICAgaWYgKG91dHNpZGVab25lRXZlbnRzLmluY2x1ZGVzKGV2ZW50TmFtZSkpIHtcclxuICAgICAgICByZXR1cm4gbmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHRoaXMuY2FsbEJhc2UuYXBwbHkodGhpcywgYXJncykpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAobmdab25lLmlzU3RhYmxlICYmIGluc2lkZVpvbmVFdmVudHMuaW5jbHVkZXMoZXZlbnROYW1lKSkge1xyXG4gICAgICAgIHJldHVybiBuZ1pvbmUucnVuKCgpID0+IHRoaXMuY2FsbEJhc2UuYXBwbHkodGhpcywgYXJncykpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gdGhpcy5jYWxsQmFzZS5hcHBseSh0aGlzLCBhcmdzKTtcclxuICAgIH0sXHJcblxyXG4gICAgaXNFbGVtZW50Tm9kZShlbGVtZW50KSB7XHJcbiAgICAgIHJldHVybiBlbGVtZW50ICYmIGVsZW1lbnQubm9kZVR5cGUgPT09IDE7XHJcbiAgICB9LFxyXG5cclxuICAgIGlzVGV4dE5vZGUoZWxlbWVudCkge1xyXG4gICAgICByZXR1cm4gZWxlbWVudCAmJiBlbGVtZW50Lm5vZGVUeXBlID09PSAzO1xyXG4gICAgfSxcclxuXHJcbiAgICBpc0RvY3VtZW50KGVsZW1lbnQpIHtcclxuICAgICAgcmV0dXJuIGVsZW1lbnQgJiYgZWxlbWVudC5ub2RlVHlwZSA9PT0gOTtcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIGh0dHBSZXF1ZXN0LmluamVjdCh7XHJcbiAgICBnZXRYaHIoKSB7XHJcbiAgICAgIGlmICgheGhyRmFjdG9yeSkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNhbGxCYXNlLmFwcGx5KHRoaXMpO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IF94aHIgPSB4aHJGYWN0b3J5LmJ1aWxkKCk7XHJcbiAgICAgIGlmICghKCd3aXRoQ3JlZGVudGlhbHMnIGluIF94aHIpKSB7XHJcbiAgICAgICAgKF94aHIgYXMgYW55KS53aXRoQ3JlZGVudGlhbHMgPSBmYWxzZTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIF94aHI7XHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBydW5SZWFkeUNhbGxiYWNrc0luWm9uZSA9ICgpID0+IHtcclxuICAgIG5nWm9uZS5ydW4oKCkgPT4ge1xyXG4gICAgICBldmVudHNFbmdpbmUuc2V0KHt9KTtcclxuICAgICAgY2FsbGJhY2tzLmZvckVhY2goKGNhbGxiYWNrKSA9PiBvcmlnaW5hbEFkZC5jYWxsKG51bGwsIGNhbGxiYWNrKSk7XHJcbiAgICAgIGNhbGxiYWNrcyA9IFtdO1xyXG4gICAgICByZWFkeUNhbGxiYWNrcy5maXJlKCk7XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBydW5SZWFkeUNhbGxiYWNrc0luWm9uZSgpO1xyXG5cclxuICByZWFkeUNhbGxiYWNrQWRkID0gKGNhbGxiYWNrKSA9PiBuZ1pvbmUucnVuKCgpID0+IGNhbGxiYWNrKCkpO1xyXG4gIGRvSW5qZWN0aW9ucyA9IHJ1blJlYWR5Q2FsbGJhY2tzSW5ab25lO1xyXG59O1xyXG5cclxuQE5nTW9kdWxlKHt9KVxyXG5leHBvcnQgY2xhc3MgRHhJbnRlZ3JhdGlvbk1vZHVsZSB7XHJcbiAgY29uc3RydWN0b3IoQEluamVjdChET0NVTUVOVCkgZG9jdW1lbnQ6IGFueSwgbmdab25lOiBOZ1pvbmUsIEBPcHRpb25hbCgpIHhockZhY3Rvcnk6IFhockZhY3RvcnkpIHtcclxuICAgIGRvSW5qZWN0aW9ucyhkb2N1bWVudCwgbmdab25lLCB4aHJGYWN0b3J5KTtcclxuICB9XHJcbn1cclxuIl19