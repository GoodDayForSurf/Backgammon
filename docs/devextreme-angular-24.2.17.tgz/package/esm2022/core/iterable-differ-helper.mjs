/*!
 * devextreme-angular
 * Version: 24.2.0
 * Build date: Fri Aug 16 2024
 *
 * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-angular
 */
import { Injectable, IterableDiffers, } from '@angular/core';
import * as i0 from "@angular/core";
function isIterable(value) {
    return value && (typeof value[Symbol.iterator] === 'function');
}
export class IterableDifferHelper {
    _differs;
    _host;
    _propertyDiffers = {};
    constructor(_differs) {
        this._differs = _differs;
    }
    setHost(host) {
        this._host = host;
    }
    setup(prop, changes) {
        if (prop in changes) {
            const value = changes[prop].currentValue;
            this.setupSingle(prop, value);
        }
    }
    setupSingle(prop, value) {
        if (value && Array.isArray(value)) {
            if (!this._propertyDiffers[prop]) {
                try {
                    this._propertyDiffers[prop] = this._differs.find(value).create(null);
                    return true;
                }
                catch (e) { }
            }
        }
        else {
            delete this._propertyDiffers[prop];
        }
        return false;
    }
    getChanges(prop, value) {
        if (this._propertyDiffers[prop]) {
            return this._propertyDiffers[prop].diff(value);
        }
    }
    checkChangedOptions(propName, hostValue) {
        return this._host.changedOptions[propName] === hostValue;
    }
    doCheck(prop) {
        if (this._propertyDiffers[prop] && this._host.instance) {
            const hostValue = this._host[prop];
            const changes = isIterable(hostValue) && this.getChanges(prop, hostValue);
            if (changes && !this.checkChangedOptions(prop, hostValue)) {
                this._host.lockWidgetUpdate();
                this._host.instance.option(prop, hostValue);
            }
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IterableDifferHelper, deps: [{ token: i0.IterableDiffers }], target: i0.ɵɵFactoryTarget.Injectable });
    /** @nocollapse */ static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IterableDifferHelper });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IterableDifferHelper, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i0.IterableDiffers }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlcmFibGUtZGlmZmVyLWhlbHBlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2Rpc3QvY29yZS9pdGVyYWJsZS1kaWZmZXItaGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsT0FBTyxFQUNMLFVBQVUsRUFFVixlQUFlLEdBQ2hCLE1BQU0sZUFBZSxDQUFDOztBQU12QixTQUFTLFVBQVUsQ0FBQyxLQUFLO0lBQ3ZCLE9BQU8sS0FBSyxJQUFJLENBQUMsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQ2pFLENBQUM7QUFFRCxNQUFNLE9BQU8sb0JBQW9CO0lBS0Y7SUFKckIsS0FBSyxDQUFjO0lBRW5CLGdCQUFnQixHQUEwQixFQUFFLENBQUM7SUFFckQsWUFBNkIsUUFBeUI7UUFBekIsYUFBUSxHQUFSLFFBQVEsQ0FBaUI7SUFBSSxDQUFDO0lBRTNELE9BQU8sQ0FBQyxJQUFpQjtRQUN2QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztJQUNwQixDQUFDO0lBRUQsS0FBSyxDQUFDLElBQVksRUFBRSxPQUFzQjtRQUN4QyxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUU7WUFDbkIsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUMvQjtJQUNILENBQUM7SUFFRCxXQUFXLENBQUMsSUFBWSxFQUFFLEtBQVU7UUFDbEMsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNoQyxJQUFJO29CQUNGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3JFLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUc7YUFDaEI7U0FDRjthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDcEM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxVQUFVLENBQUMsSUFBWSxFQUFFLEtBQVU7UUFDakMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDL0IsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hEO0lBQ0gsQ0FBQztJQUVELG1CQUFtQixDQUFDLFFBQWdCLEVBQUUsU0FBYztRQUNsRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsQ0FBQztJQUMzRCxDQUFDO0lBRUQsT0FBTyxDQUFDLElBQVk7UUFDbEIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7WUFDdEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNuQyxNQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFFMUUsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxFQUFFO2dCQUN6RCxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7YUFDN0M7U0FDRjtJQUNILENBQUM7MkhBckRVLG9CQUFvQjsrSEFBcEIsb0JBQW9COzs0RkFBcEIsb0JBQW9CO2tCQURoQyxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiBkZXZleHRyZW1lLWFuZ3VsYXJcbiAqIFZlcnNpb246IDI0LjIuMFxuICogQnVpbGQgZGF0ZTogRnJpIEF1ZyAxNiAyMDI0XG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDEyIC0gMjAyNCBEZXZlbG9wZXIgRXhwcmVzcyBJbmMuIEFMTCBSSUdIVFMgUkVTRVJWRURcbiAqXG4gKiBUaGlzIHNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCBhbmQgZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIHRlcm1zXG4gKiBvZiB0aGUgTUlUIGxpY2Vuc2UuIFNlZSB0aGUgTElDRU5TRSBmaWxlIGluIHRoZSByb290IG9mIHRoZSBwcm9qZWN0IGZvciBkZXRhaWxzLlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZXZFeHByZXNzL2RldmV4dHJlbWUtYW5ndWxhclxuICovXG5cbmltcG9ydCB7XHJcbiAgSW5qZWN0YWJsZSxcclxuICBTaW1wbGVDaGFuZ2VzLFxyXG4gIEl0ZXJhYmxlRGlmZmVycyxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7XHJcbiAgRHhDb21wb25lbnQsXHJcbn0gZnJvbSAnLi9jb21wb25lbnQnO1xyXG5cclxuZnVuY3Rpb24gaXNJdGVyYWJsZSh2YWx1ZSkge1xyXG4gIHJldHVybiB2YWx1ZSAmJiAodHlwZW9mIHZhbHVlW1N5bWJvbC5pdGVyYXRvcl0gPT09ICdmdW5jdGlvbicpO1xyXG59XHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEl0ZXJhYmxlRGlmZmVySGVscGVyIHtcclxuICBwcml2YXRlIF9ob3N0OiBEeENvbXBvbmVudDtcclxuXHJcbiAgcHJpdmF0ZSBfcHJvcGVydHlEaWZmZXJzOiB7IFtpZDogc3RyaW5nXTogYW55IH0gPSB7fTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBfZGlmZmVyczogSXRlcmFibGVEaWZmZXJzKSB7IH1cclxuXHJcbiAgc2V0SG9zdChob3N0OiBEeENvbXBvbmVudCkge1xyXG4gICAgdGhpcy5faG9zdCA9IGhvc3Q7XHJcbiAgfVxyXG5cclxuICBzZXR1cChwcm9wOiBzdHJpbmcsIGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuICAgIGlmIChwcm9wIGluIGNoYW5nZXMpIHtcclxuICAgICAgY29uc3QgdmFsdWUgPSBjaGFuZ2VzW3Byb3BdLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgdGhpcy5zZXR1cFNpbmdsZShwcm9wLCB2YWx1ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzZXR1cFNpbmdsZShwcm9wOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcclxuICAgIGlmICh2YWx1ZSAmJiBBcnJheS5pc0FycmF5KHZhbHVlKSkge1xyXG4gICAgICBpZiAoIXRoaXMuX3Byb3BlcnR5RGlmZmVyc1twcm9wXSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICB0aGlzLl9wcm9wZXJ0eURpZmZlcnNbcHJvcF0gPSB0aGlzLl9kaWZmZXJzLmZpbmQodmFsdWUpLmNyZWF0ZShudWxsKTtcclxuICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgfVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkZWxldGUgdGhpcy5fcHJvcGVydHlEaWZmZXJzW3Byb3BdO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcblxyXG4gIGdldENoYW5nZXMocHJvcDogc3RyaW5nLCB2YWx1ZTogYW55KSB7XHJcbiAgICBpZiAodGhpcy5fcHJvcGVydHlEaWZmZXJzW3Byb3BdKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLl9wcm9wZXJ0eURpZmZlcnNbcHJvcF0uZGlmZih2YWx1ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjaGVja0NoYW5nZWRPcHRpb25zKHByb3BOYW1lOiBzdHJpbmcsIGhvc3RWYWx1ZTogYW55KSB7XHJcbiAgICByZXR1cm4gdGhpcy5faG9zdC5jaGFuZ2VkT3B0aW9uc1twcm9wTmFtZV0gPT09IGhvc3RWYWx1ZTtcclxuICB9XHJcblxyXG4gIGRvQ2hlY2socHJvcDogc3RyaW5nKSB7XHJcbiAgICBpZiAodGhpcy5fcHJvcGVydHlEaWZmZXJzW3Byb3BdICYmIHRoaXMuX2hvc3QuaW5zdGFuY2UpIHtcclxuICAgICAgY29uc3QgaG9zdFZhbHVlID0gdGhpcy5faG9zdFtwcm9wXTtcclxuICAgICAgY29uc3QgY2hhbmdlcyA9IGlzSXRlcmFibGUoaG9zdFZhbHVlKSAmJiB0aGlzLmdldENoYW5nZXMocHJvcCwgaG9zdFZhbHVlKTtcclxuXHJcbiAgICAgIGlmIChjaGFuZ2VzICYmICF0aGlzLmNoZWNrQ2hhbmdlZE9wdGlvbnMocHJvcCwgaG9zdFZhbHVlKSkge1xyXG4gICAgICAgIHRoaXMuX2hvc3QubG9ja1dpZGdldFVwZGF0ZSgpO1xyXG4gICAgICAgIHRoaXMuX2hvc3QuaW5zdGFuY2Uub3B0aW9uKHByb3AsIGhvc3RWYWx1ZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19